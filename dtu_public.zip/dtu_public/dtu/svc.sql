col name for a20
col network_name for a15
col failover_method for a15
col failover_type for a13
col failover_retries for a15
col failover_delay for a14
col blocked for a7
select
v.name
,v.network_name
,v.blocked
--,v.con_name
,t.failover_method
,t.failover_type
,t.failover_delay
,t.failover_retries
from v$active_services v, all_services t
where v.service_id = t.service_id(+)
and lower(v.name) like lower('&1')
order by v.name
/


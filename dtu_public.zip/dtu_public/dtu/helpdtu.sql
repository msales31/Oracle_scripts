-- Licensed under the Apache License, Version 2.0. See LICENSE.txt for terms &
-- conditions.

--------------------------------------------------------------------------------
--
-- File name:   helpdtu.sql
-- Purpose:     Help
-- Author:      Rogê Gonçalves based on help tpt of TanelPoder
-- Usage:       @help <string>
-- Version:     1.6
--------------------------------------------------------------------------------
--ACCEPT search_string CHAR PROMPT "Search: [%] "


DEFINE amp=chr(38)
DEFINE nl=chr(10)
DEFINE search_string=&1


COLUMN name FORMAT A25 TRUNC
COLUMN description FORMAT A60 WORD_WRAP
COLUMN usage FORMAT A110


WITH q AS (
SELECT name, description, usage
FROM (
  SELECT '46on.sql' AS name, 'Enable trace 10046 on current session' AS description, '@46on' AS usage FROM dual UNION ALL
  SELECT '46off.sql' AS name, 'Disable trace 10046 on current session' AS description, '@46off' AS usage FROM dual UNION ALL
  SELECT '53on.sql' AS name, 'Enable trace 10053 (optimizer) on current session' AS description, '@53on'||&nl||'@53on 1' AS usage FROM dual UNION ALL
  SELECT '53off.sql' AS name, 'Disable trace 10053 on current session' AS description, '@53off' AS usage FROM dual UNION ALL
  SELECT 'a.sql' AS name, 'Display current active sessions' AS description, '@a' AS usage FROM dual UNION ALL
  SELECT 'appinfo.sql' AS name, 'Display app info from a session' AS description, '@appinfo <sid>'||&nl||'@appinfo 123,234'||&nl||'@appinfo "select sid from v$session"' AS usage FROM dual UNION ALL
  SELECT 'apps.sql' AS name, 'DTU - Display applications created on app root' AS description, '@apps' AS usage FROM dual UNION ALL
  SELECT 'aps.sql' AS name, 'DTU - Display applications pdbs status' AS description, '@aps' AS usage FROM dual UNION ALL 
  SELECT 'asql.sql' AS name, 'Display active sessions current SQLs' AS description, '@asql' AS usage FROM dual UNION ALL
  SELECT 'ash_wait_chains.sql' AS name, 'Display ASH wait chains (multi-session wait signature, a session waiting for another session etc.)' AS description, '@ash/ash_wait_chains <grouping_cols> <filters> <from_time> <to_time>'||&nl||'@ash/ash_wait_chains username||''-''||program2 "wait_class=''Application''" sysdate-1/24 sysdate' AS usage FROM dual UNION ALL
  SELECT 'ashtop.sql' AS name, 'Display ash active sess history analisys based on filters' AS description, '@ashtop <grouping_cols> <filters> <from_time> <to_time>'||&nl||'@ashtop event2 1=1 5min'||&nl||'@ashtop event2,sql_opname,objt,sql_plan_operation,sql_plan_options 1=1 hour'||&nl||'@ashtop event2,blocking_session_status,blocking_session "event like ''enq:%''" 5min'||&nl||'@ashtop event2 1=1 "TIMESTAMP''2018-02-16 15:12:07''" "TIMESTAMP''2018-02-16 15:16:07''"' AS usage FROM dual UNION ALL
  SELECT 'asqlmon.sql' AS name, 'Report SQL-monitoring-style drill-down into where in an execution plan the execution time is spent (ASH based)' AS description, '@ash/asqlmon <sql_id> <child#> <from_time> <to_time>'||&nl||'@ash/asqlmon 7q729nhdgtsqq 0 sysdate-1/24 sysdate'||&nl||'@ash/asqlmon 7q729nhdgtsqq % sysdate-1 sysdate' AS usage FROM dual UNION ALL
  SELECT 'asmls.sql' AS name, 'Display disks from a diskgroup ASM' AS description, '@asmls <diskgroup>' AS usage FROM dual UNION ALL
  SELECT 'asmdg.sql' AS name, 'Display diskgroups ASM' AS description, '@asmdg' AS usage FROM dual UNION ALL
  SELECT 'aw.sql' AS name, 'Display last minute database activity' AS description, '@aw <filter_expression>'||&nl||'@aw 1=1' AS usage FROM dual UNION ALL
  SELECT 'awr_sqlid.sql' AS name, 'Display SQL text from AWR' AS description, '@awr/awr_sqlid <sql_id>'||&nl||'@awr/awr_sqlid 7q729nhdgtsqq' AS usage FROM dual UNION ALL
  SELECT 'awr_sqlstats.sql' AS name, 'Display SQL statistics from AWR' AS description, '@awr/awr_sqlstats <sql_id> <plan_hash_value> <from_time> <to_time>'||&nl||'@awr/awr_sqlstats 0sh0fn7r21020 1541789278 sysdate-7 sysdate'||&nl||'@awr/awr_sqlstats 0sh0fn7r21020 % sysdate-7 sysdate' AS usage FROM dual UNION ALL
  SELECT 'awr_sqlstats_per_exec.sql' AS name, 'Display SQL statistics per execution from AWR' AS description, '@awr/awr_sqlstats_per_exec <sql_id> <plan_hash_value> <from_time> <to_time>'||&nl||'@awr/awr_sqlstats_per_exec 0sh0fn7r21020 1541789278 sysdate-7 sysdate'||&nl||'@awr/awr_sqlstats_per_exec 0sh0fn7r21020 % sysdate-7 sysdate' AS usage FROM dual UNION ALL
  SELECT 'awr_sqlstats_unstable.sql' AS name, 'Display unstable SQL execution plans from AWR' AS description, '@awr/awr_sqlstats_unstable <sql_id> <plan_hash_value> <from_time> <to_time>'||&nl||'@awr/awr_sqlstats_unstable 0sh0fn7r21020 % sysdate-7 sysdate' AS usage FROM dual UNION ALL
  SELECT 'bclass.sql' AS name, 'Display class of a block' AS description, '@bclass <block_class#>' AS usage FROM dual UNION ALL
  SELECT 'bg.sql' AS name, 'Display background processes' AS description, '@bg <process_name|process_description>'||&nl||'@bg dbw'||&nl||'@bg writer'||&nl||'@bg %' AS usage FROM dual UNION ALL
  SELECT 'bhobjects.sql' AS name, 'Display top objects in buffer cache' AS description, '@bhobjects' AS usage FROM dual UNION ALL
  SELECT 'bhobjects2.sql' AS name, 'Display buffer cache statistics' AS description, '@bhobjects2' AS usage FROM dual UNION ALL
  SELECT 'bhla.sql' AS name, 'Report which blocks are in buffer cache, protected by a cache buffers chains child latch' AS description, '@bhla <child latch address>'||&nl||'@bhla 27E5A780' AS usage FROM dual UNION ALL
  SELECT 'bufprof.sql' AS name, 'Display buffer gets done by a session and their reason' AS description, '@bufprof <SID> <#samples>'||&nl||'@bufprof 142 1000' AS usage FROM dual UNION ALL
  SELECT 'calc.sql' AS name, 'Basic calculator and dec/hex converter' AS description, '@calc <num1> <operation> <num2>'||&nl||'@calc 10 + 0x10'||&nl||'@calc 0xFFFF - 0x5F'||&nl||'@calc xBB * 1234' AS usage FROM dual UNION ALL
  SELECT 'cancel.sql' AS name, 'Generate commands for canceling selected SQL' AS description, '@cancel <filter_expression>'||&nl||'@cancel sid=150'||&nl||'@cancel username=''SYSTEM'''||&nl||'@cancel "username=''APP'' and program like ''sqlplus%''"' AS usage FROM dual UNION ALL
  SELECT 'cc.sql' AS name, 'Set current container' AS description, '@cc <container_name>' AS usage FROM dual UNION ALL
  SELECT 'cdbdirs.sql' AS name, 'DTU - Display cdb database directories' AS description, '@cdbdirs' AS usage FROM dual UNION ALL
  SELECT 'cellver.sql' AS name, 'Report Exadata cell details from V$CELL_CONFIG' AS description, '@exadata/cellver' AS usage FROM dual UNION ALL
  SELECT 'ccr.sql' AS name, 'Set current container to CDB$ROOT' AS description, '@ccr' AS usage FROM dual UNION ALL
  SELECT 'ci.sql' AS name, 'Set Session Identifier' AS description, '@ci <client_name>' AS usage FROM dual UNION ALL
  SELECT 'cid.sql' AS name, 'Set Session Identifier' AS description, '@cid <client_name>' AS usage FROM dual UNION ALL
  SELECT 'cofef.sql' AS name, 'Compare Optimizer Features Enable Fix values' AS description, '@cofef' AS usage FROM dual UNION ALL
  SELECT 'cofef_missing.sql' AS name, 'Compare Optimizer Features Enable Fix values - find fixes that are not affected by optimizer_features_enable setting' AS description, '@cofef_missing' AS usage FROM dual UNION ALL
  SELECT 'cofep.sql' AS name, 'Compare Optimizer Features Enable Parameter values' AS description, '@cofep' AS usage FROM dual UNION ALL
  SELECT 'col.sql' AS name, 'Display column' AS description, '@col <column_name>'||&nl||'@col open_mode' AS usage FROM dual UNION ALL
  SELECT 'colusage.sql' AS name, 'Display column usage' AS description, '@colusage [<owner>.]<table_name>'||&nl||'@colusage soe.orders'||&nl||'@colusage soe.%' AS usage FROM dual UNION ALL
  SELECT 'cons.sql' AS name, 'Display constraints on table' AS description, '@cons [<owner>.]<table_name>'||&nl||'@cons soe.orders'||&nl||'@colusage soe.%' AS usage FROM dual UNION ALL
  SELECT 'cnt.sql' AS name, 'Select count rows in a table' AS description, '@cnt <table_name>'||&nl||'@cnt "soe.orders where id in (1)"' AS usage FROM dual UNION ALL
  SELECT 'cnta.sql' AS name, 'Select count rows in a table with where clause' AS description, '@cnta <table_name> <condition>'||&nl||'@cnta soe.orders id=1' AS usage FROM dual UNION ALL
  SELECT 'cntg.sql' AS name, 'Select count rows in a table with group by' AS description, '@cnta <table_name> <group_coluns>'||&nl||'@cntg soe.orders id' AS usage FROM dual UNION ALL
  SELECT 'create_sql_baseline.sql' AS name, 'Create SQL Plan Baseline from an existing "good" cursor' AS description, '@create_sql_baseline <good_sqlid> <good_plan_hash_value> <to_bad_sqlid>'||&nl||'@create_sql_baseline g5tuxh82pk3qf 2966233522 d7khnbh6c9qas' AS usage FROM dual UNION ALL
  SELECT 'create_sql_patch.sql' AS name, 'Create SQL patch' AS description, '@create_sql_patch <sql_id> <hint>'||&nl||'@create_sql_patch g4pkmrqrgxg3b GATHER_PLAN_STATISTICS'||&nl||q'[@create_sql_patch b9dmj0ahu6xgc 'NO_INDEX_SS(@"SEL$26CA4453" "STORE_SALES"@"SEL$1")']' AS usage FROM dual UNION ALL
  SELECT 'curlog.sql' AS name, 'Display current redo logfile' AS description, '@curlog' AS usage FROM dual UNION ALL
  SELECT 'cs.sql' AS name, 'Set current schema' AS description, '@cs <username>' AS usage FROM dual UNION ALL
  SELECT 'csv.sql' AS name, 'Generate the result content in csv format and try to open it' AS description, '@csv' AS usage FROM dual UNION ALL
  SELECT 'd.sql' AS name, 'Display data dictionary views and x$ tables' AS description, '@d <object_name>'||&nl||'@d sql'||&nl||'@d %' AS usage FROM dual UNION ALL
  SELECT 'dashtop.sql' AS name, 'Display ash dba hist active sess history based on filters' AS description, '@ash/dashtop <grouping_cols> <filters> <from_time> <to_time>'||&nl||'@ash/dashtop event2 1=1 sysdate-1 sysdate'||&nl||'@ash/dashtop event2,blocking_session_status,blocking_session "event like ''enq:%''" 5min'||&nl||'@ash/dashtop event2 1=1 "TIMESTAMP''2018-02-16 15:12:07''" "TIMESTAMP''2018-02-16 15:16:07''"' AS usage FROM dual UNION ALL
  SELECT 'dash_wait_chains.sql' AS name, 'Display ASH (based on DBA_HIST) wait chains (multi-session wait signature, a session waiting for another session etc.)' AS description, '@ash/dash_wait_chains <grouping_cols> <filters> <from_time> <to_time>'||&nl||'@ash/dash_wait_chains username||''-''||program2 "wait_class=''Application''" sysdate-1/24 sysdate' AS usage FROM dual UNION ALL
  SELECT 'dasqlmon.sql' AS name, 'Report SQL-monitoring-style drill-down into where in an execution plan the execution time is spent (AWR based)' AS description, '@ash/dasqlmon <sqlid> <plan_hash_value> <from_time> <to_time>'||&nl||'@ash/dasqlmon 7q729nhdgtsqq 0 "timestamp''2019-10-07 07:00:00''" "timestamp''2019-10-07 07:00:00''"'||&nl||'@ash/dasqlmon 7q729nhdgtsqq % sysdate-1 sysdate' AS usage FROM dual UNION ALL
  SELECT 'date.sql' AS name, 'Display current date in Timestamp Format' AS description, '@date'||&nl||'@d sql'||&nl||'@d %' AS usage FROM dual UNION ALL
  SELECT 'date2unix.sql' AS name, 'Convert date to unix format' AS description, '@datetounix <date>'||&nl||'@date sysdate' AS usage FROM dual UNION ALL
  SELECT 'db.sql' AS name, 'Display database information' AS description, '@db' AS usage FROM dual UNION ALL
  SELECT 'dba.sql' AS name, 'Convert Data Block Address (a 6 byte hex number) to file#, block# and find to which segment it belongs' AS description, '@dba <data_block_address>'||&nl||'@dba 40EB02' AS usage FROM dual UNION ALL
  SELECT 'dba2.sql' AS name, 'Display information about a block' AS description, '@dba2 <file#> <block_id>' AS usage FROM dual UNION ALL
  SELECT 'dblinks.sql' AS name, 'Display db links' AS description, '@dblinks' AS usage FROM dual UNION ALL
  SELECT 'dc.sql' AS name, 'Display dictionary information from column' AS description, '@dc <column_name>'||&nl||'@dc con_id' AS usage FROM dual UNION ALL
  SELECT 'ddl.sql' AS name, 'Extracts DDL statements for specified objects' AS description, '@ddl [<owner>.]<object_name>'||&nl||'@ddl sys.dba_users'||&nl||'@ddl sys.%tab%' AS usage FROM dual UNION ALL
  SELECT 'desc.sql' AS name, 'Describe object' AS description, '@desc <object_name>'||&nl||'@desc dba_tables' AS usage FROM dual UNION ALL
  SELECT 'descx.sql' AS name, 'Describe histogram from a object ' AS description, '@descx [<owner>.]<object_name>' AS usage FROM dual UNION ALL
  SELECT 'descx2.sql' AS name, 'Describe histogram from a object ' AS description, '@descx2 [<owner>.]<object_name>' AS usage FROM dual UNION ALL
  SELECT 'descxx.sql' AS name, 'Describe histogram enhanced from a object ' AS description, '@descxx [<owner>.]<object_name>' AS usage FROM dual UNION ALL
  SELECT 'descxx2.sql' AS name, 'Describe histogram enhanced from a object ' AS description, '@descxx2 [<owner>.]<object_name>' AS usage FROM dual UNION ALL
  SELECT 'devent_hist.sql' AS name, 'Display a histogram of the number of waits from AWR (milliseconds)' AS description, '@ash/devent_hist.sql <event> <filter_expression> <from_time> <to_time>'||&nl||'@ash/devent_hist.sql log_file 1=1 sysdate-1/24 sysdate'||&nl||'@ash/devent_hist.sql log.file|db.file "wait_class=''User I/O'' AND session_type=''FOREGROUND''" sysdate-1/24 sysdate' AS usage FROM dual UNION ALL
  SELECT 'df.sql' AS name, 'Display tablespace usage (GB)' AS description, '@df' AS usage FROM dual UNION ALL
  SELECT 'dfm.sql' AS name, 'Display tablespace usage (MB)' AS description, '@dfm' AS usage FROM dual UNION ALL
  SELECT 'dg.sql' AS name, 'Display database role plus some dataguard information' AS description, '@dg' AS usage FROM dual UNION ALL
  SELECT 'dist.sql' AS name, 'Display distinct column from table' AS description, '@dist <column> <table_name>' AS usage FROM dual UNION ALL
  SELECT 'diag.sql' AS name, 'Display diag info directories' AS description, '@dirs' AS usage FROM dual UNION ALL
  SELECT 'diag_sid.sql' AS name, 'Display informations das wais do sid plus snapper' AS description, '@diag_sid <sid>' AS usage FROM dual UNION ALL
  SELECT 'dirs.sql' AS name, 'Display database directories' AS description, '@dirs' AS usage FROM dual UNION ALL
  SELECT 'disco.sql' AS name, 'Generates commands for disconnecting selected sessions' AS description, '@disco <filter expression>'||&nl||'@disco sid=150'||&nl||'@disco username=''SYSTEM'''||&nl||'@disco "username=''APP'' and program like ''sqlplus%''"' AS usage FROM dual UNION ALL
  SELECT 'doid.sql' AS name, 'Display object on a particular segment based on dictionary object number' AS description, '@doid <data_object_id>' AS usage FROM dual UNION ALL
  SELECT 'drop_sql_patch.sql' AS name, 'Drop SQL patch' AS description, '@drop_sql_patch <patch_name>'||&nl||'@drop_sql_patch SQL_PATCH_g4pkmrqrgxg3b' AS usage FROM dual UNION ALL
  SELECT 'drop_sql_baseline.sql' AS name, 'Drop SQL Plan Baseline' AS description, '@drop_sql_baseline <sql_handle>   (get sql_handle from DBMS_XPLAN notes or DBA_SQL_PLAN_BASELINES)'||&nl||'@drop_sql_baseline SQL_52cb74b7097edbbd' AS usage FROM dual UNION ALL
  SELECT 'du.sql' AS name, 'Display Size per Schema' AS description, '@du %' ||&nl||'@du <schema_name>' AS usage FROM dual UNION ALL
  SELECT 'dump.sql' AS name, 'Dump a block of a file and specifies regexp' AS description, '@dump <file#> <block#> <what regexp>' AS usage FROM dual UNION ALL
  SELECT 'el.sql' AS name, 'Edit actual spool file in use' AS description, '@el' AS usage FROM dual UNION ALL
  SELECT 'ep.sql' AS name, 'Explain plan for' AS description, '@ep' AS usage FROM dual UNION ALL
  SELECT 'ev.sql' AS name, 'Set session event' AS description, '@ev <event> <level>'||&nl||'@ev 10046 12' AS usage FROM dual UNION ALL
  SELECT 'event_hist.sql' AS name, 'Display a histogram of the number of waits from ASH (milliseconds)' AS description, '@ash/event_hist.sql <event> <filter_expression> <from_time> <to_time>'||&nl||'@ash/event_hist.sql log.file 1=1 sysdate-1/24 sysdate'||&nl||'@ash/event_hist.sql log.file|db.file "wait_class=''User I/O'' AND session_type=''FOREGROUND''" sysdate-1/24 sysdate' AS usage FROM dual UNION ALL
  SELECT 'event_hist_micro.sql' AS name, 'Display a histogram of the number of waits from ASH (microseconds)' AS description, '@ash/event_hist_micro <event> <filter_expression> <from_time> <to_time>'||&nl||'@ash/event_hist_micro log.file 1=1 sysdate-1/24 sysdate'||&nl||'@ash/event_hist_micro log.file|db.file "wait_class=''User I/O'' AND session_type=''FOREGROUND''" sysdate-1/24 sysdate' AS usage FROM dual UNION ALL
  SELECT 'evh.sql' AS name, 'Display a histogram of the number of waits' AS description, '@evh <event>'||&nl||'@evh log.file'||&nl||'@evh log.file|db.file' AS usage FROM dual UNION ALL
  SELECT 'evo.sql' AS name, 'Disable session event' AS description, '@evo <event>'||&nl||'@evo 10046' AS usage FROM dual UNION ALL
  SELECT 'es.sql' AS name, 'Edit script using vim' AS description, '@es file_name' AS usage FROM dual UNION ALL
  SELECT 'et.sql' AS name, 'Edit tracefile from the current session' AS description, '@et' AS usage FROM dual UNION ALL
  SELECT 'fcha.sql' AS name, 'Find in which heap (UGA, PGA or Shared Pool) the memory address 1 resides' AS description, '@fcha <addr_hex>'||&nl||'@fcha F6A14448' AS usage FROM dual UNION ALL
  SELECT 'fix.sql' AS name, 'Display session fix controls' AS description, '@fix <bugno|description|optimizer_feature_enable|sql_feature>'||&nl||'@fix 13836796'||&nl||'@fix adaptive' AS usage FROM dual UNION ALL
  SELECT 'fra.sql' AS name, 'DTU - Display Recovery Area information' AS description, '@fra' AS usage FROM dual UNION ALL
  SELECT 'fusage.sql' AS name, 'Display feature usage internal' AS description, '@fusage' AS usage FROM dual UNION ALL
  SELECT 'getprev.sql' AS name, 'Get previously executed SQL ID, child number and other details into sqlplus variables for further us' AS description, '@getprev' AS usage FROM dual UNION ALL
  SELECT 'gettracename.sql' AS name, 'Get currently trace name file' AS description, '@gettracename' AS usage FROM dual UNION ALL
  SELECT 'grp.sql' AS name, 'Group function wrapper' AS description, '@grp <column_name> <table_name>'||&nl||'@grp owner dba_tables'||&nl||'@grp owner,object_type dba_objects' AS usage FROM dual UNION ALL
  SELECT 'grpn.sql' AS name, 'Quick group by query for aggregating Numeric columns - Calculate sum,min,max,avg,count for simple expressions' AS description, '@grpn <agg_col> <from_table> <filter_cond> <group_by_cols>'||&nl||'@grpn bytes dba_segments tablespace_name=''SYSTEM'' owner,segment_type' AS usage FROM dual UNION ALL
  SELECT 'grpo.sql' AS name, 'Quick group by with count (*)' AS description, '@grpo <column_name> <table_name>'||&nl||'@grpo id soe.users' AS usage FROM dual UNION ALL
  SELECT 'gss.sql' AS name, 'Gather schema stats size repeat for histogram' AS description, '@gss <schema_name>' AS usage FROM dual UNION ALL
  SELECT 'gts.sql' AS name, 'Gather table stats size repeat for histogram on current schema' AS description, '@gts <table_name>' AS usage FROM dual UNION ALL
  SELECT 'gtsa.sql' AS name, 'Gather table stats size with histogram 254 buckets on current_schema' AS description, '@gtsa <table_name>' AS usage FROM dual UNION ALL
  SELECT 'help.sql' AS name, 'Display TPT script help' AS description, '@help <search_expression>'||&nl||'@help explain'||&nl||'@help lock|latch.*hold'||&nl||'@help ^ind.*sql|^tab.*sql' AS usage FROM dual UNION ALL
  SELECT 'hash.sql' AS name, 'Display the hash value, sql_id, and child number of the last SQL in session' AS description, '@hash' AS usage FROM dual UNION ALL
  SELECT 'hhist.sql' AS name, 'DTU - Display Historical Column Histogram - Param: table,owner,column' AS description, '@hhist' AS usage FROM dual UNION ALL
  SELECT 'hint.sql' AS name, 'Display all available hints' AS description, '@hint <name>'||&nl||'@hint full' AS usage FROM dual UNION ALL
  SELECT 'hintclass.sql' AS name, 'Display all available hints with hint class info' AS description, '@hintclass <hint_name>'||&nl||'@hintclass merge' AS usage FROM dual UNION ALL
  SELECT 'hintfeature.sql' AS name, 'Display all available hints with SQL feature info' AS description, '@hintfeature <feature_name>'||&nl||'@hintfeature transformation' AS usage FROM dual UNION ALL
  SELECT 'hinth.sql' AS name, 'Display hint hierarchy' AS description, '@hinth <hint_name>'||&nl||'@hinth merge' AS usage FROM dual UNION ALL
  SELECT 'hon.sql' AS name, 'Set html spool on' AS description, '@hon' AS usage FROM dual UNION ALL
  SELECT 'hoff.sql' AS name, 'Set html spool off' AS description, '@hoff' AS usage FROM dual UNION ALL
  SELECT 'html.sql' AS name, 'Generate the result in html format' AS description, '@html' AS usage FROM dual UNION ALL
  SELECT 'htmlon.sql' AS name, 'Set html spool format on' AS description, '@htmlon' AS usage FROM dual UNION ALL
  SELECT 'htmloff.sql' AS name, 'Set html spool format off' AS description, '@htmloff' AS usage FROM dual UNION ALL
  SELECT 'htmlrun.sql' AS name, 'Generate the result of the query in html format' AS description, '@htmlrun <query>'||&nl||'@htmlrun "select * from v$session"' AS usage FROM dual UNION ALL
  SELECT 'i.sql' AS name, 'Display information referenced who i am' AS description, '@i' AS usage FROM dual UNION ALL
  SELECT 'i2h.sql' AS name, 'Converts sql_id to hash_value' AS description, '@i2h <sql_id>' AS usage FROM dual UNION ALL
  SELECT 'ii.sql' AS name, 'Display more program information about my session' AS description, '@ii' AS usage FROM dual UNION ALL
  SELECT 'ima.sql' AS name, 'Display inmemory area' AS description, '@ima' AS usage FROM dual UNION ALL
  SELECT 'imseg.sql' AS name, 'Display inmemory segments' AS description, '@imseg' AS usage FROM dual UNION ALL
  SELECT 'init.sql' AS name, 'Load session configuration referente ao login' AS description, '@login' AS usage FROM dual UNION ALL
  SELECT 'ind.sql' AS name, 'Display indexes' AS description, '@ind [<owner>.]<index_name|table_name>'||&nl||'@ind orders'||&nl||'@ind soe.ord_customer_ix'||&nl||'@ind soe.%' AS usage FROM dual UNION ALL
  SELECT 'indf.sql' AS name, 'Display function-based index expressions' AS description, '@indf [<owner>.]<index_name|table_name>'||&nl||'@indf orders'||&nl||'@indf soe.ord_customer_ix'||&nl||'@indf soe.%' AS usage FROM dual UNION ALL
  SELECT 'inv.sql' AS name, 'Display invalid objects, indexes, index partitions and index subpartitions' AS description, '@inv' AS usage FROM dual UNION ALL
  SELECT 'jobdisable.sql' AS name, 'Display a command to disable a scheduler job' AS description, '@jobdisable' AS usage FROM dual UNION ALL
  SELECT 'jobs.sql' AS name, 'Display all jobs' AS description, '@jobs' AS usage FROM dual UNION ALL
  SELECT 'jobsr.sql' AS name, 'Display all jobs running' AS description, '@jobsr' AS usage FROM dual UNION ALL
  SELECT 'kill.sql' AS name, 'Generate command to for killing user session' AS description, '@kill <filter_expression>'||&nl||'@kill sid=284'||&nl||'@kill username=''SYSTEM'''||&nl||'@kill "username=''APP'' AND program LIKE ''sqlplus%''"' AS usage FROM dual UNION ALL
  SELECT 'ktuxe.sql' AS name, 'Display transactions in rollback' AS description, '@ktuxe' AS usage FROM dual UNION ALL
  SELECT 'l.sql' AS name, 'Display Latch Stats from v$latch for latchs matching string' AS description, '@l <string>'||&nl||'@l real' AS usage FROM dual UNION ALL
  SELECT 'la.sql' AS name, 'Display which latch occupies a given memory address and its stats' AS description, '@la <address_in_hex>'||&nl||'@la 50BE2178' AS usage FROM dual UNION ALL
  SELECT 'lastchanged.sql' AS name, 'Detect when a datablock in table was last changed' AS description, '@lastchanged <table_name> <filter_conditions>'||&nl||'@lastchanged emp empno=100' AS usage FROM dual UNION ALL
  SELECT 'latchprof.sql' AS name, 'Profile top latch holders (V$ version)' AS description, '@latchprof <grouping_columns> <sid> <latch_name> <samples>'||&nl||'@latchprof name,sqlid 123 % 10000'||&nl||'@latchprof sid,name,sqlid % "shared pool" 10000' AS usage FROM dual UNION ALL
  SELECT 'latchprofx.sql' AS name, 'Profile top latch holders eXtended (X$ version)' AS description, '@latchprofx <grouping_columns> <sid> <latch_name> <samples>'||&nl||'@latchprofx sid,name 123 % 10000'||&nl||'@latchprofx sid,name,timemodel,hmode,func % "shared pool" 10000' AS usage FROM dual UNION ALL
  SELECT 'lc.sql' AS name, 'Display Latch Children stats from V$LATCH for latches matching %1%' AS description, '@lc <latch_name>' AS usage FROM dual UNION ALL
  SELECT 'ldprof.sql' AS name, 'DTU - Display Lockdown profiles' AS description, '@ldprof' AS usage FROM dual UNION ALL
  SELECT 'lock.sql' AS name, 'Display current locks' AS description, '@lock <filter_expression>'||&nl||'@lock 1=1'||&nl||'@lock type=''TM''' AS usage FROM dual UNION ALL
  SELECT 'lock2.sql' AS name, 'DTU - Display lock in chain/tree format' AS description, '@lock2' AS usage FROM dual UNION ALL
  SELECT 'log.sql' AS name, 'Display redo log layout' AS description, '@log' AS usage FROM dual UNION ALL
  SELECT 'long.sql' AS name, 'Display session long operations' AS description, '@long <filter_expression>'||&nl||'@long 1=1'||&nl||'@long username=''SOE''' AS usage FROM dual UNION ALL
  SELECT 'ls.sql' AS name, 'Display tablespace' AS description, '@ls <tablespace_name>'||&nl||'@ls system'||&nl||'@ls %' AS usage FROM dual UNION ALL
  SELECT 'lscpu.sql' AS name, 'Display cpu count' AS description, '@lscpu' AS usage FROM dual UNION ALL
  SELECT 'lt.sql' AS name, 'Display lock type info' AS description, '@lt <lock_name>'||&nl||'@lt TM' AS usage FROM dual UNION ALL
  SELECT 'm.sql' AS name, 'Display session events from my session' AS description, '@m' AS usage FROM dual UNION ALL
  SELECT 'measure_io.sql' AS name, 'Measure IO reasons and "sizes" from v$iostat_function_detail' AS description, '@measuire_io "SELECT your query here"' AS usage FROM dual UNION ALL
  SELECT 'mem.sql' AS name, 'Display information about the dynamic SGA components' AS description, '@mem' AS usage FROM dual UNION ALL
  SELECT 'memres.sql' AS name, 'Display information about the last completed memory resize operations' AS description, '@memres' AS usage FROM dual UNION ALL
  SELECT 'minelog.sql' AS name, 'Execute logmining de um redo' AS description, '@minelog <redo_path|archivelog_path>' AS usage FROM dual UNION ALL
  SELECT 'minmax.sql' AS name, 'Display min max value of a columns in a table' AS description, '@minmax <column_name> <table_name>' AS usage FROM dual UNION ALL
  SELECT 'mystats.sql' AS name, 'DTU - Display mystats info Latch|Statistic|Time Model - +info on file' AS description, '@mystats start'||&nl||'<do some work>'||&nl||'@mystats stop' AS usage FROM dual UNION ALL
  SELECT 'nls.sql' AS name, 'Display nls parameter from current session', '@nls' AS usage FROM dual UNION ALL
  SELECT 'nonshared.sql' AS name, 'Display reasons for non-shared child cursors from v$shared_cursor', '@nonshared <sql_id>'||&nl||'@nonshared 7q729nhdgtsqq' AS usage FROM dual UNION ALL
  SELECT 'o.sql' AS name, 'Display database object based on object owner and name', '@o [<owner>.]<object_name>'||&nl||'@o sys.dba_users'||&nl||'@o %.%files' AS usage FROM dual UNION ALL
  SELECT 'oerr.sql' AS name, 'Display Oracle error decription' AS description, '@oerr <error_number>'||&nl||'@oerr 7445' AS usage FROM dual UNION ALL
  SELECT 'ofe.sql' AS name, 'Alter session optimizer feature enable' AS description, '@ofe <version>'||&nl||'@ofe 11.2.0.4' AS usage FROM dual UNION ALL
  SELECT 'oi.sql' AS name, 'Display invalid objects' AS description, '@oi' AS usage FROM dual UNION ALL
  SELECT 'oid.sql' AS name, 'Display database objects based on object id' AS description, '@oid <object_id>'||&nl||'@oid 10'||&nl||'@oid 10,20' AS usage FROM dual UNION ALL
  SELECT 'otherxml.sql' AS name, 'Display outline hints from library cache' AS description, '@otherxml <sql_id> <child#>'||&nl||'@otherxml 1fbwxvngasv1f 1' AS usage FROM dual UNION ALL
  SELECT 'ovvdb.sql' AS name, 'DTU - Display overview of Database and spool ot /home/oracle/ovvdb.txt' AS description, '@ovvdb' AS usage FROM dual UNION ALL
  SELECT 'p.sql' AS name, 'Display parameter name and value' AS description, '@p <parameter_name>'||&nl||'@pd optimizer' AS usage FROM dual UNION ALL
  SELECT 'partkeys.sql' AS name, 'Display table partition keys' AS description, '@partkeys [<owner>.]<table_name>'||&nl||'@partkeys soe.orders'||&nl||'@partkeys soe.%' AS usage FROM dual UNION ALL
  SELECT 'pd.sql' AS name, 'Display parameter name, description and value' AS description, '@pd <parameter_description>'||&nl||'@pd optimizer' AS usage FROM dual UNION ALL
  SELECT 'pdbs.sql' AS name, 'Display information about pdbs' AS description, '@pdbs' AS usage FROM dual UNION ALL
  SELECT 'pdbsp.sql' AS name, 'DTU - Display information about spfile from pdbs' AS description, '@pdbsp' AS usage FROM dual UNION ALL
  SELECT 'pdbspp.sql' AS name, 'DTU - Display information about properties from pdbs' AS description, '@pdbspp %'||&nl||'@pdbspp max' AS usage FROM dual UNION ALL
  SELECT 'pdbusers.sql' AS name, 'DTU - Display information about pdbs users' AS description, '@pdbusers <username>'||&nl||'@pdbusers %' AS usage FROM dual UNION ALL
  SELECT 'pmem.sql' AS name, 'Display pga process memory usage' AS description, '@pmem <spid>'||&nl||'@pmem 1000' AS usage FROM dual UNION ALL
  SELECT 'pmem_detail.sql' AS name, 'Show process memory usage breakdown details - lookup by process SPID' AS description, '@pmem_detail <spid>' AS usage FROM dual UNION ALL
  SELECT 'pga.sql' AS name, 'Display pga process memory stats' AS description, '@pga' AS usage FROM dual UNION ALL
  SELECT 'pinfo.sql' AS name, 'Display session information based on pid from so' AS description, '@pinfo <spid>' AS usage FROM dual UNION ALL
  SELECT 'pr.sql' AS name, 'Display Last result in format tabular' AS description, '@pr' AS usage FROM dual UNION ALL
  SELECT 'privgrants.sql' AS name, 'Display privileges in a grant format' AS description, '@privgrants <grantee>'||&nl||'@privgrants soe' AS usage FROM dual UNION ALL
  SELECT 'privs.sql' AS name, 'Display privileges from a user' AS description, '@privs <grantee>'||&nl||'@privs soe'  AS usage FROM dual UNION ALL
  SELECT 'privscdb.sql' AS name, 'DTU - Display privileges from a user' AS description, '@privscdb <grantee>'||&nl||'@privscdb soe'  AS usage FROM dual UNION ALL
  SELECT 'proc.sql' AS name, 'Display functions and procedures' AS description, '@proc <object_name> <procedure_name>'||&nl||'@proc dbms_stats table'||&nl||'@proc dbms_stats %' AS usage FROM dual UNION ALL
  SELECT 'procid.sql' AS name, 'Display functions and procedures' AS description, '@procid <object_id> <subprogram_id>'||&nl||'@procid 13615 84' AS usage FROM dual UNION ALL
  SELECT 'pv.sql' AS name, 'Display parameters based on the current value' AS description, '@pv <value>'||&nl||'@pv MANUAL' AS usage FROM dual UNION ALL
  SELECT 'pvalid.sql' AS name, 'Display valid parameter values' AS description, '@pvalid <parameter_name>'||&nl||'@pvalid optimizer' AS usage FROM dual UNION ALL
  SELECT 'reco.sql' AS name, 'Display recovery area usage' AS description, '@reco' AS usage FROM dual UNION ALL
  SELECT 'reg.sql' AS name, 'Display information about patches / dba_registry_patch' AS description, '@reg' AS usage FROM dual UNION ALL
  SELECT 'res.sql' AS name, 'Display reserved words matching character' AS description, '@res <keywork>' AS usage FROM dual UNION ALL
  SELECT 'res2.sql' AS name, 'Display reserved words matching a single keywork' AS description, '@res2 _' AS usage FROM dual UNION ALL
  SELECT 'rman.sql' AS name, 'Display rman information' AS description, '@rman' AS usage FROM dual UNION ALL
  SELECT 'rmanr.sql' AS name, 'DTU - Display rman running operation' AS description, '@rmanr' AS usage FROM dual UNION ALL
  SELECT 'roles.sql' AS name, 'Display roles information' AS description, '@roles <role_name>'||&nl||'@roles %' AS usage FROM dual UNION ALL
  SELECT 'rowcache.sql' AS name, 'Show parent rowcache entries mathcing an object name' AS description, '@rowcache <objectname>'||&nl||'@rowcache dba_tables' AS usage FROM dual UNION ALL
  SELECT 'rowid.sql' AS name, 'Display Show file, block, row numbers from rowid' AS description, '@rowid <rowid>' AS usage FROM dual UNION ALL
  SELECT 'rowid_scan.sql' AS name, 'Display rowid based on a search format' AS description, '@rowid_scan <table_name> <where_condition>'||&nl||'@rowid_scan soe.orders id=1' AS usage FROM dual UNION ALL
  SELECT 's.sql' AS name, 'Display current session wait and SQL_ID info (10g+)' AS description, '@s <sid>'||&nl||'@s 52,110,225'||&nl||'@s "select sid from v$session where username = ''XYZ''"'||&nl||'@s '||&amp||'mysid' AS usage FROM dual UNION ALL
  SELECT 'sample.sql' AS name, 'Sample any V$ view or X$ table and display aggregated results' AS description, '@sample <column[,column]> <table> <filter condition> <num. samples>'||&nl||'@sample sql_id v$session sid=142 1000000'||&nl||'@sample sql_id,event v$session "sid=142 and state=''WAITING''" 1000000'||&nl||'@sample plsql_object_id,plsql_subprogram_id,sql_id v$session sid=142 1000000' AS usage FROM dual UNION ALL
  SELECT 'sdr.sql' AS name, 'Control direct read in serial (_serial_direct_read)' AS description, '@sdr <TRUE|FALSE>' AS usage FROM dual UNION ALL
  SELECT 'se.sql' AS name, 'Display session events' AS description, '@se <sid>'||&nl||'@se 10' AS usage FROM dual UNION ALL
  SELECT 'sed.sql' AS name, 'Display wait events description' AS description, '@sed <event>'||&nl||'@sed log_file'||&nl||'@sed "enq: TX"' AS usage FROM dual UNION ALL
  SELECT 'seg.sql' AS name, 'Display segment information' AS description, '@seg [<owner>.]<segment_name>'||&nl||'@seg soe.customers'||&nl||'@seg soe.%' AS usage FROM dual UNION ALL
  SELECT 'segcached.sql' AS name, 'Display number of buffered blocks of a segment' AS description, '@segcached [<owner>.]<object_name>'||&nl||'@segcached soe.orders'||&nl||'@segcached soe.%' AS usage FROM dual UNION ALL
  SELECT 'seq.sql' AS name, 'Display sequence information' AS description, '@seq [<owner>.]<sequence_name>'||&nl||'@seq sys.jobseq'||&nl||'@seq %.jobseq' AS usage FROM dual UNION ALL
  SELECT 'ses.sql' AS name, 'Display session statistics for given sessions, filter by statistic name' AS description, '@ses <sid> <statname>'||&nl||'@ses 10 %'||&nl||'@ses 10 parse'||&nl||'@ses 10,11,12 redo'||&nl||'@ses "select sid from v$session where username = ''APPS''" parse' AS usage FROM dual UNION ALL
  SELECT 'ses2.sql' AS name, 'Display session statistics for given sessions, filter by statistic name and show only stats with value > 0' AS description, '@ses2 <sid> <statname>'||&nl||'@ses2 10 %'||&nl||'@ses2 10 parse'||&nl||'@ses2 10,11,12 redo'||&nl||'@ses2 "select sid from v$ses2sion where username = ''APPS''" parse' AS usage FROM dual UNION ALL
  SELECT 'settings.sql' AS name, 'Display AWR configuration' AS description, '@awr/settings' AS usage FROM dual UNION ALL
  SELECT 'sga.sql' AS name, 'Display instance memory usage breakdown from v$memory_dynamic_components' AS description, '@sga' AS usage FROM dual UNION ALL
  SELECT 'sgai.sql' AS name, 'Display instance memory usage breakdown from v$sgainfo' AS description, '@sgai' AS usage FROM dual UNION ALL
  SELECT 'sgares.sql' AS name, 'Display information about the last completed SGA resize operations from v$sga_resize_ops' AS description, '@sgares' AS usage FROM dual UNION ALL
  SELECT 'sgastat.sql' AS name, 'Display detailed information on the SGA from v$sgastat' AS description, '@sgastat <name|pool>'||&nl||'@sgastat %'||&nl||'@sgastat result' AS usage FROM dual UNION ALL
  SELECT 'sgastatx.sql' AS name, 'Display shared pool stats by sub-pool from X$KSMSS' AS description, '@sgastatx <statistic_name>'||&nl||'@sgastatx "free memory"'||&nl||'@sgastatx cursor' AS usage FROM dual UNION ALL
  SELECT 'sinfo.sql' AS name, 'Display session information based on sid' AS description, '@sinfo <sid>' AS usage FROM dual UNION ALL
  SELECT 'sw.sql' AS name, 'Display current Session Wait info' AS description, '@sw <sid>'||&nl||'@sw 52,110,225'||&nl||'@sw "select sid from v$session where username = ''XYZ''"'||&nl||'@sw AMPmysid' AS usage FROM dual UNION ALL
  SELECT 'sys.sql' AS name, 'Display system statistics' AS description, '@sys <statistic_name>'||&nl||'@sys redo'||&nl||'@sys ''redo write''' AS usage FROM dual UNION ALL
  SELECT 'sysm.sql' AS name, 'Display system metrics from v$metric' AS description, '@sysm <metric_name>'||&nl||'@sysm latency' AS usage FROM dual UNION ALL
  SELECT 'sl.sql' AS name, 'Set statistics level' AS description, '@sl <statistics_level>'||&nl||'@sl all' AS usage FROM dual UNION ALL
  SELECT 'sleep.sql' AS name, 'Sleep Interval dbms_lock.sleep' AS description, '@sleep <interval_s>' AS usage FROM dual UNION ALL
  SELECT 'smem.sql' AS name, 'Display process memory usage - pga' AS description, '@smem <sid>'||&nl||'@smem 1000' AS usage FROM dual UNION ALL
  SELECT 'smem_detail.sql' AS name, 'Show process memory usage breakdown details - lookup by session ID - Oradebug pga' AS description, '@smem_detail <sid>'||&nl||'@smem_detail 1000' AS usage FROM dual UNION ALL
  SELECT 'sn.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for lazy person' AS description, '@sn <sleep#> <sid>'||&nl||'@sn 5 123'||&nl||'@sn 5 lgwr' AS usage FROM dual UNION ALL
  SELECT 'snapper.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION' AS description, '@snapper <options> <sleep#> <snap_count> <sid>'||&nl||'@snapper ash=event+sql_id,ash1=program+username 5 1 program=%sqlplus%'||&nl||'@snapper all 5 1 sid'||&nl||'@snapper stats,gather=s,sinclude=undo.change.*size|redo.size 5 1 all' AS usage FROM dual UNION ALL
  SELECT 'snapredo.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for redo size' AS description, '@snapredo <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snappio.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for IO' AS description, '@snappio <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snappiomb.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for IO em mb' AS description, '@snappiomb <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snapundo.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for undo' AS description, '@snapundo <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snapcpu.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for DB CPU' AS description, '@snapcpu <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snapio.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for physical io' AS description, '@snapio <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snaplio.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for logical io' AS description, '@snaplio <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snapnet.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for SQL NET' AS description, '@snapnet <sleep>' AS usage FROM dual UNION ALL
  SELECT 'snapwait.sql' AS name, 'Display performance metric deltas in a snapshot from GV$SESSION for wait eventt' AS description, '@snapwait <sleep> <wait_eventt>' AS usage FROM dual UNION ALL
  SELECT 'sql.sql' AS name, 'Display SQL text, child cursors and execution stats for SQL hash value 1 child 2' AS description, '@sql <hash_value> <child_no>' AS usage FROM dual UNION ALL
  SELECT 'sqlbinds.sql' AS name, 'Display captured SQL bind variable values' AS description, '@sqlbinds <sql_id> <child_number>'||&nl||'@sqlbinds 2swu3tn1ujzq7 0'||&nl||'@sqlbinds 2swu3tn1ujzq7 %' AS usage FROM dual UNION ALL
  SELECT 'sqlid.sql' AS name, 'Display SQL: text, child cursors and execution statistics' AS description, '@sqlid <sql_id> <child_number>'||&nl||'@sqlid 7q729nhdgtsqq 0'||&nl||'@sqlid 7q729nhdgtsqq %' AS usage FROM dual UNION ALL
  SELECT 'sqlf.sql' AS name, 'Display full sql text from memory' AS description, '@sqlf <sql_id>'||&nl||'@sqlf 7q729nhdgtsqq' AS usage FROM dual UNION ALL
  SELECT 'sqlfn.sql' AS name, 'Display SQL functions' AS description, '@sqlf <name>'||&nl||'@sqlfn date' AS usage FROM dual UNION ALL
  SELECT 'sqlmen.sql' AS name, 'Display shared pool memory usage of SQL statement with SQL_ID 1' AS description, '@sqlmen <sql_id>' AS usage FROM dual UNION ALL
  SELECT 'sqlmenh.sql' AS name, 'Display shared pool memory usage of SQL statement with hash_value 1' AS description, '@sqlmen <hash_value>' AS usage FROM dual UNION ALL
  SELECT 'sqlmon.sql' AS name, 'Run SQL Monitor report' AS description, '@sqlmon <sid>'||&nl||'@sqlmon 1019' AS usage FROM dual UNION ALL
  SELECT 'sqlprof.sql' AS name, 'Run sample on v$session for a sql_id' AS description, '@sqlprof <sql_id>' AS usage FROM dual UNION ALL
  SELECT 'sql_profile_hints.sql' AS name, 'Display Hints from a sql profile' AS description, '@sqlprofile_hints <profile_name>' AS usage FROM dual UNION ALL
  SELECT 'sqlhc.sql' AS name, 'DTU - Display SQL Tuning Health Check - Doc 1366133.1' AS description, '@dtu/sqlhc/sqlhc.sql <[T|D|N]> <sql_id>' AS usage FROM dual UNION ALL
  SELECT 'sqlt.sql' AS name, 'Display sql_text from v$sql' AS description, '@sqlt <texto>' AS usage FROM dual UNION ALL
  SELECT 'sqltune_tune_sqlid.sql' AS name, 'Create tuning task for a given sql_id' AS description, '@sqltune_tune_sqlid <sql_id>' AS usage FROM dual UNION ALL
  SELECT 'stat.sql' AS name, 'Execute SQL statement in script argument and report basic execution statistics' AS description, '@stat "<SQL>"'||&nl||'@stat "select * from dual"'||&nl||'@stat "create table t as select * from all_objects"' AS usage FROM dual UNION ALL
  SELECT 'statn.sql' AS name, 'Display statistics from my session based on a stat name' AS description, '@statn <name_stats>' AS usage FROM dual UNION ALL
  SELECT 'stbsync.sql' AS name, 'DTU - Display standby syncronization information' AS description, '@stbsync' AS usage FROM dual UNION ALL
  SELECT 'sum.sql' AS name, 'Display sum information from a table' AS description, '@sum <column_name> <table_name>' AS usage FROM dual UNION ALL
  SELECT 'svc.sql' AS name, 'DTU - Display service actives' AS description, '@svc <service_name>'||&nl||'@svc %' AS usage FROM dual UNION ALL
  SELECT 'svcs.sql' AS name, 'Display service stats' AS description, '@svcs <service_name> <stat_name>' AS usage FROM dual UNION ALL
  SELECT 'sye.sql' AS name, 'Display system event name v$system_event' AS description, '@sye <event_name>' AS usage FROM dual UNION ALL
  SELECT 'syn.sql' AS name, 'Display synonym information' AS description, '@syn [<owner>.]<synonym_name>'||&nl||'@syn system.tab'||&nl||'@syn system.%' AS usage FROM dual UNION ALL
  SELECT 'syscontext.sql' AS name, 'DTU - Display all syscontext of current session' AS description, '@syscontext' AS usage FROM dual UNION ALL
  SELECT 'sw.sql' AS name, 'Display current Session Wait info' AS description, '@sw <sid>'||&nl||'@sw 52,110,225'||&nl||'@sw AMPmysid'||&nl||'@sw "select sid from v$session where username = ''XYZ''"' AS usage FROM dual UNION ALL
  SELECT 'swa.sql' AS name, 'Display current Session Wait info from my sid' AS description, '@swa' AS usage FROM dual UNION ALL
  SELECT 'swb.sql' AS name, 'Display current Session Wait info from background processes' AS description, '@swb' AS usage FROM dual UNION ALL
  SELECT 't.sql' AS name, 'Display default trace file' AS description, '@t' AS usage FROM dual UNION ALL
  SELECT 'tab.sql' AS name, 'Display table information' AS description, '@tab [<owner>.]<table_name>'||&nl||'@tab soe.orders'||&nl||'@tab soe.%' AS usage FROM dual UNION ALL
  SELECT 'tabhist.sql' AS name, 'Display column histograms' AS description, '@tabhist [<owner>.]<table_name> <column_name>'||&nl||'@tabhist soe.orders order_mode'||&nl||'@tabhist soe.orders %' AS usage FROM dual UNION ALL
  SELECT 'tabpart.sql' AS name, 'Display table partitions' AS description, '@tabpart [<owner>.]<table_name>'||&nl||'@tabpart soe.orders'||&nl||'@tabpart soe.%' AS usage FROM dual UNION ALL
  SELECT 'tabsubpart.sql' AS name, 'Display table subpartitions' AS description, '@tabsubpart [<owner>.]<table_name>'||&nl||'@tabsubpart soe.orders'||&nl||'@tabsubpart soe.%' AS usage FROM dual UNION ALL
  SELECT 'temp.sql' AS name, 'Display occupants in Temp Tablespace' AS description, '@temp' AS usage FROM dual UNION ALL
  SELECT 'ti.sql' AS name, 'Force new trace file' AS description, '@ti' AS usage FROM dual UNION ALL
  SELECT 'time_model.sql' AS name, 'Ash analisys of time model based on filters' AS description, '@ash/time_model <column> <filter> <date_from> <date_to>'||&nl||'@ash/time_model username 1=1 hour' AS usage FROM dual UNION ALL
  SELECT 'tom_kyte_unindexed_fk.sql' AS name, 'Display Foreign Keys FKs unindexed ' AS description, '@demos/tom_kyte_unindexed_fk' AS usage FROM dual UNION ALL
  SELECT 'topcur.sql' AS name, 'Display SQLs with at least atleast cursors' AS description, '@topcur <number_of_cursors>' AS usage FROM dual UNION ALL
  SELECT 'topseg.sql' AS name, 'Display top space users per tablespace' AS description, '@topseg <tablespace_name>'||&nl||'@topseg soe'||&nl||'@topseg %' AS usage FROM dual UNION ALL
  SELECT 'topsegs.sql' AS name, 'DTU - Display top space segments per schema' AS description, '@topsegs <schema_name>'||&nl||'@topsegs soe' AS usage FROM dual UNION ALL
  SELECT 'topsegstat.sql' AS name, 'Display information about top segment-level statistics' AS description, '@topsegstat <statistic_name>'||&nl||'@topsegstat reads'||&nl||'@topsegstat %' AS usage FROM dual UNION ALL
  SELECT 'topsql.sql' AS name, 'Display SQL ordered by user-provided criteria' AS description, '@topsql <column> <snapshot_seconds>'||&nl||'@topsql cpu_time 6'||&nl||'@topsql executions 6'||&nl||'@topsql buffer_gets/decode(executions,0,1,executions) 6' AS usage FROM dual UNION ALL
  SELECT 'trace.sql' AS name, 'Enable tracing' AS description, '@trace <filter_expression>'||&nl||'@trace sid=123'||&nl||'@trace username=''SOE''' AS usage FROM dual UNION ALL
  SELECT 'traceme.sql' AS name, 'Enable tracing for the current session' AS description, '@traceme' AS usage FROM dual UNION ALL
  SELECT 'traceoff.sql' AS name, 'Disable tracing' AS description, '@traceoff <filter_expression>'||&nl||'@traceoff sid=123'||&nl||'@traceoff username=''SOE''' AS usage FROM dual UNION ALL
  SELECT 'tracesid.sql' AS name, 'Enable tracing directly on sid' AS description, '@tracesid <sid>'||&nl||'@tracesid 123' AS usage FROM dual UNION ALL
  SELECT 'trans.sql' AS name, 'Display active transactions' AS description, '@trans' AS usage FROM dual UNION ALL
  SELECT 'trcname.sql' AS name, 'DTU - Display trace name of a session' AS description, '@trcname <sid>' AS usage FROM dual UNION ALL
  SELECT 'trcspool.sql' AS name, 'DTU - Spool trace content to sqlpath/tmp dir (>12.2)' AS description, '@trcspool <trace_name>' AS usage FROM dual UNION ALL
  SELECT 'trctk.sql' AS name, 'DTU - Disable trace and do a tkprof sort and normal' AS description, '@trctk <sid>' AS usage FROM dual UNION ALL
  SELECT 'trig.sql' AS name, 'Display triggers by table/trigger name' AS description, '@trig [<owner>.][<table_name>|<trigger_name>|%]'||&nl||'@trig soe.%'||&nl||'@trig trg_orders'||&nl||'@trig soe.orders' AS usage FROM dual UNION ALL
  SELECT 'trigoff.sql' AS name, 'DTU - Disable triggers command by table/trigger name' AS description, '@trigoff [<owner>.][<table_name>|<trigger_name>|%]'||&nl||'@trigoff soe.%'||&nl||'@trigoff trg_orders'||&nl||'@trigoff soe.orders' AS usage FROM dual UNION ALL
  SELECT 'ts.sql' AS name, 'Display tablespaces' AS description, '@ts <tablespace_name>'||&nl||'@ts soe'||&nl||'@ts %' AS usage FROM dual UNION ALL
  SELECT 'tvdxtat.sql' AS name, 'Trivadis Profiler Analyzer (tkprof alternative)' AS description, '@dtu/tvdxtat/tvdxtat.sql -i <trace_file> -o <trace_output>'||&nl||'@es dtu/tvdxtat/readme.html' AS usage FROM dual UNION ALL
  SELECT 'uds.sql' AS name, 'Display undo statistics' AS description, '@uds' AS usage FROM dual UNION ALL
  SELECT 'uu.sql' AS name, 'Display user sessions' AS description, '@uu <username>'||&nl||'@uu %'||&nl||'@uu username'||&nl||'@uu %username%' AS usage FROM dual UNION ALL
  SELECT 'uupt.sql' AS name, 'DTU - Display sessions by user,program or machine' AS description, '@uupt <username|program|machine>'||&nl||'@uupt username'||&nl||'@uupt %program%'||&nl||'@uupt %machine%' AS usage FROM dual UNION ALL
  SELECT 'us.sql' AS name, 'Display database usernames from dba_users' AS description, '@us <username>'||&nl||'@us username' AS usage FROM dual UNION ALL
  SELECT 'usid.sql' AS name, 'Display session information plus pid from sid' AS description, '@usid <sid>' AS usage FROM dual UNION ALL
  SELECT 'uspid.sql' AS name, 'Display session information from process id pid so' AS description, '@uspid <pid_so>' AS usage FROM dual UNION ALL
  SELECT 'up.sql' AS name, 'Display all sessions with program like %' AS description, '@up <filter_expression>'||&nl||'@up developer' AS usage FROM dual UNION ALL
  SELECT 'v.sql' AS name, 'Display View name and SQL Text from views matching' AS description, '@v <name>'||&nl||'@v dba_free_space' AS usage FROM dual UNION ALL
  SELECT 'wrka.sql' AS name, 'Display PGA and TEMP usage' AS description, '@wrka <filter_expression>'||&nl||'@wrka 1=1'||&nl||'@wrka sid=1000' AS usage FROM dual UNION ALL
  SELECT 'wrkasum.sql' AS name, 'Display summary of SQL workareas grouped by opertion type (PGA and TEMP)' AS description, '@wrkasum <filter_expression>'||&nl||'@wrkasum sql_id=''7q729nhdgtsqq''' AS usage FROM dual UNION ALL
  SELECT 'x.sql' AS name, 'Display SQL execution plan for the last SQL statement' AS description, '@x' AS usage FROM dual UNION ALL
  SELECT 'xa.sql' AS name, 'Display SQL execution plan for the last SQL statement - alias' AS description, '@xa' AS usage FROM dual UNION ALL
  SELECT 'xall.sql' AS name, 'Display SQL execution plan for the last SQL statement - advanced' AS description, '@xall' AS usage FROM dual UNION ALL
  SELECT 'xawr.sql' AS name, 'Display SQL execution plan from AWR' AS description, '@xawr <sql_id> <plan_hash_value>'||&nl||'@xawr 0sh0fn7r21020 1541789278'||&nl||'@xawr 0sh0fn7r21020 %' AS usage FROM dual UNION ALL
  SELECT 'xb.sql' AS name, 'Explain a SQL statements execution plan with execution profile directly from library cache - for the last SQL executed in current session' AS description, '@xb' AS usage FROM dual UNION ALL
  SELECT 'xbi.sql' AS name, 'Explain a SQL statements execution plan with execution profile directly from library cache - look up by SQL ID' AS description, '@xbi <sql_id> <sql_child_number>'||&nl||'@xbi a5ks9fhw2v9s1 0' AS usage FROM dual UNION ALL
  SELECT 'xi.sql' AS name, 'Display SQL execution plan from library cache' AS description, '@xi <sql_id> <child#>'||&nl||'@xi 7q729nhdgtsqq 0'||&nl||'@xi 7q729nhdgtsqq %' AS usage FROM dual UNION ALL
  SELECT 'xia.sql' AS name, 'Display SQL execution plan from library cache: ADVANCED format' AS description, '@xia <sql_id>'||&nl||'@xia 7q729nhdgtsqq' AS usage FROM dual UNION ALL
  SELECT 'xp.sql' AS name, 'Explain with profile Running DBMS_SQLTUNE.REPORT_SQL_MONITOR for session in Text format' AS description, '@xp <sid>' AS usage FROM dual UNION ALL
  SELECT 'xprof.sql' AS name, 'Run DBMS_SQLTUNE.REPORT_SQL_MONITOR for session' AS description, '@xprof <report_level> <type> <sql_id|session_id> <sql_id|sid>' AS usage FROM dual UNION ALL
  SELECT 'xplto.sql' AS name, 'Display execution plan operations' AS description, '@xplto <name>'||&nl||'@xplto full' AS usage FROM dual UNION ALL
  SELECT 'xma.sql' AS name, 'Display SQL execution plan from library cache - look up by hash' AS description, '@xma <sql_hash_value> <child#>'||&nl||'@xms 593239587 0'||&nl||'@xms 593239587 %' AS usage FROM dual UNION ALL
  SELECT 'xmon.sql' AS name, 'Display SQL execution plan from v$sql_monitoring' AS description, '@xmon <sql_id>'||&nl||'@xmon 7q729nhdgtsqq' AS usage FROM dual UNION ALL
  SELECT 'xms.sql' AS name, 'Display SQL execution plan from memory with statistics' AS description, '@xms <sql_id> <child#>'||&nl||'@xms 7q729nhdgtsqq 0'||&nl||'@xms 7q729nhdgtsqq %' AS usage FROM dual UNION ALL
  SELECT 'x9.sql' AS name, 'Explain plan for in default mode' AS description, '@x9' AS usage FROM dual UNION ALL
  SELECT 'x9all.sql' AS name, 'Explain plan for in advanced mode' AS description, '@x9all' AS usage FROM dual UNION ALL
  SELECT '' AS name, '' AS description, '' AS usage FROM dual UNION ALL
  SELECT '' AS name, '' AS description, '' AS usage FROM dual
  )
)
SELECT * FROM q
WHERE
   (upper(name)        LIKE upper ('%&search_string%') OR regexp_like(name, '&search_string', 'i'))
OR (upper(description) LIKE upper ('%&search_string%') OR regexp_like(description, '&search_string', 'i'))
-- OR (upper(usage)       LIKE upper ('%&search_string%') OR regexp_like(usage,
-- '&search_string', 'i'))
ORDER BY
    name
/


UNDEFINE search_string
CLEAR COLUMNS

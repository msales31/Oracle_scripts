COLUMN container_name FORMAT A20
COLUMN app_name FORMAT A20
COLUMN app_version FORMAT A10

SELECT c.name CONTAINER_NAME,
       aps.con_uid,
       aps.app_name,
       aps.app_version,
       aps.app_status
FROM   dba_app_pdb_status aps
JOIN v$containers c ON c.con_uid = aps.con_uid;

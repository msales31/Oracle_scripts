SET LINES 132
COL opname
COL pct_complete COL start_time COL hours_running COL minutes_left COL est_comp_time --
FORM A30 HEAD "Oper."
FORM 99.99 HEAD "% Comp."
FORM A15 HEAD "Start|Time"
FORM 9999.99 HEAD "Hours|Running" FORM 999999 HEAD "Minutes|Left" FORM A15 HEAD "Est. Comp.|Time"
SELECT sid, serial#, 
opname,
ROUND(sofar/totalwork*100,2) AS pct_complete,
TO_CHAR(start_time,'dd-mon-yy hh24:mi') start_time,
(sysdate-start_time)*24 hours_running, ((sysdate-start_time)*24*60)/(sofar/totalwork) - (sysdate-start_time)*24*60 minutes_left,
TO_CHAR((sysdate-start_time)/(sofar/totalwork) + start_time,'dd-mon-yy hh24:mi') est_comp_time
FROM v$session_longops
WHERE opname LIKE 'RMAN%'
AND opname NOT LIKE '%aggregate%'
AND totalwork != 0
AND sofar <> totalwork;

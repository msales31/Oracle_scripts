SET LINESIZE 150 TAB OFF
COLUMN property_name FORMAT A20
COLUMN pdb_name FORMAT A10
COLUMN property_value FORMAT A15
COLUMN description FORMAT A50

SELECT pr.con_id,
       p.pdb_name,
       pr.property_name, 
       pr.property_value,
       pr.description 
FROM   cdb_properties pr
       JOIN cdb_pdbs p ON pr.con_id = p.con_id
WHERE lower(PROPERTY_NAME) LIKE lower('%&1%') 
order by pr.property_name
/ 

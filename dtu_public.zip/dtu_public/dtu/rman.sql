PROMPT [RMAN OPERATIONS]

select  operation as "OPERACAO",
           object_type as "TIPO",
           status,
           output_device_type as "MEDIA",
           to_char(end_time,'DD-MM-RRRR HH24:MI:SS') as "DATA",
           round(MBYTES_PROCESSED/1024,2) as "TAMANHO(MB)"
from v$rman_status
where operation <> 'CATALOG'
and trunc(end_time)>=trunc(sysdate-1)
 order by end_time;

select  start_time, input_type,
        TRUNC(INPUT_BYTES/1024/1024) AS INPUT_BYTES_MB,
        TRUNC(OUTPUT_BYTES/1024/1024) AS OUTPUT_BYTES_MB,
        TRUNC(ELAPSED_SECONDS/60) AS ELAPSED_MINUTES
from V$RMAN_BACKUP_JOB_DETAILS
WHERE START_TIME BETWEEN SYSDATE-1 AND SYSDATE
AND INPUT_TYPE = 'DB FULL';


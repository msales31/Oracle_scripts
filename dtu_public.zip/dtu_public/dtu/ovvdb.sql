----------- Consulta Oracle Overview BD -----------


spool "/home/oracle/ovvdb.txt"


set linesize 999
set pagesize 5000
set long 10000000
set longchunksize 10000000
set arraysize 500
set verify off
set trimspool on
set trimout on
set tab off
set describe depth 1 linenum on indent on
set termout on


alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS';

prompt Consulta 0: Overview
prompt =================================
select NAME "Database Name",CREATED "Criado", (SELECT TO_CHAR(STARTUP_TIME,'DD-MON-YYYY "at" HH24:MI')
FROM V$INSTANCE, v$database) "Iniciado", LOG_MODE "Status",
(select banner
  from sys.v_$version
  where banner like '%Oracle%') as "Versão", (select CPU_CORE_COUNT_CURRENT from V$LICENSE) "Core_Count"
from sys.v_$database;

prompt Consulta 1: Tamanho do banco de dados
prompt =================================


select 'datafile' name, sum(bytes)/1024/1024/1024 size_gb from v$datafile
union
select 'tempfile' name, sum(bytes)/1024/1024/1024 size_gb from v$tempfile
union
select 'controlfile' name, (BLOCK_SIZE*FILE_SIZE_BLKS)/1024/1024/1024 size_gb from v$controlfile;


prompt Consulta 2: Redo Log info
prompt =====================


select GROUP#,THREAD#,SEQUENCE#,BYTES from v$log;


prompt Consulta 3: Histórico de redo log
prompt ===========================
set pages 100
select THREAD#,to_char(COMPLETION_TIME,'MM-DD') "MM-DD",count(*) QTD, round(sum(BLOCKS*BLOCK_SIZE)/1024/1024) SIZE_MB
from gv$archived_log group by THREAD#,to_char(COMPLETION_TIME,'MM-DD') order by 1,2;

prompt Consulta 4: Conjunto de caracteres
prompt =============================
Set line 200
Col PROPERTY_VALUE form a40
select PROPERTY_NAME,PROPERTY_VALUE from database_properties;


prompt Consulta 5: Consumo de CPU e I/O da semana
prompt ======================================

SELECT min(to_char(begin_time, 'dd-mm-yy-hh24:mi')) inicio,
       max(to_char(end_time, 'dd-mm-yy-hh24:mi')) fim,
       round(sum(case metric_name when 'Host CPU Utilization (%)' then average end),1) Host_CPU_util,
       round(sum(case metric_name when 'Physical Read Total Bytes Per Sec' then average end) / 1024 / 1024, 1) Physical_Read_MBps,
       round(sum(case metric_name when 'Physical Write Total Bytes Per Sec' then average end) / 1024 / 1024, 1) Physical_Write_MBps,
       round(sum(case metric_name when 'Physical Read Total IO Requests Per Sec' then average  end), 1) Physical_Read_IOPS,
       round(sum(case metric_name when 'Physical Write Total IO Requests Per Sec' then average end), 1) Physical_write_IOPS,
       round(sum(case metric_name when 'Redo Writes Per Sec' then average end), 1) Physical_redo_IOPS,
       round(sum(case metric_name when 'Network Traffic Volume Per Sec' then average end) / 1024 / 1024, 1) Network_Mb_per_sec,
       snap_id
  from dba_hist_sysmetric_summary
where trunc(begin_time) > trunc(sysdate - 7)
group by snap_id
order by snap_id;
prompt Consulta 6: Utilização de recursos
prompt ============================


SELECT version, name, detected_usages, currently_used, first_usage_date, last_usage_date
  from DBA_FEATURE_USAGE_STATISTICS
where name in ('Spatial','OLAP - Analytic Workspaces','OLAP - Cubes','Data Mining','Real Application Cluster (RAC)','Partitioning (user)',
                'Partitioning (system)','Oracle Database Vault','Label Security','Active Data Guard - Real-Time Query on Physical Standby',
                'Flashback Data Archive','Diagnostic Pack','Database Replay: Workload Capture','Database Replay: Workload Replay',
                'Audit Options','ASO native encryption and checksumming','Oracle Secure Backup','Tuning Pack')
order by name;


prompt Consulta 7: Parametros de memoria
prompt ============================


col nome format a26
col valor format a40
SELECT
sp.name as nome,
sp.display_value as valor
FROM v$spparameter sp
WHERE (SP.NAME LIKE '%memory_target%'
or SP.NAME LIKE '%sga_target%'
or sp.name like '%pga_aggregate_target'
or sp.name like '%db_recovery_file_dest%'
or sp.name like '%db_recovery_file_dest_size%'
or sp.name like 'processes')
ORDER BY sp.name;


prompt Consulta 8: Size por Owner
prompt ============================
select
    owner              du_owner
  , sum(bytes)/1048576 du_MB
  , sum(bytes)/1048576/1024 du_GB
from
    dba_segments
where
    lower(owner) like lower('%')
group by
    owner
order by
    du_MB desc;
    
prompt Consulta 9: Size por Tablespace
prompt ============================
select t.tablespace_name, t.mb "TotalMB", t.mb - nvl(f.mb,0) "UsedMB", nvl(f.mb,0) "FreeMB"
       ,lpad(ceil((1-nvl(f.mb,0)/decode(t.mb,0,1,t.mb))*100)||'%', 6) "% Used", t.ext "Ext",
       '|'||rpad(lpad('#',ceil((1-nvl(f.mb,0)/decode(t.mb,0,1,t.mb))*20),'#'),20,' ')||'|' "Used"
from (
  select tablespace_name, trunc(sum(bytes)/1048576) MB
  from dba_free_space
  group by tablespace_name
union all
  select tablespace_name, trunc(sum(bytes_free)/1048576) MB
  from v$temp_space_header
  group by tablespace_name
) f, (
  select tablespace_name, trunc(sum(bytes)/1048576) MB, max(autoextensible) ext
  from dba_data_files
  group by tablespace_name
union all
  select tablespace_name, trunc(sum(bytes)/1048576) MB, max(autoextensible) ext
  from dba_temp_files
  group by tablespace_name
) t
where t.tablespace_name = f.tablespace_name (+)
order by t.tablespace_name;


prompt Consulta 10: Informações FRA
prompt ============================


PROMPT [ESPAÇO FRA]


COL NAME FORMAT A50
SELECT
    NAME,
    SPACE_LIMIT/1024/1024 AS "TAM_MAX (MB)",
    ROUND(SPACE_USED/1024/1024,2) AS "TAM_USADO (MB)",
    ROUND((SPACE_LIMIT - SPACE_USED + SPACE_RECLAIMABLE)/1024/1024,2)  AS "TAM_DISPONIVEL (MB)",
    ROUND((SPACE_USED - SPACE_RECLAIMABLE)/SPACE_LIMIT * 100, 1) AS "PERCT_CHEIO"
FROM V$RECOVERY_FILE_DEST;


SELECT FILE_TYPE "Type",
PERCENT_SPACE_USED "% Used",
PERCENT_SPACE_RECLAIMABLE "% Reclaim",
NUMBER_OF_FILES "# Files"
FROM V$FLASH_RECOVERY_AREA_USAGE;


PROMPT [ARCHIVE GERADO POR DIA]


select count(1) as QTDE, (avg(blocks*block_size)/1024/1024) as "Tamanho (MB)"
from v$archived_log where completion_time between sysdate-1 and sysdate;


PROMPT [SWITCH LOG POR HORA]


select to_char(first_time,'DD/MM/YYYY') day,
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'00',1,0)),'999') "00",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'01',1,0)),'999') "01",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'02',1,0)),'999') "02",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'03',1,0)),'999') "03",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'04',1,0)),'999') "04",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'05',1,0)),'999') "05",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'06',1,0)),'999') "06",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'07',1,0)),'999') "07",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'08',1,0)),'999') "08",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'09',1,0)),'999') "09",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'10',1,0)),'999') "10",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'11',1,0)),'999') "11",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'12',1,0)),'999') "12",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'13',1,0)),'999') "13",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'14',1,0)),'999') "14",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'15',1,0)),'999') "15",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'16',1,0)),'999') "16",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'17',1,0)),'999') "17",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'18',1,0)),'999') "18",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'19',1,0)),'999') "19",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'20',1,0)),'999') "20",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'21',1,0)),'999') "21",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'22',1,0)),'999') "22",
to_char(sum(decode(substr(to_char(first_time,'HH24'),1,2),'23',1,0)),'999') "23",
sum(1) "TOTAL_IN_DAY"
from v$log_history
group by to_char(first_time,'DD/MM/YYYY')
order by to_date(day) desc

spool off;

exit;

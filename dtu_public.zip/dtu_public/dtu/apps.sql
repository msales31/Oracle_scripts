COLUMN app_name FORMAT A20
COLUMN app_version FORMAT A10
COLUMN app_implicit format a12

SELECT app_name,
       app_version,
       app_status,
       app_implicit
FROM   dba_applications;

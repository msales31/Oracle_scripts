spool /home/oracle/pga_analise.log
PROMPT ==================== PARAMETROS DE MEMÓRIA ==========================
col NAME format a20
col VALUE format a15
col DISPLAY_VALUE format a15
select name, VALUE, DISPLAY_VALUE from v$parameter where (REGEXP_LIKE (name, '(pga_aggregate|sga)_target') or name like 'pga_aggregate_limit');
col NAME clear
col VALUE clear
col DISPLAY_VALUE clear
PROMPT ===================== PGA ADVISORY ==================================
select * from v$pga_target_advice;
PROMPT ============= PGA USAGE INSTANCE LEVEL STATISTICS ===================
select * from V$PGASTAT;
PROMPT =============== PGA USAGE BY PROCESS CONNECTED ======================
select category,sum(allocated)/1024/1024 AllocMB,sum(used) UsedMB, sum(max_allocated)/1024/1024 MaxAllocMB from v$process_memory  group by category;
select sum(pga_alloc_mem)/1024/1024 as pga_alloc_mem_mb from v$process;
PROMPT =============== ACTIVE SESSION HISTORY ANALYSIS =====================
@ashtop event2,program 1=1 &hour
@ashtop event2,sql_opname,objt,sql_plan_operation,sql_plan_options "(event like 'direct%' or event like 'PGA%')" &hour
PROMPT =================== WORKAREA ANALYSIS ===============================
PROMPT WORKAREA: SORT e hash area estão na PGA para armazenar dados que precisam ser hash grouped ou sorted
select inst_id,sid,sql_id,operation_type,sum(actual_mem_used)/1024/1024 as wrka_used,sum(work_area_size)/1024/1024 wrka_size, sum(tempseg_size)/1024/1024 tempseg_size_mb from gv$sql_workarea_active group by inst_id,sid,sql_id,operation_type;
@wrkasum 1=1
PROMPT =================== PGA USAGE BY SESSION ============================
COL OSUSER format a30
COL NAME FORMAT A30
SELECT * FROM (
select vses.sid,vses.serial#,vses.module,vstt.name,vses.sql_id,
         round(min(vsst.value)/1024/1024,2) MinMB,
         round(max(vsst.value)/1024/1024,2) MaxMB,
         round(avg(vsst.value)/1024/1024,2) AvgMB
from     sys.v_$sesstat  vsst,
         sys.v_$statname vstt,
         sys.v_$session  vses
where    vstt.statistic# = vsst.statistic#
     and vsst.sid = vses.sid
     and vstt.name in ('session pga memory','session pga memory max','session uga memory','session uga memory max')
     and vses.username is not null group by  vses.sid,vses.serial#,vstt.name,vses.sql_id,vses.module order by MAXMB DESC)
WHERE ROWNUM < 15;
PROMPT ===================== SGA ADVISORY ==================================
select * from v$sga_target_advice;
spool off


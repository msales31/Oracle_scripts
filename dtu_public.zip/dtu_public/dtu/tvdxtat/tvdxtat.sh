#!/bin/sh

JAVA_HOME=$ORACLE_HOME/jdk/jre/
TVDXTAT_HOME=/home/oracle/.script/dtu/tvdxtat

$JAVA_HOME/bin/java -Xmx1024m -Dtvdxtat.home=$TVDXTAT_HOME -Djava.util.logging.config.file=$TVDXTAT_HOME/config/logging.properties -jar $TVDXTAT_HOME/lib/tvdxtat.jar $*

def _trace_file_name="NA"
define nl=chr(10)
COL trace_file FORMAT A65 new_value _trace_file_name
COL PROGRAM FORMAT A20

declare
    l_sid    number;
    l_serial number;
begin

    select sid, serial#
    into l_sid, l_serial
    from v$session
    where sid = &1;

    sys.dbms_monitor.session_trace_disable(l_sid,l_serial);

end;
/

SELECT s.sid
       ,s.serial#
       ,s.program||&nl||'on '||s.machine as program
       ,(select value from v$diag_info where name = 'Diag Trace') || '/' || SYS_CONTEXT('userenv','instance_name') ||    
       '_ora_' || p.spid || '.trc' AS trace_file
FROM   v$session s,
       v$process p
WHERE  1=1
AND    s.paddr = p.addr
AND    s.sid in (&1)
/


PROMPT Executando tkprof...
host tkprof &_trace_file_name &_TPT_TEMPDIR/trctk_sid_&1..trc
host tkprof &_trace_file_name "&_TPT_TEMPDIR/trctk_sort_sid_&1..trc" sys=no sort=prsela,exeela,fchela

PROMPT
PROMPT Tkprof Sort: @es "tmp/trctk_sort_sid_&1..trc"
PROMPT Tkprof: @es "tmp/trctk_sid_&1..trc"
PROMPT
PROMPT

undef _trace_file_name

col dirs_directory_path head DIRECTORY_PATH for a90
col dirs_directory_name head DIRECTORY_NAME for a30 WRAP
col dirs_owner HEAD DIRECTORY_OWNER FOR A30
col con_id format 9999
col owner for a10
select con_id,directory_name dirs_directory_name, directory_path dirs_directory_path,owner from cdb_directories;

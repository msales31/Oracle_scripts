COL username FORMAT A15
COL inherited FORMAT A9
COL common FORMAT A6
COL con_name FORMAT A10
COL account_status FORMAT A14
COL proxy_only_connect FORMAT A10

SELECT u.username, u.common, u.inherited, u.con_id, c.name con_name, u.account_status, u.proxy_only_connect
FROM cdb_users u, v$containers c
WHERE 1=1 
and u.con_id = c.con_id
and u.oracle_maintained = 'N'
and username like '%&1%' 
ORDER BY con_id;


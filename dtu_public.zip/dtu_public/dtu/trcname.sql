define nl=chr(10)

COLUMN trace_file FORMAT A60
COL PROGRAM FORMAT A40


SELECT s.sid
       ,s.serial#
       ,s.program||&nl||'on '||s.machine as program
       ,(select value from v$diag_info where name = 'Diag Trace') || '/' || SYS_CONTEXT('userenv','instance_name') || '_ora_' || p.spid || '.trc' AS trace_file
FROM   v$session s,
       v$process p
WHERE  s.paddr = p.addr
AND    s.sid in (&1)
/



col name for a25
col value$ for a40
col comment$ format a30
col sid format a5
col db_uniq_name for a8 

select db_uniq_name, pdb_uid, sid, name, value$, comment$ from pdb_spfile$
/

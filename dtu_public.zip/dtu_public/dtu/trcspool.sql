-- Works on 12.2 onwards only

PROMPT Spool payload of trace file content to &_TPT_TEMPDIR

spool &_TPT_TEMPDIR/&1

SELECT payload
FROM   v$diag_trace_file_contents
WHERE  trace_filename = '&1'
ORDER BY line_number
/

spool off

prompt Disable triggers by table/trigger name &1....

COL table_owner    FOR A20
COL trigger_name   FOR A30

select 'alter trigger '||table_owner||'.'||trigger_name||' disable;' as DISABLE
from dba_triggers
where (
    UPPER(table_name) LIKE
                UPPER(CASE
                    WHEN INSTR('&1','.') > 0 THEN
                        SUBSTR('&1',INSTR('&1','.')+1)
                    ELSE
                        '&1'
                    END
                     )
AND UPPER(table_owner) LIKE
        CASE WHEN INSTR('&1','.') > 0 THEN
            UPPER(SUBSTR('&1',1,INSTR('&1','.')-1))
        ELSE
            user
        END
)
OR (
    UPPER(trigger_name) LIKE
                UPPER(CASE
                    WHEN INSTR('&1','.') > 0 THEN
                        SUBSTR('&1',INSTR('&1','.')+1)
                    ELSE
                        '&1'
                    END
                     )
AND UPPER(owner) LIKE
        CASE WHEN INSTR('&1','.') > 0 THEN
            UPPER(SUBSTR('&1',1,INSTR('&1','.')-1))
        ELSE
            user
        END
)
order by
    table_owner,
    table_name,
    trigger_name
/

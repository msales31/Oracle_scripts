col name for a20
col masterkeyid_base64 for a40
SELECT name,utl_raw.cast_to_varchar2(utl_encode.base64_encode('01'||substr(mkeyid, 1, 4))) || utl_raw.cast_to_varchar2(utl_encode.base64_encode(substr(mkeyid, 5, length(mkeyid)))) masterkeyid_base64
FROM
  (SELECT t.name,RAWTOHEX(x.mkid) mkeyid from v$tablespace t, x$kcbdbk x);
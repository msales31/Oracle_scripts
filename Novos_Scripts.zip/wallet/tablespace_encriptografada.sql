set linesize 200
col WALLET_DIR for a32
col status for a21
select STATUS,WRL_PARAMETER WALLET_DIR,WALLET_TYPE from V$ENCRYPTION_WALLET;
select TABLESPACE_NAME, ENCRYPTED from dba_tablespaces;
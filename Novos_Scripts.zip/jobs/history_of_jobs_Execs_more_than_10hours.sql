SELECT
    job_name,
    log_id,
    status,
    actual_start_date,
    run_duration,
    session_id,
    instance_id,
    cpu_used
FROM
    dba_scheduler_job_run_details
WHERE
    run_duration > INTERVAL '10' HOUR
ORDER BY
    actual_start_date DESC;

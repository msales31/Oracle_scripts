BEGIN
DBMS_SCHEDULER.SET_ATTRIBUTE (
name => '&job_name',
attribute => 'repeat_interval',
value => 'FREQ=DAILY;BYHOUR=1;BYMINUTE=0');
END;
/
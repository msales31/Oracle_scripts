execute dbms_scheduler.disable (job_name => '&job_name_with_owner');

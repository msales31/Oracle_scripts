col START_DATE for a21;
col REPEAT_INTERVAL for a21;
col JOB_NAME for a40;
select OWNER,JOB_NAME,STATE, START_DATE, REPEAT_INTERVAL from DBA_SCHEDULER_JOBS
where UPPER(JOB_NAME) like upper('%&name%')
order by 2;


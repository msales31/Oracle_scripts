SET LINESIZE 300

COLUMN job FORMAT 9999999999
COLUMN last_date FORMAT A20
COLUMN next_date FORMAT A20
COLUMN schema_user FORMAT A15
COLUMN broken FORMAT A5

SELECT
	job, schema_user, last_date, next_date, broken, interval
  FROM 
	DBA_JOBS
WHERE upper(broken) = 'Y'
order by 3;
--Caso tenha problemas veja se o job n esta rodando na dba_jobs_running;
--Caso tenha algo travado, dar um kill no id

set pages 4000
set lines 4000
col what format a30
select job, 
what, 
LAST_DATE, NEXT_DATE, TOTAL_TIME, BROKEN, FAILURES, INTERVAL from dba_jobs 
where job=461
order by 1;


--column job format 999999999
--column log_user format a20
--column last_date format A20
--column next_date format A20
--column interval format A30
--column broken format A3
--column failures format 999
--column instance format 99
--SELECT /*+RULE */ JOB,
--LOG_USER,
--to_char(LAST_DATE,'DD/MM/YYYY HH24:MI:SS') LAST_DATE,
--to_char(NEXT_DATE,'DD/MM/YYYY HH24:MI:SS') NEXT_DATE,
--INTERVAL,
--FAILURES,
--BROKEN,
--INSTANCE
--FROM DBA_JOBS
----where LOG_USER like NVL(UPPER('&OWNER'),'%')
----where job = 462
----where upper(broken) = 'N'
--order by NEXT_DATE;




--set pages 4000
--set lines 4000
--col what format a30
--select job, what, LAST_DATE, NEXT_DATE, TOTAL_TIME, BROKEN, FAILURES, INTERVAL from dba_jobs;


--column job format 999999999
--column log_user format a20
--column last_date format A20
--column next_date format A20
--column interval format A30
--column broken format A3
--column failures format 999
--column instance format 99
--SELECT /*+RULE */ JOB,
--LOG_USER,
--to_char(LAST_DATE,'DD/MM/YYYY HH24:MI:SS') LAST_DATE,
--to_char(NEXT_DATE,'DD/MM/YYYY HH24:MI:SS') NEXT_DATE,
--INTERVAL,
--FAILURES,
--BROKEN,
--INSTANCE,
--WHAT
--FROM DBA_JOBS
--where job = 445
--order by NEXT_DATE;

column INTERVAL FORMAT a39;
column JOB_NAME FORMAT a22;
column OWNER FORMAT a10;
column RUN FORMAT a7;
column FAIL FORMAT a5;
column RUNDURATION FORMAT a09;
column JOB_CLASS FORMAT a12;
column STATE FORMAT a09;
column P FORMAT 9;
SELECT OWNER,
       JOB_NAME,
       JOB_ACTION,
       SUBSTR(REPEAT_INTERVAL,1,39) INTERVAL,
       TO_CHAR(RUN_COUNT,'999999') RUN,
       TO_CHAR(FAILURE_COUNT,'9999') FAIL,
       decode(LAST_START_DATE,null,'00-xxx 00:00:00',TO_CHAR(LAST_START_DATE, 'dd-mon hh24:mi:ss')) LASTSTART,
       TO_CHAR(NEXT_RUN_DATE, 'dd-mon hh24:mi:ss') NEXT,
       EXTRACT(DAY FROM LAST_RUN_DURATION)*24+EXTRACT(HOUR from LAST_RUN_DURATION)||'h'||
       EXTRACT(MINUTE from LAST_RUN_DURATION)||'m'||
       trunc(EXTRACT(SECOND from LAST_RUN_DURATION))||'s' RUNDURATION,
       STATE
--       DECODE(JOB_CLASS,'DEFAULT_JOB_CLASS','DEFAULT',JOB_CLASS) JOB_CLASS,
--       JOB_PRIORITY P
FROM dba_scheduler_jobs
where job_name like upper('%&Jobname%')
order by job_name;
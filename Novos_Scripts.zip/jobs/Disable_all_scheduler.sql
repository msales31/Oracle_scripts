set head off
spool job_disable.sql
select 'execute dbms_scheduler.disable('||''''||owner||'.'||job_name||''''||');' from dba_scheduler_jobs where enabled='TRUE';
spool off;
@job_disable.sql
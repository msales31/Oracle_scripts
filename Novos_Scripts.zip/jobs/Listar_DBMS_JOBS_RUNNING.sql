col this_date for a20
col next_date for a20
select sid,job,this_date,last_date from dba_jobs_running;
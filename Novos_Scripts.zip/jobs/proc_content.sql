SELECT text
FROM dba_source
WHERE owner = '&schema'
and name = '&procedure'
ORDER BY line;
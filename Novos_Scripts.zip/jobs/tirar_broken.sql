EXEC DBMS_IJOB.BROKEN('&job_name',false);

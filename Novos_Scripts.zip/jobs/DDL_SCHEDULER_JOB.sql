select dbms_metadata.get_ddl('PROCOBJ','&SCHEDULER_NAME','&OWNER') from dual;

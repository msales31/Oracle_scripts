exec dbms_ijob.remove(&number);

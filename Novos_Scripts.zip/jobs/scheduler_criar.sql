BEGIN
DBMS_SCHEDULER.CREATE_JOB (
job_name => 'sys.statspacksnap',
job_type => 'STORED_PROCEDURE',
job_action => 'statspack.snap',
start_date         =>  to_date('12-02-2022 11:00:00', 'dd-mm-yyyy hh24:mi:ss'),
repeat_interval => 'FREQ=HOURLY; INTERVAL=1',
auto_drop => FALSE,
enabled => TRUE,
comments => 'Statspack automated snap');
END;
/

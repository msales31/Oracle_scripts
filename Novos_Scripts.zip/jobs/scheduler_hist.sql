col status format a10
col owner format a10
col job_name format a30
col ACTUAL_START_DATE format a40
col RUN_DURATION format a20
col ADDITIONAL_INFO format a30
select 
LOG_ID,
OWNER,
JOB_NAME,
STATUS,
ACTUAL_START_DATE,
RUN_DURATION,
ADDITIONAL_INFO 
from ALL_SCHEDULER_JOB_RUN_DETAILS 
where 
--owner='&owner' and 
JOB_NAME=UPPER('&job') and 
--status='FAILED' and
ACTUAL_START_DATE>trunc(sysdate)-7
order by 5;
begin
  dbms_ijob.submit (
   job       =>    '&job_number',
   luser     =>    '&schema',
   puser     =>    '&schema',
   cuser     =>    '&schema',
   next_date =>    '03/05/2021 15:23',
   interval  =>    'sysdate+1/24/60',
   broken    =>    TRUE,
   what      =>    'PKG_T120.SP_PROCESSA_CONTROLE;',
   nlsenv    =>    'NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY''',
   env       =>    '0102000200000000'
);
end;
/
SET LINESIZE 300 COLUMN job FORMAT 99999 COLUMN last_date FORMAT A10 COLUMN next_date FORMAT A10 COLUMN schema_user FORMAT A20 COLUMN broken FORMAT A5 COL INTERVAL for A25 col next_sec for a12 col B for a2
SELECT  job
       ,schema_user
       ,last_date
       ,last_sec
       ,next_date
       ,next_sec
       ,broken B
       ,interval
FROM DBA_JOBS
ORDER BY 1;
set pagesize 299
set lines 299
col JOB_NAME for a24
col actual_start_date for a56
col RUN_DURATION for a34
select job_name,status,actual_start_date,run_duration from DBA_SCHEDULER_JOB_RUN_DETAILS where owner='&OWNER' AND JOB_NAME='&JOB_NAME'
order by ACTUAL_START_DATE ASC;
 -- ----------------------------------------------------------------------------------- -- jobs running -- --------------------------------------------------------------------------------- 
-- SET LINESIZE 200
SELECT  sid 
       ,r.JOB 
       ,r.LAST_DATE 
       ,r.THIS_DATE 
       ,d.what
FROM DBA_JOBS_RUNNING r, DBA_JOBS d
WHERE r.job=d.job;  
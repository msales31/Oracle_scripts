SET LINESIZE 200
COLUMN owner FORMAT A20
COLUMN table_name FORMAT A30
COLUMN column_name FORMAT A30
COLUMN segment_name FORMAT A40
COLUMN compression FORMAT A10
 
SELECT 
    owner,
    table_name,
    column_name,
    segment_name,
    compression 
FROM dba_lobs
WHERE securefile = 'YES'
AND segment_name = '&nomedolob'; 
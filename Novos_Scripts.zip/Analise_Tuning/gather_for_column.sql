EXEC DBMS_STATS.gather_table_stats (ownname => '&schema',  tabname=> '&table', method_opt => 'FOR ALL COLUMNS SIZE 1', cascade=> true);

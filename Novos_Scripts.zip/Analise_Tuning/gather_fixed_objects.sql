EXEC DBMS_STATS.gather_fixed_objects_stats;
 
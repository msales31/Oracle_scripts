SET linesize 200
COLUMN Parameter     FORMAT A35
COLUMN Session       FORMAT A20
COLUMN Instance      FORMAT A20
COLUMN S             FORMAT A1
COLUMN I             FORMAT A1
COLUMN D             FORMAT A1
COLUMN Description   FORMAT A60

SELECT
    a.ksppinm                         AS "Parameter",
    DECODE(p.isses_modifiable, 'FALSE', NULL, b.ksppstvl) AS "Session",
    c.ksppstvl                        AS "Instance",
    DECODE(p.isses_modifiable, 'FALSE', 'F', 'TRUE', 'T') AS "S",
    DECODE(p.issys_modifiable, 'FALSE', 'F', 'IMMEDIATE', 'I', 'DEFERRED', 'D') AS "I",
    DECODE(p.isdefault, 'FALSE', 'F', 'TRUE', 'T') AS "D",
    a.ksppdesc                        AS "Description"
FROM
    x$ksppi a
  JOIN x$ksppcv b ON a.indx = b.indx
  JOIN x$ksppsv c ON a.indx = c.indx
  LEFT JOIN v$parameter p ON a.ksppinm = p.name
WHERE
    UPPER(a.ksppinm) LIKE UPPER('%&1%')
ORDER BY
    a.ksppinm;

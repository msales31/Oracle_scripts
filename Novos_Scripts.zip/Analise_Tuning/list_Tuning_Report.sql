select task_name,execution_end, task_id from DBA_ADVISOR_LOG where task_name like '%TASK%';

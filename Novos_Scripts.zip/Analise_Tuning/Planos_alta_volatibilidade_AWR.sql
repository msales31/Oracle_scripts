ALTER SESSION
SET nls_date_format = 'dd-mm-yyyy hh24:mi:ss';

col SUM(EXECS)
FOR 999999999999;

col PLAN_HASH_VALUE
FOR 99999999999999;


SELECT *
FROM
  (SELECT sql_id,
          sum(execs),
          min(avg_etime) min_etime,
          max(avg_etime) max_etime,
          stddev_etime/min(avg_etime) norm_stddev,
          plans
   FROM
     (SELECT sql_id,
             plan_hash_value,
             execs,
             avg_etime,
             stddev(avg_etime) OVER (PARTITION BY sql_id) stddev_etime,
                                    plans
      FROM
        (SELECT s.sql_id,
                s.plan_hash_value,
                COUNT(DISTINCT X.plan_hash_value) plans,
                sum(nvl(executions_delta, 0)) execs,
                (sum(elapsed_time_delta)/decode(sum(nvl(executions_delta, 0)), 0, 1, sum(executions_delta))/1000000) avg_etime
         FROM DBA_HIST_SQLSTAT S,
              DBA_HIST_SNAPSHOT SS,
              dba_hist_sql_plan X
         WHERE ss.snap_id = S.snap_id
           AND ss.instance_number = S.instance_number
           AND executions_delta > 0
           AND to_char(BEGIN_INTERVAL_TIME, 'DD/MM/YYYY hh24:mi:ss') > SYSDATE-10
           AND X.dbid = s.dbid
           AND X.sql_id = s.sql_id
         GROUP BY s.sql_id,
                  s.plan_hash_value))
   GROUP BY sql_id,
            stddev_etime,
            plans)
WHERE norm_stddev > 10
  AND max_etime > 20
  AND plans > 1
ORDER BY 2;
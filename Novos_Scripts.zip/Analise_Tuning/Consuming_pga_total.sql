SELECT COUNT(mem_used_in_MB)
FROM (SELECT sid
    ,username
    ,round(total_user_mem / 1024 / 1024) mem_used_in_MB
    ,round(100 * total_user_mem / total_mem,2) mem_percent
     FROM (SELECT b.sid sid
    ,nvl(b.username,p.NAME) username
    ,SUM(VALUE) total_user_mem
     FROM sys.v_$statname c
    ,sys.v_$sesstat a
    ,sys.v_$session b
    ,sys.v_$bgprocess p
     WHERE a.statistic# = c.statistic# AND p.paddr (+)  = b.paddr AND b.sid = a.sid AND c.NAME IN ('session pga memory','session uga memory')
     GROUP BY b.sid,nvl(b.username,p.NAME))
    ,(SELECT SUM(VALUE) total_mem
     FROM sys.v_$statname c
    ,sys.v_$sesstat a
     WHERE a.statistic# = c.statistic# AND c.NAME IN ('session pga memory','session uga memory'))
     ORDER BY 3 DESC);
COLUMN ksppinm FORMAT A40
COLUMN ksppstvl FORMAT A20
SELECT ksppinm,ksppstvl FROM x$ksppi a,x$ksppsv b WHERE a.indx=b.indx
AND ksppinm in ('_optimizer_nlj_hj_adaptive_join', '_optimizer_strans_adaptive_pruning', '_px_adaptive_dist_method', '_sql_plan_directive_mgmt_control', '_optimizer_dsdir_usage_control',
'_optimizer_use_feedback', '_optimizer_gather_feedback', '_optimizer_performance_feedback') ORDER BY ksppinm;
SELECT 'exec dbms_stats.gather_table_stats(' || '''' || '"' || OWNER || '"' || '''' || ',' || '''' || '"' || OBJECT_NAME || '"' || '''' || ', estimate_percent => 1, cascade => true);'
,LAST_DDL_TIME
FROM dba_objects
WHERE OWNER LIKE '%&___OWNER___%'
AND OBJECT_TYPE = 'TABLE'
AND LAST_DDL_TIME > trunc(SYSDATE -  & ___SYSDATE___)
AND TEMPORARY LIKE 'N'
ORDER BY OBJECT_NAME;
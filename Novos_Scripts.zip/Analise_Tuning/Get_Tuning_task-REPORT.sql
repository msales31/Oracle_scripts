select dbms_sqltune.report_tuning_task('&TASK_NAME') from dual;

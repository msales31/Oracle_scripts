-- V13.2 - Carlos Furushima : Remodelagem do  - Correção linhas duplicadas para mesmo SQL TEXT
set timing on
set sqlblanklines on
alter session set nls_date_format='DD/MM/YYYY HH24:MI:SS';
SET PAGES 400
SET LINES 400
COL "SID" 9999 Head "Session ID|SID"  JUSTIFY center
COL "SERIAL#" 9999 Head "Session |Serial#"  JUSTIFY center
COL EVENT FORMAT A29 Head "Wait Event|Evento de Espera"  JUSTIFY center
COL "SQL TEXT" FORMAT A61 word_wrapped   HEADING  "       |               SQL or PL/SQL TEXT            |      "  JUSTIFY center
COL "SQLID_CHILDNUMBER" FORMAT A17 Head "SQL ID|Child Number"  JUSTIFY center
COL "SID SERIAL#" FORMAT A11 Head "SID|SERIAL#"  JUSTIFY center
COL "PGA USED MB" FORMAT 99999 Head "PGA|USED|MB"  JUSTIFY center
COL "TEMP USED MB" FORMAT 99999 Head "TEMP|USED|MB"  JUSTIFY center
COL "Offload" FORMAT A10 Head "OFFLOAD"  JUSTIFY center
COL "SEC_IN_WAIT" FORMAT 999 Head "Segs|in|wait"  JUSTIFY center
COL "SEC_IN_WAIT_WAIT_TIME" FORMAT a7 Head "Segs|in|wait"  JUSTIFY center
COL "SEC_IN_WAIT_WAIT_TIME" FORMAT a7 Head "Segs|in|wait"  JUSTIFY center
COL "LAST_CALL_ET" FORMAT 99999 Head "Last|Call|ET"  JUSTIFY center
COL "BLCKSESS" FORMAT a8 Head "BLCK|SESS"  JUSTIFY center
-- COL "BLCKSESS" FORMAT 99999 Head "BLCK|SESS"  JUSTIFY center
COL "OS PID" FORMAT A5 Head "OS|PID"  JUSTIFY center
COL "SECONDS WAITED" FORMAT a6 Head "SEC|WAITED"  JUSTIFY center
COL "OBJETO_PLSQL" FORMAT a22 Head "OBJETO|PLSQL"  JUSTIFY center
COL "PGA TEMP MB"  FORMAT a7 Head "PGA/TMP|MB"  JUSTIFY center
COL "ORIGEM"  FORMAT a18 Head "MACHINE|ORIGEM"  JUSTIFY center
COL "DETALHE CHAMADA"  FORMAT a35 Head "ORIGEM:DETALHE|CHAMADA|Mch->Usr->Pg->Call->CMD->Obj->COUNT_EXEC_SQL"  JUSTIFY center
-- COL "DETALHE CHAMADA"  FORMAT a35 Head "ORIGEM:DETALHE|CHAMADA"  JUSTIFY center



SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance FROM dual;
SET TERMOUT ON;

/* FURUSHIMA - WAITEVENT.sql */
with PLSQL_OBJ as
(select       /* NOIA WAITEVENT  */
decode(d_o.object_name, null, 'N.O.', d_o.object_name) as "OBJETO_PLSQL" ,
        sid , decode(vs.plsql_entry_object_id, null, 'N.O.', vs.plsql_entry_object_id) -- ,vs.plsql_entry_object_id
from dba_objects d_o right join v$session vs on d_o.object_id = vs.plsql_entry_object_id
where vs.status='ACTIVE'),
DBAOBJECTS as (
select object_id, object_name,  TO_CHAR(LAST_DDL_TIME, 'DD/MON') as "LAST_DDL_TIME" from dba_objects
union all
select 0 , 'Read UNDO', 'N/D' from dual
union all
select -1 , 'Wait bkg process', 'N/D' from dual
),
TX_INFO as
(select
   sid as SID,
   substr(s.username,1,18) as username,
   substr(s.program,1,15) as program,
decode(s.command, 0,'No Command', 1,'Create Table', 2,'Insert', 3,'Select', 6,'Update', 7,'Delete', 9,'Create Index', 15,'Alter Table', 21,'Create View', 23,'Validate Index', 35,'Alter Database', 39,'Create Tablespace', 41,'Drop Tablespace', 40,'Alter Tablespace', 47,'PL/SQL EXECUTE', 53,'Drop User', 62,'Analyze Table', 63,'Analyze Index',122,'NETWORK ERROR',128,'FLASHBACK',129,'CREATE SESSION',134,'ALTER PUBLIC SYNONYM',135,'DIRECTORY EXECUTE',136,'SQL*LOADER DIRECT PATH LOAD',137,'DATAPUMP DIRECT PATH UNLOAD',160,'CREATE JAVA',161,'ALTER JAVA',162,'DROP JAVA',170, 'CALL METHOD', s.command||': Other') as command
from v$session s , AUDIT_ACTIONS aa
where s.COMMAND=aa.ACTION ) ,
CURSOR_CACHE as (
  SELECT a.value curr_cached, p.value max_cached,
s.username, s.sid as SID, s.serial# as SERIAL#
FROM v$sesstat a, v$statname b, v$session s, v$parameter2 p
WHERE a.statistic# = b.statistic# and s.sid=a.sid
AND p.name='session_cached_cursors'
AND b.name = 'session cursor cache count') ,
TUDOM_SESSIONS as (
SELECT distinct *  FROM
(
    (SELECT W.SID as SID_SESSION_WAIT , W.WAIT_TIME as WAIT_TIME_SESSION_WAIT , W.EVENT as EVENT_SESSION_WAIT , W.SECONDS_IN_WAIT as SECONDS_IN_WAIT_SESSION_WAIT  , W.WAIT_CLASS as WAIT_CLASS_SESSION_WAIT FROM V$SESSION_WAIT W) A
    FULL OUTER JOIN
    ( select decode( WAIT_TIME, 0,'WAITING', 'ON CPU') session_state , V$SESSION.* from V$SESSION
        ) B on A.SID_SESSION_WAIT= B.sid
) where   (  status='ACTIVE'  and   wait_time > 0 )   or  (  wait_class != 'Idle'   )
),
V_SQL as (
select distinct
SQLT.SQL_TEXT as SQL_TEXT_NEWLINE ,
SQLT.PIECE as PIECE_NEWLINE ,
SQLT.ADDRESS as ADDRESS_NL ,
SQL.IO_CELL_OFFLOAD_ELIGIBLE_BYTES ,
SQL.SQL_ID as SQL_ID ,
SQL.HASH_VALUE as HASH_VALUE,
SQL.ADDRESS as ADDRESS,
SQL.CPU_TIME ,
SQL.CHILD_NUMBER as CHILD_NUMBER ,
SQL.PLAN_HASH_VALUE as PLAN_HASH_VALUE ,
SQL.EXECUTIONS as EXECUTIONS ,
decode(SQL.SQL_PLAN_BASELINE,null,' ','SQL PLAN Baseline USED') as BASELINE ,
decode(SQL.SQL_PROFILE,null,' ','SQL PROFILE USED') as PROFILE
       from V$SQLTEXT_WITH_NEWLINES  SQLT FULL OUTER JOIN V$SQL SQL
                on SQLT.SQL_ID = SQL.SQL_ID
                        and SQLT.HASH_VALUE = SQL.HASH_VALUE and SQLT.PIECE < 2
)
select  "SID SERIAL#" ,  "OS PID" , EVENT , BLCKSESS, "SQL TEXT", "DETALHE CHAMADA" , "SQLID_CHILDNUMBER" , "PGA USED MB" , "TEMP USED MB" , "SEC_IN_WAIT_WAIT_TIME" , LAST_CALL_ET from (
select distinct * from (
SELECT /* FURUSHIMA - WAITEVENT.sql */
ROW_NUMBER() OVER(ORDER BY SQL.PIECE_NEWLINE ASC) AS Row#,
                TDSESS.SID|| ',' ||TDSESS.SERIAL# "SID SERIAL#" ,
                to_char(P.SPID) "OS PID" ,
                TDSESS.EVENT,
                TDSESS.BLOCKING_INSTANCE ||':'|| TDSESS.BLOCKING_SESSION as BLCKSESS,
                REPLACE(DBMS_LOB.SUBSTR(SQL.SQL_TEXT_NEWLINE, 60), CHR(5)) "SQL TEXT",
                TDSESS.machine||' -> '||TDSESS.USERNAME||' -> '||txi.program||' -> '||OBJETO_PLSQL||' -> '||txi.command||' -> '|| OBJECT_NAME || ' -> ' ||  max_cached ||':'||curr_cached ||
                                ' -> '  || TDSESS.session_state || ' -> ' || SQL.executions || ' -> ' || SQL.BASELINE || ' ' || SQL.PROFILE     as "DETALHE CHAMADA",
                TDSESS.SQL_ID|| ':' ||TDSESS.SQL_CHILD_NUMBER "SQLID_CHILDNUMBER" ,
                ROUND(p.pga_used_mem/(1024*1024), 2) as "PGA USED MB",
                round(u.blocks * 8 / 1024) as "TEMP USED MB",
                to_char(DECODE(SIGN(TDSESS.WAIT_TIME), 1,'C',0,'W',-1,'C') ||' : '||TDSESS.SECONDS_IN_WAIT) as "SEC_IN_WAIT_WAIT_TIME" ,
                TDSESS.LAST_CALL_ET , SQL.PIECE_NEWLINE as PIECE
-----------------------------------------------
------------ CLAUSULAS FROM
-----------------------------------------------
FROM
                V$PROCESS P,
                V_SQL SQL ,
                TUDOM_SESSIONS TDSESS FULL OUTER JOIN PLSQL_OBJ plobj on   TDSESS.sid = plobj.sid
                                                                          FULL OUTER JOIN  DBAOBJECTS DBAOBJ on TDSESS.ROW_WAIT_OBJ# = DBAOBJ.OBJECT_ID
                                                                          FULL OUTER JOIN  TX_INFO txi on TDSESS.SID = txi.SID
                                                                          FULL OUTER JOIN  CURSOR_CACHE cc on TDSESS.SID = cc.SID
                                                                          left join v$sort_usage u on TDSESS.saddr = u.session_addr
-----------------------------------------------
------------ CLAUSULAS WHERE
-----------------------------------------------
WHERE
                                1=1
                                AND TDSESS.sid IS NOT NULL
                                AND TDSESS.paddr = p.addr
                                AND TDSESS.SQL_ID = SQL.SQL_ID
                                AND TDSESS.sql_hash_value = SQL.hash_value
                                AND TDSESS.sql_child_number = SQL.child_number
                                AND TDSESS.sql_address = SQL.address
                                AND SQL.PIECE_NEWLINE < 2
-----------------------------------------------
------------ CLAUSULAS ORDER BY
-----------------------------------------------
ORDER BY
TDSESS.LAST_CALL_ET  ,
TDSESS.SID_SESSION_WAIT ,
SQL.PIECE_NEWLINE    ) order by PIECE )
order by  11, 10 , 1 , PIECE  ;

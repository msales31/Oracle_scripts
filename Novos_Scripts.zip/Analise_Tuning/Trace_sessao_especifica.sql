begin
  execute immediate 'alter session set timed_statistics=TRUE';
  execute immediate 'alter session set sql_trace=TRUE';
  execute immediate 'alter session set statistics_level=ALL';
  execute immediate 'ALTER SESSION SET TRACEFILE_IDENTIFIER = ''BATCH_''';
  sp_atualizaVerbaBaixaPDV;
end;

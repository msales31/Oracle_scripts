EXEC DBMS_STATS.gather_table_stats (ownname => '&schema',tabname=> '&table',method_opt => 'FOR ALL COLUMNS SIZE AUTO',cascade=> true,DEGREE=>'&degree');

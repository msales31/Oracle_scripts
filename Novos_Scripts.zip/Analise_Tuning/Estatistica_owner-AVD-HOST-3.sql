EXEC DBMS_STATS.gather_schema_stats(ownname => '&OWNER',method_opt => 'FOR ALL COLUMNS SIZE AUTO',cascade=> true,DEGREE=>'&DEGREE');

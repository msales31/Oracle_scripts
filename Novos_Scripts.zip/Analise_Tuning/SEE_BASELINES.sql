select SQL_TEXT, SQL_HANDLE, PLAN_NAME, ENABLED,ACCEPTED FROM DBA_SQL_PLAN_BASELINES;


select SQL_TEXT, SQL_HANDLE, PLAN_NAME, ENABLED,ACCEPTED FROM DBA_SQL_PLAN_BASELINES;



select count(*)  FROM DBA_SQL_PLAN_BASELINES;



DBA_SQL_PLAN_BASELINES


declare
  l_cnt  pls_integer;
begin
  for i in ( select distinct plan_name from dba_sql_plan_baselines )
  loop
    l_cnt := 
        dbms_spm.drop_sql_plan_baseline (
            sql_handle => null,
            plan_name  => i.plan_name);
    
  end loop;  
end;
/



COLUMN parameter_name FORMAT A25
COLUMN parameter_value FORMAT a15

SELECT parameter_name, parameter_value
FROM   dba_advisor_parameters
WHERE  task_name = 'SYS_AUTO_SPM_EVOLVE_TASK'
AND    parameter_value != 'UNUSED'
ORDER BY parameter_name;


BEGIN
  DBMS_SPM.set_evolve_task_parameter(
    task_name => 'SYS_AUTO_SPM_EVOLVE_TASK',
    parameter => '_SPM_VERIFY',
    value     => 'FALSE');
END;
/

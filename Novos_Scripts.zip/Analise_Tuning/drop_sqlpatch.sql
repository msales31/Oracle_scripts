BEGIN
  SYS.DBMS_SQLDIAG.drop_sql_patch(name => '&sqlpatchname:');
END;
/

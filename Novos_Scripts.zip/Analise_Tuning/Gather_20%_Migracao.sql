select 'exec dbms_stats.gather_table_stats(''"'||a.owner||'"'' ,''"'||a.table_name||'"'',  cascade => true, method_opt=>''FOR ALL COLUMNS SIZE AUTO'', degree=>20);'
 from dba_tables a
 where a.temporary like 'N'
 and a.owner not in ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS',
 'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN',
 'OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS',
 'SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY',
 'WKSYS','WMSYS','XDB','ORACLE_OCM','PUBLIC');

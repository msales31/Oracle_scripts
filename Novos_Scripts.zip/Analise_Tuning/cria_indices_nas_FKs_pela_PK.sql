
DROP TABLE foreign_key_exceptions purge;

CREATE TABLE foreign_key_exceptions
           (owner           VARCHAR2(30),
            constraint_name VARCHAR2(30),
            status          VARCHAR2(8),
            table_name      VARCHAR2(30),
            foreign_key     VARCHAR2(2000),
            owner_pai       VARCHAR2(30),
            table_pai       VARCHAR2(30));

declare
  pl_cons_column VARCHAR2(30);
  pl_foreign_key VARCHAR2(2000);
  pl_ind_column  VARCHAR2(30);
  pl_ind_name    VARCHAR2(30);
  pl_ind_owner   VARCHAR2(30);
  pl_index       VARCHAR2(2000);
  tabela_pai     varchar2(200);

    CURSOR c1 IS SELECT c1.constraint_name, c1.owner, c1.table_name, c1.status, c1.r_constraint_name, c1.r_owner
                 FROM dba_constraints c1
                WHERE c1.constraint_type='R'
                  and c1.r_constraint_name in (select c2.constraint_name from dba_constraints c2 where c2.table_name = 'TRA_CTRC' and c2.owner = 'MGTRA' and c2.constraint_type in ('P','U') );

--  CURSOR c1 IS SELECT constraint_name,owner,table_name,status, r_constraint_name, r_owner
--                 FROM dba_constraints
--                WHERE constraint_type='R'
--                  AND owner in ('SBE_URBS')
--                  and table_name in ('USUARIO');
--                  AND owner not in ('SYSTEM','SYS','WKSYS','HR','EXFSYS','SYSMAN','DBSNMP','OWBREP');

/*  CURSOR c1 IS SELECT c1.constraint_name, c1.owner, c1.table_name, c1.status, c1.r_constraint_name, c1.r_owner
                 FROM dba_constraints c1
                WHERE constraint_type='R'
                  AND owner = 'OWNER'
                  and table_name in ('TABLE_NAME');*/

  CURSOR c2(cons_name VARCHAR2,cons_owner VARCHAR2) IS SELECT column_name
                 FROM dba_cons_columns
                WHERE constraint_name=cons_name
                  AND owner=cons_owner
                ORDER BY dba_cons_columns.position;

  CURSOR c3(ind_table varchar2,tab_owner varchar2) IS
                 SELECT index_name, owner
                 FROM dba_indexes
                WHERE table_name=ind_table
                  AND table_owner=tab_owner;
  CURSOR c4(ind_name varchar2,ind_owner varchar2) IS
                 SELECT column_name
                 FROM dba_ind_columns
                WHERE INDEX_NAME=ind_name
                  AND INDEX_OWNER=ind_owner
                 ORDER BY dba_ind_columns.column_position;
BEGIN

  delete foreign_key_exceptions;
  commit;

  FOR c1_rec in c1 LOOP

    pl_cons_column := NULL;
    pl_foreign_key := NULL;
    pl_ind_column := NULL;
    pl_ind_name := NULL;
    pl_ind_owner := NULL;
    pl_index := NULL;
    OPEN c2(c1_rec.constraint_name,c1_rec.owner);
    FETCH c2 INTO pl_cons_column;
    pl_foreign_key := pl_cons_column; -- the first col in the foreign key
<<constraint_names>>
    LOOP
      FETCH c2 into pl_cons_column;
      EXIT WHEN c2%NOTFOUND;
      pl_foreign_key := pl_foreign_key||','||pl_cons_column;
    END LOOP constraint_names;
    CLOSE c2;
    OPEN c3(c1_rec.table_name,c1_rec.owner);
<<index_name>>
    LOOP

      FETCH c3 INTO pl_ind_name,pl_ind_owner;
      EXIT WHEN c3%NOTFOUND;
      OPEN c4(pl_ind_name,pl_ind_owner);
      FETCH c4 INTO pl_ind_column;
      pl_index := pl_ind_column;        -- the first column in the index
      IF pl_index=pl_foreign_key THEN   -- check this doesn't already match
        CLOSE c4;                       -- the foreign key
        EXIT index_name;
      END IF;
      IF pl_index = SUBSTR(pl_foreign_key,1,LENGTH(pl_index)) THEN

<<index_columns>>
        LOOP

          FETCH c4 INTO pl_ind_column;
          EXIT WHEN c4%NOTFOUND;
          pl_index:= pl_index||','||pl_ind_column;

          IF pl_index=pl_foreign_key
          THEN
            CLOSE c4;
            EXIT index_name;
          END IF;

          IF pl_index != SUBSTR(pl_foreign_key,1,LENGTH(pl_index))
          THEN
             EXIT index_columns;
          END IF;
        END LOOP index_columns;
      END IF;
      CLOSE c4;
    END LOOP index_name;
    CLOSE c3;
    IF pl_index != pl_foreign_key OR pl_index IS NULL THEN

      select table_name into tabela_pai
         from dba_constraints
         where constraint_name = c1_rec.r_constraint_name
           and owner = c1_rec.r_owner;

      INSERT INTO foreign_key_exceptions VALUES
              (c1_rec.owner,c1_rec.constraint_name,c1_rec.status,
               c1_rec.table_name,pl_foreign_key,
               c1_rec.r_owner, tabela_pai);

      COMMIT;
    END IF;
  END LOOP;
END;
/

---------------------------------------------------------------
set linesize 20000
set heading off
set feedback off
set echo off

spool mk_indx.sql

select 'CREATE INDEX ' || owner || '.' || upper(constraint_name) || '_IDX ON ' || owner || '.' || table_name || '(' || upper(foreign_key) || ');'
from  foreign_key_exceptions;

spool off

set heading on
set feedback on
set echo on
---------------------------------------------------------------

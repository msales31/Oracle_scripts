SET VERIFY OFF
undefine sql_id;
col plan_hash_value for 999999999999999
PRO
WITH
p AS (
        SELECT plan_hash_value
          FROM gv$sql_plan
         WHERE sql_id = TRIM('&&sql_id.')
           AND other_xml IS NOT NULL
         UNION
        SELECT plan_hash_value
          FROM dba_hist_sql_plan
         WHERE sql_id = TRIM('&&sql_id.')
           AND other_xml IS NOT NULL ),
m AS (
        SELECT plan_hash_value,
               SUM(elapsed_time)/SUM(executions) avg_et_secs,
               SUM(executions) executions
          FROM gv$sql
         WHERE sql_id = TRIM('&&sql_id.')
           AND executions > 0
         GROUP BY
               plan_hash_value ),
a AS (
        SELECT plan_hash_value,
               SUM(elapsed_time_delta)/SUM(executions_delta) avg_et_secs,
               SUM(executions_delta) executions
          FROM dba_hist_sqlstat
         WHERE sql_id = TRIM('&&sql_id.')
           AND executions_delta > 0
         GROUP BY
               plan_hash_value )
SELECT
       TO_CHAR(ROUND(m.avg_et_secs/1e6, 6), '999,990.000000') avg_et_secs_mem,
       TO_CHAR(ROUND(a.avg_et_secs/1e6, 6), '999,990.000000') avg_et_secs_awr,
       p.plan_hash_value,
       m.executions executions_mem,
       a.executions executions_awr
       --TO_CHAR(ROUND(NVL(m.avg_et_secs, a.avg_et_secs)/1e6, 6), '999,990.000000') avg_et_secs
  FROM p, m, a
WHERE p.plan_hash_value = m.plan_hash_value(+)
   AND p.plan_hash_value = a.plan_hash_value(+)
ORDER BY
       NVL(m.avg_et_secs, a.avg_et_secs) NULLS LAST, a.avg_et_secs;
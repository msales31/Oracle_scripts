@ashtop event2,program,sql_id,sid 1=1 &hour

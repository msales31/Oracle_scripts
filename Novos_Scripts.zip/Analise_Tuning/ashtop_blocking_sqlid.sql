@ashtop event2,program,sql_id,sid,blocking_session sql_id='&sql_id' &hour

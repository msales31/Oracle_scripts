SET NUMWIDTH 7
COLUMN ID FORMAT 9;
COLUMN sid FORMAT 9999;
COLUMN serial FORMAT 999999;
COLUMN pid FORMAT 999;
COLUMN spid FORMAT A6;
COLUMN program FORMAT A30;
COLUMN username FORMAT A18;
COLUMN os_user FORMAT A16;
COLUMN event FORMAT A25;
COLUMN blstat FORMAT A12;
COLUMN sec FORMAT 9999999;
COLUMN last_call FORMAT A5;
COLUMN logon FORMAT A20;
COLUMN ELAPSED_LOGON FORMAT A6;
COLUMN MODULE FORMAT A25;
COLUMN sql_id FORMAT A14;
COLUMN pdb_name FORMAT A20;

SELECT /*+RULE*/ p.inst_id ID, 
       s.sid, 
       s.serial#, 
       p.pid, 
       p.spid, 
       s.sql_id,
       s.osuser AS os_user, 
       s.program, 
       s.username, 
       s.MODULE,
       c.name AS pdb_name,
       TO_CHAR(s.logon_time, 'DD-MM-YYYY HH24:MI:SS') logon,
       TO_CHAR(TRUNC((SYSDATE - s.logon_time) * 1440 / 60)) || ':' || 
       LTRIM(TO_CHAR(MOD((TRUNC((SYSDATE - s.logon_time) * 1440)), 60), '00')) ELAPSED_LOGON,
       TO_CHAR(TRUNC(s.LAST_CALL_ET / 3600)) || ':' || 
       LTRIM(TO_CHAR(TRUNC(s.LAST_CALL_ET / 60) - (TRUNC(s.LAST_CALL_ET / 3600) * 60), '00')) last_call,
       SUBSTR(sw.event, 1, 22) event
FROM gv$process p
JOIN gv$session s ON (p.inst_id = s.inst_id AND p.addr = s.paddr)
JOIN gv$session_wait sw ON (s.inst_id = sw.inst_id AND s.sid = sw.sid)
JOIN v$containers c ON (s.con_id = c.con_id)
WHERE s.type != 'BACKGROUND'
  AND s.status = 'ACTIVE'
  AND s.program NOT LIKE 'racgimon%'
  AND s.event NOT LIKE '%jobq slave wait%'
ORDER BY last_call DESC, p.inst_id, s.sid;

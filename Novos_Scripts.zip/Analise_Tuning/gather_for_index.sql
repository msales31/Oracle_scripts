EXEC DBMS_STATS.gather_index_stats('&owner', '&index_name');

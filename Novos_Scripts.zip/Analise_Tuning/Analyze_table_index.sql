
-- Check Analyzed Who:
SELECT /* +RULE */ 'exec dbms_stats.gather_'||c.OBJECT_TYPE||'_stats('''||a.OWNER||''',''"'||a.table_name||'"'',  estimate_percent => 1);'
                      FROM dba_tables a, dba_objects c 
                     WHERE (a.last_analyzed IS NULL OR a.last_analyzed < SYSDATE - 15) 
AND a.OWNER NOT IN ('APPQOSSYS','ANONYMOUS','BACKUP','BACKUPDUMP','BKPDMP','FLOWS_FILES','ORDDATA','OWBSYS','APEX_050000','APEX_050100','APEX_030200','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','GSMADMIN_INTERNAL', 
'MDDATA','MDSYS','MGMT_VIEW','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES', 
'QS_OS','QS_WS','RECOVER','SCOTT','SH','DVSYS','DBSFWUSER','SI_INFORMTN_SCHEMA','STANDBY','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','PUBLIC', 
'ORACLE_OCM','COMUM','TESTE','OJVMSYS','AUDSYS') AND a.temporary = 'N' AND a.table_name NOT IN 
        (SELECT table_name FROM dba_external_tables) AND a.table_name NOT IN 
            (SELECT TABLE_NAME FROM dba_tab_statistics 
            WHERE STATTYPE_LOCKED IS NOT NULL) 
            AND c.created < TRUNC (SYSDATE -15) 
            AND c.OBJECT_TYPE NOT IN ('SYNONYM')
            AND a.table_name = c.object_name 
			AND a.TABLE_NAME not in ('PLAN_TABLE','TOAD_PLAN_TABLE','TOAD_PLAN_SQL')
UNION ALL 			
SELECT /* +RULE */ 'exec dbms_stats.gather_'||c.OBJECT_TYPE||'_stats('''||a.OWNER||''',''"'||a.index_name||'"'',  estimate_percent => 1);'
        FROM dba_indexes a, dba_objects c 
        WHERE (a.last_analyzed IS NULL OR a.last_analyzed < SYSDATE - 15) 
	AND a.owner NOT IN 
('APPQOSSYS','DVSYS','DBSFWUSER','ANONYMOUS','BACKUP','BACKUPDUMP','BKPDMP','FLOWS_FILES','ORDDATA','OWBSYS','APEX_050000','APEX_050100','APEX_030200','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','GSMADMIN_INTERNAL', 'MDDATA','MDSYS','MGMT_VIEW','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES', 'QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','STANDBY','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','PUBLIC', 
'ORACLE_OCM','COMUM','TESTE','OJVMSYS','AUDSYS') AND a.temporary = 'N' 
    AND a.INDEX_TYPE != 'LOB' AND a.INDEX_TYPE != 'DOMAIN' AND a.STATUS <> 'UNUSABLE' 
    AND a.index_name NOT IN 
        (SELECT INDEX_NAME FROM DBA_IND_STATISTICS WHERE STATTYPE_LOCKED IS NOT NULL) 
            AND c.created < TRUNC (SYSDATE - 15) 
            AND c.OBJECT_TYPE NOT IN ('SYNONYM')
            AND a.index_name = c.object_name;
SELECT
  begin_interval_time,
  sql_id,
  plan_hash_value,
  NVL(executions_delta,0) execs,
  trunc((elapsed_time_delta  /DECODE(NVL(executions_delta,0),0,1,executions_delta))/1000000) avg_etime,
  trunc((buffer_gets_delta  /DECODE(NVL(buffer_gets_delta,0),0,1,executions_delta))) avg_lio,
  trunc((disk_reads_delta    /DECODE(NVL(buffer_gets_delta,0),0,1,executions_delta))) avg_pio,
  trunc((ROWS_PROCESSED_DELTA/DECODE(NVL(executions_delta,0),0,1,executions_delta))) avg_rows
FROM DBA_HIST_SQLSTAT S,
  DBA_HIST_SNAPSHOT SS
WHERE sql_id          = '9t980qrtvf2sd' -- adapt here
AND ss.snap_id        = S.snap_id
AND ss.instance_number = S.instance_number
AND executions_delta  > 0
and begin_interval_time > to_date('12062022','ddmmyyyy') -- adapt here
ORDER BY 1,2,3;


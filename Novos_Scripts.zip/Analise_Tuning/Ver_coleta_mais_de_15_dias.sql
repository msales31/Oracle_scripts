SELECT
    a.owner,
    a.object_name,
    a.object_type
FROM (
    SELECT a.owner,
           a.table_name AS object_name,
           'TABLE' AS object_type,
           a.last_analyzed
    FROM dba_tables a
    WHERE (a.last_analyzed IS NULL OR a.last_analyzed < SYSDATE - 15)
    AND a.OWNER NOT IN ('DBSFWUSER','APPQOSSYS','ANONYMOUS','BACKUP','BACKUPDUMP','BKPDMP','FLOWS_FILES','ORDDATA','OWBSYS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','GSMADMIN_INTERNAL', 'MDDATA','MDSYS','MGMT_VIEW','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','STANDBY','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','PUBLIC', 'ORACLE_OCM','COMUM','TESTE','OJVMSYS','AUDSYS','DVSYS')
    AND a.owner NOT LIKE 'APEX%'
    AND a.temporary = 'N'
    AND a.table_name NOT IN (SELECT table_name FROM dba_external_tables)
    AND a.table_name NOT IN (SELECT TABLE_NAME FROM dba_tab_statistics WHERE STATTYPE_LOCKED IS NOT NULL)
    AND a.table_name NOT IN ('PLAN_TABLE','TOAD_PLAN_TABLE','TOAD_PLAN_SQL')
    AND a.table_name IN (SELECT object_name FROM dba_objects WHERE created < TRUNC(SYSDATE - 15))
    UNION ALL
    SELECT a.owner,
           a.index_name AS object_name,
           'INDEX' AS object_type,
           a.last_analyzed
    FROM dba_indexes a
    WHERE (a.last_analyzed IS NULL OR a.last_analyzed < SYSDATE - 15)
    AND a.owner NOT IN ('APPQOSSYS','ANONYMOUS','BACKUP','BACKUPDUMP','BKPDMP','FLOWS_FILES','ORDDATA','OWBSYS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','GSMADMIN_INTERNAL', 'MDDATA','MDSYS','MGMT_VIEW','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES', 'QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','STANDBY','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','PUBLIC','ORACLE_OCM','COMUM','TESTE','OJVMSYS','AUDSYS','DVSYS','DBSFWUSER')
    AND a.owner NOT LIKE 'APEX%'
    AND a.temporary = 'N'
    AND a.INDEX_TYPE != 'LOB'
    AND a.INDEX_TYPE != 'DOMAIN'
    AND a.STATUS <> 'UNUSABLE'
    AND a.index_name NOT IN (SELECT INDEX_NAME FROM DBA_IND_STATISTICS WHERE STATTYPE_LOCKED IS NOT NULL)
    AND a.index_name IN (SELECT object_name FROM dba_objects WHERE created < TRUNC(SYSDATE - 15))
) a
ORDER BY a.owner, a.object_name, a.object_type;
drop table plan_table ;
/
delete from PLAN_TABLE where statement_id = 'Sales' ;
/
explain plan set STATEMENT_ID = 'Sales' for

### COLOCAR QUERY 






## EXECUTAR PARA CONSULTAR
select * from table (dbms_xplan.display ('PLAN_TABLE', 'Sales', 'ALL'));



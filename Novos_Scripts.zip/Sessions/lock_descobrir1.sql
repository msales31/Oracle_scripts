col machine format a70
SELECT  inst_id
       ,g.SID
       ,v.machine
       ,g.SERIAL#
       ,g.BLOCKING_INSTANCE
       ,g.BLOCKING_SESSION
FROM gv$session g, V$SESSION v
WHERE g.BLOCKING_SESSION is not null
and g.sid=v.sid
ORDER BY g.BLOCKING_INSTANCE, g.BLOCKING_SESSION;  
DECLARE
  l_owner VARCHAR2(30) := '&schema_name';
BEGIN
  FOR r IN (SELECT object_name, object_type FROM all_objects WHERE owner = l_owner) LOOP
    BEGIN
      IF r.object_type IN ('PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION', 'TRIGGER') THEN
        EXECUTE IMMEDIATE 'ALTER ' || r.object_type || ' ' || l_owner || '.' || r.object_name || ' COMPILE';
        DBMS_OUTPUT.put_line(r.object_type || ' ' || l_owner || '.' || r.object_name || ' compiled successfully.');
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.put_line(r.object_type || ' ' || l_owner || '.' || r.object_name || ' compilation failed: ' || SQLERRM);
    END;
  END LOOP;
END;
/
SELECT * FROM gv_$lock
  WHERE id1 = (SELECT object_id FROM DBA_objects WHERE owner ='&OWNER' AND object_name ='&TABLE_NAME');

--SELECT sid,serial# FROM v$session WHERE sid in (9,895,173);


--select 'alter system kill session ''' || sid || ',' || serial#  || ''' immediate;'
--from gv_$session where sid in (9,895,173);

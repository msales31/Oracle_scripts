set numwidth 7
column ID format 9;
column sid format 9999;
column serial format 999999;
column spid format a6;
column program format a24;
column username format a10;
column os_user format a16;
column event format a25;
column blstat format a12;
column sec format 9999999;
column last_call format a5;
column logon format a19;
column ELAPSED_LOGON format a6;
column sql_id format a14;
column service_name format a15;
select /*+RULE*/ p.inst_id id , s.sid, s.serial#, p.spid, s.sql_id, s.service_name,
       substr(s.action,1,10) action,
       substr(s.program,1,24) program, substr(s.username,1,10) username,
       to_char(logon_time, 'DD-MM-YYYY HH24:MI:SS') logon,
       to_char(trunc((SYSDATE - s.logon_time) * 1440 / 60)) || ':' || ltrim(to_char(mod((trunc((SYSDATE - s.logon_time) * 1440)),60),'00')) ELAPSED_LOGON,
       to_char(trunc(s.LAST_CALL_ET / 3600)) || ':' || ltrim(to_char(trunc(s.LAST_CALL_ET / 60) - (trunc(s.LAST_CALL_ET / 3600) * 60),'00')) last_call,
       substr(sw.event,1,22) event
from gv$process p, gv$session s, gv$session_wait sw
where (p.inst_id = s.inst_id and p.addr = s.paddr)
and (s.inst_id = sw.inst_id and s.sid = sw.sid)
and type != 'BACKGROUND'
and status = 'ACTIVE'
and s.program not like 'racgimon%'
and s.event  not like '%jobq slave wait%'
order by last_call desc, p.inst_id, s.sid;
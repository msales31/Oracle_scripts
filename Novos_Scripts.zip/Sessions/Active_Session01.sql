 -- IN Flight SQL
SELECT  nvl(ses.username,'ORACLE PROC')||' ('||ses.sid||')' USERNAME
       ,SID
       ,MACHINE
       ,REPLACE(SQL.SQL_TEXT,CHR(10),'') STMT
       ,ltrim(to_char(floor(SES.LAST_CALL_ET/3600),'09')) || ':' || ltrim(to_char(floor(mod(SES.LAST_CALL_ET,3600)/60),'09')) || ':' || ltrim(to_char(mod(SES.LAST_CALL_ET,60),'09')) RUNT
FROM V$SESSION SES, V$SQLtext_with_newlines SQL
WHERE 
SES.STATUS = 'ACTIVE' AND 
SES.USERNAME is not null 
AND SES.SQL_ADDRESS = SQL.ADDRESS 
AND SES.SQL_HASH_VALUE = SQL.HASH_VALUE 
AND Ses.AUDSID <> userenv('SESSIONID')
--and (ses.sid = 1520)
-- or ses.sid =3541 or ses.sid=1723 or ses.sid=523 or ses.sid=2611 or ses.sid=2048)
ORDER BY runt desc, 1,sql.piece; 
set serveroutput on
declare
sqlStmt VARCHAR2(1000);
BEGIN
For x in (SELECT SID,SERIAL# FROM V$SESSION WHERE STATUS='INACTIVE' AND last_call_et > '&timeinseconds') loop
sqlStmt := 'ALTER SYSTEM KILL SESSION ''' ||X.SId ||',' ||X.Serial# ||''' immediate' ;
dbms_output.put_line( sqlStmt );
EXECUTE IMMEDIATE sqlStmt;
End loop;
end;
/

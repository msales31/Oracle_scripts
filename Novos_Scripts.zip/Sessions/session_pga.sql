SET LINESIZE 500
SET PAGESIZE 1000
COLUMN username FORMAT A20
COLUMN osuser FORMAT A40
COLUMN sid FORMAT 999999
COLUMN spid FORMAT 999999
COLUMN service_name FORMAT A15
COLUMN module FORMAT A35
COLUMN machine FORMAT A30
COLUMN logon_time FORMAT A20
COLUMN pga_used_mem_mb FORMAT 99990.00
COLUMN pga_alloc_mem_mb FORMAT 99990.00
COLUMN pga_freeable_mem_mb FORMAT 99990.00
COLUMN pga_max_mem_mb FORMAT 99990.00
COLUMN program A30
SELECT NVL(s.username, '(oracle)') AS username,
-- s.osuser,
--s.sid,
--s.serial#,
--p.spid,
ROUND(p.pga_used_mem/1024/1024,2) AS pga_used_mem_mb,
ROUND(p.pga_alloc_mem/1024/1024,2) AS pga_alloc_mem_mb,
ROUND(p.pga_freeable_mem/1024/1024,2) AS pga_freeable_mem_mb,
ROUND(p.pga_max_mem/1024/1024,2) AS pga_max_mem_mb,
-- s.lockwait,
s.status,
s.service_name,
--s.module,
--s.machine,
--s.program,
--TO_CHAR(s.logon_Time,'DD-MON-YYYY HH24:MI:SS') AS logon_time,
s.last_call_et AS last_call_et_secs
FROM v$session s,
v$process p
WHERE s.paddr = p.addr
and s.service_name = 'tint'
ORDER BY pga_used_mem_mb,s.username, s.osuser;







--select component,current_size/1024/1024 from v$sga_dynamic_components;














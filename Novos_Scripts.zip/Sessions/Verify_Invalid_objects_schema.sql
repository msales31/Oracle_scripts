BREAK ON OWNER
column OBJECT_NAME format a50
column owner for a25
set linesize 200
set pagesize 9999


select OWNER,OBJECT_NAME, OBJECT_TYPE, STATUS
from dba_objects
where STATUS<> 'VALID' and
OWNER like upper('&owner')
order by 2
/
SELECT 'alter system kill session '''|| SID|| ','|| SERIAL#|| ',@'|| inst_id|| ''' immediate ;'
FROM gv$session
WHERE sql_id = '&sql_id';
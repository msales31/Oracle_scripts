with
Q1 as (
  select q1.INST_ID S_INST,
         q1.SID S_SID,
         q1.SERIAL# S_SERIAL,
         q1.SQL_ID Q_SQL,
         q1.START_TIME Q_START,
         q1.LAST_UPDATE_TIME Q_END,
         q1.ELAPSED_SECONDS Q_ELAPSED,
         q1.SOFAR W_COMPLETED,
         q1.TOTALWORK W_TOTAL,
         q1.TIME_REMAINING W_REMAINING,
         q1.MESSAGE W_MSG
    from GV$SESSION_LONGOPS q1
   where q1.TOTALWORK > 0
     and q1.SOFAR > 0
     and q1.ELAPSED_SECONDS > 3
     and (q1.SOFAR != q1.TOTALWORK or (sysdate - q1.LAST_UPDATE_TIME) < 0.03)
     and sysdate - q1.LAST_UPDATE_TIME < 0.5
)
select rpad (C1, max (length (C1)) over (), C0P) ||'('||
       rpad (C2, max (length (C2)) over (), C0P) ||','||
       rpad (C3, max (length (C3)) over (), C0P) ||')'||
       lpad (C4, max (length (C4)) over (), C0P) ||'|'||
       lpad (C5, max (length (C5)) over (), C0P) ||'|'||
       lpad (C6, max (length (C6)) over (), C0P) ||'|'||
       lpad (C7, max (length (C7)) over (), C0P) ||'|'||
       rpad (C8, max (length (C8)) over (), C0P)
from (
  (select 0 C0O, '_' C0P,
          'I' C1,
          'SID' C2,
          'SRAL' C3,
          'SQL' C4,
          'Start' C5, sysdate - 4000 C5O,
          'Done' C6,
          'End' C7,
          'Work' C8
     from dual)
union all
  (select 1 C0O, ' ' C0P,
          nvl (to_char (q1.S_INST), '???') C1,
          nvl (to_char (q1.S_SID), '???') C2,
          nvl (to_char (q1.S_SERIAL), '???') C3,
          nvl (q1.Q_SQL, ' ') C4,
          to_char (q1.Q_START, 'HH24:MI:SS') C5,
          q1.Q_START C5O,
          decode (q1.W_COMPLETED, q1.W_TOTAL, 'done',
            to_char (100 * q1.W_COMPLETED / greatest (q1.W_TOTAL, 1), 'FM990D0')||'%') C6,
          decode (q1.W_REMAINING, 0,
            to_char (q1.Q_END, 'HH24:MI:SS'),
            to_char (q1.W_REMAINING / 60, 'FM9990D0') ||'m') C7,
          substr (q1.W_MSG, 1, 70) C8
     from Q1 q1
  )
) where (C0O = 0
     or upper (C1 ||' '|| C2 ||' '|| C3 ||' '|| C4 ||' '|| C5 ||' '|| C6 ||' '|| C7 ||' '|| C8) like upper ('%&___SEARCH___%'))
order by C0O, C5O, C1, C2, C3, C4 ;

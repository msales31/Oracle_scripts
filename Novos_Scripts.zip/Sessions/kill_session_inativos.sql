--spool inativos.sql
set pages 4000
SELECT  'alter system kill session ''' || sid || ',' || serial# || ''' immediate;'
FROM v$session
WHERE username is not null 
--AND osuser <> 'oracle'
--and username= 'SISPAT'
and STATUS = 'INACTIVE';  
--spool off
--@inativos.sql
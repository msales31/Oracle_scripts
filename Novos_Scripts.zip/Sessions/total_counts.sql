select count(s.status) TOTAL_SESSIONS
from gv$session s
--where USERNAME='CCP'
;
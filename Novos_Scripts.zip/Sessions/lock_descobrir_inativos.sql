SELECT w.sid "WSid",
S1.inst_id "WInst",
P1.spid "WPid",
s1.osuser "WAITING OS-User",
h.sid "HSid",
S2.inst_id "HInst",
P2.spid "HPid",
S2.status "HStatus",
s2.osuser "HOLDING OS-User",
o.name "HOLDING Object"
FROM sys.gv_$process  P1,
sys.gv_$process  P2,
sys.gv_$session  S1,
sys.gv_$session  S2,
sys.gv_$lock     w,
sys.gv_$lock     h,
sys.obj$         o
WHERE w.LMODE = 0
AND h.request = 0
AND s1.row_wait_obj# = o.obj#
AND w.type(+) = h.type
AND w.id1(+) = h.id1
AND w.id2(+) = h.id2
AND w.sid = S1.sid
AND h.sid = S2.sid
AND S1.paddr = P1.addr(+)
AND S2.paddr = P2.addr(+)
AND S1.inst_id = w.inst_id
AND S2.inst_id = h.inst_id
AND S2.STATUS LIKE 'INACTIVE'
ORDER BY w.ctime DESC;
 col username format a30
 col machine format a30
SELECT  ss.username
       ,ss.MACHINE
       ,q1s.sql_id
       ,se.SID
       ,VALUE/100 cpu_usage_seconds
FROM v$session ss, v$sesstat se, v$statname sn, GV$SESSION q1s
WHERE se.STATISTIC# = sn.STATISTIC#
and q1s.sid = se.sid
AND NAME like '%CPU used by this session%' 
AND se.SID = ss.SID 
AND ss.status='ACTIVE' 
AND ss.username is not null
ORDER BY VALUE asc; 
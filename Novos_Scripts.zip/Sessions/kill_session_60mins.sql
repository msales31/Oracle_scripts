select '!kill -9 '||spid||';'
from gv$process p, gv$session s, gv$session_wait sw
where (p.inst_id = s.inst_id and p.addr = s.paddr)
and (s.inst_id = sw.inst_id and s.sid = sw.sid)
and type != 'BACKGROUND'
and (status = 'INACTIVE' or status = 'SNIPED')
AND s.LAST_CALL_ET > 60
--and logon_time < sysdate -1/24
and s.USERNAME not in ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM');

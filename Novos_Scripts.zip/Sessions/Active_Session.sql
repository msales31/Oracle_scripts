Rem ===================================================================================
Rem    NAME
Rem     session.sql - Script para mostrar os usuarios conectados ao banco
Rem
Rem    NOTE - Usuarios conectados
Rem
Rem ===================================================================================
set lines 	200
set pages 	400
set trimout 	on
set trimspool  	on
set feed 	on
set term 	on
set verify	off
col sid 		form 		9999
col serial# 		form 		999999
col username 		form 		a11
col status 		form 		a12 trunc
col osuser 		form 		a10 trunc
col machine 		form 		a19 trunc
col logon_time 		form 		a20
col module 		form		a20
col event               form a30 trunc
col action		form		a20
col program		form		a20
col rows_processed	form		99,999,999,999
col inst_id             form            9999
undef sid
undef username
select
s.inst_id,
s.sid,
s.serial#,
s.username,
s.status,
s.osuser,
s.server,
s.SECONDS_IN_WAIT,
s.EVENT,
substr(s.machine,1,34) machine,
to_char(s.logon_time, 'dd/mm/yyyy hh24:mi:ss') logon_time
from 	gv$session s, gv$process p
where s.username is not null
and   s.inst_id=p.inst_id
and   s.paddr=p.addr
and   s.status like nvl(upper('ACTIVE'),'%')
Order by SECONDS_IN_WAIT DESC
/
################
## SESSIONS 3
################

with
Q1 as (
select q1s.INST_ID S_INST, q1s.SID S_SID, q1s.SERIAL# S_SERIAL, q1p.SPID S_PID,
q1s.LOCKWAIT S_LW, q1s.SQL_TRACE S_TRACE, q1s.EVENT S_EVENT,
decode (q1s.SQL_ID, null,
decode (decode (q1s.SQL_HASH_VALUE, 0, null, q1s.SQL_HASH_VALUE), null,
decode (q1s.PREV_SQL_ID, null,
decode (decode (q1s.PREV_HASH_VALUE, 0, null, q1s.PREV_HASH_VALUE), null, ' ',
'~'|| q1s.PREV_HASH_VALUE),
'~'|| q1s.PREV_SQL_ID),
'!'|| q1s.SQL_HASH_VALUE),
'!'|| q1s.SQL_ID
) S_SQL,
nvl (q1s.COMMAND, 0) S_CMD,
substr (nvl (decode (q1s.STATUS, 'INACTIVE', ' ', q1s.STATUS), '?'), 1, 1) S_STATUS,
q1s.LAST_CALL_ET S_LASTCALL,
nvl (q1s.USERNAME, '<oracle>') S_USER,
decode (q1s.MODULE,
'Data Pump Worker', '-<dp-worker='|| q1s.ACTION ||'> --- ',
'Data Pump Master', '-<dp-master='|| q1s.ACTION ||'> --- ',
'DBMS_SCHEDULER', '-<jobsched='||
nvl ((select q1j.JOB_NAME ||
decode (q1j.JOB_SUBNAME, null, '', '/'|| q1j.JOB_SUBNAME)
from DBA_SCHEDULER_RUNNING_JOBS q1j
where q1j.SESSION_ID = q1s.SID
and q1j.RUNNING_INSTANCE = q1s.INST_ID), q1s.ACTION)||'> --- ') ||
(select '-<job='|| q1j.ID2 || '> --- '
from GV$LOCK q1j
where q1j.TYPE = 'JQ'
and q1j.INST_ID = q1s.INST_ID
and q1j.SID = q1s.SID) ||
decode (substr (q1s.PROGRAM, 1, 5),
'rman@', '-<rman='|| decode (substr (q1s.MODULE, 1, 5),
'rman@', upper (q1s.ACTION), upper (q1s.MODULE)) ||':'|| q1s.CLIENT_INFO ||'> --- ', '') ||
decode (substr (q1s.PROGRAM, 1, 4),
'exp@', '-<export='|| to_char (q1s.LOGON_TIME, 'DDMon/HH24:MI') ||'> --- ',
'imp@', '-<import='|| to_char (q1s.LOGON_TIME, 'DDMon/HH24:MI') ||'> --- ', '') ||
decode (substr (q1s.MODULE, 1, 4),
'ude@', '-<dp-export='|| to_char (q1s.LOGON_TIME, 'DDMon/HH24:MI') ||'> --- ',
'udi@', '-<dp-import='|| to_char (q1s.LOGON_TIME, 'DDMon/HH24:MI') ||'> --- ', '') ||
decode (trim (q1s.OSUSER), null, '', '', '', q1s.OSUSER ||',') ||
decode (trim (q1s.MACHINE), null, '', '', '', q1s.MACHINE ||',') ||
decode (trim (q1s.MODULE), null, '', '', '', q1s.MODULE ||',') ||
decode (trim (q1s.PROGRAM), null, '', '', '', q1s.PROGRAM ||',') ||
decode (trim (q1s.CLIENT_INFO), null, '', '', '', q1s.CLIENT_INFO ||',') ||
decode (trim (q1s.ACTION), null, '', '', '', q1s.ACTION ||',')
S_CLIENT
from GV$SESSION q1s,
GV$PROCESS q1p
where q1s.USERNAME is not null
and q1s.TYPE != 'BACKGROUND'
and (q1s.MODULE is null or substr (q1s.MODULE, 1, 9) != 'racgimon@')
and q1s.INST_ID = q1p.INST_ID (+)
and q1s.PADDR = q1p.ADDR (+)
),
Q2 as (
select q2s.INST_ID S_INST, q2s.SID S_SID, sum (q2s.VALUE) S_REDO
from GV$SESSTAT q2s,
GV$STATNAME q2n
where q2s.INST_ID = q2n.INST_ID
and q2s.STATISTIC# = q2n.STATISTIC#
and upper (q2n.NAME) = 'REDO SIZE'
and q2s.VALUE is not null
and q2s.VALUE >= 1
group by q2s.INST_ID, q2s.SID
),
Q3 as (
select q3s.INST_ID S_INST, q3s.SID S_SID, sum (q3s.VALUE) S_UNDO
from GV$SESSTAT q3s,
GV$STATNAME q3n
where q3s.INST_ID = q3n.INST_ID
and q3s.STATISTIC# = q3n.STATISTIC#
and upper (q3n.NAME) = 'UNDO CHANGE VECTOR SIZE'
and q3s.VALUE is not null
and q3s.VALUE >= 1
group by q3s.INST_ID, q3s.SID
),
Q4 as (
select q4l.INST_ID S_INST, q4l.SESSION_ID S_SID, count (q4l.OBJECT_ID) S_LCK
from GV$LOCKED_OBJECT q4l
where q4l.LOCKED_MODE not in (0, 1)
group by q4l.INST_ID, q4l.SESSION_ID
),
Q5 as (
select q5l.KADDR S_LW, q5l.ID1 S_LW1, q5l.ID2 S_LW2
from GV$LOCK q5l
where q5l.BLOCK = 0
),
Q6 as (
select q6l.INST_ID S_INST, q6l.SID S_SID, q6l.ID1 S_LH1, q6l.ID2 S_LH2
from GV$LOCK q6l
where q6l.BLOCK != 0
and q6l.LMODE not in (0, 1)
)
select substr (S, 1, 123)
from (
select lpad (C1, max (length (C1)) over (), C0P) ||'#'||
lpad (C2, max (length (C2)) over (), C0P) ||'('||
lpad (C3, max (length (C3)) over (), C0P) ||','||
rpad (C4, max (length (C4)) over (), C0P) ||')'||
lpad (C5, max (length (C5)) over (), C0P) ||'|'||
lpad (C6, max (length (C6)) over (), C0P) ||':'||
lpad (C7, max (length (C7)) over (), C0P) ||'|'||
lpad (C8, max (length (C8)) over (), C0P) ||'|'||
lpad (C9, max (length (C9)) over (), C0P) ||'|'||
lpad (C10, max (length (C10)) over (), C0P) ||'|'||
rpad (C11, max (length (C11)) over (), C0P) ||'|'||
rpad (C12, max (length (C12)) over (), C0P) S
from (
(select 0 C0O, '_' C0P,
'I' C1,
'PID' C2,
'SID' C3,
'SRIAL' C4,
'SQL' C5,
'L' C6,
'S' C7, -1 C7O,
'TIME' C8, -1 C8O,
'REDO' C9,
'UNDO' C10, -1 C10O,
'User' C11,
'Client' C12
from dual)
union all
(select 2 C0O, '_' C0P,
'I' C1,
'PID' C2,
'SID' C3,
'SRIAL' C4,
'_' C5,
'_' C6,
'_' C7, -1 C7O,
'TIME' C8, -1 C8O,
'REDO' C9,
'UNDO' C10, -1 C10O,
'_' C11,
'_' C12
from dual)
union all
(select 1 C0O, ' ' C0P,
nvl (to_char (q1.S_INST), '???') C1,
nvl (to_char (q1.S_PID), '???') C2,
nvl (to_char (q1.S_SID), '???') C3,
nvl (to_char (q1.S_SERIAL), '???') C4,
nvl (q1.S_SQL, '???') C5,
decode (q4.S_LCK, null, ' ', 0, ' ', to_char (q4.S_LCK, 'FM9999990')) C6,
nvl (q1.S_STATUS, '?') C7,
decode (substr (q1.S_CLIENT, 1, 1), '-', 8,
decode (q1.S_LW, null,
decode (q1.S_STATUS, 'S', 0, 'K', 1, ' ', 2, 'C', 3, 'A', 6)
, 9)) C7O,
decode (least (180, q1.S_LASTCALL), 180,
to_char (greatest (0, ceil (q1.S_LASTCALL / 60 / 60) - 1), 'FM9999990') ||'h'||
to_char (mod (q1.S_LASTCALL / 60, 60), 'FM90') ||'m',
decode (q1.S_STATUS, 'A', q1.S_LASTCALL ||'s', ' ')) ||
decode (q1.S_TRACE, 'ENABLED', '-@', '') C8,
decode (q1.S_STATUS, ' ', 0 - q1.S_LASTCALL, q1.S_LASTCALL) C8O,
decode (q1.S_LW, null,
decode (greatest (q2.S_REDO, 1047527423), 1047527423,
decode (greatest (q2.S_REDO, 1022975), 1022975,
to_char (q2.S_REDO / 1024, 'FM990') ||'K',
to_char (q2.S_REDO / 1048576, 'FM990') ||'M'),
decode (q2.S_REDO, null, ' ', 0, ' ',
to_char (q2.S_REDO / 1073741824, 'FM990') ||'G')), '*LCK*') C9,
decode (q1.S_LW, null,
decode (greatest (q3.S_UNDO, 1047527423), 1047527423,
decode (greatest (q3.S_UNDO, 1022975), 1022975,
to_char (q3.S_UNDO / 1024, 'FM990') ||'K',
to_char (q3.S_UNDO / 1048576, 'FM990') ||'M'),
decode (q3.S_UNDO, null, ' ', 0, ' ',
to_char (q3.S_UNDO / 1073741824, 'FM990') ||'G')),
'<'|| q6.S_INST ||'.'|| q6.S_SID ||'>') C10,
decode (q1.S_LW, null, 0, 1) C10O,
q1.S_USER C11,
decode (sys_context ('USERENV','SID'), q1.S_SID,
decode (sys_context ('USERENV','INSTANCE'), q1.S_INST, '--- MYSESSION --- ', ''), '') ||
decode (least (5, q1.S_LASTCALL), 5,
decode (a.NAME, null, '', 'UNKNOWN', '', upper (a.NAME) ||'] '), '') ||
decode ('&___1_CLIENT___2_EVENT___', '2',
decode (q1.S_EVENT, 'SQL*Net message from client', ' ', q1.S_EVENT), q1.S_CLIENT) C12
from Q1 q1,
AUDIT_ACTIONS a,
Q2 q2,
Q3 q3,
Q4 q4,
Q5 q5,
Q6 q6
where q1.S_CMD = a.ACTION (+)
and q1.S_INST = q2.S_INST (+)
and q1.S_SID = q2.S_SID (+)
and q1.S_INST = q3.S_INST (+)
and q1.S_SID = q3.S_SID (+)
and q1.S_INST = q4.S_INST (+)
and q1.S_SID = q4.S_SID (+)
and q1.S_LW = q5.S_LW (+)
and q5.S_LW1 = q6.S_LH1 (+)
and q5.S_LW2 = q6.S_LH2 (+)
)
) order by C0O, C7O, C10O, C8O, C12
) where ROWNUM = 1 or upper (S) like upper ('%&___SEARCH___%') ;

set lines 4000
col status format a20
col program format a20
col pid format a10
col username format a20
col os_user format a20
select
       substr(a.spid,1,9) pid,
       substr(b.sid,1,5) sid,
       substr(b.serial#,1,5) ser#,
--       substr(b.machine,1,25) box,
       substr(b.username,1,10) username,
       substr(b.status,1,10) status,
       substr(b.module,1,10) module,
--       TO_CHAR(b.logon_Time,'DD-MON-YYYY HH24:MI:SS') AS logon_time,
--       substr(b.osuser,1,8) os_user,
       substr(b.program,1,30) program,
       substr(b.action,1,10) action
from v$session b, v$process a
where
b.paddr = a.addr
and type='USER'
and b.sid in (&sid)
--===and b.username='CS271002'
--and (b.sid = 4766 or b.sid = 1551 or b.sid=3411 or b.sid=7206 or b.sid=7256)
order by b.sid desc; 

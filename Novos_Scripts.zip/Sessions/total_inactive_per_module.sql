col program for a60
COL MODULE FOR A30
prompt TOTAL SESSIONS
col INACTIVE_PROGRAMS FOR A40
select s.module,count(s.module) Total_Inactive_Sessions, s.status
from gv$session s,v$process p
where p.addr=s.paddr 
--AND s.status='INACTIVE'
group by s.module
order by 2 desc;
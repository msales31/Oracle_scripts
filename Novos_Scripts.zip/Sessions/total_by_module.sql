col module for a30
prompt TOTAL SESSIONS
select s.module,count(s.sid) Total_Sessions
from gv$session s, v$process p
where p.addr=s.paddr
group by s.module
order by Total_Sessions;
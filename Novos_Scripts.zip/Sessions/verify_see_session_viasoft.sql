COLUMN machine FORMAT A20
COLUMN program FORMAT A50
COLUMN osuser FORMAT A15
COLUMN module FORMAT A30
COLUMN sid FORMAT 9999
COLUMN logon_time FORMAT A30

SELECT machine, program, osuser, module, sid, logon_time
FROM gv$session
WHERE machine LIKE '%GRAV%'
ORDER BY logon_time;

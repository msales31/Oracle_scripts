col program for a30
select s.program,count(s.program) Total_Sessions
from gv$session s, v$process p
where p.addr=s.paddr
group by s.program
order by 2;
SELECT  'alter system kill session ''' || sid || ',' || serial# || ''' immediate;'
FROM v$session
WHERE username is not null 
AND osuser <> 'oracle' 
AND username ='&USERNAME';  
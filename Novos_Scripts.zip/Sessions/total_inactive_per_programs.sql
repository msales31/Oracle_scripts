col program for a30
prompt TOTAL INACTIVE SESSIONS
col INACTIVE_PROGRAMS FOR A40
select s.program,count(s.program) Total_Inactive_Sessions
from gv$session s,v$process p
where p.addr=s.paddr AND
s.status='INACTIVE'
group by s.program
order by 2 desc;
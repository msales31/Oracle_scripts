column  sid         format   99999
column  serial#         format   999999
column  operation   format   a11    heading 'Acao'
column  object      format   a35    heading 'Objeto'
column  executado   format   99999999 heading 'BLK|Lidos'
column  total       format   99999999 heading 'BLK|Total'
column  pct         format   990.90   heading 'PCT(%)'
column  rate        format   a08      heading 'Rate|Mb/Min'
column  l_update    format   a11    heading 'Dt Start'
column  t_elap      format   a11 heading 'Elapsed|DD:HH:MI:SS'
column  t_remain    format   a11 heading 'Remaining|DD:HH:MI:SS'
column  unidade     format   a3     heading 'Uni'
--accept SesID prompt 'Informe Sid: '
select sid,
serial#,
decode(opname,'Hash Join',    'Hash Join',
'Index Fast Full Scan','Index Scan',
'Sort Output',         'Sort Output',
'Sort/Merge',          'Sort Merge',
'Table Scan',          'Table Scan',
'-') operation,
target object,
SQL_ID,
sofar executado,
totalwork total,
trunc((sofar/totalwork)*100,2) pct,
to_char(60*sofar*8192/(24*60*(last_update_time - start_time))/1024/1024/60, '9990.90') Rate,
to_char(start_time, 'DD/MM HH24:MI') l_update,
trunc(elapsed_seconds/86400)|| ':'
|| to_char(to_date(mod(elapsed_seconds,86400), 'SSSSS'), 'HH24:MI:SS') t_elap,
trunc(time_remaining/86400)|| ':'
|| to_char(to_date(mod(time_remaining,86400), 'SSSSS'), 'HH24:MI:SS') t_remain
from v$session_longops
where time_remaining > 0
order by start_time;
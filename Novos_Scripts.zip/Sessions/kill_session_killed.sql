select 'alter system kill session ''' || sid || ',' || serial#  || ''' immediate;'
from v$session where username is not null and osuser <> 'oracle'
and status like '%KILLED%';

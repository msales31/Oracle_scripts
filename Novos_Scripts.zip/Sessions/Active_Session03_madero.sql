-- SESSION/PROCESS REFERENCE:
-- This section is very important for most of the above sections to find out
-- which user/os_user/process is identified to which session/process.
--to_char(trunc((SYSDATE - s.logon_time) * 1440 / 60)) || ':' || ltrim(to_char(mod((trunc((SYSDATE - s.logon_time) * 1440)),60),'00')) ELAPSED_LOGON2
set numwidth 7
column ID format 9;
column sid format 9999;
column serial format 999999;
column pid format 999;
column spid format a6;
column program format a20;
column username format a10;
--column os_user format a10;
column event format a20;
column blstat format a12;
column sec format 9999999;
column last_call format a5;
column logon format a20;
column ELAPSED_LOGON format a6;
col SERVICE_NAME for a25
column sql_id format a14;
select /*+RULE*/ p.inst_id id , s.sid, s.serial#, p.pid, p.spid, s.sql_id,
--osuser os_user, 
s.program, s.username, s.SERVICE_NAME
,to_char(logon_time, 'DD-MM-YYYY HH24:MI:SS') logon
,to_char(trunc((SYSDATE - s.logon_time) * 1440 / 60)) || ':' || ltrim(to_char(mod((trunc((SYSDATE - s.logon_time) * 1440)),60),'00')) ELAPSED_LOGON
,to_char(trunc(s.LAST_CALL_ET / 3600)) || ':' || ltrim(to_char(trunc(s.LAST_CALL_ET / 60) - (trunc(s.LAST_CALL_ET / 3600) * 60),'00')) last_call
,substr(sw.event,1,22) event
from gv$process p, gv$session s, gv$session_wait sw
where (p.inst_id = s.inst_id and p.addr = s.paddr)
and (s.inst_id = sw.inst_id and s.sid = sw.sid)
and type != 'BACKGROUND'
and status = 'ACTIVE'
and lower(s.service_name) like 'prothprdintegracao'
and s.program not like 'racgimon%'
and s.event not like '%jobq slave wait%'
order by last_call desc, p.inst_id, s.sid;



col host format a30
col owner format a30
col db_link format a40
set lines 30000
SELECT  host
       ,owner
       ,db_link
FROM dba_db_links; 
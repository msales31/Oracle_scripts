select 'conn ' || OWNER || ';' || CHR(10) ||
      'create ' ||
       case when a.OWNER='PUBLIC' then 'public database link ' else 'database link ' end ||
      a.DB_LINK || ' connect to ' || a.USERNAME || ' identified by values ' ||''''|| b.PASSWORDX ||'''' ||
      ' using ' || '''' || UPPER(a.HOST) || '''' || ';'
from dba_db_links a,
    link$ b
where lower(a.DB_LINK) = lower(b.name)
order by a.owner;
SELECT  
--'HOST: ' || HOST || 
'CREATE VIEW '||owner||'.for_dblink_test_only AS
SELECT  *
FROM dual@'||db_link||';', 'DROP VIEW '||owner||'.for_dblink_test_only;'
FROM dba_db_links
WHERE username is not null
and DB_LINK='LINK_SIV.WORLD'; 

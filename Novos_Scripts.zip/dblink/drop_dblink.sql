set serveroutput on
DECLARE
l_sql CLOB :=
'CREATE PROCEDURE <OWNER>.drop_db_links_prc
IS
BEGIN
FOR i IN (SELECT * FROM user_db_links)
LOOP
dbms_output.put_line(''to drop ''||i.db_link);
EXECUTE IMMEDIATE ''DROP DATABASE LINK ''||i.db_link;
END LOOP;
END;';
l_sql1 clob;
BEGIN
FOR i in (SELECT DISTINCT owner
FROM dba_objects
WHERE owner IN ('RM')
AND object_type='DATABASE LINK')
LOOP
l_sql1 := REPLACE(l_sql, '<OWNER>', i.owner);
dbms_output.put_line(l_sql1);
EXECUTE IMMEDIATE l_sql1;

l_sql1 := 'BEGIN '||i.owner||'.drop_db_links_prc; END;';

EXECUTE IMMEDIATE l_sql1;

l_sql1 := 'DROP PROCEDURE '||i.owner||'.drop_db_links_prc';



EXECUTE IMMEDIATE l_sql1;
END loop;
END;
/
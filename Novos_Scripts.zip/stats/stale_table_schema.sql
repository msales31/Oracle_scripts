Column table_name for a30
select LAST_ANALYZED,STATTYPE_LOCKED,table_name from dba_tab_statistics where owner='&schema' and stale_stats ='YES';
SELECT 'exec dbms_stats.gather_table_stats(ownname => ''' || t.owner || ''',tabname => ''' || t.TABLE_NAME || ''', METHOD_OPT => ''FOR TABLE FOR ALL COLUMNS SIZE AUTO'', cascade => TRUE , degree=> 2);'
from dba_tables t, dba_tab_statistics s
where t.owner=s.owner
and t.table_name=s.table_name
and t.owner like ('%&schema%')
and t.temporary = 'N'
and s.STALE_STATS='YES';

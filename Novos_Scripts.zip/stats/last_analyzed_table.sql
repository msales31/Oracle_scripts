select owner, table_name, last_analyzed, global_stats
from dba_tables
where owner in ('&owner')
AND table_name IN (
'&table_name'
)
order by owner, table_name
/
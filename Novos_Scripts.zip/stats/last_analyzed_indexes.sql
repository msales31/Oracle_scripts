set tab off underline off linesize 2050 newpage none pagesize 4000
set feedback on colsep | editfile /tmp/sqlplusedit.tmp long 10000000 trimout on;
set numwidth 13;
set serveroutput on size 1000000 trimspool on longchunksize 10000000 time on;
spool 06-analyzed_indexes.log;
col owner format a18;
col analyzed format a11;
col index format a5;
select owner, to_char(last_analyzed,'DD/MM/YYYY') analyzed, 'INDEX' from dba_indexes  where temporary != 'Y' group by owner, to_char(last_analyzed,'DD/MM/YYYY') order by owner;
spool off;

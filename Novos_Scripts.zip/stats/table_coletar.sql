BEGIN
DBMS_STATS.GATHER_TABLE_STATS (
ownname => '&schema',
tabname => '&tabela',
cascade => true, -- For collecting stats for respective indexes
method_opt=>'for all indexed columns size 1',
granularity => 'ALL',
estimate_percent =>1,
degree => 4);
END;
/
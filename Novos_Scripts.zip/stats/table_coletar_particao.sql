BEGIN
DBMS_STATS.GATHER_TABLE_STATS (
ownname => 'HR',
tabname => 'EMP', — TABLE NAME
partname => 'EMP_P1' — PARTITOIN NAME
method_opt=>'for all indexed columns size 1',
GRANULARITY => 'APPROX_GLOBAL AND PARTITION',
degree => 8);
END;
/


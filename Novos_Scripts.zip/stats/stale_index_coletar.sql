SELECT 'exec dbms_stats.gather_index_stats(ownname => ''' || t.owner || ''',indname => ''' || t.index_name || ''', estimate_percent =>DBMS_STATS.AUTO_SAMPLE_SIZE, degree=> 2);'
from dba_indexes t, dba_ind_statistics s
where t.owner=s.owner
and t.index_name=s.index_name
and t.owner like ('%&schema%')
and s.STALE_STATS='YES';

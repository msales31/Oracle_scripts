select owner, index_name, last_analyzed, global_stats
from dba_indexes
where owner in ('&owner')
AND INDEX_NAME IN ('&index_name')
order by owner, index_name
/

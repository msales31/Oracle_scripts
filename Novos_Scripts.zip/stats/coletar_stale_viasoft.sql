set lines 2000
spool stat.sql
SELECT 'exec dbms_stats.gather_table_stats(ownname => ''' || t.owner || ''',tabname => ''' || t.TABLE_NAME || ''', METHOD_OPT => ''FOR TABLE FOR ALL COLUMNS SIZE AUTO'', cascade => TRUE , degree=> 1);'
from dba_tables t, dba_tab_statistics s
where t.owner=s.owner
and t.table_name=s.table_name
and t.owner like ('%VIA%')
and t.temporary = 'N'
and s.STALE_STATS='YES';

SELECT 'exec dbms_stats.gather_index_stats(ownname => ''' || t.owner || ''',indname => ''' || t.index_name || ''', estimate_percent =>DBMS_STATS.AUTO_SAMPLE_SIZE, degree=> 1);'
from dba_indexes t, dba_ind_statistics s
where t.owner=s.owner
and t.index_name=s.index_name
and t.owner like ('%VIA%')
and t.temporary = 'N'
and s.STALE_STATS='YES';
spool off
@stat.sql
Begin
dbms_stats.gather_schema_stats(
ownname => '&schema',
options => 'GATHER AUTO',
estimate_percent => dbms_stats.auto_sample_size,
method_opt => 'for all columns size repeat',
degree => 2
);
END;
/
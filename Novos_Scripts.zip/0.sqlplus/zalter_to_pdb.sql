show pdbs
alter session set container=&PDBNAME;
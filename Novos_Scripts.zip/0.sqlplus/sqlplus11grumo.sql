sqlplus /nolog 
conn TR030380_ADM/"Trem!1610"
set tab off underline off linesize 2050 newpage none pagesize 4000 appinfo "dba";
set feedback on colsep | editfile /tmp/reginaldo-sqlplusedit.tmp long 1000000 trimout on;
set serveroutput on size 1000000 trimspool on longchunksize 1000000 time on;
--set sqlblanklines on timing on sqlprompt "_user'@'_connect_identifier> ";
def;
show user;
show parameter unique;
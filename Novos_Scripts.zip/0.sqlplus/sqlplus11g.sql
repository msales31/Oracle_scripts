cd /home/msales/dtu_public
export NLS_DATE_FORMAT='yyyy/mm/dd hh24:mi:ss'
sqlplus /nolog
conn / as sysdba
set tab off underline off linesize 2050 newpage none pagesize 4000 appinfo "dba";
set feedback on colsep | editfile /tmp/reginaldo-sqlplusedit.tmp long 1000000 trimout on;
set serveroutput on size 1000000 trimspool on longchunksize 1000000 time on;
set sqlblanklines on timing on sqlprompt "_user'@'_connect_identifier> ";
ALTER SESSION SET NLS_DATE_FORMAT = 'dd/mm/yyyy hh24:mi:ss';
def;
select open_mode from v$database;
@login
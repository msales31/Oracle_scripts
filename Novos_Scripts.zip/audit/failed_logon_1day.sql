col os_username format A18;
col username format A25;
col terminal format A25;
col INTERVAL format num_failed_logins;
SELECT os_username, username, terminal, COUNT(*) as num_failed_logins
FROM dba_audit_session
WHERE action_name = 'LOGON' AND returncode != 0
AND timestamp >= (SYSDATE - 1)
GROUP BY os_username, username, terminal;
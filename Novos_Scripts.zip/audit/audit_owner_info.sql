SELECT user_name,
       audit_option,
       success,
       failure
FROM   dba_stmt_audit_opts
WHERE  UPPER(user_name) = '&nomeuser'
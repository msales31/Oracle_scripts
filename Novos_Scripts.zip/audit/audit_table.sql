CREATE TABLE CONSINCO.exemplo_tabela (
    id NUMBER,
    nome VARCHAR2(50)
);


INSERT INTO CONSINCO.exemplo_tabela (id, nome) VALUES (1, 'João da Silva');
INSERT INTO CONSINCO.exemplo_tabela (id, nome) VALUES (2, 'Maria Souza');
INSERT INTO CONSINCO.exemplo_tabela (id, nome) VALUES (3, 'José Santos');


AUDIT  UPDATE, DELETE,  ON CONSINCO.EXEMPLO_TABELA BY ACCESS;


DELETE 



AUDIT TRUNCATE TABLE ON consinco.exemplo_tabela BY ACCESS;


DELETE FROM consinco.exemplo_tabela WHERE id = 3 AND nome = 'José Santos';


SELECT OS_USERNAME,USERNAME,USERHOST,SQL_TEXT
FROM DBA_AUDIT_TRAIL
WHERE OBJ_NAME = 'EXEMPLO_TABELA';
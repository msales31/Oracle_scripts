CREATE TABLE failed_logins (
    logon_time TIMESTAMP,
    username VARCHAR2(30),
    ip_address VARCHAR2(15),
    os_user VARCHAR2(80),
    module VARCHAR2(50),
    action VARCHAR2(50),
    pid VARCHAR2(10),
    program VARCHAR2(48),
    client_id VARCHAR2(64)
);


Atualize a Trigger para Inserir Registros na Tabela:

Agora, atualize a trigger logon_denied_to_alert para inserir os registros na tabela failed_logins:

sql
Copy code
CREATE OR REPLACE TRIGGER logon_denied_to_table
AFTER SERVERERROR ON DATABASE
DECLARE
    ip_address   VARCHAR2(15);
    v_os_user    VARCHAR2(80);
    v_module     VARCHAR2(50);
    v_action     VARCHAR2(50);
    v_pid        VARCHAR2(10);
    v_sid        NUMBER;
    v_program    VARCHAR2(48);
    v_client_id  VARCHAR2(64);
BEGIN
    IF (ora_is_servererror(1017)) THEN

        -- Obter IP para conexões remotas:
        IF sys_context('userenv','network_protocol') = 'TCP' THEN
            ip_address := sys_context('userenv','ip_address');
        END IF;

        SELECT DISTINCT sid INTO v_sid FROM sys.v_$mystat;
        SELECT p.SPID, v.PROGRAM INTO v_pid, v_program
        FROM V$PROCESS p, V$SESSION v
        WHERE p.ADDR = v.PADDR AND v.sid = v_sid;

        v_os_user := sys_context('userenv','os_user');
        dbms_application_info.READ_MODULE(v_module,v_action);

        v_client_id := sys_context('userenv','client_identifier');

        -- Inserir os dados na tabela
        INSERT INTO failed_logins (
            logon_time,
            username,
            ip_address,
            os_user,
            module,
            action,
            pid,
            program,
            client_id
        ) VALUES (
            systimestamp, -- Adiciona o timestamp da tentativa de login
            USER,
            nvl(ip_address,'localhost'),
            v_os_user,
            v_module,
            v_action,
            v_pid,
            v_program,
            v_client_id
        );
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        NULL; -- Trate a exceção conforme necessário.
END;
/
Agora, a trigger logon_denied_to_table irá inserir os detalhes das tentativas de login malsucedidas na tabela failed_logins. Lembre-se de testar em um ambiente não produtivo antes de implementar em produção.





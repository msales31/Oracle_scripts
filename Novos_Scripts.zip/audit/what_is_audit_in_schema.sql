select * from sys.dba_stmt_audit_opts where USER_NAME='&USER';


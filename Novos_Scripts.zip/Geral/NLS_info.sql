SELECT 'database '||NAME||' role '||DATABASE_ROLE||' log_mode '||LOG_MODE|| ' open_mode '||OPEN_MODE INFO
FROM v$database
UNION ALL
SELECT 'instance '||upper(INSTANCE_NAME)|| ' thread '||THREAD#||' version '||VERSION||' host '||upper(HOST_NAME)||' status '|| STATUS INFO
FROM v$instance
UNION ALL
SELECT lower(NAME)||' '||VALUE$ INFO
FROM sys.props$
WHERE name in ('DEFAULT_TEMP_TABLESPACE',
               'NLS_LANGUAGE',
               'NLS_TERRITORY',
               'NLS_CHARACTERSET',
               'NLS_NCHAR_CHARACTERSET',
               'GLOBAL_DB_NAME',
               'DBTIMEZONE')
UNION ALL
SELECT 'startup time '||lower(to_char(STARTUP_TIME, 'DDMONYYYY HH24:MI:SS'))
FROM v$instance
UNION ALL
SELECT 'current date and time '||lower(to_char(sysdate, 'DDMONYYYY HH24:MI:SS'))
FROM dual;
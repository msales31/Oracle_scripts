SELECT sys_context('USERENV', 'SID') AS SID FROM dual;

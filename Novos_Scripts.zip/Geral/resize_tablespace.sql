SET PAGESIZE 1000;
SET LINESIZE 300;
COL EVENT FORMAT A80;
select 'alter database datafile ''' || file_name || ''' resize ' ||
 ceil( (nvl(hwm,1)*8192)/1024/1024+1 )|| 'm;' smallest,
 ceil( blocks*8192/1024/1024) currsize,
 ceil( blocks*8192/1024/1024) -
 ceil( (nvl(hwm,1)*8192)/1024/1024 ) savings
 from dba_data_files a,
 ( select file_id, max(block_id+blocks-1) hwm
 from dba_extents where tablespace_name in ('SYSAUX','UNDOTBS1','USERS','SYSTEM')
 group by file_id ) b
 where a.file_id = b.file_id(+)
 and tablespace_name in
 ('%&TBS%')
 order by savings;
column OWNER format a30
column SEGMENT_NAME format a30
select *
from (
    select owner, segment_name, segment_type, trunc(sum(bytes)/1024/1024/1024, 2) "SIZE GB",TABLESPACE_NAME
    from dba_segments
    where segment_type IN ('TABLE', 'TABLE PARTITION', 'INDEX', 'INDEX PARTITION', 'LOBSEGMENT','LOB PARTITION')
    group by owner, segment_name, segment_type,TABLESPACE_NAME
    order by trunc(sum(bytes)/1024/1024/1024, 2) desc
)
where rownum <= 20;

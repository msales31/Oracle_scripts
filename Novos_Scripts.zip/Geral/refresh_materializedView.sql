select 'EXEC DBMS_MVIEW.refresh(''' || owner || '.' || mview_name || ''',' || '''C''' || ');'
from dba_mviews
where owner = '&owner'
order by owner, mview_name;
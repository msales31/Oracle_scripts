with
Q_TBS as (
  select decode (t1.CONTENTS,
           'TEMPORARY', 't', 'UNDO', 'U', 'PERMANENT', '-', t1.CONTENTS) ||
         decode (t1.LOGGING,
           'LOGGING', '-', 'NOLOGGING', 'N', t1.LOGGING) ||
         decode (t1.EXTENT_MANAGEMENT,
           'LOCAL', '-', 'DICTIONARY', 'D', t1.EXTENT_MANAGEMENT) ||
         decode (t1.SEGMENT_SPACE_MANAGEMENT,
           'AUTO', '-', 'MANUAL', 'M', t1.SEGMENT_SPACE_MANAGEMENT) ||
         decode (t1.ALLOCATION_TYPE, 'SYSTEM', '-',
           'UNIFORM', 'U', t1.ALLOCATION_TYPE)
           TBS_FLAGS,
         t1.TABLESPACE_NAME || decode (t1.STATUS, 'ONLINE', '', '*('|| t1.STATUS ||')') TBS_NAME
    from DBA_TABLESPACES t1
),
Q_TBS_ALLOC_MAX as (
  select t1.TABLESPACE_NAME TBS_NAME,
         sum (greatest (0, nvl (f1.BYTES, 0))) / 1048576 TBS_ALLOC,
         sum (greatest (0, nvl (f1.MAXBYTES, 0), nvl (f1.BYTES, 0))) / 1048576 TBS_MAX,
         count (f1.FILE_ID) TBS_FILE_CNT
    from DBA_TABLESPACES t1,
         DBA_DATA_FILES f1
   where t1.TABLESPACE_NAME = f1.TABLESPACE_NAME
     and t1.CONTENTS != 'TEMPORARY'
   group by t1.TABLESPACE_NAME
   union all
  select t2.TABLESPACE_NAME TBS_NAME,
         sum (greatest (0, nvl (f2.BYTES, 0))) / 1048576 TBS_ALLOC,
         sum (greatest (0, nvl (f2.MAXBYTES, 0), nvl (f2.BYTES, 0))) / 1048576 TBS_MAX,
         count (f2.FILE_ID) TBS_FILE_CNT
    from DBA_TABLESPACES t2,
         DBA_TEMP_FILES f2
   where t2.TABLESPACE_NAME = f2.TABLESPACE_NAME
     and t2.CONTENTS = 'TEMPORARY'
   group by t2.TABLESPACE_NAME
),
Q_TBS_FREE as (
  select t1.TABLESPACE_NAME TBS_NAME,
         sum (greatest (0, nvl (s1.BYTES, 0))) / 1048576 TBS_FREE
    from DBA_TABLESPACES t1,
         DBA_FREE_SPACE s1
   where t1.TABLESPACE_NAME = s1.TABLESPACE_NAME (+)
     and t1.CONTENTS not in ('TEMPORARY','UNDO')
   group by t1.TABLESPACE_NAME
),
Q_TBS_USED as (
  select t1.TBS_NAME TBS_NAME,
         sum (greatest (0, nvl (t1.TBS_ALLOC, 0)))
           - sum (greatest (0, nvl (t2.TBS_FREE, 0))) TBS_USED
    from Q_TBS_ALLOC_MAX t1,
         Q_TBS_FREE t2
   where t1.TBS_NAME = t2.TBS_NAME
   group by t1.TBS_NAME
   union all
  select t3.NAME TBS_NAME,
         (avg (greatest (0, greatest (nvl (s3.USED_BLOCKS, 0), nvl (s4.BLOCKS, 0))
           * nvl (f3.BYTES / f3.BLOCKS, 8192)))) / 1048576 TBS_USED
    from V$TABLESPACE t3,
         V$TEMPFILE f3,
         GV$SORT_SEGMENT s3,
         GV$SORT_USAGE s4
   where t3.TS# = f3.TS#
     and t3.NAME = s3.TABLESPACE_NAME (+)
     and t3.NAME = s4.TABLESPACE (+)
   group by t3.NAME
   union all
  select t4.TABLESPACE_NAME TBS_NAME,
         sum (greatest (0, nvl (s4.BYTES, 0))) / 1048576 TBS_USED
    from DBA_TABLESPACES t4,
         DBA_UNDO_EXTENTS s4
   where t4.TABLESPACE_NAME = s4.TABLESPACE_NAME (+)
     and t4.CONTENTS = 'UNDO'
     and s4.STATUS != 'EXPIRED'
   group by t4.TABLESPACE_NAME
)
select lpad (C1, max (length (C1)) over (), C0P) ||'|'||
       lpad (C2, max (length (C2)) over (), C0P) ||'|'||
       lpad (C3, max (length (C3)) over (), C0P) ||''||
       lpad (C4, max (length (C4)) over (), C0P) ||''||
       lpad (C5, max (length (C5)) over (), C0P) ||'['||
       rpad (C6, max (length (C6)) over (), C0P) ||'<'||
       lpad (C7, max (length (C7)) over (), C0P) ||']'||
       lpad (C8, max (length (C8)) over (), C0P) ||'|'||
       rpad (C9, max (length (C9)) over (), C0P)
from (
  (select 0 C0O, '_' C0P,
          'CLESA' C1,
          '#F' C2,
          'USED' C3,
          'ALLOC' C4,
          'MAX_' C5,
          'GRAPH' C6,
          'USE' C7,
          'USABLE' C8,
          '_TableSpace_' C9
     from dual)
union all
  (select decode (t.TBS_NAME, 'SYSTEM', 1, 'SYSAUX', 2, 'XDB', 3, 'TOOLS', 4, 'DRSYS', 5,
                'ODM', 6, 'CWMLITE', 7, 'PERFSTAT', 8, 'EXAMPLE', 9, 'USERS', 10, 'INDX', 11,
                decode (substr (t.TBS_FLAGS, 1, 1), 'U', 12, 't', 13, 14)) C0O,
          ' ' C0P,
          nvl (t.TBS_FLAGS, '????') C1,
          to_char (nvl (s.TBS_FILE_CNT, 0), 'FM990') C2,
          to_char (nvl (u.TBS_USED, 0), '9G999G990') ||'M' C3,
          to_char (nvl (s.TBS_ALLOC, 0), '9G999G990') ||'M' C4,
          decode (greatest (s.TBS_MAX, 999), 999, to_char (s.TBS_MAX, '9990') ||'M ',
            to_char (ceil (s.TBS_MAX / 1024), '9G990') ||'G ') C5,
          rpad (substr (decode (substr (t.TBS_FLAGS, 1, 1), 'U', '*********!!', '*******#!@@'),
            1, greatest (1, 100 * nvl (u.TBS_USED, 0) / s.TBS_MAX / 10)), 10, ' ') C6,
          to_char (100 * nvl (u.TBS_USED, 0) / s.TBS_MAX, 'FM90') ||'%' C7,
          to_char ((greatest (s.TBS_MAX, s.TBS_ALLOC) - s.TBS_ALLOC
            + nvl (f.TBS_FREE, s.TBS_ALLOC - nvl (u.TBS_USED, 0))) / 1024, '9990D0') ||'G' C8,
          ' '|| t.TBS_NAME C9
     from Q_TBS t,
          Q_TBS_ALLOC_MAX s,
          Q_TBS_FREE f,
          Q_TBS_USED u
    where t.TBS_NAME = s.TBS_NAME (+)
      and t.TBS_NAME = f.TBS_NAME (+)
      and t.TBS_NAME = u.TBS_NAME (+)
  )
) order by C0O, reverse (C9) ;

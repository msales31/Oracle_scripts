set tab off underline off linesize 2050 newpage none pagesize 4000
set feedback on colsep | editfile /tmp/sqlplusedit.tmp long 10000000 trimout on;
set numwidth 13;
set serveroutput on size 1000000 trimspool on longchunksize 10000000 time on;
col DATE format a10;
col h00 format 999;
col h01 format 999;
col h02 format 999;
col h03 format 999;
col h04 format 999;
col h05 format 999;
col h06 format 999;
col h07 format 999;
col h08 format 999;
col h09 format 999;
col h10 format 999;
col h11 format 999;
col h12 format 999;
col h13 format 999;
col h14 format 999;
col h15 format 999;
col h16 format 999;
col h17 format 999;
col h18 format 999;
col h19 format 999;
col h20 format 999;
col h21 format 999;
col h22 format 999;
col h23 format 999;
SELECT to_char(first_time,'YYYY/MM/DD') "DATE"
      ,SUM(DECODE(to_char(first_time,'HH24'),'00',1,NULL)) h00
      ,SUM(DECODE(to_char(first_time,'HH24'),'01',1,NULL)) h01
      ,SUM(DECODE(to_char(first_time,'HH24'),'02',1,NULL)) h02
      ,SUM(DECODE(to_char(first_time,'HH24'),'03',1,NULL)) h03
      ,SUM(DECODE(to_char(first_time,'HH24'),'04',1,NULL)) h04
      ,SUM(DECODE(to_char(first_time,'HH24'),'05',1,NULL)) h05
      ,SUM(DECODE(to_char(first_time,'HH24'),'06',1,NULL)) h06
      ,SUM(DECODE(to_char(first_time,'HH24'),'07',1,NULL)) h07
      ,SUM(DECODE(to_char(first_time,'HH24'),'08',1,NULL)) h08
      ,SUM(DECODE(to_char(first_time,'HH24'),'09',1,NULL)) h09
      ,SUM(DECODE(to_char(first_time,'HH24'),'10',1,NULL)) h10
      ,SUM(DECODE(to_char(first_time,'HH24'),'11',1,NULL)) h11
      ,SUM(DECODE(to_char(first_time,'HH24'),'12',1,NULL)) h12
      ,SUM(DECODE(to_char(first_time,'HH24'),'13',1,NULL)) h13
      ,SUM(DECODE(to_char(first_time,'HH24'),'14',1,NULL)) h14
      ,SUM(DECODE(to_char(first_time,'HH24'),'15',1,NULL)) h15
      ,SUM(DECODE(to_char(first_time,'HH24'),'16',1,NULL)) h16
      ,SUM(DECODE(to_char(first_time,'HH24'),'17',1,NULL)) h17
      ,SUM(DECODE(to_char(first_time,'HH24'),'18',1,NULL)) h18
      ,SUM(DECODE(to_char(first_time,'HH24'),'19',1,NULL)) h19
      ,SUM(DECODE(to_char(first_time,'HH24'),'20',1,NULL)) h20
      ,SUM(DECODE(to_char(first_time,'HH24'),'21',1,NULL)) h21
      ,SUM(DECODE(to_char(first_time,'HH24'),'22',1,NULL)) h22
      ,SUM(DECODE(to_char(first_time,'HH24'),'23',1,NULL)) h23
      ,ROUND (COUNT (1) / 24, 2) "Avg"
FROM sys.gv_$log_history
where first_time > sysdate-30
GROUP BY to_char(first_time,'YYYY/MM/DD')
ORDER BY 1 DESC
/
tem menu de contexto
col OWNER format A20;
col OBJECT_NAME format A20;
col object_type format A20;
select owner,object_name,object_type from dba_objects where object_name like '%&OBJECT_NAME%';
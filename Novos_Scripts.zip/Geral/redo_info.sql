with
Q1 as (
  select q1f.GROUP# F_GROUP,
         q1f.STATUS F_STATUS,
         q1f.TYPE F_TYPE,
         q1f.MEMBER F_NAME
    from V$LOGFILE q1f
),
Q2 as (
  select q2l.THREAD# L_THREAD,
         q2l.GROUP# L_GROUP,
         q2l.SEQUENCE# L_SEQUENCE,
         q2l.BYTES L_SIZE,
         decode (q2l.ARCHIVED, 'YES', ' ', 'NOT-ARCHIVED') L_ARCHIVED,
         decode (q2l.STATUS, 'INACTIVE', ' ', q2l.STATUS) L_STATUS,
         row_number () over (
             partition by q2l.THREAD#
                 order by q2l.GROUP#
         ) L_GROUP_BY_THREAD
    from V$LOG q2l
)
select lpad (C1, max (length (C1)) over (), C0P) ||'|'||
       lpad (C2, max (length (C2)) over (), C0P) ||'|'||
       rpad (C3, max (length (C3)) over (), C0P) ||' '||
       rpad (C4, max (length (C4)) over (), C0P) ||'|'||
       lpad (C5, max (length (C5)) over (), C0P) ||'|'||
       rpad (C6, max (length (C6)) over (), C0P) ||'|'||
       lpad (C7, max (length (C7)) over (), C0P) ||'/'||
       rpad (C8, max (length (C8)) over (), C0P)
from (
  (select 0 C0O, '_' C0P,
          'GR' C1, -1 C1O,
          'Sequence' C2, -1 C2O,
          'Status' C3,
          'Archived' C4,
          'Size' C5,
          'T-TG-M' C6,
          'Directory' C7,
          'File' C8
     from dual)
union all
  (select 1 C0O, ' ' C0P,
          nvl (to_char (q2.L_GROUP, 'FM9900'), ' ') C1, q2.L_GROUP C1O,
          nvl (to_char (q2.L_SEQUENCE), ' ') C2, q2.L_SEQUENCE C2O,
          nvl (to_char (q2.L_STATUS), ' ') C3,
          nvl (to_char (q2.L_ARCHIVED), ' ') C4,
          nvl (to_char (q2.L_SIZE / 1048576, 'FM999990'), ' ') ||'M' C5,
          q2.L_THREAD ||'-'|| to_char (q2.L_GROUP_BY_THREAD, 'FM00') ||'-'||
          decode (row_number () over (
            partition by q2.L_GROUP
                order by reverse (q1.F_NAME)
            ), 1, 'a', 2, 'b', 3, 'c', 4, 'd', 5, 'e', '?') C6,
          nvl (to_char (substr (q1.F_NAME, 1, instr (q1.F_NAME, '/', -1) - 1)), ' ') C7,
          nvl (to_char (substr (q1.F_NAME, instr (q1.F_NAME, '/', -1) + 1)), ' ') C8
     from Q1 q1, Q2 q2
    where q1.F_GROUP = q2.L_GROUP
  )
)
order by C0O, C6, C1O, C2O, reverse (C8), C2O ;

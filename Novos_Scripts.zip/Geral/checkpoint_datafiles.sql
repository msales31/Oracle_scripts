SET LINES 4000;
SET PAGES 4000;
SELECT 'F#_|CheckPoint:Difference_____|_CheckPointTime___|Fzy|File___________________'
FROM dual 
UNION ALL
SELECT S FROM (
    SELECT TO_CHAR(h.FILE#, 'FM000') || '|' ||
           RPAD(TO_CHAR(h.CHECKPOINT_CHANGE#, 'FM999999999G99990') || ':' ||
           TO_CHAR((h.CHECKPOINT_CHANGE# - MAX(h.CHECKPOINT_CHANGE#) OVER ()), 'FM99999999G999G990'), 26, ' ') || '|' ||
           TO_CHAR(h.CHECKPOINT_TIME, 'DDMonYYYY/HH24:MI:SS') || '|' ||
           RPAD(h.FUZZY, 3, ' ') || '|' ||
           h.NAME AS S
    FROM V$DATAFILE_HEADER h
    ORDER BY h.CHECKPOINT_TIME DESC, h.NAME
);

### APEX CONFIGURACAO MODELO

- Versão:
Apex: 22.2
link para download: https://www.oracle.com/tools/downloads/apex-downloads/

ORDS: 23.1
link para download: https://www.oracle.com/database/technologies/appdev/rest-data-services-downloads.html


- Ambiente
S.O: Oracle Linux 8
SGBD: Oracle 19c 
Banco: Single Instance com Multitenant (CDB e PDBs)
Java: java-17-openjdk.x86_64


0 - Instalar java (caso necessario)
java -version
root 
yum search openjdk
yum install java-17-openjdk.x86_64 : OpenJDK 17 Runtime Environment


############## APEX


1 - Copiar arquivos baixados para a maquina

apex_22.2.zip
ords-23.1.0.086.1423.zip


2 - Descompactar zip do apex 

cd /home/oracle
unzip apex_22.2.zip


3 - crie uma tablespace especifica para o apex 

sqlplus / as sysdba
SQL> ALTER SESSION SET CONTAINER=APEXPDB01;
SQL> CREATE TABLESPACE apx_tbs DATAFILE '/u01/app/oracle/oradata/CDB19C/apexpdb01/apx_tbs01.dbf' SIZE 50M AUTOEXTEND ON MAXSIZE UNLIMITED;


4 - Rodar script de instalação do apex no banco de dados: apexins.sql

cd /home/oracle/apex 
sqlplus / as sysdba
SQL> ALTER SESSION SET CONTAINER=APEXPDB01;
SQL> @apexins.sql APX_TBS APX_TBS TEMP /i/

	- Descrição do comando:

		@apexins.sql tablespace_apex tablespace_files tablespace_temp images 
			tablespace_apex: Nome da tablespace para o usuario do APEX
			tablespace_files: Nome da tablespace para os arquivos do usuario do APEX
			tablespace_temp: Nome da tablespace temporaria do usuario do APEX
			images : Diretorio virtual para as imagens do APEX
				Define o diretorio virtual de imagens como /i/ para updates futuros
			
	- Quando o APEX é instalado, ele cria três novas contas de banco de dados, todas com status LOCKED no banco de dados:
		APEX_220200 – A conta que possui o esquema e os metadados do APEX.
		FLOWS_FILES – A conta que possui os arquivos carregados do APEX.
		APEX_PUBLIC_USER – A conta com privilégios mínimos é usada para configuração do APEX com ORDS.			

SELECT username, account_status 
FROM dba_users 
WHERE TRUNC(CREATED) = TRUNC(sysdate) ORDER BY 1;


5 - Alterar a senha do usuário principal do apex o usuario ADMIN: apxchpwd.sql

cd /home/oracle/apex 
sqlplus / as sysdba
SQL> ALTER SESSION SET CONTAINER=APEXPDB01;
SQL> @apxchpwd.sql
oracle_4U


6 - Configurar o ORDS no banco de dados: apex_rest_config.sql 

cd /home/oracle/apex 
sqlplus / as sysdba
SQL> ALTER SESSION SET CONTAINER=APEXPDB01;
SQL> @apex_rest_config.sql
oracle_4U

- Ajustar as senhas do seguintes usuarios ao final 

SQL> ALTER SESSION SET CONTAINER=APEXPDB01;
SQL> ALTER USER apex_public_user IDENTIFIED BY oracle_4U ACCOUNT UNLOCK;
SQL> ALTER USER apex_listener IDENTIFIED BY oracle_4U ACCOUNT UNLOCK;
SQL> ALTER USER apex_rest_public_user IDENTIFIED BY oracle_4U ACCOUNT UNLOCK;


############## ORDS 


7 - Criar diretorio para o ORDS e descompactar zip 

mkdir -p /u01/app/oracle/ords 
cp ords-23.1.0.086.1423.zip /u01/app/oracle/ords 
cd /u01/app/oracle/ords 
unzip ords-23.1.0.086.1423.zip


8 - Copiar pasta de imagens para dentro do ORDS 

cd /home/oracle/apex
cp -r images /u01/app/oracle/ords


9 - Criar diretorio de configuração do ORDS 

mkdir -p /u01/app/oracle/ords/config 


10 - crie uma tablespace especifica para o ords  

sqlplus / as sysdba
SQL> ALTER SESSION SET CONTAINER=APEXPDB01;
SQL> CREATE TABLESPACE ords_tbs DATAFILE '/u01/app/oracle/oradata/CDB19C/apexpdb01/ords_tbs01.dbf' SIZE 50M AUTOEXTEND ON MAXSIZE UNLIMITED;


11 - Iniciando configuração do ORDS 

cd /u01/app/oracle/ords/bin 
./ords --config /u01/app/oracle/ords/config install

[2] Create or update a database pool and install/upgrade ORDS in the database
[1] Basic (host name, port, service name)
[1] Database Actions  (Enables all features)
[1] Configure and start ORDS in standalone mode
[1] HTTP
Enter the HTTP port [8080]: 8080
Enter the APEX static resources location: /u01/app/oracle/ords/images

- Para iniciar apos instalado 
cd /u01/app/oracle/ords/bin
./ords --config /u01/app/oracle/ords/config serve


12 - Acessando 

http://192.168.1.65:8080/ords
internal
admin
oracle_4U


13 - Configurando startup automatico do ORDS 

--> Criar diretorio de logs (oracle)
mkdir -p /u01/app/oracle/ords/logs 

--> criando arquivo (root)
vi /etc/init.d/apex

#!/bin/bash
# chkconfig: 345 99 10
# Description: auto start apex
#
case "$1" in
 'start')
   su - oracle -c "cd /u01/app/oracle/ords/bin ; ./ords --config /u01/app/oracle/ords/config serve > /u01/app/oracle/ords/logs/apex.log 2>/u01/app/oracle/ords/logs/apex_error.log &";;
 'stop')
   pkill -f "config /u01/app/oracle/ords/config serve";;
esac

--> atribuindo permissao (root)
    cd /etc/init.d
	chown root.root apex
	chmod 777 apex

--> Configuração serviço	(root)
	chkconfig --add apex
	chkconfig --level 2345 apex on
	chkconfig --level 016  apex off

--> Teste (root)
	service apex start
	service apex stop
	
	
	
	
	NFO: Before starting ORDS service, run the below command as user oracle:
         ords --config /etc/ords/config install
INFO: To enable the ORDS service during startup, run the below command:
         sudo  systemctl enable ords

  Verifying        : ords-24.3.1-4.el8.noarch                
  
  
  
  
  NFO: Before starting ORDS service, run the below command as user oracle:
         ords --config /etc/ords/config install
INFO: To enable the ORDS service during startup, run the below command:
         sudo  systemctl enable ords

  Verifying        : ords-24.3.1-4.el8.noarch                
  
  
  ords --config /etc/ords/config serve
  
  
  
  
 #### upgrade apex version  
 
  
https://doyensys.com/blogs/manually-upgrade-apex-for-19c-upgrade/ 

ugrade apex para 24.1 

select comp_name,status,version from dba_registry where comp_id='APEX';




select * from apex_instance_parameters where name = 'IMAGE_PREFIX'
14:39:54   2  ;
NAME
VALUE
CREATED_ON         |LAST_UPDATED_ON
IMAGE_PREFIX
/i/
2024-03-14 17:09:20|2024-03-14 17:09:20


1 row selected.

Elapsed: 00:00:00.01
14:39:55 SYS@voxline> @PR
SP2-0310: unable to open file "PR.sql"
14:39:56 SYS@voxline> @pr
==============================
NAME                          : IMAGE_PREFIX
VALUE                         : /i/
CREATED_ON                    : 2024-03-14 17:09:20
LAST_UPDATED_ON               : 2024-03-14 17:09:20




@apexins TSD_APEX TSD_APEX TEMP /i/



  begin 
        apex_instance_admin.set_parameter(
            p_parameter => 'IMAGE_PREFIX',
            p_value     => 'https://static.oracle.com/cdn/apex/24.1.0/' );
        
        commit;
  end;
  
--
  
 begin 
        apex_instance_admin.set_parameter(
            p_parameter => 'IMAGE_PREFIX',
            p_value     => 'https://static.oracle.com/cdn/apex/24.1.0/' );
        
        commit;
  end; 
  
  
  
--### upgrade ords 

yum upgrade ords 

 ords --config /etc/ords/config serve
  
  
 /root/logs/ords_upgrade_2024-12-04_130103_66270.log
TABLE_NAME                     TABLESPACE_NAME                  NUM_ROWS AVG_ROW_LEN     BLOCKS EMPTY_BLOCKS    SIZE_MB
------------------------------ ------------------------------ ---------- ----------- ---------- ------------ ----------
ENV_ADDRESS                    TSD_TSS                                 0           0          0            0          0
ENV_CONFIG                     TSD_TSS                                 0           0          0            0          0
ENV_INFO                       TSD_TSS                                 0           0          0            0          0
ENV_RECEIVE                    TSD_TSS                                 0           0          0            0          0
MP_CUSTOM_METRICS              TSD_TSS                                 0           0          0            0          0
MP_CUSTOM_METRICS_EXP          TSD_TSS
SPED000                        TSD_TSS                             14144         318        748            0       5.84
SPED000L                       TSD_TSS                                 0           0          0            0          0
SPED001                        TSD_TSS                               309         783         35            0        .27
SPED001A                       TSD_TSS                               309        2227        103            0         .8
SPED001B                       TSD_TSS                                 0           0          0            0          0
SPED001L                       TSD_TSS                                 0           0          0            0          0
SPED001M                       TSD_TSS                                 0           0          0            0          0
SPED050                        TSD_TSS                             65309        5212      59057            0     461.38
SPED050L                       TSD_TSS                                 0           0          0            0          0
SPED051                        TSD_TSS                                91        7806        244            0       1.91
SPED052                        TSD_TSS                             57025         947       9077            0      70.91
SPED052L                       TSD_TSS                                 0           0          0            0          0
SPED053                        TSD_TSS                                 3        3731          5            0        .04
SPED054                        TSD_TSS                             87110        1102      14177            0     110.76
SPED054L                       TSD_TSS                                 0           0          0            0          0
SPED055                        TSD_TSS                                 0           0          0            0          0
SPED056                        TSD_TSS                                 0           0          0            0          0
SPED057L                       TSD_TSS                                 0           0          0            0          0
SPED058L                       TSD_TSS                                 0           0          0            0          0
SPED060                        TSD_TSS                                 0           0          0            0          0
SPED061                        TSD_TSS                                 0           0          0            0          0
SPED062                        TSD_TSS                                 0           0          0            0          0
SPED063                        TSD_TSS                                 0           0          0            0          0
SPED064                        TSD_TSS                                 0           0          0            0          0
SPED070                        TSD_TSS                               824         447         58            0        .45
SPED072L                       TSD_TSS                                 0           0          0            0          0
SPED074L                       TSD_TSS                                 0           0          0            0          0
SPED076L                       TSD_TSS                                 0           0          0            0          0
SPED080L                       TSD_TSS                                 0           0          0            0          0
SPED082L                       TSD_TSS                                 0           0          0            0          0
SPED084L                       TSD_TSS                                 0           0          0            0          0
SPED090                        TSD_TSS                                 0           0          0            0          0
SPED091                        TSD_TSS                                 0           0          0            0          0
SPED092                        TSD_TSS                                 0           0          0            0          0
SPED093                        TSD_TSS                                 0           0          0            0          0
SPED094                        TSD_TSS                                 0           0          0            0          0
SPED094R                       TSD_TSS                                 0           0          0            0          0
SPED150                        TSD_TSS                              2677        2595       1000            0       7.81
SPED154                        TSD_TSS                             15535        1952       4276            0      33.41
SPED155                        TSD_TSS                                 0           0          0            0          0
SPED156                        TSD_TSS                               583        1675        244            0       1.91
SPED157                        TSD_TSS                                 0           0          0            0          0
SPED158                        TSD_TSS                              6583         301        384            0          3
SPED159                        TSD_TSS                                 0           0          0            0          0
SPED201                        TSD_TSS                              1351        3833       1000            0       7.81
SPED201A                       TSD_TSS                              1432        2269        496            0       3.88
SPED201B                       TSD_TSS                                15        1734          5            0        .04
SPED202                        TSD_TSS                                 0           0          0            0          0
SPED202A                       TSD_TSS                                 0           0          0            0          0
SPED400                        TSD_TSS                                 0           0          0            0          0
SPED400A                       TSD_TSS                                 0           0          0            0          0
SPED400B                       TSD_TSS                                 0           0          0            0          0
SPED401                        TSD_TSS                                 0           0          0            0          0
SPED500                        TSD_TSS                                 0           0          0            0          0
SPED500A                       TSD_TSS                                 0           0          0            0          0
SYSTEM_INFO                    TSD_TSS                                 0           0          0            0          0
SYS_ADDRESS                    TSD_TSS                                 0           0          0            0          0
SYS_APP_PARAM                  TSD_TSS                                 2         315          5            0        .04
SYS_BCAST_ENVR                 TSD_TSS                                 0           0          0            0          0
SYS_BCAST_KEYSTAGE             TSD_TSS                                12          68          5            0        .04
SYS_BCAST_STAGE                TSD_TSS                                 4         115          5            0        .04
TOP_FIELD                      TSD_TSS                               453         111         13            0         .1
TOP_IDXSTATS                   TSD_TSS                                 0           0          0            0          0
TOP_PARAM                      TSD_TSS                                 0           0          0            0          0
TOP_SP                         TSD_TSS                                 0           0          0            0          0
TOP_VIEW                       TSD_TSS                                 0           0          0            0          0
TOP_VIRTUALIDX                 TSD_TSS                                 0           0          0            0          0
TSS0001                        TSD_TSS                                12         587          4            0        .03
TSS0002                        TSD_TSS                                42         161          4            0        .03
TSS0003                        TSD_TSS                               133          69          2            0        .02
TSS0004                        TSD_TSS                                 0           0        874            0       6.83
TSS0005                        TSD_TSS                                 0           0          0            0          0
TSS0006                        TSD_TSS                                 0           0          0            0          0
TSS0007                        TSD_TSS                                 0           0          0            0          0
TSS0008                        TSD_TSS                                 0           0          0            0          0
TSS0010                        TSD_TSS                                10         218          4            0        .03
TSS0011                        TSD_TSS                                 7         368         20            0        .16
TSS0012                        TSD_TSS                                 0           0          0            0          0
TSS0014                        TSD_TSS                                 0           0          0            0          0
TSS0015                        TSD_TSS
TSS0016                        TSD_TSS
TSSTR1                         TSD_TSS                                10         333         20            0        .16
TSSTR2                         TSD_TSS                              6532         225        748            0       5.84
TSSTR3                         TSD_TSS

SET HEAD OFF;
SPOOL truncate_table.sql
select 'TRUNCATE TABLE '||OWNER||'.'||table_name||';' from all_tables where owner='&owner';
SPOOL OFF;
@truncate_table.sql



SELECT owner, SUM(bytes)/1024/1024/1024 "Size (GB)"
FROM dba_segments
GROUP BY owner
ORDER BY SUM(bytes) DESC;
col table_name for a15
select table_name, to_char(last_analyzed,'DD-MON-YYYY HH24:MI:SS') from dba_tables where owner='&owner' AND TABLE_NAME = '%&table';
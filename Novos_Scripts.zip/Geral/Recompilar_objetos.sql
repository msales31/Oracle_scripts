EXEC DBMS_UTILITY.compile_schema(schema => '&owner', compile_all => false);

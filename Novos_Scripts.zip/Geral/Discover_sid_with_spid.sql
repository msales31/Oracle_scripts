  SELECT b.spid,
         a.sid,
         a.serial#,
         a.username,
         a.osuser
    FROM v$session a, v$process b
   WHERE a.paddr = b.addr AND b.spid = '&spid'
ORDER BY b.spid;
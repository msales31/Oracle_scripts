SET lines 4000;
SET pages 4000;

SELECT  'F#_|CheckPoint:Difference_____|_CheckPointTime___|Fzy|File___________________'
FROM dual 
UNION ALL
SELECT  S
FROM 
(
	SELECT  to_char (h.FILE#,'FM000') ||'|'|| rpad (to_char (h.CHECKPOINT_CHANGE#,'FM999999999G99990') ||':'|| to_char ((h.CHECKPOINT_CHANGE# - max (h.CHECKPOINT_CHANGE#) over ()),'FM99999999G999G990'),26,' ')||'|'|| to_char (h.CHECKPOINT_TIME,'DDMonYYYY/HH24:MI:SS') ||'|'|| rpad (h.FUZZY,3,' ') ||'|'|| h.NAME S
	FROM V$DATAFILE_HEADER h
	ORDER BY h.FILE#, h.NAME 
) ;
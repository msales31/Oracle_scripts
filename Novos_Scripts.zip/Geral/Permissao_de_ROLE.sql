SELECT table_name, privilege
FROM dba_tab_privs
WHERE grantee = '&ROLE';
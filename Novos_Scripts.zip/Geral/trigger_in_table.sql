SELECT OWNER, TRIGGER_NAME, STATUS
FROM all_triggers 
WHERE table_name = '&table_name' 
AND owner = '&owner';

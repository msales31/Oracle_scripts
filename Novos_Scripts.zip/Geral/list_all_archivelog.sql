COLUMN name FORMAT A30
COLUMN thread# FORMAT 9999
COLUMN sequence# FORMAT 9999999
COLUMN status FORMAT A10
COLUMN first_time FORMAT A20
COLUMN next_time FORMAT A20
COLUMN first_change# FORMAT 9999999999999999999
COLUMN next_change# FORMAT 9999999999999999999

SELECT 
    name,
    thread#,
    sequence#,
    status,
    TO_CHAR(first_time, 'DD-MM-YYYY HH24:MI:SS') AS first_time,
    TO_CHAR(next_time, 'DD-MM-YYYY HH24:MI:SS') AS next_time,
    TO_CHAR(first_change#, '9999999999999999999') AS first_change#,
    TO_CHAR(next_change#, '9999999999999999999') AS next_change#
FROM 
    v$archived_log;

SELECT 
    owner,
    object_name
FROM 
    dba_procedures
WHERE
    object_type = 'PROCEDURE'
AND
	OWNER='&OWNER';
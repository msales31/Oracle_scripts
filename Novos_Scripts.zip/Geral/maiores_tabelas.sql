column OWNER format a30
column SEGMENT_NAME format a30
select * from
  (select owner, segment_name, trunc(sum(bytes)/1024/1024/1024,2) "SIZE GB"
      from dba_segments
      where segment_type = 'TABLE'
      group by segment_name, owner
      order by 3 desc)
      where rownum <= 100;
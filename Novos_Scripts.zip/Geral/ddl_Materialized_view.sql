SELECT DBMS_METADATA.GET_DDL('MATERIALIZED_VIEW', mview_name, owner) AS ddl
FROM all_mviews
WHERE owner = '&owner';
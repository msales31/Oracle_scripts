SET PAGESIZE 1000;
SET LINESIZE 300;
COL EVENT FORMAT A80;
col username for a25
col default_Tablespace for a25
col temp_tablespace for a20
select 
	username, 
	default_tablespace, 
	temporary_tablespace, 
	user_id,
	created,
  account_status,
	profile
from 
	dba_users;
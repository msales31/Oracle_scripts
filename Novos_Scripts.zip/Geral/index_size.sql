select a.owner,b.temporary, sum(a.bytes)/1024/1024/1024 total
from dba_segments a, dba_indexes b
where a.segment_name like upper('&segment_name')
and a.segment_name = b.index_name
and a.owner = b.owner
group by a.owner, b.temporary;
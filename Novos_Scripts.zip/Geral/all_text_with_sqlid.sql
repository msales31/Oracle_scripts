select sql_fulltext from v$sql where sql_id='&sql_id';


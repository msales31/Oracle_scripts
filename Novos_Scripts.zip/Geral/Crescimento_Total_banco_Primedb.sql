with
Q1 as (
select trunc (q1t.CAPTURED_DATE, 'MM') TBS_DATE,
(sum (q1t.TSUSED)) / count (distinct trunc (q1t.CAPTURED_DATE) + 1) TBS_USED
from PRM.PRIME_TABLESPACE q1t
where q1t.CONTENTS = 'PERMANENT'
and q1t.TSUSED is not null and q1t.TSUSED > 0
and upper (q1t.TABLESPACE_NAME) not in ('SYSTEM','SYSAUX','TOOLS','XDB','DRSYS')
group by trunc (q1t.CAPTURED_DATE, 'MM')
)
select rpad (C1, max (length (C1)) over (), C0P) ||'|'||
lpad (C2, max (length (C2)) over (), C0P) ||'|'||
lpad (C3, max (length (C3)) over (), C0P) ||'|'||
lpad (C4, max (length (C4)) over (), C0P)
from (
(select 0 C0O, '_' C0P, sysdate - 4000 C1O,
'Date' C1,
'TotalUsage' C2,
'MonthGrown' C3,
'Percentage' C4
from dual)
union all
(select 1 C0O, ' ' C0P, q1.TBS_DATE,
to_char (q1.TBS_DATE, 'MonYYYY') C1,
to_char (q1.TBS_USED / 1024, 'FM999G999G990D0') ||'G' C2,
to_char (lead (q1.TBS_USED, 1, q1.TBS_USED)
over (order by q1.TBS_DATE) - q1.TBS_USED, 'FMS999G999G990') ||'M' C3,
to_char (
q1.TBS_USED * 100 / min (q1.TBS_USED) over ()
, 'FM999990D0') ||'%' C4
from Q1 q1
)
) where (C0O = 0 or upper (C1 ||' '|| C2 ||' '|| C3) like upper ('%&__SEARCH__%'))
order by C0O, C1O, C1 ;
WITH
Q_TBS AS (
    SELECT decode (t1.CONTENTS,
                   'TEMPORARY', 't',
                   'UNDO', 'U',
                   'PERMANENT', '-', 
                   t1.CONTENTS) ||
           decode (t1.LOGGING,
                   'LOGGING', '-', 
                   'NOLOGGING', 'N',
                   t1.LOGGING) ||
           decode (t1.EXTENT_MANAGEMENT,
                   'LOCAL', '-', 
                   'DICTIONARY', 'D',
                   t1.EXTENT_MANAGEMENT) ||
           decode (t1.SEGMENT_SPACE_MANAGEMENT,
                   'AUTO', '-', 
                   'MANUAL', 'M',
                   t1.SEGMENT_SPACE_MANAGEMENT) ||
           decode (t1.ALLOCATION_TYPE,
                   'SYSTEM', '-', 
                   'UNIFORM', 'U',
                   t1.ALLOCATION_TYPE) TBS_FLAGS,
           t1.TABLESPACE_NAME ||
           decode (t1.STATUS,'ONLINE','', '*('|| t1.STATUS ||')') TBS_NAME
    FROM   DBA_TABLESPACES t1
),
Q_TBS_ALLOC_MAX AS (
    SELECT t1.TABLESPACE_NAME TBS_NAME,
           SUM(GREATEST(0, NVL(f1.BYTES,0)))/1048576 TBS_ALLOC,
           SUM(GREATEST(0, NVL(f1.MAXBYTES,0), NVL(f1.BYTES,0)))/1048576 TBS_MAX,
           COUNT(f1.FILE_ID) TBS_FILE_CNT
    FROM   DBA_TABLESPACES t1,
           DBA_DATA_FILES f1
    WHERE  t1.TABLESPACE_NAME = f1.TABLESPACE_NAME
    AND    t1.CONTENTS != 'TEMPORARY'
    GROUP BY t1.TABLESPACE_NAME
    UNION ALL
    SELECT t2.TABLESPACE_NAME TBS_NAME,
           SUM(GREATEST(0, NVL(f2.BYTES,0)))/1048576 TBS_ALLOC,
           SUM(GREATEST(0, NVL(f2.MAXBYTES,0), NVL(f2.BYTES,0)))/1048576 TBS_MAX,
           COUNT(f2.FILE_ID) TBS_FILE_CNT
    FROM   DBA_TABLESPACES t2,
           DBA_TEMP_FILES f2
    WHERE  t2.TABLESPACE_NAME = f2.TABLESPACE_NAME
    AND    t2.CONTENTS = 'TEMPORARY'
    GROUP BY t2.TABLESPACE_NAME
),
Q_TBS_FREE AS (
    SELECT t1.TABLESPACE_NAME TBS_NAME,
           SUM(GREATEST(0, NVL(s1.BYTES,0)))/1048576 TBS_FREE
    FROM   DBA_TABLESPACES t1,
           DBA_FREE_SPACE s1
    WHERE  t1.TABLESPACE_NAME = s1.TABLESPACE_NAME (+)
    AND    t1.CONTENTS NOT IN ('TEMPORARY','UNDO')
    GROUP BY t1.TABLESPACE_NAME
),
Q_TBS_USED AS (
    SELECT t1.TBS_NAME,
           SUM(GREATEST(0, NVL(t1.TBS_ALLOC,0))) -
           SUM(GREATEST(0, NVL(t2.TBS_FREE,0))) TBS_USED
    FROM   Q_TBS_ALLOC_MAX t1,
           Q_TBS_FREE t2
    WHERE  t1.TBS_NAME = t2.TBS_NAME
    GROUP BY t1.TBS_NAME
    UNION ALL
    SELECT t3.NAME TBS_NAME,
           (AVG(GREATEST(0,
              GREATEST(NVL(s3.USED_BLOCKS,0), NVL(s4.BLOCKS,0))
              * NVL(f3.BYTES/f3.BLOCKS,8192))))/1048576 TBS_USED
    FROM   V$TABLESPACE t3,
           V$TEMPFILE f3,
           GV$SORT_SEGMENT s3,
           GV$SORT_USAGE s4
    WHERE  t3.TS# = f3.TS#
    AND    t3.NAME = s3.TABLESPACE_NAME (+)
    AND    t3.NAME = s4.TABLESPACE (+)
    GROUP BY t3.NAME
    UNION ALL
    SELECT t4.TABLESPACE_NAME TBS_NAME,
           SUM(GREATEST(0, NVL(s4.BYTES,0)))/1048576 TBS_USED
    FROM   DBA_TABLESPACES t4,
           DBA_UNDO_EXTENTS s4
    WHERE  t4.TABLESPACE_NAME = s4.TABLESPACE_NAME (+)
    AND    t4.CONTENTS = 'UNDO'
    AND    s4.STATUS != 'EXPIRED'
    GROUP BY t4.TABLESPACE_NAME
)
SELECT lpad (C1, max (length (C1)) over (), C0P) ||'|'||
       lpad (C2, max (length (C2)) over (), C0P) ||'|'||
       lpad (C3, max (length (C3)) over (), C0P) ||''||
       lpad (C4, max (length (C4)) over (), C0P) ||''||
       lpad (C5, max (length (C5)) over (), C0P) ||'['||
       rpad (C6, max (length (C6)) over (), C0P) ||'<'||
       lpad (C7, max (length (C7)) over (), C0P) ||']'||
       lpad (C8, max (length (C8)) over (), C0P) ||'|'||
       rpad (C9, max (length (C9)) over (), C0P)
FROM (
    (SELECT 0 C0O, '_' C0P,
            'CLESA' C1,
            '#F' C2,
            'USED' C3,
            'ALLOC' C4,
            'MAX_' C5,
            'GRAPH' C6,
            'USE' C7,
            'USABLE' C8,
            '_TableSpace_' C9
     FROM dual)
    UNION ALL
    (SELECT decode (t.TBS_NAME,'SYSTEM',1,'SYSAUX',2,'XDB',3,'TOOLS',4,'DRSYS',5,
                    'ODM',6,'CWMLITE',7,'PERFSTAT',8,'EXAMPLE',9,'USERS',10,'INDX',11,
                    decode(substr(t.TBS_FLAGS,1,1),'U',12,'t',13,14)) C0O,
            ' ' C0P,
            NVL(t.TBS_FLAGS,'????') C1,
            TO_CHAR(NVL(s.TBS_FILE_CNT,0),'FM990') C2,
            -- USED
            TO_CHAR(NVL(u.TBS_USED,0),'999,999,999,999') ||'M' C3,
            -- ALLOC
            TO_CHAR(NVL(s.TBS_ALLOC,0),'999,999,999,999') ||'M' C4,
            -- MAX
            ROUND(s.TBS_MAX/1024,1) || 'G' C5,
            RPAD(SUBSTR(DECODE(SUBSTR(t.TBS_FLAGS,1,1),'U','*********!!','*******#!@@'),
                 1,GREATEST(1,100*NVL(u.TBS_USED,0)/NULLIF(s.TBS_MAX,0)/10)),10,' ') C6,
            TO_CHAR(ROUND(100*NVL(u.TBS_USED,0)/NULLIF(s.TBS_MAX,0),1)) ||'%' C7,
            TO_CHAR((GREATEST(s.TBS_MAX,s.TBS_ALLOC) - s.TBS_ALLOC +
                    NVL(f.TBS_FREE,s.TBS_ALLOC - NVL(u.TBS_USED,0)))/1024,
                    '999,999,999,999.9') ||'G' C8,
            ' '||t.TBS_NAME C9
     FROM   Q_TBS t,
            Q_TBS_ALLOC_MAX s,
            Q_TBS_FREE f,
            Q_TBS_USED u
     WHERE  t.TBS_NAME = s.TBS_NAME (+)
     AND    t.TBS_NAME = f.TBS_NAME (+)
     AND    t.TBS_NAME = u.TBS_NAME (+)
    )
) ORDER BY C0O, REVERSE(C9);

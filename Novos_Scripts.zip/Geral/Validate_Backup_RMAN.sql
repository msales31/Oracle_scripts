set pages 9999 lines 500
set numformat 99999.99
set trim on
set trims on
alter session set nls_date_format = 'DD-MM-YYYY HH24:MI:SS';
col status for a25
col COMMAND_ID for a20
col INPUT_TYPE for a10
col OUTPUT_DEVICE_TYPE for a10
col OUTPUT_BYTES_PER_SEC_DISPLAY for a9
col status heading "BACKUP| STATUS"
col COMMAND_ID heading "BACKUP| NAME"
col STARTED_TIME heading "START| TIME"
COL END_TIME heading "END| TIME"
col ELAPSED_TIME heading "MINUTES | TAKEN"
col INPUT_TYPE heading "INPUT| TYPE"
col OUTPUT_DEVICE_TYPE heading "OUTPUT| DEVICES"
col INPUT_SIZE heading  "INPUT SIZE|GB"
col OUTPUT_SIZE heading  "OUTPUT SIZE|GB"
col OUTPUT_BYTES_PER_SEC_DISPLAY heading "OUTPUT | RATE|(PER SEC)"
SELECT rj.COMMAND_ID,
       rj.INPUT_TYPE || 
	   case when rj.input_type = 'DB INCR' then 
	     case when (rj.output_bytes / rj.input_bytes * 100) < 10 then '-1' 
		   else '-0'
		 end 
	   end INPUT_TYPE,
	   rj.STATUS,
       to_char(max(rj.START_TIME), 'dd/mm/yyyy hh24:mi:ss') STARTED_TIME,
       to_char(rj.END_TIME, 'dd/mm/yyyy hh24:mi:ss') END_TIME,
       rj.ELAPSED_SECONDS/60 ELAPSED_TIME,
       rj.OUTPUT_DEVICE_TYPE,
       rj.INPUT_BYTES/1024/1024/1024 INPUT_SIZE,
       rj.OUTPUT_BYTES/1024/1024/1024 OUTPUT_SIZE,
       rj.OUTPUT_BYTES_PER_SEC_DISPLAY
  from v$rman_backup_job_details rj, v$rman_status rs
 where rj.COMMAND_ID=rs.COMMAND_ID
   and rj.INPUT_TYPE=Nvl('&INPUT_TYPE', rj.INPUT_TYPE)
 group by rs.sid,rj.COMMAND_ID,rj.STATUS,rj.START_TIME,rj.END_TIME,rj.ELAPSED_SECONDS,rj.INPUT_TYPE,rj.OUTPUT_DEVICE_TYPE,rj.INPUT_BYTES,rj.OUTPUT_BYTES,rj.OUTPUT_BYTES_PER_SEC_DISPLAY
having max(rj.START_TIME) > sysdate-&NUMBER_OF_DAYS 
 order by rj.START_TIME desc;
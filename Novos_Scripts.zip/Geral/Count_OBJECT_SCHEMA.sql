col Owner for a18;
col TABLE for 99999;
col PTABLE for 9999;
col INDEX for 99999;
col PINDEX for 9999;
col PCK  for 9999;
col PBODY for 9999;
col SEQUENCE for 9999;
col TRIGGER for 99999;
col PROCEDURE for 999999;
col FUNCTION for 9999;
col VIEW for 9999;
col TYPE for 9999;
col SYNONYM for 99999;
col LOB for 9999;
col JOB for 9999;
col MT_VIEW for 999;
col DBLINK for 999;
col Other for 99999;
col Total for 9999999;
SELECT DECODE(GROUPING(a.owner),1,'All Owners',a.owner) AS "Owner"
      ,COUNT(CASE WHEN a.object_type = 'TABLE'             THEN 1 ELSE NULL END) "TABLE"
      ,COUNT(CASE WHEN a.object_type = 'TABLE PARTITION'   THEN 1 ELSE NULL END) "PTABLE"
      ,COUNT(CASE WHEN a.object_type = 'INDEX'             THEN 1 ELSE NULL END) "INDEX"
      ,COUNT(CASE WHEN a.object_type = 'INDEX PARTITION'   THEN 1 ELSE NULL END) "PINDEX"
      ,COUNT(CASE WHEN a.object_type = 'PACKAGE'           THEN 1 ELSE NULL END) "PCK"
      ,COUNT(CASE WHEN a.object_type = 'PACKAGE BODY'      THEN 1 ELSE NULL END) "PBODY"
      ,COUNT(CASE WHEN a.object_type = 'SEQUENCE'          THEN 1 ELSE NULL END) "SEQUENCE"
      ,COUNT(CASE WHEN a.object_type = 'TRIGGER'           THEN 1 ELSE NULL END) "TRIGGER"
      ,COUNT(CASE WHEN a.object_type = 'PROCEDURE'         THEN 1 ELSE NULL END) "PROCEDURE"
      ,COUNT(CASE WHEN a.object_type = 'FUNCTION'          THEN 1 ELSE NULL END) "FUNCTION"
      ,COUNT(CASE WHEN a.object_type = 'VIEW'              THEN 1 ELSE NULL END) "VIEW"
      ,COUNT(CASE WHEN a.object_type = 'TYPE'              THEN 1 ELSE NULL END) "TYPE"
      ,COUNT(CASE WHEN a.object_type = 'SYNONYM'           THEN 1 ELSE NULL END) "SYNONYM"
      ,COUNT(CASE WHEN a.object_type = 'LOB'               THEN 1 ELSE NULL END) "LOB"
      ,COUNT(CASE WHEN a.object_type = 'JOB'               THEN 1 ELSE NULL END) "JOB"
      ,COUNT(CASE WHEN a.object_type = 'MATERIALIZED VIEW' THEN 1 ELSE NULL END) "MT_VIEW"
      ,COUNT(CASE WHEN a.object_type = 'DATABASE LINK'     THEN 1 ELSE NULL END) "DBLINK"
      ,COUNT(CASE
             WHEN a.object_type NOT IN ('PACKAGE','TABLE','INDEX','SEQUENCE','TRIGGER','PACKAGE BODY','PROCEDURE','FUNCTION','VIEW','TYPE','SYNONYM','LOB','JOB', 'DATABASE LINK','MATERIALIZED VIEW') THEN 1
             ELSE NULL END) "Other"
      ,COUNT(CASE WHEN 1 = 1                               THEN 1 ELSE NULL END) "Total"
FROM dba_objects a
where owner like nvl(upper('&owner'),'%')
  and owner not in
           ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS',
            'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN',
            'OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS',
            'SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY',
            'WKSYS','WMSYS','XDB','ORACLE_OCM','PUBLIC','REMOTE_SCHEDULER_AGENT')
  and oracle_maintained = 'N'
GROUP BY rollup(a.owner);

SELECT TO_CHAR(action_time, 'DD-MON-YYYY HH24:MI:SS') AS action_time,
       action,
       STATUS,
       DESCRIPTION,
       PATCH_ID,
       PATCH_TYPE
FROM   sys.dba_registry_sqlpatch
ORDER by action_time desc;

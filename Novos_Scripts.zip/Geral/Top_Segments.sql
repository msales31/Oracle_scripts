COLUMN owner FORMAT A15
COLUMN table_name FORMAT A30
COLUMN column_name FORMAT A30
COLUMN segment_name FORMAT A30
COLUMN index_name FORMAT A30
COLUMN tablespace_name FORMAT A20
SELECT l.owner, l.table_name, l.column_name, l.segment_name, l.index_name, s.tablespace_name
FROM dba_lobs l
JOIN dba_segments s ON l.segment_name = s.segment_name
WHERE l.segment_name LIKE '&SEGMENT_NAME';
 sqlplus /nolog conn / AS sysdba

SET tab off underline off linesize 2050 newpage none pagesize 4000 appinfo "dba";
SET feedback
ON colsep | editfile /tmp/reginaldo-sqlplusedit.tmp long 1000000 trimout on;

SET serveroutput
ON size 1000000 trimspool
ON longchunksize 1000000 time on;

SET sqlblanklines
ON timing
ON sqlprompt "_user'@'_connect_identifier> "; col name format a25; col path format a30;

SELECT  name
       ,header_status
       ,state
       ,path
       ,TOTAL_MB
       ,MOUNT_STATUS
FROM V$ASM_DISK;
--SELECT  *
--FROM DBA_RSRC_IO_CALIBRATE; exec dbms_stats.gather_system_stats 
--('EXADATA' 
--);

--SET SERVEROUTPUT
--ON DECLARE lat INTEGER; iops INTEGER; mbps INTEGER; BEGIN DBMS_RESOURCE_MANAGER.CALIBRATE_IO （<DISKS> <MAX_LATENCY> iops mbps lat）; DBMS_RESOURCE_MANAGER.CALIBRATE_IO （8 10 iops mbps lat）; DBMS_OUTPUT.PUT_LINE （'max_iops = ' || iops）; DBMS_OUTPUT.PUT_LINE （'latency = ' || lat）; dbms_output.put_line（'max_mbps = ' || mbps）; end; /






   SET SERVEROUTPUT ON 
   DECLARE 
   lat INTEGER; 
   iops INTEGER; 
   mbps INTEGER;
   BEGIN 
   SYS.DBMS_RESOURCE_MANAGER.CALIBRATE_IO(8, 10, iops, mbps, lat); 
   DBMS_OUTPUT.PUT_LINE ('max_iops = ' || iops); 
   DBMS_OUTPUT.PUT_LINE ('latency = ' || lat); 
   dbms_output.put_line ('max_mbps = ' || mbps); 
   end; 
   /







BEGIN
DBMS_RESOURCE_MANAGER.CALIBRATE_IO (
   num_physical_disks => 10,
   max_latency => 20,
   max_iops,
   max_mbps,
   actual_latency);
END;
/
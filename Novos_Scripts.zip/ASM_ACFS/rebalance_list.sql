SELECT  group_number
       ,operation
       ,state
       ,power
       ,actual
       ,sofar
       ,est_work
       ,est_rate
       ,est_minutes
FROM V$ASM_OPERATION;
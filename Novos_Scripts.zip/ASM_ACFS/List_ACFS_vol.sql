SELECT SUBSTR(fs_name,1,24) FILESYSTEM, SUBSTR(vol_device,1,20) DEVICE, prepared_status, 
     enabled_status FROM V$ASM_ACFS_SECURITY_INFO;


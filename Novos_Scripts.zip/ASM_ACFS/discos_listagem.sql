 col name format a25; col path format a30;

SELECT  name 
       ,header_status 
       ,state 
       ,path 
       ,TOTAL_MB 
       ,MOUNT_STATUS
FROM V$ASM_DISK; 
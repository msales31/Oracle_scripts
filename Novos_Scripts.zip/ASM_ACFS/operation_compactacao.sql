 -- verifica compacta��o, se REBALST_KFGMG estiver igual a 2, quer dizer que est� compactando.
SELECT  NUMBER_KFGMG
       ,OP_KFGMG
       ,ACTUAL_KFGMG
       ,REBALST_KFGMG COMPACTING
FROM X$KFGMG; 
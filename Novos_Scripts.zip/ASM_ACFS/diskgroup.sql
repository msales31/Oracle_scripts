SET feedback off heading
ON appinfo "CHECK-ASM" pages 50000 lines 200; col group_name format a20 head 'disk group|name' col sector_size format 99,999 head 'sector|size' col block_size format 99,999 head 'block|size' col allocation_unit_size format 999,999,999 head 'allocation|unit size' col state format a11 head 'state' col type format a6 head 'type' col total_mb format 999,999,999 head 'total size (mb)' col used_mb format 999,999,999 head 'used size (mb)' col free_mb format 999,999,999 head 'free size (mb)' col pct_used format 999.99 head 'pct. used' col offline_disks format 9999 head 'offline|disks' break
ON report
ON group_name skip 0 compute sum label "total: " of total_mb used_mb free_mb
ON report
SELECT  name group_name
       ,sector_size sector_size
       ,block_size block_size
       ,allocation_unit_size allocation_unit_size
       ,state state
       ,type type
       ,total_mb total_mb
       ,(total_mb - free_mb) used_mb
       ,free_mb free_mb
       ,round((1 - (free_mb / total_mb)) * 100,2) pct_used
FROM v$asm_diskgroup
WHERE name not IN ('TEMP','TMP01','UNDO1','UNDO2')
ORDER BY name /  
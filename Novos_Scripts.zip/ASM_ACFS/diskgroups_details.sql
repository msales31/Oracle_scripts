 Conn AS sqlplus '/ AS sysasm'

SET lines 255 col path for a35 col Diskgroup for a15 col DiskName for a20 col disk# for 999 col total_mb for 999,999,999 col free_mb for 999,999,999 compute sum of total_mb
ON DiskGroup compute sum of free_mb
ON DiskGroup break
ON DiskGroup skip 1
ON report

SET pages 255
SELECT  a.name DiskGroup
       ,b.disk_number Disk#
       ,b.name DiskName
       ,b.os_mb
       ,b.total_mb
       ,b.free_mb
       ,b.path
       ,b.header_status
FROM v$asm_disk b, v$asm_diskgroup a
WHERE a.group_number (+) =b.group_number
ORDER BY b.group_number, b.disk_number, b.name / 
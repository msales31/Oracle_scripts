alter database recover managed standby database disconnect using current logfile;
-- para dg com rac -- alter database recover managed standby database disconnect using current logfile parallel 32 INSTANCES ALL;
--madero -- alter database recover managed standby database disconnect using current logfile parallel 10 INSTANCES ALL;
--Known Issues and Recommendations related to MIRA from 12.2 Onwards (Exadata and Non Exadata envirnoment) (Doc ID 2678711.1)	
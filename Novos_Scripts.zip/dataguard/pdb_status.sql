SELECT name, open_mode, recovery_status 
FROM   v$pdbs
ORDER BY 1;
col id for 99
col message for a125
select DEST_ID ID,
         to_char(timestamp,'DD/MM/YYYY HH24:MI:SS')||' '||message message
from v$dataguard_status;

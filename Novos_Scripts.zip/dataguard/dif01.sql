select sequenceInPrimary
, sequenceSynchedInStandBy
, sequenceInPrimary-sequenceSynchedInStandBy as logApplyGap from (select max(sequence#) sequenceInPrimary from v$archived_log) 
,(select max(sequence#) sequenceSynchedInStandBy from v$archived_log where applied='YES'); 
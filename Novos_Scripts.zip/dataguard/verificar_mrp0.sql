select inst_id, process, thread#, sequence#, block#, status, client_process from gv$managed_standby;

col name format a30
col value format a30
select name,value,TIME_COMPUTED,DATUM_TIME from V$DATAGUARD_STATS;

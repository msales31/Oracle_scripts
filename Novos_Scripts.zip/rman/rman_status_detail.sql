select 
start_time, 
end_time, 
status, 
sum(elapsed_seconds)/60/60 final_horas 
from sys.V_$RMAN_BACKUP_JOB_DETAILS group by start_time, end_time, status;

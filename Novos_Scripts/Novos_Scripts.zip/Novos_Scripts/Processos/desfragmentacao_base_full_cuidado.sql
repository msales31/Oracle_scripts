

#####Lista tabelas fragmentadas do owner x.####

col table_Name for a25
col "Table size" for 9999999999
col "Actual Data size" for 99999999999
col pct_free for 99999999
col "KB Free Space" for 999999999
select table_name,
round((blocks*8),2)||'kb' "Table size",
round((num_rows*avg_row_len/1024),2)||'kb' "Actual Data size",
pct_free,
round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) "KB Free Space"
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc;
###################################


spool tuning.log;
@?/rdbms/admin/utlrp.sql;
@enable.sql;
@enable.sql;

@?/rdbms/admin/utlrp.sql;
@shrink.sql;
@shrink_lobs.sql;
@disable.sql;
@disable.sql;
@rebuild_all.sql

@?/rdbms/admin/utlrp.sql;
@coleta.sql;
spool off;


####### ENABLE ROW MOVEMENT TABLES #####
spool enable.sql;
select 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' ENABLE ROW MOVEMENT;'
from dba_tables
where UPPER(owner) not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM');
spool off;


###### SHRINK por order de tamanho, maiores no final.
spool shrink.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' SHRINK SPACE;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

####### DISABLE ROW MOVEMENT TABLES #####
spool disable.sql;
select 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' DISABLE ROW MOVEMENT;'
from dba_tables
where UPPER(owner) not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM');
spool off;

###### coleta.sql ordenado por bytes
spool coleta.sql
select 'exec dbms_stats.gather_table_stats(''"'||a.owner||'"'' ,''"'||a.object_name||'"'',  estimate_percent => 100, cascade => true, degree=>8);'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.owner not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;


###### coleta.sql all
spool coleta.sql
select 'exec dbms_stats.gather_table_stats(''"'||owner||'"'' ,''"'||table_name||'"'',  method_opt => ''FOR ALL COLUMNS SIZE AUTO'');'
from dba_tables
where temporary like 'N'
and owner not in ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS',
'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN',
'OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS',
'SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY',
'WKSYS','WMSYS','XDB','ORACLE_OCM','PUBLIC');
spool off;


## Shrink de todos os lobs por  tamanho - shrink meio online
spool shrink_lobs.sql
select 'alter table '||a.owner||'."' || a.TABLE_NAME ||'" MODIFY LOB ("'||a.column_name||'")  (SHRINK SPACE);'
from dba_lobs a, DBA_SEGMENTS B
where A.OWNER=B.OWNER
and a.table_name = b.segment_name
ORDER BY B.BYTES;
spool off

############

#### rebuild todos os indices
spool rebuild_all.sql;
select 'ALTER INDEX '||a.OWNER||'.'||a.OBJECT_NAME||' REBUILD;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
AND a.owner not in
       ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
       'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
       'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
       'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
order by b.bytes;
spool off;


########################################################################




spool rebuild_consinco.sql;
select 'ALTER INDEX '||a.OWNER||'.'||a.OBJECT_NAME||' REBUILD TABLESPACE TSI_CONSINCO;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.OWNER LIKE 'CONSINCO'
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

spool rebuild_monitor.sql;
select 'ALTER INDEX '||a.OWNER||'.'||a.OBJECT_NAME||' REBUILD TABLESPACE TSI_CONSINCOMONITOR;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.OWNER LIKE 'CONSINCOMONITOR'
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

spool rebuild_datavale.sql;
select 'ALTER INDEX '||a.OWNER||'.'||a.OBJECT_NAME||' REBUILD TABLESPACE TSI_DATAVALE;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and B.TABLESPACE_NAME in ('TSD_DATAVALE','TSI_DATAVALE')
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
AND a.owner not in
       ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
       'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
       'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
       'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
order by b.bytes;
spool off;



spool rebuild_resto.sql;
select 'ALTER INDEX '||a.OWNER||'.'||a.OBJECT_NAME||' REBUILD;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and B.TABLESPACE_NAME not in ('TSD_CONSINCO','TSI_CONSINCO','TSD_CONSINCOMONITOR','TSI_CONSINCOMONITOR')
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
AND a.owner not in
             ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
       'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
       'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
       'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
order by b.bytes;
spool off;



spool rebuild_resto.sql;
select 'ALTER INDEX '||a.OWNER||'.'||a.OBJECT_NAME||' REBUILD;'
--select a.owner, a.object_name, a.last_ddl_time
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.object_type like '%INDEX%'
and a.last_ddl_time < sysdate - 1
AND a.TEMPORARY LIKE 'N'
AND a.owner not in
       ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
       'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
       'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
       'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
order by bytes;
spool off;


#### tirar paralelismo de index, pois qdo usa rebuild parallel, ele deixa em parallel como default e isso prejudica muito a base
#!/bin/sh

test -s /etc/profile.d/oracle.sh && source /etc/profile.d/oracle.sh
export ORACLE_SID=dbprod

sqlplus -S /nolog << _CLRECBIN_
  connect / as sysdba ;
set tab off underline off linesize 2050 newpage none pagesize 4000 appinfo "dba";
set feedback on colsep | editfile /tmp/ibanes-sqlplusedit.tmp long 1000000 trimout on;
set serveroutput on size 1000000 trimspool on longchunksize 1000000 time on;
set linesize 200;
set sqlblanklines on timing on sqlprompt "_user'@'_connect_identifier> ";
spool no_parallel_index.sql
SELECT 'ALTER INDEX '||OWNER||'.'||INDEX_NAME||' parallel 1;'
FROM DBA_INDEXES
WHERE OWNER NOT IN ('SYS','SYSTEM','OUTLN','DIP','TSMSYS','DBSNMP','WMSYS','EXFSYS','XDB','ANONYMOUS','CTXSYS','MDSYS','PUBLIC','ORDSYS','ORDPLUGINS')
and degree > 1;
spool off;
@no_parallel_index.sql
  quit ;
_CLRECBIN_


############



@rebuild_resto.sql

spool rebuild_all.sql;
select 'ALTER INDEX '||OWNER||'.'||INDEX_NAME||' REBUILD TABLESPACE TSI_DATAVALE;'
from dba_indexes
WHERE TABLESPACE_NAME in ('TSD_DATAVALE','TSI_DATAVALE');
spool off;

##### MOVER LOBS #####
spool move_lobs.sql;
select 'ALTER TABLE '||A.OWNER||'.'||A.TABLE_NAME||' MOVE LOB('||A.COLUMN_NAME||') STORE AS (TABLESPACE '||A.TABLESPACE_NAME||');'
FROM DBA_LOBS A, DBA_SEGMENTS B
WHERE A.SEGMENT_NAME IN ('SYS_LOB0000100707C00004$$','SYS_LOB0000100883C00009$$','SYS_LOB0000100919C00004$$','SYS_LOB0000100932C00018$$','SYS_LOB0000100603C00012$$','SYS_LOB0000100932C00005$$')
AND A.SEGMENT_NAME = B.SEGMENT_NAME
AND A.OWNER=B.OWNER
ORDER BY B.BYTES;
spool off;


#############
### MOVE LOBS POR TABELA E OWNER
### CUIDADO, VAI INVALIDAR OBJETOS E TRAVAR A BASE

select 'ALTER TABLE '||A.OWNER||'.'||A.TABLE_NAME||' MOVE LOB('||A.COLUMN_NAME||') STORE AS (TABLESPACE '||A.TABLESPACE_NAME||');'
FROM DBA_LOBS A, DBA_SEGMENTS B
WHERE A.SEGMENT_NAME = B.SEGMENT_NAME
AND A.OWNER=B.OWNER
and a.table_name = 'COLD_PROD'
and A.OWNER='NDD_COLD'
ORDER BY B.BYTES;

###############
##################




#############
## move todos lobs > 1MB.
spool move_lobs.sql;
select 'ALTER TABLE '||A.OWNER||'.'||A.TABLE_NAME||' MOVE LOB('||A.COLUMN_NAME||') STORE AS (TABLESPACE '||A.TABLESPACE_NAME||');'
FROM DBA_LOBS A, DBA_SEGMENTS B
WHERE A.SEGMENT_NAME = B.SEGMENT_NAME
AND A.OWNER=B.OWNER
AND B.BYTES > 104857
AND b.owner not in
       ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
       'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
       'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
       'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
ORDER BY B.BYTES;
spool off;
##################




### SHRINK SPACE DAS 50 TABELAS MAIS FRAGMENTADAS DO BANCO
select * from (
select table_name
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
and owner in ('TEKNISA','MADERO')
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc
)
where rownum < 50;

####### ENABLE ROW MOVEMENT TABLES #####
spool enable.sql;
select 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' ENABLE ROW MOVEMENT;' from (
select owner, table_name
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
and owner in ('TEKNISA','MADERO')
and TEMPORARY = 'N'
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc
)
where rownum < 50;
spool off;


###### SHRINK por order de tamanho, maiores no final.
spool shrink.sql;
select 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' SHRINK SPACE;' from (
select owner, table_name
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
and owner in ('TEKNISA','MADERO')
and TEMPORARY = 'N'
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc
)
where rownum < 50;
spool off;




####### DISABLE ROW MOVEMENT TABLES #####
spool disable.sql;
select 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' DISABLE ROW MOVEMENT;' from (
select owner, table_name
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
and owner in ('TEKNISA','MADERO')
and TEMPORARY = 'N'
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc
)
where rownum < 50;
spool off;



###### coleta.sql ordenado por bytes
spool coleta.sql
select 'exec dbms_stats.gather_table_stats(''"'||owner||'"'' ,''"'||table_name||'"'',  estimate_percent => 30, cascade => true, degree=>1);'
from (
select owner, table_name
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
and owner in ('TEKNISA','MADERO')
and TEMPORARY = 'N'
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc
)
where rownum < 50;
spool off;
##########################################

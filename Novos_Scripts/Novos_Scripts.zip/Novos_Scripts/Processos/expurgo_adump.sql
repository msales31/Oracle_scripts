#!/bin/bash

# Defina a variável ORACLE_UNIQUE_NAME aqui
ORACLE_UNIQUE_NAME="manc01_vcp13b"

# Define o diretório adump com base no ORACLE_UNIQUE_NAME
ADUMP_DIR="/u01/app/oracle/admin/$ORACLE_UNIQUE_NAME/adump"

# Verifica se o diretório existe
if [ ! -d "$ADUMP_DIR" ]; then
    echo "Erro: O diretório $ADUMP_DIR não existe."
    exit 1
fi

# Deleta arquivos .aud com mais de 1 dia
find "$ADUMP_DIR" -name "*.aud" -type f -mtime +1 -exec rm -f {} \;

echo "Limpeza do diretório $ADUMP_DIR concluída."

#!/bin/bash

# Defina o arquivo de log
LOGFILE="coleta_estatisticas.log"

# Limpa o arquivo de log existente ou cria um novo
: > $LOGFILE

# Obtém a lista de owners
OWNERS=$($ORACLE_HOME/bin/sqlplus -S / as sysdba <<EOF
SET PAGESIZE 0
SET FEEDBACK OFF
SET HEADING OFF
SELECT DISTINCT owner
FROM dba_objects
WHERE owner NOT LIKE '%SYS%'
AND OWNER NOT LIKE '%BACKUP%'
AND owner NOT IN ('SYS','SYSTEM','SYSMAN','OUTLN','PERFSTAT','GGADMIN','REMOTE_SCHEDULER_AGENT','DIP','TSMSYS','DBSNMP','WMSYS','EXFSYS','XDB','ANONYMOUS','CTXSYS','DMSYS','MDSYS','ORDSYS','GSMADMIN_INTERNAL','APPQOSSYS','DBSFWUSER','ORDDATA','OJVMSYS','DVSYS','LBACSYS','OLAPSYS')
ORDER BY owner;
EOF
)

# Remove linhas vazias e espaços em branco da lista de owners
OWNERS=$(echo "$OWNERS" | sed '/^\s*$/d')

# Loop para coletar as estatísticas de cada owner
for OWNER in $OWNERS; do
  # Hora de início
  START_TIME=$(date +%Y-%m-%d\ %H:%M:%S)
  echo "Iniciando coleta de estatísticas para o owner: $OWNER às $START_TIME" | tee -a $LOGFILE

  # Comando SQL para coleta de estatísticas
  SQL_CMD="EXEC DBMS_STATS.gather_schema_stats (ownname => '$OWNER', cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 8);"

  # Executa o comando no SQL*Plus
  echo "$SQL_CMD" | $ORACLE_HOME/bin/sqlplus -S / as sysdba >> $LOGFILE 2>&1

  # Hora de término
  END_TIME=$(date +%Y-%m-%d\ %H:%M:%S)
  echo "Concluída coleta de estatísticas para o owner: $OWNER às $END_TIME" | tee -a $LOGFILE

  # Calcula o tempo decorrido
  START_EPOCH=$(date -d "$START_TIME" +%s)
  END_EPOCH=$(date -d "$END_TIME" +%s)
  ELAPSED_TIME=$(($END_EPOCH - $START_EPOCH))

  # Converte o tempo decorrido para formato legível (HH:MM:SS)
  ELAPSED_HMS=$(printf '%02d:%02d:%02d\n' $(($ELAPSED_TIME/3600)) $(($ELAPSED_TIME%3600/60)) $(($ELAPSED_TIME%60)))

  echo "Tempo decorrido para $OWNER: $ELAPSED_HMS" | tee -a $LOGFILE
done

echo "Coleta de estatísticas concluída." | tee -a $LOGFILE

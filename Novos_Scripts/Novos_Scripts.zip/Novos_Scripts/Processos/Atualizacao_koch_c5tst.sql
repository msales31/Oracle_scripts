c5tst02

*************************************************

GARANTIR UM DUMP DO SCHEMA KOCK antes de iniciar!

*************************************************

================================================================================================================================================
sqlplus / as sysdba <<EOF
create pfile='/home/oracle/init-c5tst02.ora' from spfile;
exit;
EOF

startup pfile='/home/oracle/init-c5tst02.ora' nomount;
create spfile from pfile='/home/oracle/init-c5tst02.ora';
shutdown immediate;

sqlplus / as sysdba
alter system set db_name="consinco" scope=spfile;
shutdown immediate;
startup nomount;
================================================================================================================================================

control_files:
+DATA/c5tst02_gru1fz/controlfile/stby_control.ctl

asmcmd << _ASM_
rm -f  +DATA/C5TST02_GRU1FZ/CONTROLFILE/*
rm -f +DATA/C5TST02_GRU1FZ/DATAFILE/*
rm -f +DATA/C5TST02_GRU1FZ/TEMPFILE/*
rm -f +DATA/C5TST02_GRU1FZ/onlinelog/*
_ASM_
*/


_rman prod
list backup of controlfile completed between "to_date('28-JUN-2022 00:00:00','DD-MON-YYYY HH24:MI:SS')" and "to_date('29-JUN-2022 23:59:00','DD-MON-YYYY HH24:MI:SS')";


BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ -------------------
311816  Full    5.50M      SBT_TAPE    00:00:03     28/06/2022 21:26:36
        BP Key: 311816   Status: AVAILABLE  Compressed: YES  Tag: INC1DDIARIO202206281915
        Handle: rman_ctrl_consinco_INC1D_dbid312226828_s317097_t1108589193_p1.bkp   Media: objectstorage.sa-saopau..loud.com/n/grzcvzqjrljm/Backup-consinco
  Standby Control File Included: Ckp SCN: 174269162429   Ckp time: 28/06/2022 21:01:20

================================================================================================================================================

rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
restore CONTROLFILE from 'rman_ctrl_consinco_INC1D_dbid312226828_s317097_t1108589193_p1.bkp';
}
ALTER DATABASE MOUNT;
__RMAN__


rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
spool log to '/tmp/restore-c5tst02.log';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c6 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c7 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
allocate channel c8 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/consinco/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/consinco/opcconsinco.ora)';
SET NEWNAME FOR DATABASE TO NEW;
RESTORE DATABASE until SCN 174269162429;
switch datafile all;
switch tempfile all;
RECOVER DATABASE until SCN 174269162429;
}
__RMAN__


Starting restore at 29/06/2022 19:44:31

Finnish 30Jun2022/12:52



================================================================================================================================================

alter database backup controlfile to trace as '/tmp/back-c5tst02.ctl';
SHUTDOWN IMMEDIATE;
  
startup nomount;
alter system set db_name="c5tst02" scope=spfile;
alter system set "_allow_resetlogs_corruption"=TRUE scope=spfile;
SHUTDOWN IMMEDIATE;

================================================================================================================================================
_asm
rm -f +DATA/C5TST02_GRU1FZ/controlfile/stby_control.ctl

vi /tmp/back-c5tst02.ctl;
--CREATE CONTROLFILE SET DATABASE "c5tst02" RESETLOGS NOARCHIVELOG

--LOGFILE
--  GROUP 1 '+DATA/c5tst02_gru1fz/onlinelog/redolog_01.log'  SIZE 600M BLOCKSIZE 512,
--  GROUP 2 '+DATA/c5tst02_gru1fz/onlinelog/redolog_02.log'  SIZE 600M BLOCKSIZE 512,
--  GROUP 3 '+DATA/c5tst02_gru1fz/onlinelog/redolog_03.log'  SIZE 600M BLOCKSIZE 512
================================================================================================================================================

STARTUP NOMOUNT;
@/tmp/back-c5tst02.ctl;
ALTER DATABASE OPEN RESETLOGS;


SHUTDOWN IMMEDIATE;
STARTUP MOUNT EXCLUSIVE;
ALTER DATABASE NOARCHIVELOG;
ALTER DATABASE OPEN;
SELECT log_mode FROM gv$database;


set linesize 4000;
set pagesize 4000;
col PROPERTY_NAME format A25;
col PROPERTY_VALUE format A10;
col DESCRIPTION format A40;
SELECT * FROM DATABASE_PROPERTIES where PROPERTY_NAME='DEFAULT_TEMP_TABLESPACE';

CREATE TEMPORARY TABLESPACE TEMP999;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TEMP999;
ALTER TABLESPACE TEMP999 ADD TEMPFILE '+DATA' SIZE 50M autoextend on next 100M maxsize 32760M;
DROP TABLESPACE TMP INCLUDING CONTENTS AND DATAFILES;
alter system set job_queue_processes=0 scope=memory ;
alter system set job_queue_processes=0 scope=spfile ;
exec dbms_scheduler.set_scheduler_attribute ('SCHEDULER_DISABLED', 'TRUE') ;
commit ;
alter user SYS identified by "c5tst02";
alter user SYSTEM identified by "c5tst02";
shutdown immediate ;
startup ;

##############################################################################################
Voltar Backup do Schema KOCH

drop user KOCH CASCADE;

CREATE USER "KOCH" IDENTIFIED BY VALUES '3E80F6D30E5962C4'
DEFAULT TABLESPACE AUDITORIAS
TEMPORARY TABLESPACE TEMP999
PROFILE DEFAULT
ACCOUNT UNLOCK;
GRANT CREATE VIEW to KOCH;
GRANT DEBUG ANY PROCEDURE to KOCH;
GRANT DEBUG CONNECT SESSION to KOCH;
GRANT CREATE JOB to KOCH;
GRANT UNLIMITED TABLESPACE to KOCH;
GRANT SELECT ANY TABLE to KOCH;
GRANT CONNECT to KOCH ;
GRANT RESOURCE to KOCH ;
GRANT EXECUTE on SYS.DBMS_CRYPTO to KOCH;
GRANT DEBUG on SYS.UTL_HTTP to KOCH with grant option ;
GRANT EXECUTE on SYS.UTL_HTTP to KOCH with grant option ;
GRANT EXECUTE on CONSINCO.FC5LIMPAACENTO to KOCH;
GRANT EXECUTE on CONSINCO.FC5MASKCNPJCPF to KOCH;
GRANT EXECUTE on CONSINCO.FC5PESSOATELEFONES to KOCH;
GRANT EXECUTE on CONSINCO.FPRECOFINALTABVENDA to KOCH;
GRANT UPDATE on CONSINCO.MAD_PEDVENDA to KOCH;
GRANT INSERT on CONSINCO.MAD_PEDVENDAITEM to KOCH;
GRANT UPDATE on CONSINCO.MAD_PEDVENDAITEM to KOCH;
GRANT UPDATE on CONSINCO.MRL_PRODEMPSEG to KOCH;
GRANT DEBUG on CONSINCO.PKG_BOLETO to KOCH;
GRANT EXECUTE on CONSINCO.PKG_BOLETO to KOCH;
GRANT EXECUTE on CONSINCO.PKG_C5SEGURANCA to KOCH;
GRANT DEBUG on CONSINCO.PKG_FINANCEIRO to KOCH;
GRANT EXECUTE on CONSINCO.PKG_FINANCEIRO to KOCH;

CREATE or replace DIRECTORY DATA_PUMP_DIR2 AS '/u01/salvo';
GRANT READ,WRITE ON DIRECTORY DATA_PUMP_DIR2 TO system;

impdp \"/ as sysdba\" schemas=KOCH directory=DATA_PUMP_DIR2 dumpfile=koch_chamado.dmp transform=OID:n,PCTSPACE:1 logfile=imp.log
"
##############################################################################################





























UPGRADE
11g

/u01/app/oracle/product/19.0.0.0/dbhome_1/jdk/bin/java -jar /u01/app/oracle/product/19.0.0.0/dbhome_1/rdbms/admin/preupgrade.jar TERMINAL TEXT > /u01/app/oracle/upgrade_info-c5tst02.log

=========================================================================================================
alter system set java_jit_enabled = FALSE;
alter system set "_system_trig_enabled"=FALSE;
alter system set job_queue_processes=0  scope=both;
create or replace java system;
/

alter system set java_jit_enabled = true;
alter system set "_system_trig_enabled"=TRUE;

SET SERVEROUTPUT ON;
EXECUTE DBMS_PREUP.INVALID_OBJECTS;

EXECUTE DBMS_STATS.GATHER_DICTIONARY_STATS;
EXECUTE DBMS_STATS.GATHER_FIXED_OBJECTS_STATS;

select 'grant select on sys.v_$parameter to '|| username ||';'
from dba_users
order by username;

SELECT 'grant ADMINISTER DATABASE TRIGGER to '||owner||';'
FROM DBA_TRIGGERS
WHERE TRIM(BASE_OBJECT_TYPE)='DATABASE'
AND OWNER NOT IN (SELECT GRANTEE FROM DBA_SYS_PRIVS WHERE PRIVILEGE='ADMINISTER DATABASE TRIGGER')
;

grant ADMINISTER DATABASE TRIGGER to SYSTEM;

alter system set SEC_CASE_SENSITIVE_LOGON=false sid='*';


@/u01/app/oracle/cfgtoollogs/seniort2_gru1fz/preupgrade/preupgrade_fixups.sql;

=========================================================================================================

orapwd file=$ORACLE_HOME/dbs/orapwc5tst02
c5tst02


sqlplus / as sysdba <<EOF
create pfile='/home/oracle/init-c5tst02.ora' from spfile;
exit;
EOF

sqlplus / as sysdba <<EOF
shutdown immediate;
exit;
EOF

cp $ORACLE_HOME/dbs/orapwc5tst02 $ORACLE_BASE/product/19.0.0.0/dbhome_1/dbs/;
cp $ORACLE_HOME/dbs/spfilec5tst02.ora $ORACLE_BASE/product/19.0.0.0/dbhome_1/dbs/;

- Switch to the 19c listener.
lsnrctl stop;

export ORACLE_HOME=$ORACLE_BASE/product/19.0.0.0/dbhome_1
export PATH=${ORACLE_HOME}/bin:$PATH
unset ORA_CRS_HOME;

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
lsnrctl start;

sqlplus / as sysdba <<EOF
startup upgrade;
exit;
EOF
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


- You can run the upgrade using either of the following commands. The second is actually just a shorthand for the former.

# Regular upgrade command.
cd $ORACLE_HOME/rdbms/admin
$ORACLE_HOME/perl/bin/perl catctl.pl catupgrd.sql

# Shorthand command.
$ORACLE_HOME/bin/dbupgrade > /u01/app/oracle/dbupgrade-c5tst02.log

--Log: /u01/app/oracle/product/19.0.0.0/dbhome_1/cfgtoollogs/c5tst02_gru1fz/upgrade20220425130453

sqlplus / as sysdba <<EOF
startup
exit;
EOF

@?/rdbms/admin/utlrp.sql;



Boa tarde.

Bases c5tst02 e seniort2 criada na versão 19c no servidor Oracle Cloud OK

----------------------------------------------------------------------------------------
sys/system: seniort2

SENIORT2 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.16.0.227)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = seniort2)
    )
  )

----------------------------------------------------------------------------------------
sys/system: c5tst02

C5TST02 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.16.0.227)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = c5tst02)
    )
  )
----------------------------------------------------------------------------------------

Favor validar.
Obrigado.
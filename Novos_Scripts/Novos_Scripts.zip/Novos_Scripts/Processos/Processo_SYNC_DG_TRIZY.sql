List of Permanent Datafiles
===========================
File Size(MB) Tablespace           RB segs Datafile Name
---- -------- -------------------- ------- ------------------------
1    20720    SYSTEM               ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_system_8t1bbf3n_.dbf
2    30232    SYSAUX               ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_sysaux_8s1bbf3n_.dbf
3    10       LOBS                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_lobs_kfd61w2j_.dbf
4    276      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5ql30_.dbf
5    32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd61nrl_.dbf
6    32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd62bpd_.dbf
7    32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd62bv9_.dbf
8    32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd62kvs_.dbf
9    32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd62rsj_.dbf
10   32762    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6t6hw_.dbf
11   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qh39_.dbf
12   32762    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6t9kj_.dbf
13   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd62rws_.dbf
14   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd62rw5_.dbf
15   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6382d_.dbf
16   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qh1z_.dbf
17   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qh2z_.dbf
18   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qhg7_.dbf
19   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qh8b_.dbf
20   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qjl5_.dbf
21   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qh8p_.dbf
22   32762    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6t5ft_.dbf
23   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd63898_.dbf
24   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd64z5x_.dbf
25   32056    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd7bhym_.dbf
26   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qjpj_.dbf
27   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd67b3b_.dbf
28   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6b4do_.dbf
29   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5rdyq_.dbf
30   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd68f86_.dbf
31   32696    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k1r6_.dbf
32   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6fjqc_.dbf
33   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5rf0o_.dbf
34   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qn4l_.dbf
35   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5vp71_.dbf
36   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6fjfz_.dbf
37   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5zrg9_.dbf
38   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6b78t_.dbf
39   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd60kc9_.dbf
40   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6fjjh_.dbf
41   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6g2xt_.dbf
42   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6hftt_.dbf
43   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6jv3v_.dbf
44   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6fjg9_.dbf
45   32710    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k1p1_.dbf
46   32740    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k1w9_.dbf
47   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6fzl6_.dbf
48   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6g5sx_.dbf
49   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6g5o1_.dbf
50   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6gyps_.dbf
51   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6kb5m_.dbf
52   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6kk50_.dbf
53   276      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5rfln_.dbf
54   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd61nlv_.dbf
55   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6kb80_.dbf
56   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6kk7l_.dbf
57   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd61vpj_.dbf
58   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6sp9s_.dbf
59   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6trmr_.dbf
60   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6krbn_.dbf
61   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6kzcj_.dbf
62   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6mpjp_.dbf
63   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6r316_.dbf
64   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6rl0r_.dbf
65   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6wboc_.dbf
66   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6vknb_.dbf
67   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6wkod_.dbf
68   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6wkv2_.dbf
69   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6xbyp_.dbf
70   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6xg40_.dbf
71   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd70q7m_.dbf
72   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd70y0p_.dbf
73   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd74kh8_.dbf
74   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd72133_.dbf
75   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd72t4k_.dbf
76   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd74rfh_.dbf
77   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd75gk7_.dbf
78   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd74zcm_.dbf
79   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd75gj7_.dbf
80   32760    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd75hgx_.dbf
81   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6nhfq_.dbf
82   32672    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k1n7_.dbf
83   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6o8hl_.dbf
84   32692    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k1xm_.dbf
85   32550    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd75yq4_.dbf
86   32752    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qgwv_.dbf
87   32767    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd6r33v_.dbf
88   32100    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd75yoq_.dbf
89   32652    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd75ynh_.dbf
90   32750    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k219_.dbf
91   24716    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7dff1_.dbf
92   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6p1tb_.dbf
93   24332    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5x360_.dbf
94   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6p8pg_.dbf
95   22020    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7cd86_.dbf
96   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6pcrg_.dbf
97   21060    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k1xf_.dbf
98   32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6rkx7_.dbf
99   21296    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k1vz_.dbf
100  32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6rs3m_.dbf
101  28584    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7cm9z_.dbf
102  32767    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6sh4t_.dbf
103  30128    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7cd2m_.dbf
104  32750    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k1po_.dbf
105  32750    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k1vn_.dbf
106  32750    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k1tf_.dbf
107  31600    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7bm2h_.dbf
108  28248    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7cn9j_.dbf
109  27779    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7dfc8_.dbf
110  26248    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7dflj_.dbf
111  24540    USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7g4jo_.dbf
112  32716    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k1pr_.dbf
113  32765    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd6s873_.dbf
114  31008    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd7bj1g_.dbf
115  8696     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd7chsw_.dbf
116  31972    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd79kxl_.dbf
117  7740     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k4rn_.dbf
118  23292    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd7b0wk_.dbf
119  6352     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k42b_.dbf
120  15613    INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5k3w7_.dbf
121  5468     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k4ds_.dbf
122  8652     INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd7b31v_.dbf
123  4444     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k4wh_.dbf
124  1920     INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5qk7c_.dbf
125  3684     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k489_.dbf
126  3408     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k48s_.dbf
127  2572     INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5qhwg_.dbf
128  4868     USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5k4vl_.dbf
129  8155     UNDOTBS1             ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_undotbs1_kfd5k35o_.dbf
130  7608     UNDOTBS1             ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_undotbs1_kfd5k4hh_.dbf
131  8492     UNDOTBS1             ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_undotbs1_kfd5x3gv_.dbf
132  20346    UNDOTBS2             ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_undotbs2_kfd5k1x7_.dbf
133  19482    UNDOTBS2             ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_undotbs2_kfd5k3tz_.dbf
134  3188     UNDOTBS2             ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_undotbs2_kfd5k4g5_.dbf
135  276      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5rflt_.dbf
136  276      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qnhn_.dbf
137  298      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5ql1x_.dbf
138  295      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qk8d_.dbf
139  340      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qjx1_.dbf
140  340      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qkg0_.dbf
141  340      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qkck_.dbf
142  692      USERS                ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_users_kfd5qjrn_.dbf
143  100      INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5vppg_.dbf
144  100      INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd5zrrv_.dbf
145  100      INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd60kor_.dbf
146  100      INDX                 ***     /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_indx_kfd61nxs_.dbf

List of Temporary Files
=======================
File Size(MB) Tablespace           Maxsize(MB) Tempfile Name
---- -------- -------------------- ----------- --------------------
1    500      TEMP                 30720       /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_temp_%u_.tmp
3    4096     TEMP                 30720       /u02/oradata/sine01/SINE01_DEVO03/datafile/o1_mf_temp_%u_.tmp




SQL>

    GROUP# STATUS  TYPE    IS_ MEMBER
---------- ------- ------- --- ----------------------------------------------------------------------------------------------------
        11         ONLINE  NO  /u02/oradata/sine01/SINE01_DEVO03/onlinelog/o1_mf_11_kooxp74l_.log
        12         ONLINE  NO  /u02/oradata/sine01/SINE01_DEVO03/onlinelog/o1_mf_12_kooxp88f_.log
        16         ONLINE  NO  /u02/oradata/sine01/SINE01_DEVO03/onlinelog/o1_mf_16_kooxp9bg_.log
        21         ONLINE  NO  /u02/oradata/sine01/SINE01_DEVO03/onlinelog/o1_mf_21_kooxpnql_.log
        22         ONLINE  NO  /u02/oradata/sine01/SINE01_DEVO03/onlinelog/o1_mf_22_kooxpotr_.log
        26         ONLINE  NO  /u02/oradata/sine01/SINE01_DEVO03/onlinelog/o1_mf_26_kooxppx5_.log



NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
spfile                               string      /u01/app/oracle/product/19.0.0
                                                 .0/dbhome_1/dbs/spfilesine01.o
                                                 ra





CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';

list backup of controlfile completed between "to_date('08/11/2022 00:00:00','DD/MM/YYYY HH24:MI:SS')" and "to_date('08/11/2022 21:00:00','DD/MM/YYYY HH24:MI:SS')";

BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ -------------------
275855  Full    7.25M      SBT_TAPE    00:00:04     08/11/2022 09:42:48
        BP Key: 285649   Status: AVAILABLE  Compressed: YES  Tag: ARCHIVEHORARIO202211080937
        Handle: rman_ctrl_sine01_ARCHIVE_dbid2039177091_s267495_t1120210964_p1.bkp   Media: objectstorage.sa-sao..ud.com/n/grimkhotwqch/backup_oracle_sine01
  Standby Control File Included: Ckp SCN: 1265240396124   Ckp time: 08/11/2022 09:41:43




rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
restore CONTROLFILE from 'rman_ctrl_sine01_ARCHIVE_dbid2039177091_s267495_t1120210964_p1.bkp';
}
ALTER DATABASE MOUNT;
__RMAN__

 
{
   restore standby controlfile from service  'sine01_gru19j';
   alter database mount standby database;
}



 

rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
spool log to '/tmp/restore01.log';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c6 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c7 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
SET NEWNAME FOR DATABASE TO NEW;
RESTORE DATABASE until SCN 1265265491050;
switch datafile all;
switch tempfile all;
RECOVER DATABASE until SCN 1265265491050;
}
__RMAN__


SET ENCRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type DISK;
BACKUP CURRENT CONTROLFILE FOR STANDBY FORMAT '/u01/app/oracle/temp/ForStandbyCTRL.bck';
}

alter database clear UNARCHIVED logfile group 



alter database clear unarchived logfile group  11;
alter database clear unarchived logfile group  12;
alter database clear unarchived logfile group  13;
alter database clear unarchived logfile group  14;
alter database clear unarchived logfile group  15;
alter database clear unarchived logfile group  16;
alter database clear unarchived logfile group  21;
alter database clear unarchived logfile group  22;
alter database clear unarchived logfile group  23;
alter database clear unarchived logfile group  24;
alter database clear unarchived logfile group  25;
alter database clear unarchived logfile group  26;
alter database clear unarchived logfile group 911;
alter database clear unarchived logfile group 912;
alter database clear unarchived logfile group 913;
alter database clear unarchived logfile group 914;
alter database clear unarchived logfile group 915;
alter database clear unarchived logfile group 916;
alter database clear unarchived logfile group 921;
alter database clear unarchived logfile group 922;
alter database clear unarchived logfile group 923;
alter database clear unarchived logfile group 924;
alter database clear unarchived logfile group 925;
alter database clear unarchived logfile group 926;


alter database disable block change tracking ; 

kill -9

 kill -9 3269365;
 kill -9 3269366;
 kill -9 3269367;
 kill -9 3269368;
 kill -9 3269369;
 kill -9 3269370;
 kill -9 3269371;
 kill -9 3303490;
 kill -9 3317020;
 
 3269365
3269366
3269367
3269368
3269369
3269370
3269371


o1_mf_indx_kpntbgd2_.dbf
o1_mf_indx_kpntfhjh_.dbf
o1_mf_indx_kpntfq9m_.dbf
o1_mf_indx_kpntlpod_.dbf
o1_mf_users_kpnsz6vw_.dbf
o1_mf_users_kpnszc0x_.dbf
o1_mf_users_kpnszf4m_.dbf
o1_mf_indx_kpnssy58_.dbf
o1_mf_indx_kpnstpbg_.dbf
o1_mf_indx_kpnstpd2_.dbf
o1_mf_indx_kpnwzcyx_.dbf
o1_mf_indx_kpnx3dr4_.dbf
o1_mf_undotbs1_kpnsmt6h_.dbf
o1_mf_undotbs1_kpnssyz1_.dbf
o1_mf_undotbs1_kpnwwnlm_.dbf
o1_mf_undotbs2_kpnsmrnr_.dbf
o1_mf_undotbs2_kpnsmsy2_.dbf
o1_mf_undotbs2_kpnssz1c_.dbf
o1_mf_users_kpnsmsz3_.dbf
o1_mf_users_kpnsmt16_.dbf
o1_mf_users_kpnsmt4z_.dbf
o1_mf_users_kpnsmt5d_.dbf
o1_mf_users_kpnssypm_.dbf
o1_mf_users_kpnssyy2_.dbf
o1_mf_users_kpnszbw5_.dbf
o1_mf_users_kpnt14go_.dbf
o1_mf_users_kpnt3rpo_.dbf
o1_mf_users_kpntbbys_.dbf
o1_mf_users_kpntc735_.dbf
o1_mf_indx_kpnsmr86_.dbf
o1_mf_indx_kpnsmrc2_.dbf
o1_mf_indx_kpnssw44_.dbf
o1_mf_indx_kpnssw9m_.dbf
o1_mf_indx_kpnsswdq_.dbf
o1_mf_indx_kpnvpv72_.dbf
o1_mf_indx_kpnvqydx_.dbf
o1_mf_indx_kpnvr5b2_.dbf
o1_mf_indx_kpnvvgxf_.dbf
o1_mf_indx_kpnvw7nt_.dbf
o1_mf_indx_kpnvw7w6_.dbf
o1_mf_indx_kpnvwdtl_.dbf
o1_mf_indx_kpnvzjyz_.dbf
o1_mf_indx_kpnwrw7d_.dbf
o1_mf_indx_kpnwsyrz_.dbf
o1_mf_users_kpnsmr9p_.dbf
o1_mf_users_kpnsmrb2_.dbf
o1_mf_users_kpnsmsz1_.dbf
o1_mf_users_kpnssw2c_.dbf
o1_mf_users_kpnsto3o_.dbf
o1_mf_users_kpnvslhj_.dbf
o1_mf_users_kpnwrvkv_.dbf
o1_mf_users_kpnwrvn1_.dbf
o1_mf_users_kpnwrvwv_.dbf
o1_mf_users_kpnwt5qn_.dbf
o1_mf_users_kpnwwd5m_.dbf
o1_mf_users_kpnwy34o_.dbf
o1_mf_users_kpnwy6b0_.dbf
o1_mf_users_kpnwyocx_.dbf
o1_mf_users_kpnwyoff_.dbf
o1_mf_users_kpnwzrf9_.dbf
o1_mf_users_kpnx188k_.dbf
o1_mf_users_kpnx28of_.dbf
o1_mf_users_kpnx2htb_.dbf
o1_mf_users_kpnx2yod_.dbf
o1_mf_users_kpnx360d_.dbf
o1_mf_indx_kpnvn6cd_.dbf
o1_mf_users_kpnw3m7p_.dbf
o1_mf_users_kpnw3pcc_.dbf
o1_mf_users_kpnw8kcs_.dbf
o1_mf_users_kpnwb8sn_.dbf
o1_mf_users_kpnwb8t9_.dbf
o1_mf_users_kpnwbj9o_.dbf
o1_mf_users_kpnwc90o_.dbf
o1_mf_users_kpnwddds_.dbf
o1_mf_users_kpnwddl3_.dbf
o1_mf_users_kpnwk2c0_.dbf
o1_mf_users_kpnwkppy_.dbf
o1_mf_users_kpnwkxfx_.dbf
o1_mf_users_kpnwldjc_.dbf
o1_mf_users_kpnwlmcf_.dbf
o1_mf_users_kpnwm2gv_.dbf
o1_mf_users_kpnwm2j9_.dbf
o1_mf_indx_kpnvftp3_.dbf
o1_mf_indx_kpnvhkt1_.dbf
o1_mf_users_kpnt5j1w_.dbf
o1_mf_users_kpnth30q_.dbf
o1_mf_users_kpntlp5g_.dbf
o1_mf_users_kpnvj0sp_.dbf
o1_mf_users_kpnvk3so_.dbf
o1_mf_users_kpnvk713_.dbf
o1_mf_users_kpnvlxx4_.dbf
o1_mf_users_kpnvmfch_.dbf
o1_mf_users_kpnvml8f_.dbf
o1_mf_users_kpnvtzk1_.dbf
o1_mf_users_kpnvvgqd_.dbf
o1_mf_users_kpnw0myt_.dbf
o1_mf_users_kpnw3m7d_.dbf
o1_mf_indx_kpnsmrbt_.dbf
o1_mf_indx_kpnsmrbv_.dbf
o1_mf_indx_kpnv1k0w_.dbf
o1_mf_indx_kpnv7n9h_.dbf
o1_mf_indx_kpnv8398_.dbf
o1_mf_indx_kpnvbyjn_.dbf
o1_mf_indx_kpnvf1mj_.dbf
o1_mf_users_kpntfh1g_.dbf
o1_mf_users_kpntfp5r_.dbf
o1_mf_users_kpnv8lk3_.dbf
o1_mf_users_kpnvbxf1_.dbf
o1_mf_users_kpnvc5p0_.dbf
o1_mf_users_kpnvd8qp_.dbf
o1_mf_indx_kpnwtz0d_.dbf
o1_mf_users_kpnssw9d_.dbf
o1_mf_users_kpnsz9od_.dbf
o1_mf_users_kpnt13bj_.dbf
o1_mf_users_kpnt3rbb_.dbf
o1_mf_users_kpnt5hln_.dbf
o1_mf_users_kpntbbl1_.dbf
o1_mf_users_kpntbfq5_.dbf
o1_mf_users_kpntc6oq_.dbf
o1_mf_users_kpntc73b_.dbf
o1_mf_users_kpnty1mk_.dbf
o1_mf_users_kpnty8ok_.dbf
o1_mf_users_kpnv0mqz_.dbf
o1_mf_users_kpnv0tys_.dbf
o1_mf_users_kpnv1b1k_.dbf
o1_mf_users_kpnv54rh_.dbf
o1_mf_users_kpnv75cz_.dbf
o1_mf_users_kpnw0y33_.dbf
o1_mf_indx_kpntcfqt_.dbf
o1_mf_lobs_kpnth3l8_.dbf
o1_mf_sysaux_kpnwy6c3_.dbf
o1_mf_system_kpnx0vls_.dbf
o1_mf_users_kpnstnxb_.dbf
o1_mf_users_kpnsz67p_.dbf
o1_mf_users_kpnsz9l4_.dbf
o1_mf_users_kpnszdbc_.dbf
o1_mf_users_kpntc7mo_.dbf
o1_mf_users_kpntlsfm_.dbf
o1_mf_users_kpntn69k_.dbf
o1_mf_users_kpntoxl1_.dbf
o1_mf_users_kpntpdj8_.dbf
o1_mf_users_kpntpdjx_.dbf
o1_mf_users_kpntq5kz_.dbf
o1_mf_users_kpnttrw6_.dbf
o1_mf_users_kpnvzk42_.dbf
o1_mf_users_kpnvzzyw_.dbf
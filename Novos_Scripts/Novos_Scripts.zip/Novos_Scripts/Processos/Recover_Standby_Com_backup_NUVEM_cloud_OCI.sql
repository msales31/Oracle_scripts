##VER MENOR SCN

col CURRENT_SCN format 9999999999999999                                                        
select to_char (min (d.CURRENT_SCN)) from V$DATABASE d                                         
union                                                                                          
select to_char (max (d.CURRENT_SCN)) from V$DATABASE d                                         
union                                                                                          
select to_char (min (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           
union                                                                                          
select to_char (max (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           
union                                                                                          
select to_char (min (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f                                  
union                                                                                          
select to_char (max (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f ;   

412161091347



##GERAR BACKUP NO SERVIDOR DE DESTINO:

allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';

SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';
BACKUP INCREMENTAL FROM SCN 412161091347 DATABASE FORMAT 'ForStandby_%U' tag 'FORSTANDBY';
}

##GERAR CONTROLFILE 

SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/orcl/opcorcl.ora)';
BACKUP CURRENT CONTROLFILE FOR STANDBY TAG 'FORSTANDBY' FORMAT 'rman_ctrl_orcl_ARCHIVE_dbid%I_s%s_t%t_p%p.bkp';
}


# fazer um catalog para mandar pro destino com o nome dos arquivos


catalog DEVICE TYPE 'SBT_TAPE' backuppiece 
spool /tmp/catalog.cmd
set pagesize 0
select '   '''||HANDLE||''','||chr(10)
from V$BACKUP_PIECE bp
where bp.HANDLE is not null
and DEVICE_TYPE = 'SBT_TAPE'
AND TAG='FORSTANDBY'
order by START_TIME, PIECE#;
spool off


#catalogar

rman target / cmdfile=catalog.cmd



## fazer o recover 

RECOVER DATABASE NOREDO;

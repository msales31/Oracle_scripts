Oracle Database Cloud Schema Service - Version N/A and later
Oracle Cloud Infrastructure - Database Service - Version N/A and later
Oracle Database Backup Service - Version N/A and later
Oracle Database Cloud Service - Version N/A and later
Oracle Database - Standard Edition - Version 11.2.0.3 and later
Information in this document applies to any platform.
GOAL
How to purge DBA_RECYCLBIN for objects older than x days/minutes? or do we have RECYCLEBIN RETENTION feature or truncate recyclebin ?

--------------------------------------------------------------------------------------

DBA_RECYCLEBIN has a column called DROPTIME.

But we can not use the below queries to purge or delete the recyclebin objects older than 7 days

DELETE from DBA_RECYCLEBIN where droptime<sysdate-7;  (wrong do not use)

PURGE DBA_RECYCLEBIN where droptime<sysdate-7;  (wrong do not use)

SQL> DELETE from DBA_RECYCLEBIN where droptime<sysdate-7;
DELETE from DBA_RECYCLEBIN where droptime<sysdate-7
*
ERROR at line 1:
ORA-01752: cannot delete from view without exactly one key-preserved table

SQL> PURGE DBA_RECYCLEBIN where droptime<sysdate-7;
PURGE DBA_RECYCLEBIN where droptime<sysdate-7
*
ERROR at line 1:
ORA-00933: SQL command not properly ended

 

SOLUTION
There is no direct command or RECYCLEBIN_RETENTION parameter to purge/delete with the droptime clause, so we have to use the workaround of identifying the objects and then drop them manually. There is an enhancement request filed through an Unpublished Bug 6694377, so the feature is still not available, but there is an easy workaround available.
Unpublished Bug 6694377 : ENHANCE PURGE COMMAND WITH TIME SPECIFIC CLAUSE

SELECT .... FROM DBA_RECYCLEBIN can have WHERE condition, 

PURGE DBA_RECYCLEBIN can not have WHERE condition and throws syntax errors like ORA-00933: SQL command not properly ended

So you can workaround this by dynamically preparing sql queries to purge the recycle bin objects

Examples: 

1. Purge tables dropped before 7 days (older than 7 days)

SQL> spool purge_table_older_than_7_days.sql
SQL> select 'purge table '||owner||'."'||OBJECT_NAME||'";'
from dba_recyclebin
where type='TABLE' and to_date(droptime,'YYYY-MM-DD:HH24:MI:SS')<sysdate-7;
SQL> spool off;

1. Purge tables dropped before 5 minutes (older than 5 minutes), use sysdate-(5/(24*60)) because 24 hours per day, 60 minutes per hour

SQL> spool purge_table_older_than_5_minutes.sql
SQL> select 'purge table '||owner||'."'||OBJECT_NAME||'";'
from dba_recyclebin
where type='TABLE' and to_date(droptime,'YYYY-MM-DD:HH24:MI:SS')<sysdate-(5/(24*60));
SQL> spool off;

SQL> spool purge_table_older_than_5_min.txt
SQL> @purge_table_older_than_5_minutes.sql
SQL> spool off;
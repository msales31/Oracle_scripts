

rman_ctrl_orcl_ARCHIVE_dbid1625221670_s62421_t1136055630_p1.bkp
14981752141038

rman target / 
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020'; 
run { allocate channel d1 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/orcl/opcorcl.ora)' ; 
restore controlfile from 'rman_ctrl_orcl_ARCHIVE_dbid1625221670_s62421_t1136055630_p1.bkp' ; 
} 
alter database mount;



rman target /  << eof
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
spool log to '/tmp/restore01.log';
RUN { allocate channel c1 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/orcl/opcorcl.ora)' ; 
allocate channel c2 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/orcl/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/orcl/opcorcl.ora)' ;
set newname for database to new; 
restore database; 
switch datafile all; 
switch tempfile all; 
recover database until scn 14981752141038 delete archivelog; 
}
eof

list backup of controlfile completed between "to_date('05/05/2023 18:00:00','DD/MM/YYYY HH24:MI:SS')" and "to_date('05/05/2023 21:00:00','DD/MM/YYYY HH24:MI:SS')";


NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
cdb_cluster_name                     string
cell_offloadgroup_name               string
db_file_name_convert                 string
db_name                              string      orcl
db_unique_name                       string      orcl_hm01
global_names                         boolean     FALSE
instance_name                        string      orcl
lock_name_space                      string
log_file_name_convert                string
pdb_file_name_convert                string
processor_group_name                 string

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
service_names                        string      orcl_hm01

    GROUP# STATUS  TYPE    IS_
---------- ------- ------- ---
MEMBER
--------------------------------------------------------------------------------
         1         ONLINE  NO
+RECO/ORCL_HM01/ONLINELOG/group_1.257.1129721881

         2         ONLINE  NO
+RECO/ORCL_HM01/ONLINELOG/group_2.259.1129721881

         3         ONLINE  NO
+RECO/ORCL_HM01/ONLINELOG/group_3.258.1129721881


    GROUP# STATUS  TYPE    IS_
---------- ------- ------- ---
MEMBER
--------------------------------------------------------------------------------
         4         STANDBY NO
+RECO/ORCL_HM01/ONLINELOG/group_4.266.1129721945

         5         STANDBY NO
+RECO/ORCL_HM01/ONLINELOG/group_5.267.1129721953

         6         STANDBY NO
+RECO/ORCL_HM01/ONLINELOG/group_6.268.1129721961


    GROUP# STATUS  TYPE    IS_
---------- ------- ------- ---
MEMBER
--------------------------------------------------------------------------------
         7         STANDBY NO
+RECO/ORCL_HM01/ONLINELOG/group_7.269.1129721971

         8         ONLINE  NO
+RECO/ORCL_HM01/ONLINELOG/group_8.263.1129721883

         9         ONLINE  NO
+RECO/ORCL_HM01/ONLINELOG/group_9.264.1129721915


    GROUP# STATUS  TYPE    IS_
---------- ------- ------- ---
MEMBER
--------------------------------------------------------------------------------
        10         ONLINE  NO
+RECO/ORCL_HM01/ONLINELOG/group_10.265.1129721917


NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
_gc_undo_affinity                    boolean     TRUE
temp_undo_enabled                    boolean     FALSE
undo_management                      string      AUTO
undo_retention                       integer     900
undo_tablespace                      string      UNDOTBS1



ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 7;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 8;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 9;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 10;


sqlplus / as sysdba
 alter pluggable database ORCL_PDB1 close immediate; 
 alter pluggable database ORCL_PDB1 open restricted; 
 alter session set container=ORCL_PDB1; 
 alter pluggable database rename global_name to ORCLHM01;
 alter pluggable database ORCLHM01 close immediate; 
 alter pluggable database ORCLHM01  open;
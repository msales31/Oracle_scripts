Create a Service
We create a new service using the CREATE_SERVICE procedure. There are two overloads allowing you to amend a number of features of the service. One overload accepts an parameter array, while the other allows you to set some parameters directly. The only mandatory parameters are the the SERVICE_NAME and the NETWORK_NAME, which represent the internal name of the service in the data dictionary and the name of the service presented by the listener respectively.

BEGIN
  DBMS_SERVICE.create_service(
    service_name => 'my_new_service',
    network_name => 'my_new_service'
  );
END;
/
We can display information about existing services using the {CDB|DBA|ALL}_SERVICES views. We can see if the service is started by checking the {G}V$ACTIVE_SERVICES view.

COLUMN name FORMAT A30
COLUMN network_name FORMAT A30

SELECT name,
       network_name
FROM   dba_services
ORDER BY 1;

NAME                           NETWORK_NAME
------------------------------ ------------------------------
SYS$BACKGROUND
SYS$USERS
cdb1                           cdb1
cdb1XDB                        cdb1XDB
my_new_service                 my_new_service

SQL>


SELECT name,
       network_name
FROM   v$active_services
ORDER BY 1;

NAME                           NETWORK_NAME
------------------------------ ------------------------------
SYS$BACKGROUND
SYS$USERS
cdb1                           cdb1
cdb1XDB                        cdb1XDB
pdb1                           pdb1

SQL>
Start a Service
The START_SERVICE procedure starts an existing service, making it available for connections via the listener.

BEGIN
  DBMS_SERVICE.start_service(
    service_name => 'SMARTTESTE'
  );
END;
/


EXECUTE DBMS_SERVICE.MODIFY_SERVICE('SMARTESTE', TRUE);


We can see the service is now active.

SELECT name,
       network_name
FROM   v$active_services
ORDER BY 1;

NAME                           NETWORK_NAME
------------------------------ ------------------------------
SYS$BACKGROUND
SYS$USERS
cdb1                           cdb1
cdb1XDB                        cdb1XDB
my_new_service                 my_new_service
pdb1                           pdb1

SQL>
Modify a Service
The MODIFY_SERVICE procedure allows us to alter parameters of an existing service. Like the CREATE_SERVICE procedure, there are two overloads allowing you to amend a number of features of the service. One overload accepts an parameter array, while the other allows you to set some parameters directly.

BEGIN
  DBMS_SERVICE.modify_service(
    service_name => 'my_new_service',
    goal         => DBMS_SERVICE.goal_throughput
  );
END;
/
Stop a Service
The STOP_SERVICE procedure stops an existing service, so it is no longer available for connections via the listener.

BEGIN
  DBMS_SERVICE.stop_service(
    service_name => 'my_new_service'
  );
END;
/
The service is still present, but it is no longer active.

COLUMN name FORMAT A30
COLUMN network_name FORMAT A30

SELECT name,
       network_name
FROM   dba_services
ORDER BY 1;

NAME                           NETWORK_NAME
------------------------------ ------------------------------
SYS$BACKGROUND
SYS$USERS
cdb1                           cdb1
cdb1XDB                        cdb1XDB
my_new_service                 my_new_service

SQL>


SELECT name,
       network_name
FROM   v$active_services
ORDER BY 1;

NAME                           NETWORK_NAME
------------------------------ ------------------------------
SYS$BACKGROUND
SYS$USERS
cdb1                           cdb1
cdb1XDB                        cdb1XDB
pdb1                           pdb1

SQL>
Delete a Service
The DELETE_SERVICE procedure removes an existing service.

BEGIN
  DBMS_SERVICE.delete_service(
    service_name => 'my_new_service'
  );
END;
/
We can see it's not longer listed as an available service.

COLUMN name FORMAT A30
COLUMN network_name FORMAT A30

SELECT name,
       network_name
FROM   dba_services
ORDER BY 1;

NAME                           NETWORK_NAME
------------------------------ ------------------------------
SYS$BACKGROUND
SYS$USERS
cdb1                           cdb1
cdb1XDB                        cdb1XDB

SQL>


SET HEAD OFF;
SPOOL /tmp/sinonimos.sql
SELECT 'CREATE OR REPLACE SYNONYM EMPORIUM.' || table_name || ' FOR ' || owner || '.' || table_name || ';'
FROM all_tables
WHERE owner IN ('VERDEMAR', 'VITRUVIO', 'VERDEMAR_CSF', 'DEV_OSADMIN', 'WMSPRD');
spool off;
@/tmp/sinonimos.sql


select count(*) from all_tables WHERE owner IN ('VERDEMAR', 'VITRUVIO', 'VERDEMAR_CSF', 'DEV_OSADMIN', 'WMSPRD');

SPOOL OFF;
@/tmp/sinonimos.sql

SET HEAD OFF;
SPOOL /tmp/sinonimos1.sql
SELECT 'CREATE OR REPLACE SYNONYM VERDEMAR.' || table_name || ' FOR ' || owner || '.' || table_name || ';'
FROM all_tables 
WHERE owner='EMPORIUM';
SPOOL OFF;
@/tmp/sinonimos1.sql

SET HEAD OFF;
SPOOL /tmp/sinonimos2.sql
SELECT 'CREATE OR REPLACE SYNONYM VITRUVIO.' || table_name || ' FOR ' || owner || '.' || table_name || ';'
FROM all_tables 
WHERE owner='EMPORIUM';
SPOOL OFF;
@/tmp/sinonimos2.sql

SET HEAD OFF;
SPOOL /tmp/sinonimos3.sql
SELECT 'CREATE OR REPLACE SYNONYM CICLONE.' || table_name || ' FOR ' || owner || '.' || table_name || ';'
FROM all_tables 
WHERE owner='EMPORIUM';
SPOOL OFF;
@/tmp/sinonimos3.sql

SET HEAD OFF;
SPOOL /tmp/sinonimos1.sql
SELECT 'CREATE OR REPLACE SYNONYM DEV_OSADMIN.' || table_name || ' FOR VERDEMAR.' || table_name || ';' 
FROM all_tables 
WHERE owner='EMPORIUM';
SPOOL OFF;
@/tmp/sinonimos4.sql




SET HEAD OFF;
SPOOL /tmp/sinonimos.sql
SELECT 'CREATE OR REPLACE SYNONYM EMPORIUM.' || table_name || ' FOR VERDEMAR.' || table_name || ';' 
FROM all_tables 
WHERE owner in ('VERDEMAR','VITRUVIO','VERDEMAR_CSF','DEV_OSADMIN','WMSPRD');
SPOOL OFF;
@/tmp/sinonimos.sqlSET HEAD OFF;
SPOOL /tmp/sinonimos.sql
SELECT 'CREATE OR REPLACE SYNONYM EMPORIUM.' || table_name || ' FOR VERDEMAR.' || table_name || ';' 
FROM all_tables 
WHERE owner in ('VERDEMAR','VITRUVIO','VERDEMAR_CSF','DEV_OSADMIN','WMSPRD');
SPOOL OFF;
@/tmp/sinonimos.sql


select 'CREATE OR REPLACE SYNONYM '||object_name||' FOR '||OWNER||'.'||object_name||';' from all_objects where object_type='VIEW' AND OWNER ='USUARIO';
SPOOL OFF;
@sinonimos.sql


BEGIN
  FOR t IN (SELECT owner, table_name FROM all_tables WHERE owner IN ('VERDEMAR', 'VITRUVIO', 'VERDEMAR_CSF', 'CICLONE')) LOOP
    EXECUTE IMMEDIATE 'CREATE  SYNONYM ' || t.table_name || ' FOR ' || t.owner || '.' || t.table_name;
  END LOOP;
END;
/

###################################################################################################################
#######
###                              Criar DG sem Broker


###########################################################
##
##     adicionar redos standby (se ainda nao tem )
##        mesma quantidade e tamanho de redos existente

alter database add standby logfile group 911 size 2048M;
alter database add standby logfile group 912 size 2048M;
alter database add standby logfile group 913 size 2048M;
alter database add standby logfile group 914 size 2048M;
alter database add standby logfile group 915 size 2048M;
alter database add standby logfile group 916 size 2048M;
alter database add standby logfile group 917 size 2048M;
alter database add standby logfile group 918 size 2048M;


###########################333###########################################################
##
##     configurar listener e tnsnames
##        (primary e standby)


##########################################
#-- adicionar entrada no listener


#-- se NAO tem uma network de dr/backup, adicionar entrada no listener default

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

SID_LIST_LISTENER =
    (SID_LIST =
	   (SID_DESC =
	        (GLOBAL_DBNAME=rumo01_bm04)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/stdone)
		    (SID_NAME=pano01)
	    )
	)

lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status



#--- OU se TEM uma network de dr/backup configurar um listener separado

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

LISTENER_DG =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = xxIP_DRxx)(PORT = 1525))
    )
  )

SID_LIST_LISTENER_DG =
    (SID_LIST=
	   (SID_DESC=
	        (GLOBAL_DBNAME=rumo01_bm03)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_2)
		    (SID_NAME=rumo01)
	    )
	)


lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status


#-- adicionar entrada no tnsnames (verificar qual tns a base usa) dois dois lados

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/tnsnames.ora

VOX_PRD =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.29.10.71)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = voxline_gru16d.subnetdb.vcnvoxline.oraclevcn.com)
      (UR = A)
    )
  )

VOX_DG =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.29.10.236)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = voxline_dg)
      (UR = A)
    )
  )




###################################################################################################################
#######
###                              Copiar o pwdfile da producao para o standby

mv /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01 /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01.ori
scp $ORACLE_HOME/dbs/orapwpano01 152.67.45.93:/u01/app/oracle/product/11.2.0.4/dbhome_3/dbs



###################################################################################################################
#######
###                              Testar e validar conexao dos dois lados


conn sys/"-3SyRumo#ww"@rumo01_dbcs as sysdba
select host_name,STATUS from v$instance;


conn sys/"-3SyRumo#ww"@rumo01_bm04 as sysdba
select host_name,STATUS from v$instance;


###################################################################################################################
#######
###                              Duplicate

#. TARGET     = banco origem
#. AUXILIARY  = banco destino

connect target sys/"-3SyRumo#ww"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.32)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A))) auxiliary sys/"-3SyRumo#ww"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))

rman target sys/"-3SyRumo#ww"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.32)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A)))" auxiliary sys/"-3SyRumo#ww"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))"
#- spool log to /home/oracle/duplicate.log
run {
   allocate channel prmy1 type disk;
   allocate channel prmy2 type disk;
   allocate channel prmy3 type disk;
   allocate channel prmy4 type disk;
   allocate auxiliary channel stby1 type disk;
   DUPLICATE TARGET DATABASE
      FOR STANDBY
      FROM ACTIVE DATABASE
      DORECOVER;
}




###################################################################################################################
#######
###                              Configurar DG sem broker


##########################################
#-- no primary

alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- verificar se foram adicionados redos standby (mesmo numero de grupos e tamanho dos atuais)


#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(voxline_gru17q,voxline_gru16d)'; -- DBUNIQUE STANDBY,DBUNIQUE PROD 

#- tns do outro db (nesse caso standby)
alter system set fal_server='VOX_DG';

#- tns do proprio db (nesse caso primary)
alter system set fal_client='VOX_PRD';

#-configurar log dest do standby
alter system set log_archive_dest_2='SERVICE=VOX_DG LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=voxline_gru17q'; 

#- ativar log shipping (*** depois de tudo configurado)
alter system set log_archive_dest_state_2='ENABLE' scope=both;


###- se for DG cascade (3 nos)
##-- alter system set log_archive_dest_3='SERVICE=pano01_bm02 VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01_gru1nw';
##-- alter system set log_archive_dest_state_3='ENABLE';



##########################################
#-- no standby


alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=900 scope=both;

#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(voxline_gru16d,voxline_gru17q)'; -- PROD,STANDBY

#- tns do outro db (nesse caso primary)
alter system set fal_server='VOX_PRD';

#- tns do proprio db (nesse caso standby)
alter system set fal_client='VOX_DG';

#-configurar log dest do standby
alter system set log_archive_dest_2='SERVICE=voxline_gru16d.subnetdb.vcnvoxline.oraclevcn.com LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=voxline_gru16d';

###- se for DG cascade (3 nos)
### alter system set log_archive_dest_3='SERVICE= VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01';


#- start recover no standby (com standby redo)
alter database recover managed standby database disconnect using current logfile;




###################################################################################################################
#######
###                              script para apagar archives

echo $ORACLE_BASE
export ORACLE_BASE=/u01/app/oracle
mkdir -p $ORACLE_BASE/admin/scripts/
vi $ORACLE_BASE/admin/scripts/deletearchive

export ORACLE_SID=$1
ORAENV_ASK=NO
. oraenv

export NLS_DATE_FORMAT='DD/MM/YYYY HH24:MI:SS';
$ORACLE_HOME/bin/rman target / nocatalog << EOF >> /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log
   spool log to /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log;
   CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON ALL STANDBY;
   show all;
   DELETE noprompt archivelog until time 'sysdate-1';
EOF

chmod +x $ORACLE_BASE/admin/scripts/deletearchive

/u01/app/oracle/admin/scripts/deletearchive

20  08,20  * * *    root  su - oracle -c "/u01/app/oracle/admin/scripts/deletearchive vial01"

###################################################################################################################
#######
###                              Virada DG com SwitchOver



###########################################################
##
##     no primary
##

#- verificar o switchover_status
# -->>> A value of TO STANDBY or SESSIONS ACTIVE indicates that the primary database can be switched to the standby role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

# -->>> RECOVERY_MODE = MANAGED REAL TIME APPLY (recover ativo no standby)
# -->>> GAP_STATUS = NO GAP

col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id, DB_UNIQUE_NAME, DATABASE_MODE, recovery_mode, status, TYPE, gap_status, ARCHIVED_SEQ#, ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;

## verificar STATUS
alter database switchover to sine01_gru19j verify;

#- executar commit to switchover
alter database commit to switchover to physical standby with session shutdown;

#- montar o banco como standby
conn / as sysdba
startup nomount;
alter system set log_archive_dest_state_2='DEFER' ;
alter system set job_queue_processes=0;
alter database mount standby database;



###########################################################
##
##      no standby
##


#- verificar staus switchover_status
#->>> A value of TO PRIMARY or SESSIONS ACTIVE indicates that the standby database is ready to be switched to the primary role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

#- executar o switchover to primary
alter database commit to switchover to primary with session shutdown;


#- abrir o banco
-->>>> verificar parametro UNDO
alter database open;


#- ativar o log shipping para o antigo primary (se estiver tudo corretamente configurado)
alter system set log_archive_dest_state_2='ENABLE' ;


SELECT THREAD#, LOW_SEQUENCE#, HIGH_SEQUENCE# FROM V$ARCHIVE_GAP;


alter system set job_queue_processes=1000;











col id for 99
col destination for a40
col sequence for 99999999999
col tmode for a12
col error for a40
select dest_id id,
DESTINATION,
LOG_SEQUENCE sequence,
TRANSMIT_MODE tmode,
DELAY_MINS,
STATUS,
error
from v$archive_dest
where DESTINATION is not null
order by dest_id;





col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id,
DB_UNIQUE_NAME,
DATABASE_MODE,
recovery_mode,
STANDBY_LOGFILE_COUNT stdlogfile,
status,
TYPE,
gap_status,
ARCHIVED_SEQ#,
ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;



col id for 99
col message for a125
select DEST_ID ID,
to_char(timestamp,'DD/MM/YYYY HH24:MI:SS')||' '||message message
from v$dataguard_status;


select distinct process, status, thread#, sequence#, block#, blocks from v$managed_standby ;




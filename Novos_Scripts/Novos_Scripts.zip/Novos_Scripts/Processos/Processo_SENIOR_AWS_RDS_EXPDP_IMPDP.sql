
--trocar cosenior pelo nome do schema que sera feito o backup
DECLARE
Bkp NUMBER;
s varchar2(30000);

BEGIN

Bkp := DBMS_DATAPUMP.OPEN( operation => 'EXPORT', job_mode => 'SCHEMA', job_name=>null, version=> '12');
-- FILE
DBMS_DATAPUMP.ADD_FILE( handle => Bkp, filename => 'COSENIOR.dmp', directory => 'DATA_PUMP_DIR', filetype => dbms_datapump.ku$_file_type_dump_file,reusefile => 1);
-- LOG
DBMS_DATAPUMP.ADD_FILE( handle => Bkp, filename => 'COSENIOR.log', directory => 'DATA_PUMP_DIR', filetype => dbms_datapump.ku$_file_type_log_file);
-- METADATA ONLY
-- DBMS_DATAPUMP.DATA_FILTER(handle => Bkp, name => 'INCLUDE_ROWS', value => 0);
-- SELECAO DE OWNERs EXPORTADOS
SELECT listagg(''''||owner||'''', ', ') WITHIN GROUP (ORDER BY owner) INTO s
FROM (
-- EXCLUSAO DOS OWNERs NO DATAPUMP - EXPORT
SELECT username AS owner
FROM dba_users
WHERE username  IN ('COSENIOR') 
) ;
DBMS_DATAPUMP.metadata_filter(Bkp, 'SCHEMA_LIST', s);
-- START
DBMS_DATAPUMP.START_JOB(Bkp);
END;
/
SELECT text
FROM TABLE(rdsadmin.rds_file_util.Read_text_file (
p_directory => 'DATA_PUMP_DIR',
p_filename => 'COSENIOR.log')); 


yum -y install oracle-rdbms-server-11gR2* oracle-database-preinstall-19c*  ntpdate net-tools vim mlocate rlwrap wget


rm -rf /home/oracle/.bash_profile
echo 'if [ -f ~/.bashrc ]; then' >> /home/oracle/.bash_profile
echo '        . ~/.bashrc' >> /home/oracle/.bash_profile
echo 'fi' >> /home/oracle/.bash_profile
echo 'PATH=$PATH:$HOME/bin' >> /home/oracle/.bash_profile
echo 'export PATH' >> /home/oracle/.bash_profile
echo 'export ORACLE_BASE=/u01/app/oracle' >> /home/oracle/.bash_profile
echo 'export ORACLE_HOME=/u01/app/oracle/19.3.0/db_1' >> /home/oracle/.bash_profile
echo 'export ORACLE_SID=ORCL' >> /home/oracle/.bash_profile
echo 'export ORACLE_UNQNAME=ORCL' >> /home/oracle/.bash_profile
echo 'export ORACLE_UNQNAME=ORCL' >> /home/oracle/.bash_profile
echo 'export ORA_INVENTORY=/u01/app/oracle/oraInventory' >> /home/oracle/.bash_profile
echo 'export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib' >> /home/oracle/.bash_profile
echo 'export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"' >> /home/oracle/.bash_profile


mkdir -p /u01/stage
mkdir -p /u01/app/oracle/19.3.0/db_1
mkdir -p /u01/oradata/ORCL
mkdir -p /u01/oradata/ORCL/export
mkdir -p /u01/oradata/ORCL/admin
mkdir -p /u01/oradata/ORCL/admin/rmanlogs


chown -R oracle:oinstall /u01/app
chown -R oracle:oinstall /u01/stage
chown -R oracle:oinstall /u01/oradata
chown -R oracle:oinstall /u01/oradata
chown -R oracle:oinstall /u01/oradata
chown -R oracle:oinstall /u01/oradata

chmod -R 775 /u01/oradata
chmod -R 775 /u01/oradata
chmod -R 775 /u01/oradata
chmod -R 775 /u01/oradata
chmod -R 775 /u01/stage
chmod -R 775 /u01/app/oracle
chmod -R 777 /sistema/winthor/utilitarios
chmod -R 775 /u01/oradata/ORCL/export

cd /u01/app/oracle/19.3.0/db_1/
wget 

ntpdate c.ntp.br
clock -w

rm -rf script.sh


### CONFIGURANDO UM PDB DO ZERO ####


INSTALAR ORACLE_HOME 


########### ENTERPRISE
$ORACLE_HOME/runInstaller -ignorePrereq -waitforcompletion -silent \
-responseFile ${ORACLE_HOME}/install/response/db_install.rsp \
oracle.install.option=INSTALL_DB_SWONLY \
ORACLE_HOSTNAME=${ORACLE_HOSTNAME} \
UNIX_GROUP_NAME=oinstall \
INVENTORY_LOCATION=${ORA_INVENTORY} \
SELECTED_LANGUAGES=en,en_GB \
ORACLE_HOME=${ORACLE_HOME} \
ORACLE_BASE=${ORACLE_BASE} \
oracle.install.db.InstallEdition=EE \
oracle.install.db.OSDBA_GROUP=dba \
oracle.install.db.OSBACKUPDBA_GROUP=dba \
oracle.install.db.OSDGDBA_GROUP=dba \
oracle.install.db.OSKMDBA_GROUP=dba \
oracle.install.db.OSRACDBA_GROUP=dba \
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false \
DECLINE_SECURITY_UPDATES=true


####INSTALAR BANCO - PARAMETRO createAsContainerDatabase é o diferencial

$ORACLE_HOME/bin/dbca -silent -createDatabase \
-templateName General_Purpose.dbc \
-gdbname ${ORACLE_SID} -sid ${ORACLE_SID} -responseFile NO_VALUE \
-characterSet WE8MSWIN1252 \
-sysPassword soft##123 \
-systemPassword soft##123 \
-createAsContainerDatabase false \
-numberOfPDBs 0 \
-databaseType MULTIPURPOSE \
-automaticMemoryManagement false \
-totalMemory 5000 \
-storageType FS \
-datafileDestination "/u01/oradata/ORCL/" \
-redoLogFileSize 100 \
-emConfiguration NONE \
-ignorePreReqs


### /etc/oratab
ORCL:/u01/app/oracle/19.3.0/db_1:Y


### CONFIGURAR LISTENER


LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = srvbd01)(PORT = 1521))
      (ADDRESS = (PROTOCOL = IPC)(KEY = EXTPROC1521))
    )
  )


### TNSNAMES

ORCL =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = srvdb01)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = ORCL)
    )
  )
  
  
### SQLNET.ORA

SQLNET.ALLOWED_LOGON_VERSION_CLIENT=9
SQLNET.ALLOWED_LOGON_VERSION_SERVER=9
SQLNET_ALLOWED_LOGON_VERSION = (8,9,10,11)




SELECT ' drop ' || object_type || ' ' || owner || '."' || object_name || '"' || DECODE(object_type,'TABLE',' cascade constraints;',';')
FROM dba_objects WHERE owner = 'INTERSOLID' AND object_type NOT IN ('INDEX','TRIGGER','PACKAGE BODY');



### parametros BD

alter system set db_create_file_dest='/u01/oradata';
alter system set db_create_online_log_dest_1='/u01/oradata';
alter system set db_recovery_file_dest_size='200G';
alter system set db_recovery_file_dest='/u01/fast_recovery_area';
alter system set processes=1000 scope=spfile;
create or replace directory export_dir as '/u01/oradata/ORCL/export';
create user zabbix identified by msales123;
grant connect, resource to zabbix;
grant dba to zabbix;
alter system set SEC_CASE_SENSITIVE_LOGON=false;     
alter profile default limit password_life_time unlimited;
alter system set CURSOR_SHARING=EXACT;
alter system set filesystemio_options=setall scope=spfile;
create pfile from spfile;



### archivelog
shut immediate;
startup mount;
alter database archivelog;
alter database open;




ALTER DATABASE ADD LOGFILE MEMBER '/u01/oradata/ORCL/redo01b.log' TO GROUP 1;
ALTER DATABASE ADD LOGFILE MEMBER  '/u01/oradata/ORCL/redo02b.log'TO GROUP 2;
ALTER DATABASE ADD LOGFILE MEMBER   '/u01/oradata/ORCL/redo03b.log' TO GROUP 3;
ALTER DATABASE ADD LOGFILE MEMBER  TO GROUP 4;
ALTER DATABASE ADD LOGFILE MEMBER  TO GROUP 5;
ALTER DATABASE ADD LOGFILE MEMBER  TO GROUP 6;

alter database add logfile group 4 ('/u01/oradata/ORCL/redo04a.log','/u01/oradata/ORCL/redo04b.log') size 100M;
alter database add logfile group 5 ('/u01/oradata/ORCL/redo05a.log','/u01/oradata/ORCL/redo05b.log') size 100M;
alter database add logfile group 6 ('/u01/oradata/ORCL/redo06a.log','/u01/oradata/ORCL/redo06b.log') size 100M;



### USER INTERSOLID CONF 
create tablespace TBS_INTERSOLID_DAT logging datafile size 10G autoextend on next 1G maxsize unlimited;


create user INTERSOLID  identified by "1nt3s0l1d" default tablespace TBS_INTERSOLID_DAT temporary tablespace temp;
grant connect, resource to INTERSOLID;
grant create session to INTERSOLID with admin option;
grant alter any role to INTERSOLID; 
grant alter session to INTERSOLID; 
grant alter user to INTERSOLID; 
grant create procedure to INTERSOLID; 
grant create role to INTERSOLID; 
GRANT CREATE MATERIALIZED VIEW TO INTERSOLID;
grant create sequence to INTERSOLID; 
grant create synonym to INTERSOLID; 
grant create table to INTERSOLID; 
grant create trigger to INTERSOLID; 
grant create type to INTERSOLID; 
grant create user to INTERSOLID; 
grant create view to INTERSOLID; 
grant create database link to INTERSOLID; 
grant drop any role to INTERSOLID; 
grant drop user to INTERSOLID; 
grant debug any procedure to INTERSOLID;
grant debug connect session to INTERSOLID; 
grant query rewrite to INTERSOLID; 
grant select on sys.v_$session to INTERSOLID; 
grant select on sys.v_$sysstat to INTERSOLID; 
grant select on sys.v_$sesstat to INTERSOLID; 
grant select on sys.v_$statname to INTERSOLID;
grant select on sys.v_$lock to INTERSOLID;
grant select on dba_roles to INTERSOLID; 
grant select on dba_users to INTERSOLID; 
grant select on dba_tablespaces to INTERSOLID with grant option; 
grant select on dba_free_space to INTERSOLID with grant option; 
grant select on dba_data_files to INTERSOLID with grant option; 
grant select on dba_temp_files to INTERSOLID with grant option; 
grant select on dba_sys_privs to INTERSOLID; 
grant select on dba_tab_privs to INTERSOLID;
grant select on dba_role_privs to INTERSOLID; 
grant execute on dbms_session to INTERSOLID; 
grant select ON GV_$SESSION TO INTERSOLID;
grant select ON V_$SESSION TO INTERSOLID;
grant select ON V_$DATABASE TO INTERSOLID;
grant select ON SYS.OBJ$ TO INTERSOLID;
grant select ON SYS.VIEW$ TO INTERSOLID;
grant select ON SYS.USER$ TO INTERSOLID;
alter user INTERSOLID quota unlimited on TBS_INTERSOLID_DAT;
alter user INTERSOLID quota unlimited on LABVANTAGE;
alter user INTERSOLID quota 0m on system;
grant select on v_$parameter to INTERSOLID;
GRANT CREATE JOB TO INTERSOLID;
GRANT CREATE ANY JOB TO INTERSOLID;
GRANT EXECUTE ON DBMS_SCHEDULER TO INTERSOLID;
GRANT MANAGE SCHEDULER TO INTERSOLID;
GRANT CREATE ANY TRIGGER TO INTERSOLID;
GRANT administer database trigger TO INTERSOLID;
commit;


create or replace
package set_usuario as
    procedure set_value_in_context(usuario in varchar2);
end set_usuario;
/

create or replace
package body set_usuario as
    procedure set_value_in_context(usuario in varchar2) is
    begin
        dbms_session.set_context('INTERSOLID', 'USUARIO', usuario);
    end set_value_in_context;
end set_usuario;
/

create or replace context INTERSOLID using SET_USUARIO;
/


########### configurar listener

netca -silent -responsefile $ORACLE_HOME/assistants/netca/netca.rsp

LISTENER=
  (DESCRIPTION=
    (ADDRESS_LIST=
      (ADDRESS=(PROTOCOL=tcp)(HOST=sales-server)(PORT=1521))
      (ADDRESS=(PROTOCOL=ipc)(KEY=extproc) (queuesize=50))))
SID_LIST_LISTENER=
  (SID_LIST=
    (SID_DESC=
      (SID_NAME=plsextproc) ---editar com SID
      (ORACLE_HOME=/oracle11g) -- EDITAR COM ORACLE HOME
      (PROGRAM=extproc)))


#### CONF BACKUP FULL

PATH=$PATH:$HOME/bin
export PATH
unset USERNAME
export ORACLE_BASE=/u01/app/oracle 
export ORACLE_HOME=/u01/app/oracle/19.3.0/db_1
export ORACLE_SID=ORCL
export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"
export PATH=$PATH:$ORACLE_HOME/bin
export BUCKET_NAME=bucket-globo

export DATA=`date +%d%m%Y-%Hh`
export DIRETORIO=/u01/oradata/ORCL/export/
export PATH

cd /u01/oradata/ORCL/export
echo Iniciando Exportacao ... >> /u01/oradata/ORCL/export/export.log
date >> /u01/oradata/ORCL/export/export.log

expdp zabbix/msales123 dumpfile=EXPDP_ORCL_FULL_$DATA.dmp logfile=EXPDP_ORCL_FULL_$DATA.log full=Y directory=export_dir parallel=3

echo Termino da Exportacao ... >> /u01/oradata/ORCL/export/export.log
date >> /u01/oradata/ORCL/export/export.log
tar -zcvf EXPDP_ORCL_FULL_$DATA.tar.bz2 EXPDP_ORCL_FULL_$DATA.log EXPDP_ORCL_FULL_$DATA.dmp
rclone sync -P EXPDP_ORCL_FULL_$DATA.tar.bz2 mapeamento-cloud:/bucket-Globo
chmod -R 777 /u01/oradata/ORCL
date >> /u01/oradata/ORCL/export/export.log
find . -name "*.tar.bz2" -mtime +7 -exec rm -rf {} \;
find . -name "*.dmp" -exec rm -rf {} \;
find . -name "*.log" -exec rm -rf {} \;

### BACKUP INTERSOLID

PATH=$PATH:$HOME/bin
export PATH
unset USERNAME
export ORACLE_BASE=/u01/app/oracle 
export ORACLE_HOME=/u01/app/oracle/19.3.0/db_1
export ORACLE_SID=ORCL
export NLS_LANG="BRAZILIAN PORTUGUESE_BRAZIL.WE8ISO8859P1"
export PATH=$PATH:$ORACLE_HOME/bin
export BUCKET_NAME=bucket-globo

export DATA=`date +%d%m%Y-%Hh`
export DIRETORIO=/u01/oradata/ORCL/export/
export PATH

cd /u01/oradata/ORCL/export
echo Iniciando Exportacao ... >> /u01/oradata/ORCL/export/export.log
date >> /u01/oradata/ORCL/export/export.log

expdp exporta/expc5421 dumpfile=EXPDP_intersolid_$DATA.dmp logfile=EXPDP_intersolid_$DATA.log schemas=INTERSOLID directory=export_dir parallel=3

echo Termino da Exportacao ... >> /u01/oradata/ORCL/export/export.log
date >> /u01/oradata/ORCL/export/export.log
tar -zcvf EXPDP_intersolid_$DATA.tar.gz EXPDP_LUSA_$DATA.log EXPDP_intersolid_$DATA.dmp 
chmod -R 777 /u01/oradata/ORCL
date >> /u01/oradata/ORCL/export/export.log
find . -name "*.tar.bz2" -mtime +6 -exec rm -rf {} \;
find . -name "*.dmp" -exec rm -rf {} \;
find . -name "*.log" -exec rm -rf {} \;

#####

### conf rclone

-- alteravel secret_acess_key,acess_key_id

nxB740WaLGUxfqkXJEmcQEL6kwZAJ0H7QbZsOaVmWXI=


[mapeamento-cloud]
type = s3
provider = Other
env_auth = false
access_key_id = 814d554f316001a5fa8b3f7348397c8a99851329
secret_access_key = nxB740WaLGUxfqkXJEmcQEL6kwZAJ0H7QbZsOaVmWXI=
region = sa-saopaulo-1
endpoint = https://grbpg2xw6md6.compat.objectstorage.sa-saopaulo-1.oraclecloud.com



#### passar dados


DADOS SO
IP:192.168.1.222
user: root
senha: soft@123

DADOS BD:
SCHEMA=INTERSOLID
SENHA= 1nt3s0l1d
INSTANCIA=ORCL

super_user=sys
senha: soft##123






	  
	  

### PARAMETRIZER REDO

SQL>alter database add logfile group 1 ('/u01/oradata/ORCL/redo01a.log','/u01/oradata/ORCL/redo01b.log') size 300M;
SQL>alter database add logfile group 2 ('/u01/oradata/ORCL/redo02a.log','/u01/oradata/ORCL/redo01b.log') size 300M;
SQL>alter database add logfile group 3 ('/u01/oradata/ORCL/redo03a.log','/u01/oradata/ORCL/redo01b.log') size 300M;


#### DEFINIR OMF 

SQL > ALTER SYSTEM SET db_create_file_dest = '/u01/oradata/ORCL';

### CRIAR PLUGGABLE DATABASE

SQL > CREATE PLUGGABLE DATABASE TESTE01 ADMIN USER pdb_adm IDENTIFIED BY TESTE123;

### ALTERAR ESTADO PARA OPEN

ALTER PLUGGABLE DATABASE teste01 OPEN READ WRITE;

### COLOCAR PRA INICIAR AUTOMATICO

SQL> alter pluggable database TESTE01 save state;


#### criar listener para base 

SQL>ALTER SESSION SET CONTAINER=TESTE01;
SQL>alter system set listener_networks='(( NAME=teste01)(LOCAL_LISTENER=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=prd01)(PORT =1521)))))' scope=both;
alter system register;








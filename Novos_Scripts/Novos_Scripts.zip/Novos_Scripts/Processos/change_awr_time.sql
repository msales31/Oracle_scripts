BEGIN
  DBMS_WORKLOAD_REPOSITORY.modify_snapshot_settings(
    retention => 64800,        -- Minutes (= 45 Days). Current value retained if NULL.
    interval  => 10);          -- Minutes. Current value retained if NULL.
END;
/
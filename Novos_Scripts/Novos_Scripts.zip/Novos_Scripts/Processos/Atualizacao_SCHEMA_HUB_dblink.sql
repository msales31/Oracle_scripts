#!/bin/bash
### ROTINA DE ATUALIZACAO HUB ###
export DATA1=`date '+%d'`
. ~/profile_TESTE.sh
cd /backup/rotina_hub/

expdp \"/ as sysdba\"  directory=exporta_hub tables=HUB.sellers,HUB.omnik_sellers,HUB.ft_parametros dumpfile=dptables_DIA_${DATA1}_%U.dmp filesize=8000M  logfile=dptables_DIA_$DATA1.log


sqlplus / as sysdba << eof
ALTER USER HUB ACCOUNT LOCK;
spool kill_session.sql
SELECT  'alter system kill session ''' || sid || ',' || serial# || ''' immediate;'
FROM v$session
WHERE username is not null 
AND osuser <> 'oracle' 
AND username ='HUB'; 
spool off
@kill_session.sql
eof


sqlplus / as sysdba << eof
DROP USER HUB CASCADE;
CREATE USER "HUB" IDENTIFIED BY VALUES 'S:000000000000000000000000000000000000000000000000000000000000' DEFAULT TABLESPACE "USERS" TEMPORARY TABLESPACE "TEMP1";
exit
eof

impdp \"/ as sysdba\"  schemas=HUB directory=exporta_hub network_link=DBLPRODUCAO logfile=IMPDP__DIA_$DATA1.log


#sqlplus / as sysdba << eof
#DROP TABLE HUB.sellers;
#DROP TABLE HUB.omnik_sellers;
#DROP TABLE HUB.ft_parametros;
#exit
#eof

impdp \"/ as sysdba\"  directory=exporta_hub tables=HUB.sellers,HUB.omnik_sellers,HUB.ft_parametros dumpfile=dptables_DIA_21_01.dmp TABLE_EXISTS_ACTION=replace logfile=IMDP_dptables_DIA_$DATA1.log full=n



EXEC UTL_RECOMP.recomp_parallel(4, 'HUB');







CREATE USER "HUB" IDENTIFIED BY VALUES 'S:000000000000000000000000000000000000000000000000000000000000' DEFAULT TABLESPACE "USERS" TEMPORARY TABLESPACE "TEMP1" PASSWORD EXPIRE ACCOUNT UNLOCK;



   GRANT "CONNECT" TO "HUB";
   GRANT "RESOURCE" TO "HUB";
  GRANT CREATE JOB TO "HUB";
  GRANT CREATE VIEW TO "HUB";
  GRANT CREATE TABLE TO "HUB";
  GRANT UNLIMITED TABLESPACE TO "HUB";
  GRANT CREATE SESSION TO "HUB";


. ~/profile_TESTE.sh




select * from sellers;
select * from omnik_sellers;
select * from ft_parametros;




CREATE PUBLIC DATABASE LINK DBLPRODUCAO
  CONNECT TO exporta     
  IDENTIFIED BY exporta
  USING '(description=(address=(protocol=tcp)(host=192.168.250.22)(port=1521))(connect_data=(service_name=orcldb)(SERVER = DEDICATED)))';


https://download.oracle.com/otn_software/apex/apex_24.1.zip

https://docs.oracle.com/en/database/oracle/apex/24.1/htmig/installing-and-configuring-apex-and-ords.html#HTMIG-GUID-8EE981AD-B1F9-46C2-BB5A-C9FE60CCD4AA
https://docs.oracle.com/en/database/oracle/apex/24.1/htmig/downloading-installing-ords.html#GUID-1F0064FB-7F00-4ACE-85BD-E9B2AF73A233

https://oracle-base.com/articles/misc/oracle-application-express-apex-installation
https://oracle-base.com/articles/misc/oracle-rest-data-services-ords-installation-on-tomcat

-- upgrade
https://www.linkedin.com/pulse/upgrading-oracle-application-express-apex-involves-several-khalid-suhlf/

#- unzip
echo $ORACLE_BASE
mkdir -p $ORACLE_BASE/apex241
unzip /tmp/apex_24.1.zip -d $ORACLE_BASE/apex241/
cd $ORACLE_BASE/apex241/apex



#- Banco
server: dbcsvoxline01
pdb: bvox

@apexins.sql TSD_apex TSD_apex TEMP /i/

172.29.10.71
1521
bvox.subnetdb.vcnvoxline.oraclevcn.com



#- app
server: voxline-srvapex01

[/root] rpm -qa | grep ords
ords-24.3.0-6.el8.noarch


APEX static resources location: /etc/ords/apex/images

Senhas: Welcome1


{
systemctl stop ords
systemctl start ords
systemctl status ords
}



The structure of the link to the Oracle APEX administration services is as follows:
http://144.22.142.250/ords/apex_admin

The structure of the link to the Oracle APEX development interface is as follows:
http://144.22.142.250/ords





srvapex01


ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEAr8kFyP4NgYQB0Wke8EdfLiVJwPTfcQxaBjdH6Qq2ZdC1ZsWyK8gR3lEx7d/DcCl3+Aq2jdgHOaDkjFKDWyE23aU1ET2uu0yQBMvR2pfKj63RRmBuM63fKxa+TOD0soJecdi0GDTC/trQEbgVBwDQJ+2dI6NftbnEy70cS8jWYpfVIbYYgiza9PDrmGVgUhmX548UKe76v84i0MgxAyT8a8wuk1SBfaMxtrJxQ/j45X/VLxcVu9zT9fjSGUAcOQkpmcecUjFsxayqWSzn5Iey93LBJJraGFWn8gqZzLD81q7R7EFQBEW7ud6rZU1bqfoZrFXNwsUV1McfF/xBiSGVUw== ebentlin@primedb.com.br


Public IPv4 address: 144.22.142.250
Private IPv4 address: 172.29.3.28



##-- DB SERVER (PDB ou normal)
#- check that Oracle XML DB is present with

select comp_name, version
from dba_registry
where upper(comp_name) like 'ORACLE XML%';


#- download
https://www.oracle.com/technetwork/developer-tools/apex/downloads/index.html

wget https://download.oracle.com/otn_software/apex/apex_23.2.zip -O /tmp/apex_23.2.zip

#- unzip
echo $ORACLE_BASE
unzip /tmp/apex_23.2.zip -d $ORACLE_BASE/apex232/
cd $ORACLE_BASE/apex232/apex


##------ install 
sqlplus / as sysdba

col name for a85
select distinct NAME from v$datafile;


-- For Oracle Managed Files (OMF).
CREATE TABLESPACE tsd_apex DATAFILE SIZE 128M AUTOEXTEND ON NEXT 1M maxsize 1024M;

-- @apexins.sql tablespace_apex tablespace_files tablespace_temp images

@apexins.sql TSD_apex TSD_apex TEMP /i/

SELECT * FROM   apex_release;

#-- change the admin password by running the "apxchpwd.sql" scripts as the SYS user
@apxchpwd.sql
Welcome1#


#-- If you want to add the user silently

alter session set current_schema=APEX_230200;

BEGIN
    APEX_UTIL.set_security_group_id( 10 );
    
    APEX_UTIL.create_user(
        p_user_name       => 'ADMIN',
        p_email_address   => 'matheus.sales@primedb.solutions',
        p_web_password    => 'Welcome1',
        p_developer_privs => 'ADMIN' );
    APEX_UTIL.set_security_group_id( null );
    COMMIT;
END;
/ 


#-- Create the APEX_LISTENER and APEX_REST_PUBLIC_USER users by running the "apex_rest_config.sql" script.
@apex_rest_config.sql Welcome1# Welcome1#


ALTER USER "SYS" IDENTIFIED BY VALUES 'S:3195163A515825DB2F8D6F12DE29AA6EE0BCB679DA1D469BB465F937ED33;AE8BF6357C5895EE' TEMPORARY TABLESPACE "TEMP";

ALTER USER sys IDENTIFIED BY Welcome1 ACCOUNT UNLOCK;

ALTER USER APEX_LISTENER IDENTIFIED BY Welcome1 ACCOUNT UNLOCK;
grant create session to APEX_LISTENER;

ALTER USER APEX_PUBLIC_USER IDENTIFIED BY Welcome1 ACCOUNT UNLOCK;
grant create session to APEX_PUBLIC_USER;

ALTER USER APEX_REST_PUBLIC_USER IDENTIFIED BY Welcome1 ACCOUNT UNLOCK;
grant create session to APEX_REST_PUBLIC_USER;


#- copiar images do apex para o tomcat
scp -r /u01/app/oracle/apex232/apex/images/* root@172.29.3.28:/etc/ords/apex/images
chown -R oracle:oinstall /etc/ords/apex

###--- APP Server

yum install java-11 ords telnet


alter user APEX_LISTENER identified by Welcome1 account unlock;
alter user APEX_PUBLIC_USER identified by Welcome1 account unlock;
alter user APEX_REST_PUBLIC_USER identified by Welcome1 account unlock;
alter user ORDS_PUBLIC_USER identified by Welcome1 account unlock;
alter user ORDS_METADATA identified by Welcome1 account unlock;


mkdir -p /etc/ords/apex/images

#-config
ords --config /etc/ords/config install
[2] Create or update a database pool and install/upgrade ORDS in the database
[1] Basic (host name, port, service name)

172.29.10.71
1521
bvox.subnetdb.vcnvoxline.oraclevcn.com
sys
VOxl-20020#
Welcome1
[1] Database Actions  (Enables all features)
[1] Configure and start ORDS in standalone mode
[1] HTTP
8080
Enter the APEX static resources location: /etc/ords/apex/images


vi /usr/local/bin/ords

#- adicionar
        AddVMOption -Xms2048M
        AddVMOption -Xmx2048M

#- trocar
de -Duser.timezone=UTC para -Duser.timezone=America/Sao_Paulo



vi /etc/ords/config/databases/default/pool.xml

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE properties SYSTEM "http://java.sun.com/dtd/properties.dtd">
<properties>
<comment>Saved on Sat Jul 08 18:15:01 UTC 2023</comment>
<entry key="db.connectionType">basic</entry>
<entry key="db.hostname">srvdb01</entry>
<entry key="db.port">1521</entry>
<entry key="db.servicename">orcl</entry>
<entry key="db.username">ORDS_PUBLIC_USER</entry>
<entry key="feature.sdw">true</entry>
<entry key="plsql.gateway.mode">proxied</entry>
<entry key="restEnabledSql.active">true</entry>
<entry key="security.requestValidationFunction">ords_util.authorize_plsql_gateway</entry>
</properties>




#- log
/var/log/ords/ords.log



systemctl enable ords

{
systemctl stop ords
systemctl start ords
systemctl status ords
}







conn ORDS_PUBLIC_USER/Welcome1@172.29.10.71:1521/bvox
conn ORDS_PUBLIC_USER/Welcome1@bvox



#- verificar password
ords --config /etc/ords/config config --db-pool default get --secret db.password


#- definir password
ords config --db-pool default secret db.password
ords config --db-pool default set db.servicename
ords config --db-pool default set standalone.http.port




	The structure of the link to the Oracle APEX administration services is as follows:
	http://144.22.142.250/ords/apex_admin

	The structure of the link to the Oracle APEX development interface is as follows:
	http://144.22.142.250/ords




	http://64.181.164.156/ords/apex_admin

http://146.235.54.241/ords/apex_admin
146.235.54.241
http://144.22.142.250/ords

#- pegar os schemas 
u.username in ('D1473','D2296','D2299','D232','D2343','D235','D2362','D2405','D2432','D2446','D2453','D2455','D2461','D2462','D2463','D2472','D2478','D2493','D2508','D2520')



#- lockar usuarios 
select 'alter user '||U.USERNAME||'' account lock' from dba_users u where u.username in ('D1473','D2296','D2299','D232','D2343','D235','D2362','D2405','D2432','D2446','D2453','D2455','D2461','D2462','D2463','D2472','D2478','D2493','D2508','D2520');


alter user D2508 account lock;
alter user D1473 account lock;
alter user D2296 account lock;
alter user D2472 account lock;
alter user D2520 account lock;
alter user D2455 account lock;
alter user D2405 account lock;
alter user D2432 account lock;
alter user D2343 account lock;
alter user D2461 account lock;
alter user D2463 account lock;
alter user D232 account lock;
alter user D2446 account lock;
alter user D2462 account lock;
alter user D2478 account lock;
alter user D2299 account lock;
alter user D2362 account lock;
alter user D2493 account lock;
alter user D235 account lock;
alter user D2453 account lock;


--# select para kill 
SELECT  'alter system kill session ''' || sid || ',' || serial# || ''' immediate;'
FROM v$session
WHERE username is not null 
AND osuser <> 'oracle' 
AND username in ('D1473','D2296','D2299','D232','D2343','D235','D2362','D2405','D2432','D2446','D2453','D2455','D2461','D2462','D2463','D2472','D2478','D2493','D2508','D2520');


#- Criar tabela com os schemas 
drop table system.schema_customers purge;
create table system.schema_customers as
select rownum as pos, a.*
from (
select username, round(sum(s.bytes/1024/1024)) as sizemb, 'N' as migrado
from dba_users u,
     dba_segments s
where u.username in ('D1473','D2296','D2299','D232','D2343','D235','D2362','D2405','D2432','D2446','D2453','D2455','D2461','D2462','D2463','D2472','D2478','D2493','D2508','D2520')
  and s.owner = u.username
group by username
order by sizemb desc
) a
;



#- 
drop table system.schema_customers_a purge;
create table system.schema_customers_a as
select a.*
from system.schema_customers a
where mod(a.POS,3)=0
;

#- fazer backup 

cd /backup/v10

source /home/oracle/cdbprd03.env
export ORACLE_PDB_SID=DPCWEB1

expdp '"/ as sysdba"' \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=SCHEMA:"\"IN (select username from system.schema_customers)\"" \
flashback_time=systimestamp \
directory=dpmigra \
logfile=dpcweb1-customers_a-exp.log \
dumpfile=dpcweb1-customers_a%U.dmp \
FILESIZE=10G \
parallel=4



### TEMPO TOMADO
Dump file set for SYS.SYS_EXPORT_FULL_01 is:
  /backup/v10/dpcweb1-customers_a01.dmp
  /backup/v10/dpcweb1-customers_a02.dmp
  /backup/v10/dpcweb1-customers_a03.dmp
  /backup/v10/dpcweb1-customers_a04.dmp
Job "SYS"."SYS_EXPORT_FULL_01" successfully completed at Wed Sep 25 18:02:19 2024 elapsed 0 01:53:56




#- importar

source /home/oracle/cdbprd05.env
export ORACLE_PDB_SID=PDB1_RJ

impdp '"/ as sysdba"' \
full=y \
directory=dpmigra \
logfile=dpcweb1-customers_a-imp.log \
dumpfile=dpcweb1-customers_a%U.dmp \
parallel=4 







#- verificar log errors
cat dpcweb1-customers_a-imp.log | grep -i "ORA-" | grep -Ev 'ORA-39082|ORA-39083|ORA-01917|ORA-39384|ORA-31684'
cat dpcweb1-customers_b-imp.log | grep -i "ORA-" | grep -Ev 'ORA-39082|ORA-39083|ORA-01917|ORA-39384|ORA-31684'
cat dpcweb1-customers_c-imp.log | grep -i "ORA-" | grep -Ev 'ORA-39082|ORA-39083|ORA-01917|ORA-39384|ORA-31684'




## Na origem DPCWEB1

spool /backup/v10/grant_schemasA.sql
select 'grant '|| PRIVILEGE ||' on '|| OWNER ||'.'|| TABLE_NAME || ' to "' || grantee ||
decode (GRANTABLE, 'YES', '" with grant option ;', '";')
from DBA_TAB_PRIVS
where (grantee in (select username from system.schema_customers))
order by PRIVILEGE,OWNER,TABLE_NAME
;
spool off;

spool /tmp/grant_PriveligesA.sql
select 'grant '|| PRIVILEGE || ' to ' || grantee ||
decode (ADMIN_OPTION, 'YES', ' with admin option ;', ';')
from DBA_SYS_PRIVS
where (grantee in (select username from system.schema_customers))
order by PRIVILEGE
;
spool off



# no destino PDB1_RJ

@/backup/v10/grant_schemasA.sql
@/tmp/grant_PriveligesA.sql









#- verificar count dos objectos, contraints, etc
procedimento/migracao/conferencia-migracao.txt

- count objetos
- count objetos invalidos
- count de grants
- count de constraints



set tab off underline off linesize 2050 newpage none pagesize 4000
set feedback on colsep | editfile /tmp/sqlplusedit.tmp long 10000000 trimout on;
set numwidth 13;
set serveroutput on size 1000000 trimspool on longchunksize 10000000 time on;
spool /tmp/count_objects.log;
col Owner for a21;
col Tb for 9999999;
col Id for 9999999;
col Pk for 9999999;
col Pb for 9999999;
col Sq for 9999999;
col Tr for 9999999;
col Pr for 9999999;
col Fc for 9999999;
col Vw for 9999999;
col Tp for 9999999;
col Sy for 9999999;
col Lb for 9999999;
col Jb for 9999;
col Sy for 9999999;
col Dk for 9999;
col Other for 99999;
col Total for 9999999;
col MVW for 99999;
col TABPART for 99999;
col INDPART for 99999;
col Other for 99999;

SELECT DECODE(GROUPING(a.owner),1,'All Owners',a.owner) AS "Owner"
      ,COUNT(CASE
             WHEN a.object_type = 'TABLE' THEN 1
             ELSE NULL
             END) "Tb"
      ,COUNT(CASE
             WHEN a.object_type = 'INDEX' THEN 1
             ELSE NULL
             END) "Id"
      ,COUNT(CASE
             WHEN a.object_type = 'PACKAGE' THEN 1
             ELSE NULL
             END) "Pk"
      ,COUNT(CASE
             WHEN a.object_type = 'PACKAGE BODY' THEN 1
             ELSE NULL
             END) "Pb"
      ,COUNT(CASE
             WHEN a.object_type = 'SEQUENCE' THEN 1
             ELSE NULL
             END) "Sq"
      ,COUNT(CASE
             WHEN a.object_type = 'TRIGGER' THEN 1
             ELSE NULL
             END) "Tr"
      ,COUNT(CASE
             WHEN a.object_type = 'PROCEDURE' THEN 1
             ELSE NULL
             END) "Pr"
      ,COUNT(CASE
             WHEN a.object_type = 'FUNCTION' THEN 1
             ELSE NULL
             END) "Fc"
      ,COUNT(CASE
             WHEN a.object_type = 'VIEW' THEN 1
             ELSE NULL
             END) "Vw"
      ,COUNT(CASE
             WHEN a.object_type = 'TYPE' THEN 1
             ELSE NULL
             END) "Tp"
      ,COUNT(CASE
             WHEN a.object_type = 'SYNONYM' THEN 1
             ELSE NULL
             END) "SY"
      ,COUNT(CASE
             WHEN a.object_type = 'LOB' THEN 1
             ELSE NULL
             END) "LB"
      ,COUNT(CASE
             WHEN a.object_type = 'JOB' THEN 1
             ELSE NULL
             END) "JB"
      ,COUNT(CASE
             WHEN a.object_type = 'MATERIALIZED VIEW' THEN 1
             ELSE NULL
             END) "MVW"
      ,COUNT(CASE
             WHEN a.object_type = 'DATABASE LINK' THEN 1
             ELSE NULL
             END) "Dk"
      ,COUNT(CASE
             WHEN a.object_type = 'TABLE PARTITION' THEN 1
             ELSE NULL
             END) "TABPART"
      ,COUNT(CASE
             WHEN a.object_type = 'INDEX PARTITION' THEN 1
             ELSE NULL
             END) "INDPART"
      ,COUNT(CASE
             WHEN a.object_type NOT IN ('PACKAGE','TABLE','INDEX','SEQUENCE','TRIGGER','PACKAGE BODY','PROCEDURE','FUNCTION','VIEW','TYPE','SYNONYM','LOB','JOB', 'DATABASE LINK','MATERIALIZED VIEW', 'TABLE PARTITION','INDEX PARTITION') THEN 1
             ELSE NULL
             END) "Other"
      ,COUNT(CASE
             WHEN 1 = 1 THEN 1
             ELSE NULL
             END) "Total"
FROM dba_objects a
where owner  in ('D1473','D2296','D2299','D232','D2343','D235','D2362','D2405','D2432','D2446','D2453','D2455','D2461','D2462','D2463','D2472','D2478','D2493','D2508','D2520')
GROUP BY rollup(a.owner)
/
spool off




select 'alter ' || decode (object_type,'PACKAGE BODY','package',object_type) ||
' ' || owner || '.' ||  object_name || ' compile ' || 
decode (object_type,'PACKAGE BODY',' body ;', ' ; ') x
from dba_objects
where status = 'INVALID'
and owner in ('D1473','D2296','D2299','D232','D2343','D235','D2362','D2405','D2432','D2446','D2453','D2455','D2461','D2462','D2463','D2472','D2478','D2493','D2508','D2520');
/





SELECT COUNT(*) FROM ALL_TRIGGERS WHERE OWNER='D1473' ORDER BY 1;






## COLOCAR BASE EM READ ONLY E CLONAR 
alter session set container=CDB$ROOT;
alter pluggable database PDB1_RJ close immediate;
alter pluggable database PDB1_RJ  open read only;


## no cdbprd06/PDB1_RJ_BKP
##- copia do cdbprd05/PDB1_RJ -> cdbprd06/PDB1_RJ_BKP

create public database link ORIGEMDPCWEB5 connect to C##EXPORTA identified by exporta123 using '10.22.6.122:1521/cdbprd03_gru1ia.dpcprivadadbpro.mxmocivcn.oraclevcn.com';


create pluggable database PDB1_RJ_BKP FROM PDB1_RJ@ORIGEMDPCWEB5 keystore identified by "Cloud-DPC-2390" including shared key parallel 10;




- shutdown PDB1_RJ

alter session set container=CDB$ROOT;
alter pluggable database PDB1_RJ close immediate;
alter pluggable database PDB1_RJ  open;



#- Statisticas no final, DESATIVAR RECYCLE BINARY_INTEGER
alter system set recyclebin=off scope=spfile;

EXEC DBMS_STATS.gather_schema_stats (ownname => 'D1473',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2296',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2299',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D232', cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2343',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D235', cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2362',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2405',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2432',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2446',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2453',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2455',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2461',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2462',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2463',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2472',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2478',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2493',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2508',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);
EXEC DBMS_STATS.gather_schema_stats (ownname => 'D2520',cascade => true, estimate_percent => dbms_stats.auto_sample_size, METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', GRANULARITY => 'GLOBAL', DEGREE => 10);




## COLETAR DO DICIONARIO
EXEC DBMS_STATS.gather_dictionary_stats;
EXEC DBMS_STATS.gather_fixed_objects_stats;




alter user D2508 account unlock;
alter user D1473 account unlock;
alter user D2296 account unlock;
alter user D2472 account unlock;
alter user D2520 account unlock;
alter user D2455 account unlock;
alter user D2405 account unlock;
alter user D2432 account unlock;
alter user D2343 account unlock;
alter user D2461 account unlock;
alter user D2463 account unlock;
alter user D232 account  unlock;
alter user D2446 account unlock;
alter user D2462 account unlock;
alter user D2478 account unlock;
alter user D2299 account unlock;
alter user D2362 account unlock;
alter user D2493 account unlock;
alter user D235 account  unlock;
alter user D2453 account unlock;




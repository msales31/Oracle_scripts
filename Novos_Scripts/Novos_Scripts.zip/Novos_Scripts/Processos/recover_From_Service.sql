##############################################################################################
#######--- from service 







--## salvar informacoes do rman.

RMAN


CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 30 DAYS;
CONFIGURE BACKUP OPTIMIZATION ON;
CONFIGURE DEFAULT DEVICE TYPE TO 'SBT_TAPE';
CONFIGURE CONTROLFILE AUTOBACKUP OFF;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE SBT_TAPE TO '%F'; # default
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default
CONFIGURE DEVICE TYPE 'SBT_TAPE' PARALLELISM 8 BACKUP TYPE TO COMPRESSED BACKUPSET;
CONFIGURE DEVICE TYPE DISK PARALLELISM 8 BACKUP TYPE TO BACKUPSET;
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbveranp/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbveranp/opcdbveranp.ora)';
CONFIGURE MAXSETSIZE TO 100 G;
CONFIGURE ENCRYPTION FOR DATABASE ON;
CONFIGURE ENCRYPTION ALGORITHM 'AES128'; # default
CONFIGURE COMPRESSION ALGORITHM 'MEDIUM' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE;
CONFIGURE RMAN OUTPUT TO KEEP FOR 7 DAYS; # default
CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON ALL STANDBY;
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/u01/app/oracle/product/19.0.0.0/dbhome_1/dbs/snapcf_dbveranp.f'; # default



--### CATALOGAR BACKUP 
spool /tmp/catalog.cmd
set pagesize 0
select '   '''||HANDLE||''','||chr(10)
from V$BACKUP_PIECE bp
where bp.HANDLE is not null
and DEVICE_TYPE = 'SBT_TAPE'
order by START_TIME, PIECE#;
spool off

--### CANCELAR APLICACAO

ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;


--#.. executar no standby utilizando servico da producao

show parameter fal --> pegar informacao do fal server 

RMAN >

run{
SET NEWNAME FOR DATABASE TO NEW;
 recover  database from service dbveranp_3np_gru;
}


-- ###### NO PRIMARY ####                                      |                                                       |
-- Fazer backup do controlfile 

run{
allocate channel c1 device type DISK;
BACKUP CURRENT CONTROLFILE FOR STANDBY FORMAT '/u01/app/oracle/temp/ForStandbyCTRL.bck';                    
}							


--### STANDBY                                                                                      
-- restaurar no stby                                                                               
                                                   
RMAN> SHUTDOWN IMMEDIATE;                          
RMAN> STARTUP NOMOUNT;                  |---------------------------|
RMAN> RESTORE STANDBY CONTROLFILE FROM '/u02/ForStandbyCTRL.bck';
RMAN> alter database mount;


--# fazer switch database to copy no RMAN


catalog start with '+DATA/DBVERANP_VPC2S';
switch database to copy;


### LIMPAR GRUPO DE REDO:

ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 104;

ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     7;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP     8;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   911;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   912;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   913;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   914;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   915;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   916;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   917;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP   918;



### ATIVAR BASE 

ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;
alter database recover managed standby database disconnect using current logfile;



#######--- catalogar todos os backups pieces gerados anteriormente

-- lembrar de editar e colocar 
catalog DEVICE TYPE 'SBT_TAPE' backuppiece  

-- ultima linha sem , e sim com ;


## catalogar pecas 
rman target / cmdfile=catalog.cmd








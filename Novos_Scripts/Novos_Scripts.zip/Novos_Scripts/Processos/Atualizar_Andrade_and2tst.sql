#####################################################################################################################################################
#####
####      Procedimento para qualquer  atualizacao de bases teste
#####





#################################################################
##-- salvar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/backup/temp/andrade';
spool /backup/temp/andrade/dbnameuserpass.sql
SELECT 'ALTER USER "' || username || '"' ||
  DECODE (password,
          'EXTERNAL',' IDENTIFIED EXTERNALLY',
          'GLOBAL',' IDENTIFIED GLOBALLY AS ''' || external_name,
          ' IDENTIFIED BY VALUES '||''''||(SELECT PASSWORD FROM SYS.USER$ WHERE NAME = u.username )||'''') ||' account unlock;'
FROM dba_users u
WHERE username NOT IN
         ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
          'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
          'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
          'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM','XS$NULL','APPQOSSYS')
ORDER BY username;
spool off
_SQL_


##--- export dos usuarios
expdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-users%U.dmp \
LOGFILE=dbname-exp-users.log \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=USER \
INCLUDE=SYSTEM_GRANT \
INCLUDE=ROLE_GRANT \
INCLUDE=TABLESPACE_QUOTA \
INCLUDE=GRANT


##--- export dos dblinks
expdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=exp_dbnamedblinks.log \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=DB_LINK:"\"IN(SELECT db_link FROM dba_db_links)\""


#####################################################################################################################################################
#####
####      depois de atualizar a base, executar os procedimentos abaixo **** NA BASE TESTE ****


###

##-- restaurar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/backup/temp/andrade';
@/backup/temp/andrade/dbnameuserpass.sql
_SQL_

spool /backup/dbname/rman/dropdblinks.sql
begin
for o in (select distinct owner from dba_db_links where owner<>'PUBLIC' order by 1) loop
   DBMS_OUTPUT.PUT_LINE('CREATE PROCEDURE '||o.owner||'.drop_db_link AS' );
   DBMS_OUTPUT.PUT_LINE('BEGIN' );
   for d in (select distinct DB_LINK from dba_db_links where owner=o.owner order by 1) loop
      DBMS_OUTPUT.PUT_LINE('EXECUTE IMMEDIATE ''drop database link '||d.DB_LINK||''';');
   end loop;
   DBMS_OUTPUT.PUT_LINE('END drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('/');
   DBMS_OUTPUT.PUT_LINE('EXEC '||o.owner||'.drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('DROP PROCEDURE '||o.owner||'.drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------');
end loop;

for d in (select distinct DB_LINK from dba_db_links where owner='PUBLIC' order by 1) loop
  DBMS_OUTPUT.PUT_LINE('drop public database link '||d.DB_LINK||';');
end loop;

end;
/
spool off

@/backup/dbname/rman/dropdblinks.sql



##--- import dos dblinks
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=imp_dbnamedblinks.log


##--- import dos usuarios
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-users%U.dmp \
LOGFILE=dbname-imp-users.log \
INCLUDE=SCHEMA:"\"NOT IN(SELECT USERNAME FROM DBA_USERS)\"" 


sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
@$ORACLE_HOME/rdbms/admin/utlrp.sql
'_SQL_'


TABLESPACE_NAME               |   FILE_ID|EXT|        MB|     MAXSZ|FILE_NAME
AFV                           |        69|YES|     13572|     30720|+DATA/AND2TST_ODA02/DATAFILE/afv.496.1139732665
AFV                           |         5|YES|     32000|     30000|+DATA/AND2TST_ODA02/DATAFILE/afv.544.1139702395
AFVANDSEMIONLINE              |       120|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/afvandsemionline.458.1139756295
AFVANDSEMIONLINE              |       134|YES|      1180|     32767|+DATA/AND2TST_ODA02/DATAFILE/afvandsemionline.485.1139739585
AFVANDSEMIONLINE              |       121|YES|     32767|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/afvandsemionline.492.1139738115
AFVANDSEMIONLINE              |        17|YES|     32767|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/afvandsemionline.493.1139738115
AFVANDSEMIONLINE              |       125|YES|     18236|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/afvandsemionline.517.1139719397
AFVANDSEMIONLINE              |        92|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/afvandsemionline.677.1139719395
DTI                           |         6|YES|       297|     30000|+DATA/AND2TST_ODA02/DATAFILE/dti.484.1139739907
JANELA01                      |        71|YES|     32729|     32760|+DATA/AND2TST_ODA02/DATAFILE/janela01.2696.1139774339
JANELA01                      |         7|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/janela01.436.1139768455
JANELA01                      |         9|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/janela01.462.1139756293
JANELA01                      |       118|YES|     12984|     30720|+DATA/AND2TST_ODA02/DATAFILE/janela01.466.1139750701
JANELA01                      |        10|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/janela01.512.1139726879
JANELA01                      |         8|YES|     32708|     32760|+DATA/AND2TST_ODA02/DATAFILE/janela01.519.1139719397
JANELA01                      |       117|YES|     12856|     30720|+DATA/AND2TST_ODA02/DATAFILE/janela01.541.1139702395
JANELA01                      |       119|YES|     12984|     30720|+DATA/AND2TST_ODA02/DATAFILE/janela01.550.1139699151
JANELA01                      |        11|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/janela01.557.1139696479
MAXIMA                        |        52|YES|     16356|     30720|+DATA/AND2TST_ODA02/DATAFILE/maxima.2703.1139774341
MAXIMA                        |        60|YES|      6137|     30720|+DATA/AND2TST_ODA02/DATAFILE/maxima.486.1139738117
MAXIMA                        |        12|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/maxima.489.1139738117
MAXIMA                        |        84|YES|      2144|     30720|+DATA/AND2TST_ODA02/DATAFILE/maxima.505.1139729709
MAXIMA                        |        76|YES|      2520|     30720|+DATA/AND2TST_ODA02/DATAFILE/maxima.515.1139723007
NFEMAIS                       |       126|YES|       330|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/nfemais.474.1139746759
SPY_DADOS                     |        18|YES|       635|     30720|+DATA/AND2TST_ODA02/DATAFILE/spy_dados.2700.1139777577
SYSAUX                        |        85|YES|     16025|     30720|+DATA/AND2TST_ODA02/DATAFILE/sysaux.2707.1139768457
SYSAUX                        |         2|YES|     18459|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/sysaux.507.1139726881
SYSTEM                        |        77|YES|      3288|     30720|+DATA/AND2TST_ODA02/DATAFILE/system.2711.1139771391
SYSTEM                        |         1|YES|      2610|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/system.503.1139777205
TEMP99                        |         2|YES|      7700|  32767.98|+DATA/AND2TST_ODA02/TEMPFILE/temp99.453.1140788663
TSD_WAYDATA                   |       108|YES|         3|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/tsd_waydata.444.1139764599
TSI_WAYDATA                   |       109|YES|         2|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/tsi_waydata.549.1139700593
TS_DADOS                      |       132|YES|     14737|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2693.1139774341
TS_DADOS                      |        53|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2699.1139774339
TS_DADOS                      |        98|YES|     32767|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2705.1139732663
TS_DADOS                      |        81|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2706.1139774339
TS_DADOS                      |        36|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2708.1139774339
TS_DADOS                      |        72|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2709.1139774339
TS_DADOS                      |       133|YES|     14876|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.2712.1139768457
TS_DADOS                      |        73|YES|     32767|     32767|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.408.1139756293
TS_DADOS                      |        42|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.437.1139768455
TS_DADOS                      |        62|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.438.1139768455
TS_DADOS                      |        94|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.441.1139768455
TS_DADOS                      |        56|YES|     32767|     32767|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.443.1139768455
TS_DADOS                      |       116|YES|     30052|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.448.1139763093
TS_DADOS                      |       111|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.449.1139763093
TS_DADOS                      |        79|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.450.1139763093
TS_DADOS                      |        48|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.451.1139763093
TS_DADOS                      |        33|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.452.1139763093
TS_DADOS                      |       128|YES|     15252|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.456.1139756295
TS_DADOS                      |       103|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.459.1139756295
TS_DADOS                      |        63|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.460.1139756295
TS_DADOS                      |        43|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.461.1139756293
TS_DADOS                      |       122|YES|     21644|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.467.1139750701
TS_DADOS                      |        86|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.470.1139750701
TS_DADOS                      |        55|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.471.1139750699
TS_DADOS                      |        39|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.472.1139750699
TS_DADOS                      |       112|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.479.1139745449
TS_DADOS                      |        80|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.480.1139745449
TS_DADOS                      |        49|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.481.1139745449
TS_DADOS                      |        34|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.482.1139745447
TS_DADOS                      |        70|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.483.1139745447
TS_DADOS                      |        93|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.490.1139738117
TS_DADOS                      |        61|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.491.1139738115
TS_DADOS                      |       124|YES|     21876|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.497.1139732665
TS_DADOS                      |        99|YES|     30180|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.498.1139732665
TS_DADOS                      |       106|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.499.1139732665
TS_DADOS                      |        74|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.500.1139732663
TS_DADOS                      |        46|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.501.1139732663
TS_DADOS                      |        13|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.502.1139732663
TS_DADOS                      |       130|YES|     14400|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.506.1139726881
TS_DADOS                      |       104|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.509.1139726879
TS_DADOS                      |        64|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.510.1139726879
TS_DADOS                      |        44|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.511.1139726879
TS_DADOS                      |        96|YES|     32767|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.513.1139726879
TS_DADOS                      |       131|YES|     14488|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.516.1139719399
TS_DADOS                      |        83|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.520.1139719397
TS_DADOS                      |        54|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.521.1139719397
TS_DADOS                      |        37|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.522.1139719397
TS_DADOS                      |        68|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.523.1139763093
TS_DADOS                      |       110|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.527.1139713703
TS_DADOS                      |        78|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.528.1139713703
TS_DADOS                      |        47|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.529.1139713703
TS_DADOS                      |        19|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.530.1139713703
TS_DADOS                      |       107|YES|     32767|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.531.1139713703
TS_DADOS                      |       135|YES|     12288|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.532.1139708633
TS_DADOS                      |        88|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.536.1139708631
TS_DADOS                      |        58|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.537.1139708631
TS_DADOS                      |        41|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.538.1139708631
TS_DADOS                      |       115|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.539.1139708631
TS_DADOS                      |       100|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.540.1139750699
TS_DADOS                      |        87|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.545.1139702393
TS_DADOS                      |        57|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.546.1139702393
TS_DADOS                      |        40|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.547.1139702393
TS_DADOS                      |       114|YES|  32767.98|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.548.1139702393
TS_DADOS                      |       129|YES|     14252|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.551.1139696479
TS_DADOS                      |       123|YES|     21764|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.552.1139696479
TS_DADOS                      |       105|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.554.1139696479
TS_DADOS                      |        65|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.555.1139696479
TS_DADOS                      |        45|YES|     32760|     32760|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.556.1139696479
TS_DADOS                      |        97|YES|     32767|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_dados.558.1139696479
TS_DADOS2                     |        14|YES|         2|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_dados2.465.1139753393
TS_DADOS3                     |        15|YES|         2|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_dados3.464.1139753395
TS_DADOS_G                    |        16|YES|         2|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_dados_g.495.1139735409
TS_INDICE                     |        38|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.2704.1139774341
TS_INDICE                     |        50|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.386.1139768457
TS_INDICE                     |        89|YES|      7888|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.446.1139763095
TS_INDICE                     |        59|YES|     27320|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.447.1139763095
TS_INDICE                     |        26|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.468.1139750701
TS_INDICE                     |        67|YES|     32498|     32498|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.469.1139750701
TS_INDICE                     |        22|YES|     29852|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.478.1139745449
TS_INDICE                     |        75|YES|     28844|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.487.1139738117
TS_INDICE                     |        21|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.488.1139738117
TS_INDICE                     |        27|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.508.1139726879
TS_INDICE                     |        35|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.518.1139719397
TS_INDICE                     |        82|YES|     24896|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.525.1139713703
TS_INDICE                     |        24|YES|     30122|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.526.1139713703
TS_INDICE                     |        25|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.534.1139708631
TS_INDICE                     |        66|YES|     32000|     32000|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.535.1139708631
TS_INDICE                     |        51|YES|     26480|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.542.1139702395
TS_INDICE                     |        23|YES|     30720|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.543.1139702395
TS_INDICE                     |        20|YES|     30353|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice.553.1139696479
TS_INDICE2                    |        28|YES|         2|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice2.494.1139735411
TS_INDICE2                    |        29|YES|         2|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice2.504.1139730157
TS_INDICE2                    |        30|YES|         2|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_indice2.514.1139723703
TS_ION_DATA                   |        90|YES|      9740|     32000|+DATA/AND2TST_ODA02/DATAFILE/ts_ion_data.2710.1139705127
TS_ION_INDEX                  |        91|YES|      5520|     32000|+DATA/AND2TST_ODA02/DATAFILE/ts_ion_index.476.1139745449
TS_TEMPORARIO                 |        31|YES|        95|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_temporario.445.1139764589
TS_TMXDATA                    |       127|YES|      3316|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/ts_tmxdata.455.1139759735
TS_TMXDATA                    |       101|YES|     11312|     12000|+DATA/AND2TST_ODA02/DATAFILE/ts_tmxdata.524.1139713705
TS_TMXINDICES                 |       102|YES|       634|     12000|+DATA/AND2TST_ODA02/DATAFILE/ts_tmxindices.2702.1139771661
TS_TRANSBR                    |        32|YES|       512|     30720|+DATA/AND2TST_ODA02/DATAFILE/ts_transbr.454.1139759759
UNDOTBS02                     |        95|YES|     15262|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/undotbs02.457.1139756295
UNDOTBS02                     |       113|YES|     28336|     30720|+DATA/AND2TST_ODA02/DATAFILE/undotbs02.477.1139745449
UNDOTBS02                     |         3|YES|     25976|     32000|+DATA/AND2TST_ODA02/DATAFILE/undotbs02.533.1139708633
USERS                         |         4|YES|      1202|  32767.98|+DATA/AND2TST_ODA02/DATAFILE/users.475.1139746521

136 rows selected.

NAME                                |TYPE       |VALUE
cdb_cluster_name                    |string     |
cell_offloadgroup_name              |string     |
db_file_name_convert                |string     |
db_name                             |string     |and2tst
db_unique_name                      |string     |and2tst_oda02
global_names                        |boolean    |TRUE
instance_name                       |string     |and2tst
lock_name_space                     |string     |
log_file_name_convert               |string     |
pdb_file_name_convert               |string     |
processor_group_name                |string     |
service_names                       |string     |and2tst_oda02



list backup of controlfile completed between "to_date('09-AUG-2023 00:00:00','DD-MON-YYYY HH24:MI:SS')" and "to_date('09-AUG-2023 23:59:00','DD-MON-YYYY HH24:MI:SS')";

BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ -------------------
24453   Full    42.33M     DISK        00:00:02     2023/08/09 06:43:02
        BP Key: 24453   Status: AVAILABLE  Compressed: NO  Tag: ARCHIVEHORARIO202308090638
        Piece Name: /export/andrade/rman/rman_ctrl_andrade_ARCHIVE_dbid332276801_s23174_t1144392180_p1.bkp
  Standby Control File Included: Ckp SCN: 30990245174371   Ckp time: 2023/08/09 06:33:02


run{
restore controlfile from '/export/andrade/rman/rman_ctrl_andrade_ARCHIVE_dbid332276801_s23174_t1144392180_p1.bkp';
alter database MOUNT;
}


##### CATALOGAR PECAS DE BACKUP E RESTAURAR #####

CATALOG START WITH '/export/andrade/rman';

rman target / << '__RMAN__'
run {
SET NEWNAME FOR DATABASE TO NEW;
RESTORE DATABASE until SCN 30990245174371;
switch datafile all;
switch tempfile all;
RECOVER DATABASE until SCN 30990245174371;
}
__RMAN__


SQL > alter database backup controlfile to trace as '/home/oracle/ctlteste.ctl';

alter system set db_name='and2tst' scope=spfile;

CREATE CONTROLFILE reuse SET DATABASE "AND2TST" RESETLOGS NOARCHIVELOG


SQL> alter database open resetlogs;
alter database open resetlogs
*
ERROR at line 1:
ORA-00603: ORACLE server session ter



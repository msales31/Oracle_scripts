##########################################
#-- no primary

alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- verificar se foram adicionados redos standby (mesmo numero de grupos e tamanho dos atuais)


#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
log_archive_config                                          |string     |DG_CONFIG=(dbprod_gru1dc,dbprod_gru1s6)


alter system set log_archive_config='DG_CONFIG=(PIP_GRU1PR,PIP_GRU1ST)'; -- DBUNIQUE PROD,DBUNIQUE STANDBY 

#- tns do outro db (nesse caso standby)
alter system set fal_server='PIP_GRU1ST' SCOPE=BOTH SID='*';

#- tns do proprio db (nesse caso primary)
alter system set fal_client='PIP_GRU1PR' SCOPE=BOTH SID='*';

#-configurar log dest do standby
alter system set log_archive_dest_2='SERVICE=PIP_GRU1ST LGWR ASYNC NET_TIMEOUT=10 MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=PIP_GRU1ST'; --standby 

-- teste 

alter system set log_archive_dest_2='SERVICE="(description=(address_list=(address=(protocol=TCP)(host=10.161.101.112)(port=1521)))(connect_data=(service_name=PIP_GRU1ST)))", LGWR ASYNC MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=PIP_GRU1ST' scope=both;

#- ativar log shipping (*** depois de tudo configurado)
alter system set log_archive_dest_state_2='ENABLE' scope=both;


###- se for DG cascade (3 nos)
##-- alter system set log_archive_dest_3='SERVICE=pano01_bm02 VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01_gru1nw';
##-- alter system set log_archive_dest_state_3='ENABLE';



##########################################
#-- no standby


alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=900 scope=both;

#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(PIP_GRU1ST,PIP_GRU1PR)'; -- STANDBY,PROD

|DG_CONFIG=(dbprod_gru1s6,dbprod_gru1dc)

#- tns do outro db (nesse caso primary)
alter system set fal_server='PIP_GRU1PR';


PARAMETER_NAME                                              |TYPE       |VALUE
fal_client                                                  |string     |dbprod_dg
fal_server                                                  |string     |dbprod_dbcs01


#- tns do proprio db (nesse caso standby)
alter system set fal_client='PIP_GRU1ST.WORD';

#-configurar log dest do standby

PARAMETER_NAME                                              |TYPE       |VALUE
log_archive_dest_2                                          |string     |SERVICE=dbprod_dbcs01 LGWR ASYNC NET_TIMEOUT=10 MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=dbprod_gru1dc


alter system set log_archive_dest_2='SERVICE=PIP_GRU1PR LGWR ASYNC NET_TIMEOUT=10 MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=PIP_GRU1PR';

###- se for DG cascade (3 nos)
### alter system set log_archive_dest_3='SERVICE= VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01';


#- start recover no standby (com standby redo)
alter database recover managed standby database disconnect using current logfile;


So, the quick solution for ORA-01665 will be:

ALTER DATABASE CONVERT TO PHYSICAL STANDBY;





---recuperar gap 



##VER MENOR SCN

col CURRENT_SCN format 9999999999999999                                                        
select to_char (min (d.CURRENT_SCN)) from V$DATABASE d                                         
union                                                                                          
select to_char (max (d.CURRENT_SCN)) from V$DATABASE d                                         
union                                                                                          
select to_char (min (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           
union                                                                                          
select to_char (max (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           
union                                                                                          
select to_char (min (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f                                  
union                                                                                          
select to_char (max (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f ;   


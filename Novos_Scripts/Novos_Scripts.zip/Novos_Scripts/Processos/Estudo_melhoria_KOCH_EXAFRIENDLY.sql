SQL> @exafriendly.sql gv$active_session_history

MAX(SAMPLE_TIME)-MIN(SAMPLE_TIME)
---------------------------------------------------------------------------
+000000000 03:06:27.521

Elapsed: 00:00:00.05
Report the top active SQL statements regardless of their CPU usage/wait event breakdown

SQL_ID           SECONDS    PCT
------------- ---------- ------
8016b4nmt52cb      36778    8.2
3q2yd2j72cmxz      23375    5.2
cj4xwkxbvhbh9      23172    5.1
f14tvrp9nwqtp      15933    3.5
c3fzmz27a6ys5      15623    3.5
                   11837    2.6
8nvup8r3n8z1u       9841    2.2
0yzuz59bgrdf1       7175    1.6
916k6q96g6pgn       7034    1.6
0vtasybnah0mh       7025    1.6

10 rows selected.

Elapsed: 00:00:00.33
Report the top session state/wait class breakdown

SESSION WAIT_CLASS              SECONDS    PCT
------- -------------------- ---------- ------
ON CPU                           394268   83.8
WAITING Cluster                   25715    5.5
WAITING Other                     15521    3.3
WAITING Application               14415    3.1
WAITING User I/O                  10053    2.1
WAITING Concurrency                3193     .7
WAITING Network                    1715     .4
WAITING System I/O                 1699     .4
WAITING Configuration              1454     .3
WAITING Commit                     1306     .3

10 rows selected.

Elapsed: 00:00:00.27
Report the top session state/wait event breakdown (just like TOP-5 Timed Events in AWR)

SESSION WAIT_CLASS           EVENT                                       SECONDS    PCT
------- -------------------- ---------------------------------------- ---------- ------
ON CPU                                                                    394268   83.8
WAITING Application          enq: TX - row lock contention                 14127    3.0
WAITING Cluster              gc current block 2-way                         8263    1.8
WAITING Other                cell single block physical read: pmem ca       5860    1.2
                             che

WAITING Other                cell single block physical read: RDMA          5845    1.2
WAITING Cluster              gc cr grant 2-way                              4756    1.0
WAITING User I/O             cell list of blocks physical read              4456     .9
WAITING User I/O             cell single block physical read: flash c       3469     .7
                             ache

WAITING Cluster              gc cr block busy                               2491     .5
WAITING Cluster              gc cr multi block request                      2290     .5

10 rows selected.

Elapsed: 00:00:00.36
Report the top SQL waiting for buffered single block reads

SESSION WAIT_CLASS           EVENT                                    SQL_ID           SECONDS    PCT
------- -------------------- ---------------------------------------- ------------- ---------- ------
WAITING User I/O             cell single block physical read          2w5d7rdbw3bfy          4   44.4
WAITING User I/O             cell single block physical read          2fng3dh6fam10          3   33.3
WAITING User I/O             cell single block physical read          5ua702799dphh          1   11.1
WAITING User I/O             cell single block physical read          4c9gjt7q0cdvm          1   11.1

Elapsed: 00:00:00.25
Report the top SQL waiting for buffered single block reads the most (with sampled execution count)

PLAN_LINE                                EVENT                                    SQL_ID        NOTICED_EXECUTIONS    SECONDS    PCT
---------------------------------------- ---------------------------------------- ------------- ------------------ ---------- ------
TABLE ACCESS BY GLOBAL INDEX ROWID BATCH cell single block physical read          2w5d7rdbw3bfy                  4          4   44.4
ED

INDEX RANGE SCAN                         cell single block physical read          2fng3dh6fam10                  3          3   33.3
TABLE ACCESS STORAGE FULL                cell single block physical read          5ua702799dphh                  1          1   11.1
INDEX RANGE SCAN                         cell single block physical read          4c9gjt7q0cdvm                  1          1   11.1

Elapsed: 00:00:00.26
Report what kind of SQL execution plan operations, executed by which user wait for buffered single block reads the most

PLAN_LINE                                USERNAME                                                                                                                         EVENT                                       SECONDS    PCT
---------------------------------------- -------------------------------------------------------------------------------------------------------------------------------- ---------------------------------------- ---------- ------
INDEX RANGE SCAN                         CONSINCO                                                                                                                         cell single block physical read                   4   44.4
TABLE ACCESS BY GLOBAL INDEX ROWID BATCH CONSINCOMONITOR                                                                                                                  cell single block physical read                   4   44.4
ED

TABLE ACCESS STORAGE FULL                CONSINCO                                                                                                                         cell single block physical read                   1   11.1

Elapsed: 00:00:00.62
Report what kind of execution plan operations wait for buffered single block reads

PLAN_LINE                                EVENT                                       SECONDS    PCT
---------------------------------------- ---------------------------------------- ---------- ------
INDEX RANGE SCAN                         cell single block physical read                   4   44.4
TABLE ACCESS BY GLOBAL INDEX ROWID BATCH cell single block physical read                   4   44.4
ED

TABLE ACCESS STORAGE FULL                cell single block physical read                   1   11.1

Elapsed: 00:00:00.28
Report what kind of execution plan operations wait for buffered single block reads - against which schemas

PLAN_LINE                                OBJECT_OWNER                                                                                                                     EVENT                                       SECONDS    PCT
---------------------------------------- -------------------------------------------------------------------------------------------------------------------------------- ---------------------------------------- ---------- ------
TABLE ACCESS BY GLOBAL INDEX ROWID BATCH CONSINCO                                                                                                                         cell single block physical read                   3  100.0
ED


Elapsed: 00:00:00.30
Report what kind of execution plan operations wait for buffered single block reads - against which objects

PLAN_LINE                                OBJECT_OWNER                                                                                                                     OBJECT_NAME                                                                                                                      EVENT                                       SECONDS    PCT
---------------------------------------- -------------------------------------------------------------------------------------------------------------------------------- -------------------------------------------------------------------------------------------------------------------------------- ---------------------------------------- ---------- ------
TABLE ACCESS BY GLOBAL INDEX ROWID BATCH CONSINCO                                                                                                                         MFL_CUPOMFISCAL                                                                                                                  cell single block physical read                   3  100.0
ED


Elapsed: 00:00:00.25
Report which SQL command type consumes the most time (broken down by wait class)

COMMAND_NAME    SESSION WAIT_CLASS              SECONDS    PCT
--------------- ------- -------------------- ---------- ------
SELECT          ON CPU                           278640   59.2
INSERT          ON CPU                            55429   11.8
                ON CPU                            24181    5.1
UPDATE          ON CPU                            16138    3.4
SELECT          WAITING Cluster                   15923    3.4
DELETE          ON CPU                             9558    2.0
SELECT          WAITING Other                      9138    1.9
UPDATE          WAITING Application                8937    1.9
SELECT          WAITING User I/O                   7825    1.7
UPSERT          ON CPU                             7074    1.5

10 rows selected.

Elapsed: 00:00:00.45
Report what kind of execution plan operations wait for buffered multiblock reads the most

PLAN_LINE                                EVENT                                       SECONDS    PCT
---------------------------------------- ---------------------------------------- ---------- ------
TABLE ACCESS STORAGE FULL                cell multiblock physical read                   288   58.5
TABLE ACCESS BY INDEX ROWID              cell multiblock physical read                   100   20.3
INDEX STORAGE FAST FULL SCAN             cell multiblock physical read                    36    7.3
TABLE ACCESS BY INDEX ROWID BATCHED      cell multiblock physical read                    24    4.9
TABLE ACCESS INMEMORY FULL               cell multiblock physical read                    21    4.3
TABLE ACCESS BY LOCAL INDEX ROWID        cell multiblock physical read                     8    1.6
TABLE ACCESS BY LOCAL INDEX ROWID BATCHE cell multiblock physical read                     6    1.2
D

                                         cell multiblock physical read                     5    1.0
INDEX RANGE SCAN                         cell multiblock physical read                     3     .6
INDEX UNIQUE SCAN                        cell multiblock physical read                     1     .2

10 rows selected.

Elapsed: 00:00:00.25
Report what kind of execution plan operations wait for buffered multiblock reads - against which objects

PLAN_LINE                                OBJECT_OWNER                                                                                                                     OBJECT_NAME                                                                                                                      EVENT                                       SECONDS    PCT
---------------------------------------- -------------------------------------------------------------------------------------------------------------------------------- -------------------------------------------------------------------------------------------------------------------------------- ---------------------------------------- ---------- ------
TABLE ACCESS BY INDEX ROWID              CONSINCO                                                                                                                         RF_NOTAITEM                                                                                                                      cell multiblock physical read                    71   20.4
TABLE ACCESS STORAGE FULL                SYS                                                                                                                              WRH$_ACTIVE_SESSION_HISTORY                                                                                                      cell multiblock physical read                    56   16.1
TABLE ACCESS INMEMORY FULL               CONSINCO                                                                                                                         MFL_DOCTOFISCAL                                                                                                                  cell multiblock physical read                    21    6.0
TABLE ACCESS STORAGE FULL                CONSINCO                                                                                                                         MAC_CUSTOFORNECLOG                                                                                                               cell multiblock physical read                    19    5.5
TABLE ACCESS STORAGE FULL                CONSINCO                                                                                                                         MAD_EDILOGARQUIVO                                                                                                                cell multiblock physical read                    17    4.9
INDEX STORAGE FAST FULL SCAN             CONSINCO                                                                                                                         FI_TITOPERACXIE8                                                                                                                 cell multiblock physical read                    12    3.4
TABLE ACCESS STORAGE FULL                CONSINCO                                                                                                                         MAD_CARGARECEBLOG                                                                                                                cell multiblock physical read                    12    3.4
TABLE ACCESS BY INDEX ROWID              CONSINCO                                                                                                                         MLF_NFITEM                                                                                                                       cell multiblock physical read                    11    3.2
TABLE ACCESS BY LOCAL INDEX ROWID        CONSINCO                                                                                                                         MFL_DFITEM                                                                                                                       cell multiblock physical read                     8    2.3
TABLE ACCESS STORAGE FULL                CONSINCO                                                                                                                         MFT_MANIFESTO_DF                                                                                                                 cell multiblock physical read                     8    2.3




ALTER TABLE consinco.mrl_custodia MODIFY PARTITION SYS_P23623 STORAGE (CELL_FLASH_CACHE KEEP);
ALTER TABLE consinco.mrl_custodia MODIFY PARTITION SYS_P25401 STORAGE (CELL_FLASH_CACHE KEEP);
ALTER TABLE consinco.mrl_custodia MODIFY PARTITION SYS_P24403 STORAGE (CELL_FLASH_CACHE KEEP);



alter table CONSINCOMONITOR.TB_DOCTOCUPOM STORAGE (CELL_FLASH_CACHE KEEP);
alter table CONSINCOMONITOR.TB_DOCTOITEM STORAGE (CELL_FLASH_CACHE KEEP);
alter INDEX  CONSINCOMONITOR.IDX$$_1E8630001 STORAGE (CELL_FLASH_CACHE KEEP);
alter INDEX  CONSINCOMONITOR.IDX$$_1E8630002 STORAGE (CELL_FLASH_CACHE KEEP);


    create index CONSINCOMONITOR.IDX$$_1E8630001 on CONSINCOMONITOR.TB_DOCTOCUPOM("SEQPESSOA") tablespace TSI_CONSINCO ONLINE PARALLEL 10;
	ALTER INDEX CONSINCOMONITOR.IDX$$_1E8630001 NOPARALLEL;

  - Consider running the Access Advisor to improve the physical schema design
    or creating the recommended index.
    create index CONSINCOMONITOR.IDX$$_1E8630002 on CONSINCOMONITOR.TB_DOCTOITEM("NROEMPRESA","NROCHECKOUT","SEQDOCTO") tablespace TSI_CONSINCO ONLINE PARALLEL 10;



@mon_topsql

CONSINCO                       MRL_CUSTODIA                           70 NO  SYS_P23623                       12443624                  0 TO_DATE(' 2024-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                                 83 DISABLED
CONSINCO                       MRL_CUSTODIA                           71 NO  SYS_P24403                       13010064                  0 TO_DATE(' 2024-11-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                                 83 DISABLED
CONSINCO                       MRL_CUSTODIA                           72 NO  SYS_P25401                       13329199                  0 TO_DATE(' 2024-12-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                                 83 DISABLED





DAY               PCT TOPSQL_OWNER                   TOPSQL_OBJECT_NAME             TOPSQL_PROCEDURE_NAME          SQL_ID         PLAN_HASH TOTAL_HOURS TOTAL_SECONDS EXECUTIONS SECONDS_PER_EXEC IO_PCT CPU_PCT    MB_READ MB_PER_EXEC BUFFER_GETS BUFGET_PER_EXEC EXTRACT_PLAN_FROM_AWR
---------- ---------- ------------------------------ ------------------------------ ------------------------------ ------------- ---------- ----------- ------------- ---------- ---------------- ------ ------- ---------- ----------- ----------- --------------- --------------------------------------------------------------------------------------------------------------------------
2024-12-11       3.3%                                                                                              cj4xwkxbvhbh9 3416425155        25.6         92090       3033            30.36     .0    99.7    8.90625           0  1.5158E+10      4997558.47 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('cj4xwkxbvhbh9',3416425155, format=>'ADVANCED'));
                 3.2% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           0vtasybnah0mh 2894865324        24.9         89520     119182              .75     .0    99.4 11420.1875          .1  1.7325E+10       145361.88 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('0vtasybnah0mh',2894865324, format=>'ADVANCED'));
                 2.3% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           f14tvrp9nwqtp  696678562        17.9         64610    1287023              .05   11.9    68.4 3198138.63        2.48  3027414428         2352.26 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('f14tvrp9nwqtp',696678562, format=>'ADVANCED'));
                 1.7%                                                                                              c3fzmz27a6ys5 3502257729        13.4         48340      62775              .77     .0    99.8     .03125           0  3625913706        57760.47 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('c3fzmz27a6ys5',3502257729, format=>'ADVANCED'));
                 1.6%                                                                                              bdbm9p2d3hzzd 2695094321        12.9         46340       1626             28.5     .0    99.4 3749.14063        2.31  1.7983E+10        11059408 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('bdbm9p2d3hzzd',2695094321, format=>'ADVANCED'));
                 1.6%                                                                                                                     0        12.7         45650                                1.2    65.1
                 1.6% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           8016b4nmt52cb 1672621073        12.3         44330                                4.0    82.9                                                    SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('8016b4nmt52cb',1672621073, format=>'ADVANCED'));
                 1.3% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           8nvup8r3n8z1u 1829588489        10.5         37830      99324              .38     .4    96.4 4958.48438         .05  3581204017        36055.78 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('8nvup8r3n8z1u',1829588489, format=>'ADVANCED'));
                 1.3% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           8nvup8r3n8z1u  295662273        10.2         36720      68272              .54     .1    98.3 2171.20313         .03  3624520006        53089.41 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('8nvup8r3n8z1u',295662273, format=>'ADVANCED'));
                 1.3%                                                                                              3q2yd2j72cmxz 3572742146        10.2         36660      41007              .89     .0    98.8 131.054688           0  1.2299E+10       299919.25 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('3q2yd2j72cmxz',3572742146, format=>'ADVANCED'));
                 1.2%                                                                                              bqbpu8wrwnc1m 2201519913         9.4         33900      11594             2.92     .1    99.1 1366.95313         .12   585692923         50516.9 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('bqbpu8wrwnc1m',2201519913, format=>'ADVANCED'));
                 1.0% CONSINCO                       PKG_EFDPC                      SP_INICIA_GERACAO              0pcxach4fvp7k          0         8.2         29400                                2.1    97.2                                                    SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('0pcxach4fvp7k',NULL, format=>'ADVANCED'));

2024-12-10       4.6%                                                                                              3q2yd2j72cmxz 3572742146        10.3         36980      26996             1.37     .0    99.7 147.351563         .01  1.7131E+10       634563.94 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('3q2yd2j72cmxz',3572742146, format=>'ADVANCED'));
                 3.5% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           0vtasybnah0mh 2894865324           8         28730      41352              .69     .0    99.5 3961.03906          .1  6075889134       146930.96 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('0vtasybnah0mh',2894865324, format=>'ADVANCED'));
                 3.3% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           f14tvrp9nwqtp  696678562         7.4         26750     716366              .04   14.0    70.4  1218394.8         1.7  1537265910         2145.92 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('f14tvrp9nwqtp',696678562, format=>'ADVANCED'));
                 3.1%                                                                                              cj4xwkxbvhbh9 3416425155         6.9         24800        916            27.07     .0    99.8   .9296875           0  4376466741      4777802.12 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('cj4xwkxbvhbh9',3416425155, format=>'ADVANCED'));
                 2.5%                                                                                              bvbk141sjj8cb 3968633049         5.6         20140          0                    52.2    22.5 772975.359               308150940                 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('bvbk141sjj8cb',3968633049, format=>'ADVANCED'));
                 2.5% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           8016b4nmt52cb 1672621073         5.5         19890                                3.3    88.9                                                    SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('8016b4nmt52cb',1672621073, format=>'ADVANCED'));
                 2.4%                                                                                              c3fzmz27a6ys5 3502257729         5.4         19290      26996              .71     .0   100.0          0           0  1588227926        58831.97 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('c3fzmz27a6ys5',3502257729, format=>'ADVANCED'));
                 1.9% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           8nvup8r3n8z1u  128563509         4.3         15630      31902              .49     .3    97.3 1574.09375         .05  2105830697        66009.36 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('8nvup8r3n8z1u',128563509, format=>'ADVANCED'));
                 1.9% CONSINCOMONITOR                PKG_MOVIMENTOMONITOR           SP_EXPORTARMOVIMENTO           8nvup8r3n8z1u 2364161185         4.2         15170      26404              .57     .2    98.3  1158.0625         .04  2286468195        86595.52 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('8nvup8r3n8z1u',2364161185, format=>'ADVANCED'));
                 1.7% CONSINCO                       FCODCATEGORIANIVEL                                            22mq2rx19jzvz 1398031126         3.9         14140    1993924              .01     .0   100.0          0           0  6101394384         3059.99 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('22mq2rx19jzvz',1398031126, format=>'ADVANCED'));
                 1.7%                                                                                                                     0         3.7         13420                                1.4    70.9
                 1.6%                                                                                              bdbm9p2d3hzzd 2695094321         3.7         13190        481            27.42     .2    99.2 3344.05469        6.95  4802426325      9984254.31 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('bdbm9p2d3hzzd',2695094321, format=>'ADVANCED'));
                 1.2%                                                                                              bqbpu8wrwnc1m 2201519913         2.8         10130       3716             2.73     .0    99.5   .5234375           0   187733352        50520.28 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('bqbpu8wrwnc1m',2201519913, format=>'ADVANCED'));
                 1.0%                                                                                              86tnvjdkcw1c0 2266758783         2.3          8400          5             1680     .4    88.0 64220.0313    12844.01  2645074196       529014839 SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR('86tnvjdkcw1c0',2266758783, format=>'ADVANCED'));


26 rows selected.2w5d7rdbw3bfy



EXECUTE DBMS_SERVICE.MODIFY_SERVICE (service_name => 'consinco_gua1ex', goal =>  DBMS_SERVICE.GOAL_THROUGHPUT, clb_goal => DBMS_SERVICE.CLB_GOAL_SHORT);


default 

NAME                                                            |GOAL        |CLB_G|FAILOVER_METHOD                                                 |FAILOVER_TYPE
SYS$BACKGROUND                                                  |NONE        |SHORT|                                                                |
SYS$USERS                                                       |NONE        |SHORT|                                                                |
consincoXDB                                                     |            |LONG |                                                                |
consinco_gua1ex                                                 |            |LONG |                                                                |
consinco.koch.intranet                                          |            |LONG |                                                                |
consinco_oda2                                                   |            |LONG |                                                                |
consinco_oda1                                                   |            |LONG |                                                                |
consinco                                                        |NONE        |LONG |                                                                |
GGADMIN.OGG$Q_EC5PRD                                            |NONE        |LONG |                                                                |
consinco_vcp1st                                                 |            |LONG |                                                                |
SYS.KUPC$C_1_20240208192447_0                                   |NONE        |LONG |                                                                |


alterado

SELECT name, goal, clb_goal, failover_method, failover_type
FROM dba_services;



consinco_gua1ex Configurado com GOAL = THROUGHPUT e CLB_G = SHORT:

Este serviço agora prioriza o balanceamento de carga para maximizar o rendimento (throughput).
É indicado para workloads que requerem alta concorrência e melhor utilização de recursos entre nós.





As diferenças entre os parâmetros DBMS_SERVICE.SERVICE_TIME e DBMS_SERVICE.THROUGHPUT estão relacionadas aos objetivos de balanceamento de carga para serviços no Oracle RAC. A escolha entre eles depende do tipo de workload e do comportamento esperado para o serviço.

Diferenças
Parâmetro	SERVICE_TIME	THROUGHPUT
Objetivo	Minimizar o tempo de resposta	Maximizar o rendimento (throughput)
Comportamento	Conexões são redirecionadas dinamicamente para nós com menor tempo de resposta.	Conexões são distribuídas para balancear a carga de trabalho, priorizando maior uso de recursos.
Cenário Ideal	Workloads OLTP (transações pequenas e rápidas).	Workloads de processamento em batch ou transações longas e pesadas.
Métrica Utilizada	Baseado em latência: menor tempo de resposta para uma consulta.	Baseado em uso de recursos: maior utilização global dos recursos.
Conexão Balancing Goal (CLB_GOAL)	Geralmente usado com SHORT.	Geralmente usado com LONG.



EXECUTE DBMS_SERVICE.MODIFY_SERVICE (service_name => 'consinco_gua1ex', goal =>  DBMS_SERVICE.GOAL_THROUGHPUT, clb_goal => DBMS_SERVICE.CLB_GOAL_SHORT);


EXECUTE DBMS_SERVICE.MODIFY_SERVICE (service_name => 'consinco_gua1ex', goal => DBMS_SERVICE.GOAL_SERVICE_TIME, clb_goal => DBMS_SERVICE.CLB_GOAL_SHORT);


EXECUTE DBMS_SERVICE.MODIFY_SERVICE (service_name => 'c5db_gua1x9', goal => DBMS_SERVICE.GOAL_SERVICE_TIME, clb_goal => DBMS_SERVICE.CLB_GOAL_SHORT);


c5db_gua1x9
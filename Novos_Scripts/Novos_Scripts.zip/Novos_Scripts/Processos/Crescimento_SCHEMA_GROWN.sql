SELECT *
FROM (
    SELECT obj.owner,
           obj.object_name,
           TO_CHAR(sn.BEGIN_INTERVAL_TIME,'RRRR-MON-DD') start_day,
           SUM(a.SPACE_USED_DELTA) / (1024 * 1024) as block_increase_mb
    FROM dba_hist_seg_stat a
    JOIN dba_hist_snapshot sn ON sn.snap_id = a.snap_id
    JOIN dba_objects obj ON obj.object_id = a.obj#
    WHERE obj.owner NOT IN ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
    -- AND obj.object_name NOT IN ('TEF_DADOS', 'TEF_DADOS_AUX', 'TEF_INTEGRACAO')
    AND end_interval_time BETWEEN TO_TIMESTAMP('24-JUL-2023','DD-MON-RRRR')
                              AND TO_TIMESTAMP('31-JUL-2023','DD-MON-RRRR')
    GROUP BY obj.owner, obj.object_name, TO_CHAR(sn.BEGIN_INTERVAL_TIME,'RRRR-MON-DD')
    ORDER BY SUM(a.SPACE_USED_DELTA) DESC, obj.owner, obj.object_name
)
WHERE ROWNUM <= 10;

### CONFIGURANDO UM PDB DO ZERO ####


INSTALAR ORACLE_HOME 



### VERSAO 11

/u01/app/oracle/stage/database/runInstaller -ignorePrereq -waitforcompletion -silent \
-responseFile /u01/app/oracle/stage/database/response/db_install.rsp \
oracle.install.option=INSTALL_DB_SWONLY \
ORACLE_HOSTNAME=srvdbcs06 \
UNIX_GROUP_NAME=oinstall \
INVENTORY_LOCATION=/u01/app/oracle/oraInventory \
SELECTED_LANGUAGES=en,en_GB \
ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_1 \
ORACLE_BASE=/u01/app/oracle \
oracle.install.db.InstallEdition=EE \
oracle.install.db.DBA_GROUP=dba \
oracle.install.db.OPER_GROUP=dba \
oracle.install.db.BACKUPDBA_GROUP=dba \
oracle.install.db.DGDBA_GROUP=dba \
oracle.install.db.KMDBA_GROUP=dba \
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false \
DECLINE_SECURITY_UPDATES=true



########### ENTERPRISE 19
$ORACLE_HOME/runInstaller -ignorePrereq -waitforcompletion -silent \
-responseFile ${ORACLE_HOME}/install/response/db_install.rsp \
oracle.install.option=INSTALL_DB_SWONLY \
ORACLE_HOSTNAME=${ORACLE_HOSTNAME} \
UNIX_GROUP_NAME=oinstall \
INVENTORY_LOCATION=${ORA_INVENTORY} \
SELECTED_LANGUAGES=en,en_GB \
ORACLE_HOME=${ORACLE_HOME} \
ORACLE_BASE=${ORACLE_BASE} \
oracle.install.db.InstallEdition=EE \
oracle.install.db.OSDBA_GROUP=dba \
oracle.install.db.OSBACKUPDBA_GROUP=dba \
oracle.install.db.OSDGDBA_GROUP=dba \
oracle.install.db.OSKMDBA_GROUP=dba \
oracle.install.db.OSRACDBA_GROUP=dba \
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false \
DECLINE_SECURITY_UPDATES=true


####INSTALAR BANCO - PARAMETRO createAsContainerDatabase é o diferencial

$ORACLE_HOME/bin/dbca -silent -createDatabase \
-templateName General_Purpose.dbc \
-gdbname cdbrex -sid cdbrex -responseFile NO_VALUE \
-characterSet AL32UTF8 \
-sysPassword   \
-systemPassword ${SYS_PASSWORD} \
-createAsContainerDatabase true \
-numberOfPDBs 0 \
-databaseType MULTIPURPOSE \
-automaticMemoryManagement false \
-totalMemory 51200 \
-storageType FS \
-datafileDestination "/oradata/cdbrex" \
-redoLogFileSize 500 \
-emConfiguration NONE \
-ignorePreReqs


########### configurar listener

netca -silent -responsefile $ORACLE_HOME/assistants/netca/netca.rsp

LISTENER=
  (DESCRIPTION=
    (ADDRESS_LIST=
      (ADDRESS=(PROTOCOL=tcp)(HOST=sales-server)(PORT=1521))
      (ADDRESS=(PROTOCOL=ipc)(KEY=extproc) (queuesize=50))))
SID_LIST_LISTENER=
  (SID_LIST=
    (SID_DESC=
      (SID_NAME=plsextproc) ---editar com SID
      (ORACLE_HOME=/oracle11g) -- EDITAR COM ORACLE HOME
      (PROGRAM=extproc)))
	  
	  

### PARAMETRIZER REDO

SQL>alter database add logfile group 1 ('/u01/oradata/ORCL/redo01a.log','/u01/oradata/WINT/redo01b.log') size 300M;
SQL>alter database add logfile group 2 ('/u01/oradata/ORCL/redo02a.log','/u01/oradata/WINT/redo01b.log') size 300M;
SQL>alter database add logfile group 3 ('/u01/oradata/ORCL/redo03a.log','/u01/oradata/WINT/redo01b.log') size 300M;


#### DEFINIR OMF 

SQL > ALTER SYSTEM SET db_create_file_dest = '/u01/oradata/ORCL';

### CRIAR PLUGGABLE DATABASE

SQL > CREATE PLUGGABLE DATABASE TESTE01 ADMIN USER pdb_adm IDENTIFIED BY TESTE123;

### ALTERAR ESTADO PARA OPEN

ALTER PLUGGABLE DATABASE teste01 OPEN READ WRITE;

### COLOCAR PRA INICIAR AUTOMATICO

SQL> alter pluggable database TESTE01 save state;


#### criar listener para base 

SQL>ALTER SESSION SET CONTAINER=TESTE01;
SQL>alter system set listener_networks='(( NAME=teste01)(LOCAL_LISTENER=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=prd01)(PORT =1521)))))' scope=both;
alter system register;






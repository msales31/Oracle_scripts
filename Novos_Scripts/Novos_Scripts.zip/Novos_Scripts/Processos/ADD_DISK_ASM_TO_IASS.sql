-- pegar o parametro de nome e o tamanho do block volume


srvoravcp01-ASM06 Block volume	-	iscsi	Read/write	4 TB	10	No	Mon, Dec 12, 2022, 13:12:36 UTC

-- verificar quantos volumes tinham antes
 
[/root] ls /dev/sd
sda   sda1  sda2  sda3  sdb   sdc   sdc1  sdd   sde   sdf   sdg



-- rodar comandos iscsi

sudo iscsiadm -m node -o new -T iqn.2015-12.com.oracleiaas:57d5e7b5-4285-45a0-a7ba-03dc3207b80e -p 169.254.2.8:3260
sudo iscsiadm -m node -o update -T iqn.2015-12.com.oracleiaas:57d5e7b5-4285-45a0-a7ba-03dc3207b80e -n node.startup -v automatic
sudo iscsiadm -m node -T iqn.2015-12.com.oracleiaas:57d5e7b5-4285-45a0-a7ba-03dc3207b80e -p 169.254.2.8:3260 -l


--verificar depois 

[/root] ls /dev/sd
sda   sda1  sda2  sda3  sdb   sdc   sdc1  sdd   sde   sdf   sdg   sdh


--pegar info do novo disco 

udevadm info --query=all --name=/dev/sdh | grep -i ID_PATH
E: ID_PATH=ip-169.254.2.8:3260-iscsi-iqn.2015-12.com.oracleiaas:57d5e7b5-4285-45a0-a7ba-03dc3207b80e-lun-1
E: ID_PATH_TAG=ip-169_254_2_8_3260-iscsi-iqn_2015-12_com_oracleiaas_57d5e7b5-4285-45a0-a7ba-03dc3207b80e-lun-1


/etc/udev/rules.d/96-asm.rules

[/root] cat /etc/udev/rules.d/96-asm.rules
KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.3:3260-iscsi-iqn.2015-12.com.oracleiaas:bc89abb0-9e19-429f-8dfa-72102db97458-lun-1", SYMLINK+="DATADISK01",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"
KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.4:3260-iscsi-iqn.2015-12.com.oracleiaas:0e7b1f47-563f-4f8f-bb0e-b79e52030cb0-lun-1", SYMLINK+="DATADISK02",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"
KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.5:3260-iscsi-iqn.2015-12.com.oracleiaas:1547b95f-12ff-4db9-8632-00558e0ac254-lun-1", SYMLINK+="DATADISK03",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"
KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.6:3260-iscsi-iqn.2015-12.com.oracleiaas:3d0651fe-e9dd-41d1-9902-ec3306d2342e-lun-1", SYMLINK+="DATADISK04",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"
KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.7:3260-iscsi-iqn.2015-12.com.oracleiaas:3c3d940e-0e97-4c24-b631-723fba7b8c1e-lun-1", SYMLINK+="DATADISK05",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"
KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.7:3260-iscsi-iqn.2015-12.com.oracleiaas:3c3d940e-0e97-4c24-b631-723fba7b8c1e-lun-1", SYMLINK+="DATADISK05",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"


-- ADICIONAR NOVA LINHA

KERNEL=="sd*", ENV{DEVTYPE}=="disk", ENV{ID_PATH}=="ip-169.254.2.8:3260-iscsi-iqn.2015-12.com.oracleiaas:57d5e7b5-4285-45a0-a7ba-03dc3207b80e-lun-1", SYMLINK+="DATADISK06",  OWNER="grid",  GROUP="asmadmin",  MODE="0660"


 
-- recompilar regras 

udevadm control --reload-rules && /sbin/udevadm trigger
udevadm control --reload-rules
udevadm trigger --type=devices --action=change

 

 NAME                          |HEADER_STATU|STATE   |PATH                                                                                                                                                                                                                                                            |  TOTAL_MB|MOUNT_S
                              |CANDIDATE   |NORMAL  |/dev/DATADISK06                                                                                                                                                                                                                                                 |         0|CLOSED
DATA_0001                     |MEMBER      |NORMAL  |/dev/DATADISK03                                                                                                                                                                                                                                                 |   4194304|CACHED
DATA_0003                     |MEMBER      |NORMAL  |/dev/DATADISK04                                                                                                                                                                                                                                                 |   4194304|CACHED
DATA_0002                     |MEMBER      |NORMAL  |/dev/DATADISK01                                                                                                                                                                                                                                                 |   4194304|CACHED
DATA_0000                     |MEMBER      |NORMAL  |/dev/DATADISK02                                                                                                                                                                                                                                                 |   4194304|CACHED
DATA_0004                     |MEMBER      |NORMAL  |/dev/DATADISK05                                                                                                                                                                                                                                                 |   4194304|CACHED



sqlplus / as sysasm

 

alter diskgroup DATA add disk '/dev/DATADISK06' NAME DATA_0006 rebalance power 100;
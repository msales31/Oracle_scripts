BANCO:
Processo mapeado para Migração:

Acesso normal pelo srvbridge:
ssh 177.220.166.214 -p3400

----------------------------------------------------
Na Origem:

 - Para fila de Jobs.
alter system set job_queue_processes=0;
 
 - Lock todos os usuários:

alter user ADMIN account lock;
alter user ARCTURUS account lock;
alter user GESTAO account lock;
alter user INIFLEXARC account lock;
alter user INTEGRACAO account lock;
alter user ORACLE account lock;


 - Encerra todas as sessões no banco.
column KILLCOMAND format a50;
select 'alter system kill session ''' || sid || ',' || serial#  || ''' immediate;' as KILLCOMAND
from v$session where username is not null and osuser <> 'oracle' 
AND TYPE != 'BACKGROUND'
AND program NOT LIKE 'racgimon%'
AND event NOT LIKE '%jobq slave wait%';


 - Gera backup FULL

expdp \"/ as sysdba\" full=y directory=DIRMIGRA dumpfile=iniflex%U.dmp filesize=8000M logfile=iniflex.log flashback_time=systimestamp exclude=STATISTICS

- Transfere backup para novo servidor na OCI

cd /backup/iniflex/migra
rsync -Cravpz --progress *.log 152.67.61.17:/backup/iniflex-srvora01/
rsync -Cravpz --progress *.dmp 152.67.61.17:/backup/iniflex-srvora01/

----------------------------------------------------
 - No destino (novo ambiente:

Acesso normal pelo srvbridge:
ssh catuai-srvoradb01

 - Limpa pdb INIFLEX

spool /tmp/drop.sql
SELECT ' drop ' || object_type || ' ' || owner || '."' || object_name || '"' || DECODE(object_type,'TABLE',' cascade constraints;',';')
FROM dba_objects
WHERE owner in ('ADMIN','ARCTURUS','GESTAO','INIFLEXARC','INTEGRACAO','ORACLE')
AND object_type NOT IN ('INDEX','TRIGGER','PACKAGE BODY');
spool off;

# Importante setar essas variáveis no usuário oracle para fazer a importação:
export NLS_TIMESTAMP_FORMAT=DD-MON-RR
export NLS_DATE_FORMAT=DD-MON-RR

cd /backup/iniflex-srvora01;
impdp parfile=parfile.txt
backupdump/suporte@10.1.0.178:1521/INIFLEX

*** Fica de olho na geração de archives, +RECO vai apagando se precisar:
DELETE NOPROMPT ARCHIVELOG ALL;

Se precisar fazer rebuild nesse index:
alter index "ADMIN"."PK_TMPTRANSMISSAOLOG" rebuild;
ALTER TABLE "ADMIN"."TMPTRANSMISSAOLOG" ADD CONSTRAINT "PK_TMPTRANSMISSAOLOG" PRIMARY KEY ("EMPRESA", "USUARIO", "SEQUENCIA") USING INDEX "ADMIN"."PK_TMPTRANSMISSAOLOG"  ENABLE;

--> Compilart Objetos inválidos.
--> Coletar estatísticas:
/u01/app/oracle/admin/cdbprd/scripts/analyze_parallel ALL &

----


Se precisar, nesse caminho tem o reverso da base Origem:
/backup/iniflex-srvora01/reverso/




#### BASE 2 

create pluggable database BKPFLEX admin user pdbadmin identified by "Cloud-Cat-2390#" keystore identified by "Cloud-Cat-2390#"  including shared key;;
alter pluggable database BKPFLEX open instances=all;
alter pluggable database BKPFLEX save state instances=all;
alter session set container=BKPFLEX;
alter system register;
ADMINISTER KEY MANAGEMENT SET KEY USING TAG 'rotate_key' FORCE KEYSTORE IDENTIFIED BY "Cloud-Cat-2390#" WITH BACKUP USING 'backup_key';
eof

source ~/$CDB_SERVICE.env
sqlplus sys/$SENHA_DB@$CDB_HOSTNAME:1521/BACKUP as sysdba<<eof
ADMINISTER KEY MANAGEMENT SET KEY USING TAG 'rotate_key' FORCE KEYSTORE IDENTIFIED BY "Cloud-Cat-2390#" WITH BACKUP USING 'backup_key';
create tablespace VS_DADOS;
create tablespace VS_INDICES;
create tablespace VS_USER;



BANCO:
Processo mapeado para Migração:

Acesso normal pelo srvbridge:
ssh 177.220.166.214 -p3400

----------------------------------------------------
Na Origem:

 - Para fila de Jobs.
alter system set job_queue_processes=0;
 
 - Lock todos os usuários:

alter user ADMIN account UNLOCK;
alter user ARCTURUS account UNLOCK;
alter user GESTAO account UNLOCK;
alter user INIFLEXARC account UNLOCK;
alter user INTEGRACAO account UNLOCK;
alter user ORACLE account UNLOCK;


alter user ORACLE         account lock;
alter user ADMIN          account lock;
alter user GESTAO         account lock;
alter user INTEGRACAO     account lock;


ORACLE
ADMIN
GESTAO
INTEGRACAO
XS$NULL


DADOS                         |         4|         4|         0|  100%|YES||####################|
SYSAUX                        |         0|         0|         0|  100%|YES||####################|
SYSTEM                        |         1|         1|         0|  100%|YES||####################|
TEMP                          |         2|         2|         0|  100%|YES||####################|
UNDOTBS1                      |         0|         0|         0|  100%|YES||####################|
USERS                         |         2|         2|         0|  100%|YES||####################|


Create tablespace DADOS logging datafile size 100m autoextend on next 50m maxsize unlimited;


 - Encerra todas as sessões no banco.
column KILLCOMAND format a50;
select 'alter system kill session ''' || sid || ',' || serial#  || ''' immediate;' as KILLCOMAND
from v$session where username is not null and osuser <> 'oracle' 
AND TYPE != 'BACKGROUND'
AND program NOT LIKE 'racgimon%'
AND event NOT LIKE '%jobq slave wait%';


 - Gera backup FULL

expdp \"/ as sysdba\" full=y directory=DIRMIGRA dumpfile=iniflex%U.dmp filesize=8000M logfile=iniflex.log flashback_time=systimestamp exclude=STATISTICS



ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_06" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_19" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_29" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
. . exportou "ORACLE"."SYS_EXPORT_SCHEMA_30"             57.49 MB   25116 linhas
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_05" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_22" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_28" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_11" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_27" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo
. . exportou "ORACLE"."SYS_EXPORT_SCHEMA_04"             38.12 MB   11729 linhas
ORA-31693: Objeto de dados de tabela "ORACLE"."SYS_EXPORT_SCHEMA_24" falhou ao ser carregado/descarregado e est▒ sendo ignorado em decorr▒ncia de um erro:
ORA-02354: erro ao exportar/importar dados
ORA-01555: instant▒neo muito antigo: n▒mero de segmento de rollback  com nome  "" muito pequeno
ORA-22924: snapshot muito antigo



expdp \"/ as sysdba\"  directory=DIRMIGRA dumpfile=iniflex_final.dmp  logfile=iniflex.log flashback_time=systimestamp exclude=STATISTICS tables=oracle.SYS_EXPORT_SCHEMA_06,oracle.SYS_EXPORT_SCHEMA_19,oracle.SYS_EXPORT_SCHEMA_29,oracle.SYS_EXPORT_SCHEMA_05,oracle.SYS_EXPORT_SCHEMA_22,oracle.SYS_EXPORT_SCHEMA_28,oracle.SYS_EXPORT_SCHEMA_27,oracle.SYS_EXPORT_SCHEMA_24,oracle.SYS_EXPORT_SCHEMA_11

PARENT_PROCESS_ORDER

alter table oracle.SYS_EXPORT_SCHEMA_06 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_06 modify lob(XML_CLOB) (retention);

alter table oracle.SYS_EXPORT_SCHEMA_19 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_19 modify lob(XML_CLOB) (retention);

alter table oracle.SYS_EXPORT_SCHEMA_29 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_29 modify lob(XML_CLOB) (retention);

alter table oracle.SYS_EXPORT_SCHEMA_05 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_05 modify lob(XML_CLOB) (retention);

alter table oracle.SYS_EXPORT_SCHEMA_22 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_22 modify lob(XML_CLOB) (retention);

alter table oracle.SYS_EXPORT_SCHEMA_28 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_28 modify lob(XML_CLOB) (retention);

alter table oracle.SYS_EXPORT_SCHEMA_27 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_27 modify lob(XML_CLOB) (retention); 
 
 
alter table oracle.SYS_EXPORT_SCHEMA_24 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_24 modify lob(XML_CLOB) (retention); 
 
 

alter table oracle.SYS_EXPORT_SCHEMA_11 modify lob(XML_CLOB) (pctversion 5);
 alter table oracle.SYS_EXPORT_SCHEMA_11 modify lob(XML_CLOB) (retention); 
 
 
ORACLE,ADMIN,GESTAO,INTEGRACAO

schemas=ORACLE,ADMIN,GESTAO,INTEGRACAO
directory=export_dir
dumpfile=iniflex%U.dmp
transform=OID:n,PCTSPACE:1
logfile=impdp.log
logtime=all
metrics=yes
transform=disable_archive_logging:y

 
impdp  BACKUPDUMP/b1a1c0k1u1p9d8b3dump@BKPFLEX parfile=parfile.txt

CREATE USER "ORACLE" IDENTIFIED EXTERNALLY
      DEFAULT TABLESPACE "USERS"
      TEMPORARY TABLESPACE "TEMP";


ADMIN
GESTAO
INTEGRACAO

[23/08/23 12:12] Fabiano Souza
sqlplus BACKUPDUMP/b1a1c0k1u1p9d8b3dump@BKPFLEX
create user BACKUPDUMP identified by "b1a1c0k1u1p9d8b3dump";
grant dba to BACKUPDUMP;


select 'ALTER TABLE '||dba_objects.owner||'.'||table_name||' MODIFY LOB ('||column_name||') (PCTVERSION 20);', 'ALTER TABLE '||dba_objects.owner||'.'||table_name||' MODIFY LOB ('||column_name||') (RETENTION);', object_name, object_type, table_name, column_name, decode(bitand(flags,32),32,'RETENTION','PCTVERSION'), dba_lobs.pctversion, dba_lobs.retention
from sys.lob$, dba_objects, dba_lobs
where lobj#=object_id and object_type='LOB' and object_name=segment_name and
table_name='SYS_EXPORT_SCHEMA_06'
and dba_objects.owner='ORACLE';

SYS_LOB0000381646C00045$$     |LOB                |SYS_EXPORT_SCHEMA_06
XML_CLOB
RETENTION |          |     16500



declare
error_1578 exception;
error_1555 exception;
error_22922 exception;
pragma exception_init(error_1578,-1578);
pragma exception_init(error_1555,-1555);
pragma exception_init(error_22922,-22922);
num number;
begin
for cursor_lob in (select rowid r, &&lob_column from &table_owner..&table_with_lob) loop
begin
num := dbms_lob.instr (cursor_lob.&&lob_column, hextoraw ('889911')) ;
exception
when error_1578 then
insert into corrupt_lobs values (cursor_lob.r, 1578);
commit;
when error_1555 then
insert into corrupt_lobs values (cursor_lob.r, 1555);
commit;
when error_22922 then
insert into corrupt_lobs values (cursor_lob.r, 22922);
commit;
end;
end loop;
end;
/
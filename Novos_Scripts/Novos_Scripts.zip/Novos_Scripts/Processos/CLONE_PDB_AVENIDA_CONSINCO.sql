### standby 

alter pluggable database CONSINCO OPEN;

### CRIAR USUARIO EM AMBIENTE PRODUTIVO NO CDB

create user "C##EXPORTA" identified by exporta123;
grant connect, resource, create pluggable database to  "C##EXPORTA";

obs: passar o grant dentro do meu pdb
#alter session set container=CONSINCO;
#grant connect, resource, create pluggable database to  "C##EXPORTA";


### cancelar sincronismo no standby
ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;



### CRIAR DBLINK
create database link LINK_STANDBY connect to "C##EXPORTA" identified by  exporta123 USING 'ORACLE_STANDBY';


## DROPAR MINHA BASE DE TESTE
drop pluggable database consinco including datafiles;



### clone da base
create pluggable database C5PP from C5PRD@LINK_STANDBY keystore identified by "Cloud-Avenida-2390" including shared key parallel 4;


## colocar base em open
11:07:49 SYS@cdbavnh> alter pluggable database CONSINCO OPEN;


## voltar standby
alter database recover managed standby database disconnect using current logfile;









create pluggable database C5PP from C5PRD@LINK_STANDBY keystore identified by "Cloud-Avenida-2390" including shared key parallel 5;




column owner format a16
column object_name format a36
column start_day format a11
column block_increase_bytes 9999999999
select   obj.owner, obj.object_name,
         to_char(sn.BEGIN_INTERVAL_TIME,'RRRR-MON-DD') start_day,
         sum(a.SPACE_USED_DELTA) block_increase_bytes
from     dba_hist_seg_stat a,
         dba_hist_snapshot sn,
         dba_objects obj
where    sn.snap_id = a.snap_id
and      obj.object_id = a.obj#
and      obj.owner not in ('SYS','SYSTEM')
and      end_interval_time between to_timestamp('11-APR-2023','DD-MON-RRRR')
         and to_timestamp('12-APR-2023','DD-MON-RRRR')
group by obj.owner, obj.object_name,
         to_char(sn.BEGIN_INTERVAL_TIME,'RRRR-MON-DD')
order by block_increase_bytes
/

175431 - BACKUP MENSAL RMPROD


Owner                |      Tb|      Id|      Pk|      Pb|      Sq|      Tr|      Pr|      Fc|      Vw|      Tp|      SY|      LB|   JB|   MVW|   Dk|TABPART|INDPART| Other|   Total
EXPORTA              |       2|      12|       0|       0|       0|       0|       0|       0|       0|       0|       0|       4|    0|     0|    0|      0|      0|     0|      18
RM                   |    8056|   13242|       1|       1|     592|     595|      47|      41|     223|      17|       0|     939|    0|     4|    3|      0|      0|     0|   23761
RM_VIEW              |       0|       0|       0|       0|       0|       0|       0|       0|       0|       0|    8180|       0|    0|     0|    0|      0|      0|     0|    8180
TOTVSAUDIT           |       2|       6|       0|       0|       2|       0|       0|       0|       0|       0|       0|       2|    0|     0|    0|      0|      0|     0|      12
All Owners           |    8060|   13260|       1|       1|     594|     595|      47|      41|     223|      17|    8180|     945|    0|     4|    3|      0|      0|     0|   31971


CREATE or replace DIRECTORY DATA_PUMP_DIR2 AS '/backup/oracle/cdbrmp/175431';
GRANT READ,WRITE ON DIRECTORY DATA_PUMP_DIR2 TO BACKUPDUMP;

expdp BACKUPDUMP/b1a1c0k1u1p9d8b3dump@RMPROD schemas=RM,EXPORTA,RM_VIEW,TOTVSAUDIT directory=DATA_PUMP_DIR2 dumpfile=dprmprod%U.dmp filesize=4000M logfile=dprmprod.log flashback_time=systimestamp exclude=STATISTICS


alter user RM account lock;
alter user RM_VIEW account lock;
alter user EXPORTA account lock;
alter user TOTVSAUDIT account lock;
alter user SYSDBA account lock;

SELECT ' drop ' || object_type || ' ' || owner || '."' || object_name || '"' || DECODE(object_type,'TABLE',' cascade constraints;',';')
FROM dba_objects
WHERE owner in ('RM','EXPORTA','TOTVSAUDIT','RM_VIEW')
AND object_type NOT IN ('INDEX','TRIGGER','PACKAGE BODY');


Owner                |      Tb|      Id|      Pk|      Pb|      Sq|      Tr|      Pr|      Fc|      Vw|      Tp|      SY|      LB|   JB|   MVW|   Dk|TABPART|INDPART| Other|   Total
EXPORTA              |       2|      12|       0|       0|       0|       0|       0|       0|       0|       0|       0|       4|    0|     0|    0|      0|      0|     0|      18
NAGIOS               |       0|       0|       0|       0|       0|       0|       0|       0|       0|       0|       2|       0|    0|     0|    0|      0|      0|     0|       2
PRIME                |       1|       0|       0|       0|       0|       0|       1|       0|       0|       0|       0|       0|    1|     0|    0|      0|      0|     0|       3
RM                   |    8056|   13242|       1|       1|     592|     595|      47|      41|     223|      17|       0|     939|    0|     4|    4|      0|      0|     0|   23762
RM_VIEW              |       0|       0|       0|       0|       0|       0|       0|       0|       0|       0|    8180|       0|    0|     0|    0|      0|      0|     0|    8180
TOTVSAUDIT           |       2|       6|       0|       0|       2|       0|       0|       0|       0|       0|       0|       2|    0|     0|    0|      0|      0|     0|      12
ZABBIX               |       2|       2|       0|       0|       0|       0|       1|       0|       0|       0|       0|       0|    0|     0|    0|      0|      0|     0|       5
All Owners           |    8063|   13262|       1|       1|     594|     595|      49|      41|     223|      17|    8182|     945|    1|     4|    4|      0|      0|     0|   31982



CREATE or replace DIRECTORY DATA_PUMP_DIR2 AS '/backup/oracle/cdbrmp/175431';
GRANT READ,WRITE ON DIRECTORY DATA_PUMP_DIR2 TO BACKUPDUMP;



impdp BACKUPDUMP/b1a1c0k1u1p9d8b3dump@RM2 schemas=EXPORTA,RM_VIEW,TOTVSAUDIT,RM directory=DATA_PUMP_DIR2 dumpfile=dprmprod%U.dmp logfile=impdp.log


cat impdp.log |grep ORA- |grep -v 'ORA-39083' |grep -v 'ORA-01917' |grep -v 'ORA-31684' |grep -v 'ORA-39082' |grep -v 'ORA-00001'

ALTER TABLE "RM"."GJOBXEXECUCAO" ADD CONSTRAINT "FKGJOBXEXECUCAO_GJOBX" FOREIGN KEY ("IDJOB") REFERENCES "RM"."GJOBX" ("IDJOB") ENABLE;


cat impdp.log |grep ORA- |grep -v 'ORA-39083' |grep -v 'ORA-01917' |grep -v 'ORA-31684' |grep -v 'ORA-39082' |grep -v 'ORA-00001'

alter user RM account unlock;
alter user EXPORTA account unlock;
alter user TOTVSAUDIT account unlock;
alter user RM_VIEW account unlock;
alter user SYSDBA account unlock;

EXEC DBMS_STATS.GATHER_SCHEMA_STATS('EXPORTA',CASCADE=>TRUE);
EXEC DBMS_STATS.GATHER_SCHEMA_STATS('TOTVSAUDIT',CASCADE=>TRUE);
EXEC DBMS_STATS.GATHER_SCHEMA_STATS('RM_VIEW',CASCADE=>TRUE);
EXEC DBMS_STATS.GATHER_SCHEMA_STATS('RM',CASCADE=>TRUE);
exit;

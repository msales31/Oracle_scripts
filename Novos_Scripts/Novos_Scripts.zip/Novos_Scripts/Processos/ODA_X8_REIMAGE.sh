#### Atividade 01
#### Atualização Software ODA 19.26
#### Coleta de informações para de/para
-------------------------------------------------------------------------------------------

--Instalacao ODA pos reimage (Verificar sempre a doc atualizada no site da Oracle de acordo com a versao)
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.13/cmtxn/provisioning-oda-baremetal.html#GUID-D48E4009-A9BB-45DE-B79A-236BE31B099E
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.26/cmtxn/provisioning-oda-baremetal.html#GUID-99DE0478-DC28-49F7-88A6-34FD049D3185



--conecta na ILOM pelo sistema operacional
ipmitool sunoem cli



Na ilom selecionar

remote control > host storage device

colocar remote e o status tem que ficar como operational

exemplo de uri


depois host management e host control, colocar para boot de cd rom



colocar para power cycle no power control



-> show /SP/network


  Properties:
        commitpending = (Cannot show property)
        dhcp_clientid = none
        dhcp_server_ip = none
        ipaddress = 10.10.10.75
        ipdiscovery = static
        ipgateway = 10.10.10.199
        ipnetmask = 255.255.255.0
        link_state = up
        macaddress = A8:69:8C:03:57:46
        managementport = MGMT
        outofbandmacaddress = A8:69:8C:03:57:46
        pendingipaddress = 10.10.10.75
        pendingipdiscovery = static
        pendingipgateway = 10.10.10.199
        pendingipnetmask = 255.255.255.0
        pendingmanagementport = MGMT
        pendingvlan_id = (none)
        sidebandmacaddress = A8:69:8C:03:57:47
        state = enabled
        vlan_id = (none)



## valida os exports
exportfs

RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/orcl/log] exportfs
/backup/temp/iso
                192.168.1.251/24





RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] odacli describe-system

Appliance Information
----------------------------------------------------------------
                     ID: 2da689fb-1a98-4831-8db1-4c88c9296218
               Platform: X8-2S
        Data Disk Count: 2
         CPU Core Count: 16
                Created: July 21, 2021 3:19:08 PM BRT

System Information
----------------------------------------------------------------
                   Name: srvoda01
            Domain Name: isk.lan
              Time Zone: America/Sao_Paulo
             DB Edition: SE
            DNS Servers: 10.10.10.39
            NTP Servers: 10.10.10.8


Disk Group Information
----------------------------------------------------------------
DG Name                   Redundancy                Percentage
------------------------- ------------------------- ------------
DATA                      NORMAL                    90
RECO                      NORMAL                    10






RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] odacli describe-component
odacli describe-component
System Version
---------------
19.11.0.0.0

System node Name
---------------
srvoda01

Local System Version
---------------
19.11.0.0.0

Component                                Installed Version    Available Version
---------------------------------------- -------------------- --------------------
OAK                                       19.11.0.0.0           up-to-date

GI                                        19.11.0.0.210420      up-to-date

DB                                        19.11.0.0.210420      up-to-date

DCSAGENT                                  19.11.0.0.0           up-to-date

OS                                        7.9                   up-to-date

ILOM                                      5.0.1.21.r136383      5.0.1.21.a.r138015

BIOS                                      52030400              up-to-date

FIRMWARECONTROLLER                        VDV1RL04              up-to-date

FIRMWAREDISK                              1132                  up-to-date

HMP                                       2.4.8.0.600           up-to-date





RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] odacli list-databases

ID                                       DB Name    DB Type  DB Version           CDB        Class    Shape    Storage    Status        DbHomeID
---------------------------------------- ---------- -------- -------------------- ---------- -------- -------- ---------- ------------ ----------------------------------------
4171c363-2bd1-4598-8357-1e0d2c361b07     orcl       SI       19.11.0.0.210420     false      OLTP     odb8     ASM        CONFIGURED   bb29992a-e176-4435-8185-657ef64cc44c


RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] odacli list-dbhomes

ID                                       Name                 DB Version                               Home Location                                 Status
---------------------------------------- -------------------- ---------------------------------------- --------------------------------------------- ----------
bb29992a-e176-4435-8185-657ef64cc44c     OraDB19000_home1     19.11.0.0.210420                         /u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1 CONFIGURED


RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] odacli list-cpucores


Node  Cores  Modified                           Job Status
----- ------ ---------------------------------- ---------------
0     16     February 9, 2022 3:26:10 PM BRT    CONFIGURED


RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] df -h
Filesystem                          Size  Used Avail Use% Mounted on
devtmpfs                             94G   24K   94G   1% /dev
tmpfs                                94G  845M   93G   1% /dev/shm
tmpfs                                94G   90M   94G   1% /run
tmpfs                                94G     0   94G   0% /sys/fs/cgroup
/dev/mapper/VolGroupSys-LogVolRoot   30G   15G   14G  52% /
/dev/md126p2                        477M  156M  293M  35% /boot
/dev/md126p1                        500M  7.6M  493M   2% /boot/efi
/dev/mapper/VolGroupSys-LogVolU01    40G   23G   15G  61% /u01
/dev/mapper/VolGroupSys-LogVolOpt    30G   20G  8.3G  71% /opt
tmpfs                                19G     0   19G   0% /run/user/54328
/dev/asm/commonstore-372            5.0G  391M  4.7G   8% /opt/oracle/dcs/commonstore
/dev/asm/orahome_sh-372              80G   33G   48G  41% /u01/app/odaorahome
/dev/asm/odabase_n0-372              70G  7.7G   63G  11% /u01/app/odaorabase0
/dev/asm/acfsclone-372               10G  490M  9.6G   5% /opt/oracle/oak/pkgrepos/orapkgs/clones
/dev/asm/datbackup-372              2.5T  879G  1.6T  36% /backup
/dev/asm/archive-399                462G  150G  313G  33% /archive
tmpfs                                19G     0   19G   0% /run/user/54341
tmpfs                                19G     0   19G   0% /run/user/54331
tmpfs                                19G     0   19G   0% /run/user/54326

RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] mount
sysfs on /sys type sysfs (rw,nosuid,nodev,noexec,relatime)
proc on /proc type proc (rw,nosuid,nodev,noexec,relatime)
devtmpfs on /dev type devtmpfs (rw,nosuid,size=98186376k,nr_inodes=24546594,mode=755)
securityfs on /sys/kernel/security type securityfs (rw,nosuid,nodev,noexec,relatime)
tmpfs on /dev/shm type tmpfs (rw,nosuid,nodev)
devpts on /dev/pts type devpts (rw,nosuid,noexec,relatime,gid=5,mode=620,ptmxmode=000)
tmpfs on /run type tmpfs (rw,nosuid,nodev,mode=755)
tmpfs on /sys/fs/cgroup type tmpfs (ro,nosuid,nodev,noexec,mode=755)
cgroup on /sys/fs/cgroup/systemd type cgroup (rw,nosuid,nodev,noexec,relatime,xattr,release_agent=/usr/lib/systemd/systemd-cgroups-agent,name=systemd)
pstore on /sys/fs/pstore type pstore (rw,nosuid,nodev,noexec,relatime)
efivarfs on /sys/firmware/efi/efivars type efivarfs (rw,nosuid,nodev,noexec,relatime)
cgroup on /sys/fs/cgroup/blkio type cgroup (rw,nosuid,nodev,noexec,relatime,blkio)
cgroup on /sys/fs/cgroup/net_cls,net_prio type cgroup (rw,nosuid,nodev,noexec,relatime,net_cls,net_prio)
cgroup on /sys/fs/cgroup/freezer type cgroup (rw,nosuid,nodev,noexec,relatime,freezer)
cgroup on /sys/fs/cgroup/memory type cgroup (rw,nosuid,nodev,noexec,relatime,memory)
cgroup on /sys/fs/cgroup/perf_event type cgroup (rw,nosuid,nodev,noexec,relatime,perf_event)
cgroup on /sys/fs/cgroup/cpuset type cgroup (rw,nosuid,nodev,noexec,relatime,cpuset)
cgroup on /sys/fs/cgroup/cpu,cpuacct type cgroup (rw,nosuid,nodev,noexec,relatime,cpu,cpuacct)
cgroup on /sys/fs/cgroup/devices type cgroup (rw,nosuid,nodev,noexec,relatime,devices)
cgroup on /sys/fs/cgroup/hugetlb type cgroup (rw,nosuid,nodev,noexec,relatime,hugetlb)
cgroup on /sys/fs/cgroup/rdma type cgroup (rw,nosuid,nodev,noexec,relatime,rdma)
cgroup on /sys/fs/cgroup/pids type cgroup (rw,nosuid,nodev,noexec,relatime,pids)
configfs on /sys/kernel/config type configfs (rw,relatime)
/dev/mapper/VolGroupSys-LogVolRoot on / type ext4 (rw,relatime,data=ordered)
mqueue on /dev/mqueue type mqueue (rw,relatime)
systemd-1 on /proc/sys/fs/binfmt_misc type autofs (rw,relatime,fd=26,pgrp=1,timeout=0,minproto=5,maxproto=5,direct,pipe_ino=12884)
hugetlbfs on /dev/hugepages type hugetlbfs (rw,relatime,pagesize=2M)
debugfs on /sys/kernel/debug type debugfs (rw,relatime)
binfmt_misc on /proc/sys/fs/binfmt_misc type binfmt_misc (rw,relatime)
nfsd on /proc/fs/nfsd type nfsd (rw,relatime)
/dev/md126p2 on /boot type ext4 (rw,relatime,stripe=4,data=ordered)
/dev/md126p1 on /boot/efi type vfat (rw,relatime,fmask=0077,dmask=0077,codepage=437,iocharset=ascii,shortname=winnt,errors=remount-ro)
/dev/mapper/VolGroupSys-LogVolU01 on /u01 type ext4 (rw,relatime,data=ordered)
/dev/mapper/VolGroupSys-LogVolOpt on /opt type ext4 (rw,relatime,data=ordered)
sunrpc on /var/lib/nfs/rpc_pipefs type rpc_pipefs (rw,relatime)
tmpfs on /run/user/54328 type tmpfs (rw,nosuid,nodev,relatime,size=19650488k,mode=700,uid=54328,gid=700)
/dev/asm/commonstore-372 on /opt/oracle/dcs/commonstore type acfs (rw,relatime,device,rootsuid,ordered)
/dev/asm/orahome_sh-372 on /u01/app/odaorahome type acfs (rw,relatime,device,rootsuid,ordered)
/dev/asm/odabase_n0-372 on /u01/app/odaorabase0 type acfs (rw,relatime,device,rootsuid,ordered)
/dev/asm/acfsclone-372 on /opt/oracle/oak/pkgrepos/orapkgs/clones type acfs (rw,relatime,device,rootsuid,ordered)
/dev/asm/datbackup-372 on /backup type acfs (rw,relatime,device,rootsuid,ordered)
/dev/asm/archive-399 on /archive type acfs (rw,relatime,device,rootsuid,ordered)



RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] cat /etc/fstab

#
# /etc/fstab
# Created by anaconda on Tue Feb  8 22:11:26 2022
#
# Accessible filesystems, by reference, are maintained under '/dev/disk'
# See man pages fstab(5), findfs(8), mount(8) and/or blkid(8) for more info
#
/dev/mapper/VolGroupSys-LogVolRoot /                       ext4    defaults        1 1
UUID=fc96d4b5-c7d0-42a8-8032-5e718c5fb7a9 /boot                   ext4    defaults        1 2
UUID=A8DB-4BAC          /boot/efi               vfat    defaults,uid=0,gid=0,umask=0077,shortname=winnt 0 0
/dev/mapper/VolGroupSys-LogVolOpt /opt                    ext4    defaults        1 2
/dev/mapper/VolGroupSys-LogVolU01 /u01                    ext4    defaults        1 2
/dev/mapper/VolGroupSys-LogVolSwap swap                    swap    defaults        0 0






RIOGRANDENSE-Atualizar-STDY:srvodax01> (SID=+ASM1)
[/home/grid] asmcmd lsdg
State    Type    Rebal  Sector  Logical_Sector  Block       AU  Total_MB  Free_MB  Req_mir_free_MB  Usable_file_MB  Offline_disks  Voting_files  Name
MOUNTED  NORMAL  N         512             512   4096  4194304  10988544  1174648                0          587324              0             Y  DATA/
MOUNTED  NORMAL  N         512             512   4096  4194304   1220608   240448                0          120224              0             N  RECO/


RIOGRANDENSE-Atualizar-STDY:srvodax01> (SID=+ASM1)
[/home/grid] asmcmd volinfo --all
Diskgroup Name: DATA

         Volume Name: ACFSCLONE
         Volume Device: /dev/asm/acfsclone-372
         State: ENABLED
         Size (MB): 10240
         Resize Unit (MB): 64
         Redundancy: MIRROR
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage: ACFS
         Mountpath: /opt/oracle/oak/pkgrepos/orapkgs/clones

         Volume Name: COMMONSTORE
         Volume Device: /dev/asm/commonstore-372
         State: ENABLED
         Size (MB): 5120
         Resize Unit (MB): 64
         Redundancy: MIRROR
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage: ACFS
         Mountpath: /opt/oracle/dcs/commonstore

         Volume Name: DATBACKUP
         Volume Device: /dev/asm/datbackup-372
         State: ENABLED
         Size (MB): 2543616
         Resize Unit (MB): 64
         Redundancy: MIRROR
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage: ACFS
         Mountpath: /backup

         Volume Name: ODABASE_N0
         Volume Device: /dev/asm/odabase_n0-372
         State: ENABLED
         Size (MB): 71680
         Resize Unit (MB): 64
         Redundancy: MIRROR
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage: ACFS
         Mountpath: /u01/app/odaorabase0

         Volume Name: ORAHOME_SH
         Volume Device: /dev/asm/orahome_sh-372
         State: ENABLED
         Size (MB): 81920
         Resize Unit (MB): 64
         Redundancy: MIRROR
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage: ACFS
         Mountpath: /u01/app/odaorahome

Diskgroup Name: RECO

         Volume Name: ARCHIVE
         Volume Device: /dev/asm/archive-399
         State: ENABLED
         Size (MB): 473088
         Resize Unit (MB): 64
         Redundancy: MIRROR
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage: ACFS
         Mountpath: /archive


RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root] ip addr
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 16436 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: p7p1: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond1 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
3: p7p2: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond1 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
4: p7p3: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond2 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:32 brd ff:ff:ff:ff:ff:ff
5: p7p4: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond2 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:32 brd ff:ff:ff:ff:ff:ff
6: em1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:10:e0:ef:6c:2e brd ff:ff:ff:ff:ff:ff
7: bond0: <BROADCAST,MULTICAST,MASTER> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether b2:c3:c7:ab:16:85 brd ff:ff:ff:ff:ff:ff
8: btbond1: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 1500 qdisc noqueue master pubnet state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
10: btbond2: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:32 brd ff:ff:ff:ff:ff:ff
12: priv0: <BROADCAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether de:4e:3a:fd:34:40 brd ff:ff:ff:ff:ff:ff
    inet 192.168.16.24/28 scope global priv0
       valid_lft forever preferred_lft forever
15: pubnet: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.22/24 brd 192.168.1.255 scope global pubnet
       valid_lft forever preferred_lft forever
16: priv0.100@priv0: <BROADCAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master privasm state UP group default qlen 1000
    link/ether de:4e:3a:fd:34:40 brd ff:ff:ff:ff:ff:ff
17: privasm: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether de:4e:3a:fd:34:40 brd ff:ff:ff:ff:ff:ff
    inet 192.168.17.2/25 brd 192.168.17.127 scope global privasm
       valid_lft forever preferred_lft forever




-> cd System/
/System

-> ls

 /System
    Targets:
        Open_Problems (0)
        Processors
        Memory
        Power
        Cooling
        Storage
        Networking
        PCI_Devices
        Firmware
        BIOS
        Log

    Properties:
        health = OK
        health_details = -
        open_problems_count = 0
        type = Rack Mount
        model = ORACLE SERVER X8-2L
        qpart_id = Q13629
        part_number = 7600422-9673
        serial_number = 1946XCA01F
        rfid_serial_number = 341A583DE580000000040B7D
        system_identifier = Oracle Database Appliance X8-2 Small 1946XCA01F
        system_fw_version = 5.0.2.24
        primary_operating_system = Not Available
        primary_operating_system_detail = Comprehensive System monitoring is
                                          not available. Ensure the host is
                                          running with the Hardware Management
                                          Pack. For details go to
                                          http://www.oracle.com/goto/ilom-redire
                                          ct/hmp
        host_primary_mac_address = 00:10:e0:ef:6c:2e
        ilom_address = 192.168.1.52
        ilom_mac_address = 00:10:E0:EF:6C:32
        locator_indicator = Off
        power_state = On
        actual_power_consumption = 146 watts
        action = (Cannot show property)

--Habilita o led de reconhecimento (luz branca)
set /System/ locator_indicator=on
set /System/ locator_indicator=off


cd /SP/network
ls

srvodax01-ilom

 Properties:
        commitpending = (Cannot show property)
        dhcp_clientid = none
        dhcp_server_ip = none
        ipaddress = 192.168.1.52
        ipdiscovery = static
        ipgateway = 192.168.1.252
        ipnetmask = 255.255.255.0
        link_state = up
        macaddress = 00:10:E0:EF:6C:32
        managementport = MGMT
        outofbandmacaddress = 00:10:E0:EF:6C:32
        pendingipaddress = 192.168.1.52
        pendingipdiscovery = static
        pendingipgateway = 192.168.1.252
        pendingipnetmask = 255.255.255.0
        pendingmanagementport = MGMT
        pendingvlan_id = (none)
        sidebandmacaddress = 00:10:E0:EF:6C:33
        state = enabled
        vlan_id = (none)
-------------------------------------------------------------------------------------------



RIOGRANDENSE-Atualizar-STDY:srvodax01
[/root/.ssh] cat /etc/crontab
SHELL=/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin
MAILTO=root

# For details see man 4 crontabs

# Example of job definition:
# .---------------- minute (0 - 59)
# |  .------------- hour (0 - 23)
# |  |  .---------- day of month (1 - 31)
# |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ...
# |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat
# |  |  |  |  |
# *  *  *  *  * user-name  command to be executed

# --- STANDBY - ORCL ##
##### */10 * * * * root su - oracle -c '/u01/app/oracle/admin/orcl/scripts/sync.standby >>/tmp/oracle-cron.log 2>&1'
##### */3 * * * * root su - oracle -c '/u01/app/oracle/admin/orcl/scripts/sync.archive > /dev/null 2>&1'
# ---
# --- Backup de archive de hora em hora / Backup Full no Sabado / Backup Cumulativo Quarta / Backup incremental Seg, Ter, Qui, Sex, Dom
## 164901


#10  06-21 * * *    root  su - oracle -c /u01/app/oracle/admin/orcl/scripts/archbackup
##10  22    * * 5    root  su - oracle -c /u01/app/oracle/admin/orcl/scripts/fullbackup-inc0
#10  22    * * 3    root  su - oracle -c /u01/app/oracle/admin/orcl/scripts/fullbackup-inc1c
#10  22    * * 1,2,4,6,7    root  su - oracle -c /u01/app/oracle/admin/orcl/scripts/fullbackup-inc1d

#10  11    * * 7    root  su - oracle -c '/u01/app/oracle/admin/orcl/scripts/analyze_parallel ALL orcl' > /dev/null 2>&1


32 14 * * *  root su - oracle -c "/u01/app/oracle/admin/orcl/scripts/clean_trc" >/dev/null 2>&1
#10 10 * * *  root su - oracle -c "/u01/app/oracle/admin/orcl/scripts/rsync_datapump.sh"


12 21 * * * root /opt/purgelogs/purgelogs.bin cleanup --days 7 --aud --lsnr > /root/purgelogs.out


01,11,21,31,41,51    * * * * root su - oracle -c '/u01/app/odaorabase/oracle/admin/scripts/sync.archive orcl > /dev/null 2>&1'
06,16,26,36,46,56    * * * * root su - oracle -c '/u01/app/odaorabase/oracle/admin/scripts/sync.standby orcl > /dev/null 2>&1'



#### Atividade 01
#### Atualização Software ODA 19.9
#### Baseline Performance - Pré Upgrade

-------------------------------------------------------------------------------------------


cd /SP/network
ls

srvodax01-ilom

 Properties:
        commitpending = (Cannot show property)
        dhcp_clientid = none
        dhcp_server_ip = none
        ipaddress = 192.168.1.52
        ipdiscovery = static
        ipgateway = 192.168.1.252
        ipnetmask = 255.255.255.0
        link_state = up
        macaddress = 00:10:E0:EF:6C:32
        managementport = MGMT
        outofbandmacaddress = 00:10:E0:EF:6C:32
        pendingipaddress = 192.168.1.52
        pendingipdiscovery = static
        pendingipgateway = 192.168.1.252
        pendingipnetmask = 255.255.255.0
        pendingmanagementport = MGMT
        pendingvlan_id = (none)
        sidebandmacaddress = 00:10:E0:EF:6C:33
        state = enabled
        vlan_id = (none)


----------------------------------------------------------------------------------

[root@oak ~]# ip addr
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 16436 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: p7p1: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond1 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
3: p7p2: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond1 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
4: p7p3: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond2 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:32 brd ff:ff:ff:ff:ff:ff
5: p7p4: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond2 state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:32 brd ff:ff:ff:ff:ff:ff
6: em1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:10:e0:ef:6c:2e brd ff:ff:ff:ff:ff:ff
7: bond0: <BROADCAST,MULTICAST,MASTER> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 92:0e:f3:da:ab:d4 brd ff:ff:ff:ff:ff:ff
8: btbond1: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:30 brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.22/24 brd 192.168.1.255 scope global btbond1
       valid_lft forever preferred_lft forever
9: btbond2: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3c:fd:fe:7e:ea:32 brd ff:ff:ff:ff:ff:ff
10: priv0: <BROADCAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:ae:30:a4:d7:cf brd ff:ff:ff:ff:ff:ff
    inet 192.168.16.24/28 scope global priv0
       valid_lft forever preferred_lft forever
11: virbr0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default qlen 1000
    link/ether 52:54:00:b6:1a:80 brd ff:ff:ff:ff:ff:ff
    inet 192.168.122.1/24 brd 192.168.122.255 scope global virbr0
       valid_lft forever preferred_lft forever
12: virbr0-nic: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast master virbr0 state DOWN group default qlen 1000
    link/ether 52:54:00:b6:1a:80 brd ff:ff:ff:ff:ff:ff

RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/orcl/log] ethtool p7p1
Settings for p7p1:
        Supported ports: [ TP ]
        Supported link modes:   100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Supported pause frame use: Symmetric
        Supports auto-negotiation: Yes
        Supported FEC modes: Not reported
        Advertised link modes:  100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Advertised pause frame use: No
        Advertised auto-negotiation: Yes
        Advertised FEC modes: Not reported
        Speed: 1000Mb/s
        Duplex: Full
        Port: Twisted Pair
        PHYAD: 0
        Transceiver: internal
        Auto-negotiation: on
        MDI-X: Unknown
        Supports Wake-on: d
        Wake-on: d
        Current message level: 0x00000007 (7)
                               drv probe link
        Link detected: yes

[root@oak ~]#
[root@oak ~]#
RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/orcl/log]  ethtool p7p2
Settings for p7p2:
        Supported ports: [ TP ]
        Supported link modes:   100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Supported pause frame use: Symmetric
        Supports auto-negotiation: Yes
        Supported FEC modes: Not reported
        Advertised link modes:  100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Advertised pause frame use: No
        Advertised auto-negotiation: Yes
        Advertised FEC modes: Not reported
        Speed: 1000Mb/s
        Duplex: Full
        Port: Twisted Pair
        PHYAD: 0
        Transceiver: internal
        Auto-negotiation: on
        MDI-X: Unknown
        Supports Wake-on: d
        Wake-on: d
        Current message level: 0x00000007 (7)
                               drv probe link
        Link detected: yes
[root@oak ~]#
[root@oak ~]#
RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/orcl/log] ethtool p7p3
Settings for p7p3:
        Supported ports: [ TP ]
        Supported link modes:   100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Supported pause frame use: Symmetric
        Supports auto-negotiation: Yes
        Supported FEC modes: Not reported
        Advertised link modes:  100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Advertised pause frame use: No
        Advertised auto-negotiation: Yes
        Advertised FEC modes: Not reported
        Speed: 1000Mb/s
        Duplex: Full
        Port: Twisted Pair
        PHYAD: 0
        Transceiver: internal
        Auto-negotiation: on
        MDI-X: Unknown
        Supports Wake-on: d
        Wake-on: d
        Current message level: 0x00000007 (7)
                               drv probe link
        Link detected: yes
[root@oak ~]#
[root@oak ~]#
[root@oak ~]#
RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/orcl/log] ethtool p7p4
Settings for p7p4:
        Supported ports: [ TP ]
        Supported link modes:   100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Supported pause frame use: Symmetric
        Supports auto-negotiation: Yes
        Supported FEC modes: Not reported
        Advertised link modes:  100baseT/Full
                                1000baseT/Full
                                10000baseT/Full
        Advertised pause frame use: No
        Advertised auto-negotiation: Yes
        Advertised FEC modes: Not reported
        Speed: 1000Mb/s
        Duplex: Full
        Port: Twisted Pair
        PHYAD: 0
        Transceiver: internal
        Auto-negotiation: on
        MDI-X: Unknown
        Supports Wake-on: d
        Wake-on: d
        Current message level: 0x00000007 (7)
                               drv probe link
        Link detected: yes
[root@oak ~]#



RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/scripts] systemctl status smb
* smb.service - Samba SMB Daemon
   Loaded: loaded (/usr/lib/systemd/system/smb.service; enabled; vendor preset: disabled)
   Active: inactive (dead) since Sun 2025-03-16 14:07:25 -03; 3 days ago
     Docs: man:smbd(8)
           man:samba(7)
           man:smb.conf(5)
  Process: 3225 ExecStart=/usr/sbin/smbd --foreground --no-process-group $SMBDOPTIONS (code=killed, signal=TERM)
 Main PID: 3225 (code=killed, signal=TERM)
   Status: "smbd: ready to serve connections..."

Mar 14 07:43:39 srvodax01 systemd[1]: Starting Samba SMB Daemon...
Mar 14 07:43:39 srvodax01 smbd[3225]: [2025/03/14 07:43:39.752068,  0] ../../lib/util/become_daemon.c:136(daemon_ready)
Mar 14 07:43:39 srvodax01 systemd[1]: Started Samba SMB Daemon.
Mar 14 07:43:39 srvodax01 smbd[3225]:   daemon_ready: daemon 'smbd' finished starting up and ready to serve connections
Mar 14 07:43:39 srvodax01 smbd[3225]: [2025/03/14 07:43:39.791127,  0] ../../source3/lib/util_sock.c:334(open_socket_in)
Mar 14 07:43:39 srvodax01 smbd[3225]:   open_socket_in(): socket() call failed: Address family not supported by protocol
Mar 14 07:43:39 srvodax01 smbd[3225]: [2025/03/14 07:43:39.791386,  0] ../../source3/smbd/server.c:1130(smbd_open_one_socket)
Mar 14 07:43:39 srvodax01 smbd[3225]:   smbd_open_one_socket: open_socket_in: Address family not supported by protocol
Mar 16 14:07:25 srvodax01 systemd[1]: Stopping Samba SMB Daemon...
Mar 16 14:07:25 srvodax01 systemd[1]: Stopped Samba SMB Daemon.

RIOGRANDENSE-Atualizar-STDY:srvodax01
[/u01/app/odaorabase/oracle/admin/scripts] cat /etc/samba/smb.conf

[global]
        workgroup = RIOGRANDENSE
        server string = Samba Server Version %v
        netbios name = srvodax01
        log file = /var/log/samba/%m.log
        max log size = 1000
        client min protocol = NT1
        smb ports = 445
        security = user
        map to guest = bad user
        guest ok = yes
        client ntlmv2 auth = yes
        domain master = yes
        local master = yes
        preferred master = yes
        os level = 33
        wins support = yes
        name resolve order = host bcast
        dns proxy = no
        wins proxy = no
        load printers = no
        map to guest = Bad Password

[RMAN]
        path = /backup/oracle/orcl/rman
        public = yes
        browseable=yes
        writeable = no
        guest ok = yes
        available = yes
        read only = yes
        create mask = 0775
        directory mask = 0775









###### no ODA01 

--exemplo nfs

[root@srvodax01 temp]# cat /etc/exports
/backup/temp/iso    *(rw,sync,no_root_squash,insecure)

systemctl start nfs-server


exportfs -v
exportfs -r



#### Acessar a Ilom pelo ODA01
Host riograndense-srvodax01
ssh root@192.168.1.52
Passwd: changeme

cd /SP/services/kvms/host_storage_device/remote
set server_URI=nfs://10.10.10.10:/u01/medias/oda_bm_19.26.0.0.0_250214.iso
show

--ou
set /SP/services/kvms/host_storage_device/remote server_URI=nfs://192.168.1.251:/backup/temp/iso/oda_bm_19.26.0.0.0_250214.iso

cd /SP/services/kvms/host_storage_device/remote
set /SP/services/kvms/host_storage_device/ mode=remote

set /SP/services/kvms/host_storage_device/ mode=disabled
set /SP/services/kvms/host_storage_device/ mode=remote

show /SP/services/kvms/host_storage_device/ status

set /HOST boot_device=cdrom
show
--ou
show /HOST






## srvoda01 Limpeza do ODA
--root
/opt/oracle/oak/onecmd/cleanup.pl -erasedata



## Iniciando a Instalação do ODA
--Dentro da Ilom no ODA01 conectado na Ilom do ODa02
reset /SYS
start /SP/console





## Validar a versão após a instalação da ISO do ODA
/opt/oracle/dcs/bin/odacli describe-component -v
/opt/oracle/dcs/bin/odacli describe-component
/opt/oracle/dcs/bin/odacli validate-storagetopology


## Configurar a rede 
/opt/oracle/oak/bin/configure-firstnet

INFO: Using default bonding configuration
Select the Interface to configure the network on (btbond1 btbond2) [btbond1]:
Use LACP bonding on btbond1 (yes/no) [no]: no
Configure DHCP on btbond1 (yes/no) [no]:no
INFO: You have chosen Static configuration
Use VLAN on btbond1 (yes/no) [no]:no
Enter the IP address to configure : 10.10.10.9
Enter the Netmask address to configure : 255.255.255.0
Enter the Gateway address to configure [10.10.10.1] : 10.10.10.199
INFO: Reset default gateway, remove GATEWAYDEV=
INFO: Restarting the network
INFO: Network has been setup successfully
[root@oak ~]# systemctl restart network




## Atualizar o repositorio
/opt/oracle/dcs/bin/odacli update-repository -f /u01/medias/odacli-dcs-19.26.0.0.0-250127-GI-19.26.0.0.zip,/u01/medias/odacli-dcs-19.26.0.0.0-250127-DB-19.26.0.0.zip
/opt/oracle/dcs/bin/odacli describe-job -i bfb9024e-e264-450a-a509-f3b86c274788


## configurar arquivo JSON - (APENAS UM MODELO)
/opt/oracle/dcs/sample/sample-oda-sm.json

{
  "instance" : {
    "name" : "srvodax01",
    "instanceBaseName" : "srvodax01-c",
    "dbEdition" : "SE",
    "timeZone" : "America/Sao_Paulo",
    "systemPassword" : "ODA-iskisita-2390",
    "ntpServers" : ["10.10.10.199"],
    "dnsServers" : ["10.10.10.39","8.8.8.8"],
    "domainName" : "isk.lan",
    "isRoleSeparated" : true,
    "osUserGroup" : {
      "groups" : [ {
        "groupId" : 1001,
        "groupName" : "oinstall",
        "groupRole" : "oinstall"
      }, {
        "groupId" : 1002,
        "groupName" : "dbaoper",
        "groupRole" : "dbaoper"
      }, {
        "groupId" : 1003,
        "groupName" : "dba",
        "groupRole" : "dba"
      }, {
        "groupId" : 1004,
        "groupName" : "asmadmin",
        "groupRole" : "asmadmin"
      }, {
        "groupId" : 1005,
        "groupName" : "asmoper",
        "groupRole" : "asmoper"
      }, {
        "groupId" : 1006,
        "groupName" : "asmdba",
        "groupRole" : "asmdba"
      } ],
      "users" : [ {
        "userId" : 1000,
        "userName" : "oracle",
        "userRole" : "oracleUser"
      }, {
        "userId" : 1001,
        "userName" : "grid",
        "userRole" : "gridUser"
      } ]
    }
  },
  "nodes" : [ {
    "nodeNumber" : "0",
    "nodeName" : "srvodax01",
    "network" : [ {
       "nicName" : "btbond1",
       "ipAddress" : "10.10.10.9",
       "subNetMask" : "255.255.255.0",
       "gateway" : "10.10.10.199",
       "networkType" : [ "Public" ],
       "isDefaultNetwork" : true
      }
    ],
    "ilom" : {
      "ilomName":"srvodax01-ilom",
      "ipAddress":"10.10.10.44",
      "subNetMask":"255.255.255.0",
      "gateway":"10.10.10.199"
     }
  } ],
  "grid" : {
    "diskGroup" : [ {
      "diskGroupName" : "DATA",
      "redundancy" : "NORMAL",
      "diskPercentage" :90
    }, {
      "diskGroupName" : "RECO",
      "redundancy" : "NORMAL",
      "diskPercentage" :10
    } ],
  "scan" : {
     "scanName":"srvodax01-scan",
     "ipAddresses":[
        "10.10.10.9"
     ]
    },
  "vip":[
     {
        "nodeNumber":"0",
        "vipName":"srvodax01-vip",
        "ipAddress":"10.10.10.9"
     }
    ],
    "language" : "en",
    "enableAFD":"FALSE"
  }
}





## editar o /etc/hosts
10.10.10.44 srvodax01-ilom srvodax01-ilom.isk.lan
10.10.10.9  srvodax01.isk.lan  srvodax01
192.168.16.24  srvodax01-priv.isk.lan  srvodax01-priv  dcs0-priv
10.10.10.9 srvodax01-vip.isk.lan  srvodax01-vip
10.10.10.9  srvodax01-scan.isk.lan  srvodax01-scan



## /etc/resolv.conf
search isk.lan
nameserver 10.10.10.39
nameserver 8.8.8.8


## Criar o appliance
/opt/oracle/dcs/bin/odacli create-appliance -r /opt/oracle/dcs/sample/sample-oda-sm.json
/opt/oracle/dcs/bin/odacli describe-job -i  283d78c5-9b61-40ec-93d6-f184aee4f24a





/opt/oracle/dcs/bin/odacli update-repository -f /u01/medias/odacli-dcs-19.13.0.0.0-211109-DB-19.13.0.0.zip,/u01/medias/odacli-dcs-19.13.0.0.0-211109-GI-19.13.0.0.zip
/opt/oracle/dcs/bin/odacli update-repository -f /u01/medias/oda-sm-19.13.0.0.0-211127-server.zip

/opt/oracle/dcs/bin/odacli create-prepatchreport -s -v 19.13.0.0.0
/opt/oracle/dcs/bin/odacli update-server -v 19.13.0.0.0


## Senha root ODA02 e ILOM
ODA-riogran-2390

--para atualizar a senha de root do ODA por dentro da ILOM (após conectar no servidor pela ILOM)
start /SP/console
passwd root

--atualizar a senha de root da ILOM (senha defatul é changeme)
set /SP/users/root password

https://docs.oracle.com/cd/E27124_01/html/E27125/z40038a01989313.html#:~:text=The%20server%20ships%20with%20a,unauthorized%20access%2C%20change%20the%20password.


## Executar os passos do procedimento de criar-novo-ambiente.txt
## Criar os users pelo rundeck


## Ajustar a HUge Pages para aproximadamente 70% da memória do servidor.
vi /etc/sysctl.conf

##--- original vm.nr_hugepages=50419
vm.nr_hugepages=68100

sysctl -p ;



## Criar o Database Home Storage antes do DBHOME
odacli configure-dbhome-storage -dg DATA -s 

## Criar os dbhomes
odacli create-dbhome -v 19.26.0.0.250121 -de SE

## Criar os bancos
odacli create-database -n orcl -u orcl_odax10 -dh 627f9b12-fd62-4984-b507-c3ca77c4600c  -s Odb8 -cs WE8MSWIN1252

odacli create-database -n bht -u bht_oda02 -dh fead8d07-28be-4ec6-8ffa-87c9aa28192e -s odb1 -cs AL32UTF8

--caminho do log do odacli
/opt/oracle/dcs/log

## Ajuste de parametros no banco destino. ODA02.
alter system set pga_aggregate_limit  =50G scope=spfile;
alter system set pga_aggregate_target =25G scope=spfile;
alter system set sga_max_size         =128G scope=spfile;
alter system set sga_target           =128G scope=spfile;
alter system set lock_sga = true scope = spfile;
alter system set use_large_pages=only scope = spfile;

alter system set processes=2000 scope=spfile;
alter system set sessions=3024 scope=spfile;

alter system set open_cursors=2000 scope=spfile;
alter system set session_cached_cursors=300 scope=spfile;

alter system set optimizer_index_caching=90 scope=spfile;
alter system set optimizer_index_cost_adj=10 scope=spfile;

alter system set undo_retention=19200 scope=spfile;
alter system set undo_tablespace=UNDOTBS01 scope=spfile;

alter system set db_domain='' scope=spfile;
alter system set lock_sga=true scope=spfile sid='*';

alter system set recyclebin=OFF scope=spfile;
alter system set db_domain='' scope=spfile ;
alter system set sec_case_sensitive_logon=false scope=spfile;
alter system set global_names=false scope=spfile;

select * from global_name;
alter database rename GLOBAL_NAME to "ORCL";
update global_name set global_name='ORCL';
commit;

## restart da base
{
srvctl stop database -d orcl_oda02
srvctl start database -d orcl_oda02
}



## Criar user na origem ODA01
CREATE USER caiodba IDENTIFIED BY WORKSHOPsec2019##;
grant connect, dba to caiodba;

  

## Criar dblink na base destino. ODA02

CREATE DATABASE LINK ORCL_ODA01 CONNECT TO caiodba IDENTIFIED BY "WORKSHOPsec2019##" USING 'ORCL_ODA01';

col name format a25
col value format a50
set lines 150
set pages 500
select onprem.name, onprem.value, oci.name, oci.value from v$parameter oci, v$parameter@ORCL_ODA01 onprem
where oci.name=onprem.name
and oci.value <> onprem.value;

## Criar a entrada estatica no listener do ODA02.
SID_LIST_LISTENER =
   (SID_LIST =
      (SID_DESC =
         (SDU=32767)
         (GLOBAL_DBNAME=orcl_oda02)
         (ORACLE_HOME=/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1)
         (SID_NAME=orcl)
         (ENVS = "ORACLE_UNQNAME=orcl_oda02,TNS_ADMIN=/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/network/admin,ORACLE_BASE=/u01/app/odaorabase0")
      )
 )



## Realizar o duplicate a partir do destino. ODA02.
rman target sys/ODA-riogran-2390@192.168.1.251:1521/orcl_oda01 auxiliary sys/ODA-riogran-2390@192.168.1.22:1521/orcl_oda02

spool log to '/home/oracle/duplicate.log';
run {
allocate channel prmy1 type disk;
allocate auxiliary channel stby type disk;
DUPLICATE TARGET DATABASE
  FOR STANDBY
  FROM ACTIVE DATABASE
  DORECOVER
  NOFILENAMECHECK;
}


## Criar os ACFS de backup e archive. ODA02.
asmcmd volcreate -G DATA -s 50G DATBACKUP
asmcmd volinfo -G DATA DATBACKUP

# criar o filesystem pelo SO (como grid)
/sbin/mkfs -t acfs /dev/asm/datbackup-331


#registrar o volume pra subir junto com o grid, executar como root:
 /sbin/acfsutil registry -a -u oracle  /dev/asm/datbackup-331 /backup


-------
asmcmd volcreate -G RECO -s 350G DATARCHIVE
asmcmd volinfo -G RECO DATARCHIVE

# criar o filesystem pelo SO (como grid)
/sbin/mkfs -t acfs /dev/asm/datarchive-494


#registrar o volume pra subir junto com o grid, executar como root:
 /sbin/acfsutil registry -a -u oracle  /dev/asm/datarchive-494 /archive



#Mandar os archives para o standby
## Foi necessario restaurar alguns archives que ja haviam sido apagados na origem. ODA01.
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run
{  
  SET ARCHIVELOG DESTINATION TO '/backup/orcl/temp';
  restore archivelog from sequence 404159 until sequence 404198 thread 1;
}

## Copiar para o ODA02.
scp /backup/orcl/temp/ForStandbyCTRL.bck oracle@192.168.1.22:/backup/orcl/temp



## Catalogar os archives no ODA02.
catalog start with '/archive/orcl/';

## Recover ODA02. (sqlplus) 
Recover Standby Database;


-- Em caso de falha no update-server
Job details
----------------------------------------------------------------
                     ID:  182e5f80-05aa-4e2a-8545-4aacb6241bac
            Description:  Server Patching
                 Status:  Failure
                Created:  February 9, 2022 2:36:24 PM BRT
                Message:  DCS-10001:Internal error encountered: Cluster ware is not running to get the resource details.

/opt/oracle/dcs/bin/odacli create-prepatchreport -st -v 19.13.0.0.0
/opt/oracle/dcs/bin/odacli update-storage -v 19.13.0.0.0


/opt/oracle/dcs/bin/odacli update-repository -f /u01/medias/odacli-dcs-19.10.0.0.0-210115-DB-11.2.0.4.zip

odacli describe-job -i 3e8446ba-504f-4988-b45c-dc94d843c86d

https://192.168.1.22:7093/mgmt/index.html


--Aumentar o ACFS /u02/app/oracle/oradata/orcl
acfsutil size +1000G /u02/app/oracle/oradata/orcl

--Arrumar o spfile a SGA -- OK
--Aumentar a huge pages -- OK


Rodar o calibrate IO

-- 
SET SERVEROUTPUT ON
DECLARE
lat INTEGER;
iops INTEGER;
mbps INTEGER;
BEGIN
SYS.DBMS_RESOURCE_MANAGER.CALIBRATE_IO(8, 10, iops, mbps, lat);
DBMS_OUTPUT.PUT_LINE ('max_iops = ' || iops);
DBMS_OUTPUT.PUT_LINE ('latency = ' || lat);
dbms_output.put_line ('max_mbps = ' || mbps);
end;
/

max_iops = 677697
latency = 0
max_mbps = 3724


Criar o DG Standard com os scripts
Backup as copy

Configurar o backup
Configurar o zabbix 
Seguir o procedimento de novas instalacoes



### Listener Stand by
 LISTENER =
  (ADDRESS_LIST=
        (ADDRESS=(PROTOCOL=tcp)(HOST=192.168.1.22)(PORT=1521))
        (ADDRESS=(PROTOCOL=ipc)(KEY=EXTPROC1521)))

SID_LIST_LISTENER =
  (SID_LIST =
    (SID_DESC =
      (GLOBAL_DBNAME = standby-orcl)
      (ORACLE_HOME = /u01/app/odaorahome/oracle/product/11.2.0.4/dbhome_1)
      (SID_NAME = orcl)
    )
  )


srvctl stop listener -listener listener && srvctl start listener -listener listener


-- REnomear o database_unique_name no service do GRID
srvctl stop database -d orcl
srvctl remove database -d orcl

srvctl add database \
-d orcl_stdy \
-n orcl \
-i orcl \
-o /u01/app/odaorahome/oracle/product/11.2.0.4/dbhome_1 \
-p /u02/app/oracle/oradata/orcl/dbs/spfileorcl.ora \
-s MOUNT \
-t IMMEDIATE \
-r physical_standby \
-m isk.lan \
-y AUTOMATIC \
-a DATA \
-j "/u01/app/odaorahome,/u02/app/oracle/oradata/orcl,/u03/app/oracle/,/u01/app/odaorabase0" \
-x srvodax01 \
-c SINGLE

srvctl config database -d orcl
Database unique name: orcl
Database name: orcl
Oracle home: /u01/app/odaorahome/oracle/product/11.2.0.4/dbhome_1
Oracle user: oracle
Spfile: /u02/app/oracle/oradata/orcl/dbs/spfileorcl.ora
Domain: isk.lan
Start options: open
Stop options: immediate
Database role: PRIMARY
Management policy: AUTOMATIC
Server pools: orcl
Database instance: orcl
Disk Groups: DATA
Mount point paths: /u01/app/odaorahome,/u02/app/oracle/oradata/orcl,/u03/app/oracle/,/u01/app/odaorabase0
Services:
Type: SINGLE
Database is administrator managed



alter system set log_archive_dest_1='LOCATION=/u03/app/oracle/archive/orcl' scope=both;


col REDOLOG_FILE_NAME for a80
SELECT a.GROUP#, a.THREAD#, a.SEQUENCE#, a.ARCHIVED, a.STATUS,
b.MEMBER AS REDOLOG_FILE_NAME, (a.BYTES/1024/1024) AS SIZE_MB
FROM v$log a JOIN v$logfile b ON a.Group#=b.Group#
ORDER BY a.GROUP#;


alter database backup standby controlfile to trace as '/home/oracle/ctlteste.ctl';

alter database create standby controlfile as '/home/oracle/ctlteste.ctl';
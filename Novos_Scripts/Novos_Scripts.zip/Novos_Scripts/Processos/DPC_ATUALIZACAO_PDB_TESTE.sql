Prezados, bom dia!

Precisamos atualizar nossas instâncias de homologação. Para isso, gostaríamos que vocês importassem e exportassem as instâncias de produção: DPCWEB1(10.22.6.122:1521/dpcweb1.dpcprivadadbpro.mxmocivcn.oraclevcn.com), DPCWEB2(10.22.6.122:1521/dpcweb2.dpcprivadadbpro.mxmocivcn.oraclevcn.com) e DPCWEB4HOM(10.22.6.122:1521/dpcweb4.dpcprivadadbpro.mxmocivcn.oraclevcn.com) para as instâncias de HOMOLOGAÇÃO DPCWEB1HOM(10.22.5.135:1521/dpcweb1hom), DPCWEB2HOM(10.22.5.135:1521/dpcweb2hom) e DPCWEB4HOM(10.22.5.135:1521/dpcweb1hom), em homologação.




Origem:DPCWEB1
destino:DPCWEB1HOM

#####################################################################################################################################################
#####
####      Procedimento para qualquer  atualizacao de bases teste
#####





#################################################################
##-- salvar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/backup/temp';
spool /backup/tempdbnameuserpass.sql
SELECT 'ALTER USER "' || username || '"' ||
  DECODE (password,
          'EXTERNAL',' IDENTIFIED EXTERNALLY',
          'GLOBAL',' IDENTIFIED GLOBALLY AS ''' || external_name,
          ' IDENTIFIED BY VALUES '||''''||(SELECT PASSWORD FROM SYS.USER$ WHERE NAME = u.username )||'''') ||' account unlock;'
FROM dba_users u
WHERE username NOT IN
         ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
          'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
          'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
          'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM','XS$NULL','APPQOSSYS')
ORDER BY username;
spool off
_SQL_


##-- salvar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/backup/temp';
spool /backup/temp/dbnameuserpassdpc1hom.sql
SELECT 'ALTER USER "' || username || '"' ||
  DECODE (password,
          'EXTERNAL',' IDENTIFIED EXTERNALLY',
          'GLOBAL',' IDENTIFIED GLOBALLY AS ''' || external_name,
          ' IDENTIFIED BY VALUES '||''''||(SELECT PASSWORD FROM SYS.USER$ WHERE NAME = u.username )||'''') ||' account unlock;'
FROM dba_users u
WHERE username NOT IN
         ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
          'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
          'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
          'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM','XS$NULL','APPQOSSYS')
ORDER BY username;
spool off
_SQL_


spool /backup/temp/dbnameuserpass3.sql
SELECT 'ALTER USER "' || username || '"' ||
  DECODE (password,
          'EXTERNAL',' IDENTIFIED EXTERNALLY',
          'GLOBAL',' IDENTIFIED GLOBALLY AS ''' || external_name,
          ' IDENTIFIED BY VALUES '||''''||(SELECT PASSWORD FROM SYS.USER$ WHERE NAME = u.username )||'''') ||' account unlock;'
FROM dba_users u
WHERE username NOT IN
         ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
          'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
          'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
          'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM','XS$NULL','APPQOSSYS')
ORDER BY username;
spool off
_SQL_

spool /backup/temp/dbnameuserpass4.sql
SELECT 'ALTER USER "' || username || '"' ||
  DECODE (password,
          'EXTERNAL',' IDENTIFIED EXTERNALLY',
          'GLOBAL',' IDENTIFIED GLOBALLY AS ''' || external_name,
          ' IDENTIFIED BY VALUES '||''''||(SELECT PASSWORD FROM SYS.USER$ WHERE NAME = u.username )||'''') ||' account unlock;'
FROM dba_users u
WHERE username NOT IN
         ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
          'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
          'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
          'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM','XS$NULL','APPQOSSYS')
ORDER BY username;
spool off
_SQL_



##--- export dos usuarios
expdp msales/msales123@DPCWEB1HOM \
DIRECTORY=dprefresh \
DUMPFILE=dbname-users%U.dmp \
LOGFILE=dbname-exp-users.log \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=USER \
INCLUDE=SYSTEM_GRANT \
INCLUDE=ROLE_GRANT \
INCLUDE=TABLESPACE_QUOTA \
INCLUDE=GRANT


##--- export dos dblinks
expdp msales/Ms#ales123@DPCWEB2HOM \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks_web2hom%U.dmp \
LOGFILE=exp_dbnamedblinks.log \
full=y \
REUSE_DUMPFILES=y \
PARALLEL=5 \
INCLUDE=DB_LINK:"\"IN(SELECT db_link FROM dba_db_links)\""


#####################################################################################################################################################
#####
####      depois de atualizar a base, executar os procedimentos abaixo **** NA BASE TESTE ****


###

##-- restaurar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/tmp';
@/tmp/dbnameuserpass.sql
_SQL_

spool /backup/dbname/rman/dropdblinks.sql
begin
for o in (select distinct owner from dba_db_links where owner<>'PUBLIC' order by 1) loop
   DBMS_OUTPUT.PUT_LINE('CREATE PROCEDURE '||o.owner||'.drop_db_link AS' );
   DBMS_OUTPUT.PUT_LINE('BEGIN' );
   for d in (select distinct DB_LINK from dba_db_links where owner=o.owner order by 1) loop
      DBMS_OUTPUT.PUT_LINE('EXECUTE IMMEDIATE ''drop database link '||d.DB_LINK||''';');
   end loop;
   DBMS_OUTPUT.PUT_LINE('END drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('/');
   DBMS_OUTPUT.PUT_LINE('EXEC '||o.owner||'.drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('DROP PROCEDURE '||o.owner||'.drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------');
end loop;

for d in (select distinct DB_LINK from dba_db_links where owner='PUBLIC' order by 1) loop
  DBMS_OUTPUT.PUT_LINE('drop public database link '||d.DB_LINK||';');
end loop;

end;
/
spool off

@/backup/dbname/rman/dropdblinks.sql



##--- import dos dblinks
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=imp_dbnamedblinks.log


##--- import dos usuarios
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-users%U.dmp \
LOGFILE=dbname-imp-users.log \
INCLUDE=SCHEMA:"\"NOT IN(SELECT USERNAME FROM DBA_USERS)\"" 


sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
@$ORACLE_HOME/rdbms/admin/utlrp.sql
'_SQL_'




Obs: Não precisaremos de backup das bases de homologação.



Para realizar este procedimento, é possível realizá-lo sem parar produção? Se sim, solicitamos que seja feito o mais rápido possível.(14/08/2023).



create user C##EXPORTA identified by "exporta123";



Ex##porta123;

create public database link LINKPROD connect to C##EXPORTA identified by exporta123 using '10.22.6.122:1521/cdbprd03_gru1ia.dpcprivadadbpro.mxmocivcn.oraclevcn.com';
create public database link LINKPROD connect to C##EXPORTA identified by exporta123 using '10.22.6.122:1521/cdbprd05_gru1ia.dpcprivadadbpro.mxmocivcn.oraclevcn.com';
create public database link LINKPROD connect to C##EXPORTA identified by Ex##pORTA123 using '10.22.6.122:1521/cdbprd04_gru1ia.dpcprivadadbpro.mxmocivcn.oraclevcn.com';




--CRIAR PDBS 

create pluggable database DPCWEB1HOM FROM DPCWEB1@LINKPROD keystore identified by "Cloud-DPC-2390" including shared key parallel 7;

create pluggable database DPCWEB2HOM FROM DPCWEB2@LINKPROD keystore identified by "SaTurno#29-07" including shared key parallel 7;

create pluggable database DPCWEB3HOM FROM DPCWEB3@LINKPROD keystore identified by "Cloud-DPC-2390" including shared key parallel 7;

create pluggable database DPC1HOM FROM DPC1@LINKPROD keystore identified by "SaTurno#29-07" including shared key parallel 7;


dpcweb1.dpcprivadadbpro.mxmocivcn.oraclevcn.com

keystore identified by "xxxxxxxx" including shared key parallel 6;
"Cloud-DPC-2390"




DPC1(10.22.6.122:1521/dpc1.dpcprivadadbpro.mxmocivcn.oraclevcn.com) para a instância de homologação 
DPC1HOM(10.22.5.135:1521/dpc1hom).


create pluggable database PDB1_RJHOM FROM PDB1_RJ@LINKPROD keystore identified by "SaTurno#29-07" including shared key parallel 7;

create pluggable database PDB2_SPHOM FROM PDB2_SP@LINKPROD keystore identified by "SaTurno#29-07" including shared key parallel 7;

create pluggable database PDB3_HOM FROM PDB3_ESPEC@LINKPROD keystore identified by "Cloud-DPC-2390" including shared key parallel 7;

create pluggable database PDB5_HOM FROM PDB5_D2187@LINKPROD keystore identified by "Cloud-DPC-2390" including shared key parallel 7;


PDB2_SPHOM

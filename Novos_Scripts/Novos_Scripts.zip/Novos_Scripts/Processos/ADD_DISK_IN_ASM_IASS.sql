/etc/udev/rules.d/96-asm.rules

 

udevadm info --query=all --name=/dev/sdl | grep -i ID_PATH

 

udevadm control --reload-rules && /sbin/udevadm trigger
udevadm control --reload-rules
udevadm trigger --type=devices --action=change

 

sqlplus / as sysasm

 

alter diskgroup DATA add disk '/dev/DATADISK11' NAME DATA_0010 rebalance power 100;
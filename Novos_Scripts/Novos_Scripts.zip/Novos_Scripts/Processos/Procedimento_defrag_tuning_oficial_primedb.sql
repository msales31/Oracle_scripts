##### PROCEDIMENTO PARA DESFRAGMENTA��O BASE DE DADOS ORACLE ####
##### PRIME DB SOLUTIONS - 2023 ####
####
####  Premissas, salvar tamanho do banco liquido, bruto, tablespaces, maiores tabelas, tabelas mais fragmentadas ####

#####Lista tabelas fragmentadas do owner x.####

col table_Name for a25
col "Table size" for 9999999999
col "Actual Data size" for 99999999999
col pct_free for 99999999
col "KB Free Space" for 999999999
select table_name,
round((blocks*8),2)||'kb' "Table size",
round((num_rows*avg_row_len/1024),2)||'kb' "Actual Data size",
pct_free,
round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) "KB Free Space"
from dba_tables
where round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) > 0
order by round((blocks*8),2) - (round((blocks*8),2)*pct_free/100) - (round((num_rows*avg_row_len/1024),2)) desc;
###################################

#### Tamanho do banco liquido

select '_________Size_|_Type__________'
from dual union all
select substr (S, 1, 120) from (
select chr(27)||'[0;1;32m'||
to_char (sum (s.BYTES) / 1048576, '999G999G990') ||'M'||chr(27)||'[0m'||
' | '|| s.SEGMENT_TYPE
S
from DBA_SEGMENTS s
where s.OWNER not in
('ANONYMOUS','BACKUP','BACKUPDUMP','BKPDMP','CTXSYS',
'DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS',
'MDDATA','MDSYS','MGMT_VIEW','ODM','ODM_MTR','OE',
'OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM',
'QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES',
'QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA',
'STANDBY','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP',
'WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and s.SEGMENT_TYPE not in ('CACHE','ROLLBACK','TYPE2 UNDO','TEMPORARY')
group by s.SEGMENT_TYPE
order by s.SEGMENT_TYPE
) union all
select '--------------|----------------' from dual union all
select substr (S, 1, 120) from (
select to_char (sum (s.BYTES) / 1073741824, '9G999G990D0') ||'G | Total'
S
from DBA_SEGMENTS s
where s.OWNER not in
('ANONYMOUS','BACKUP','BACKUPDUMP','BKPDMP','CTXSYS',
'DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS',
'MDDATA','MDSYS','MGMT_VIEW','ODM','ODM_MTR','OE',
'OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM',
'QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES',
'QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA',
'STANDBY','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP',
'WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and s.SEGMENT_TYPE not in ('CACHE','ROLLBACK','TYPE2 UNDO','TEMPORARY')
) ;

###
### Tamanho do banco bruto ###

select sum(total)/1024 from (
select sum(round(sum(nvl(fs.bytes/1024/1024,0))) + round(df.bytes/1024/1024 - sum(nvl(fs.bytes/1024/1024,0)))) total
FROM dba_free_space fs, dba_data_files df
WHERE fs.file_id(+) = df.file_id
GROUP BY df.tablespace_name, df.file_id, df.bytes, df.autoextensible
UNION
SELECT sum(round(bytes)/1024/1024) total
FROM DBA_TEMP_FILES);


### Tablespaces ###

with
Q_TBS as (
select decode (t1.CONTENTS,
'TEMPORARY', 't', 'UNDO', 'U', 'PERMANENT', '-', t1.CONTENTS) ||
decode (t1.LOGGING,
'LOGGING', '-', 'NOLOGGING', 'N', t1.LOGGING) ||
decode (t1.EXTENT_MANAGEMENT,
'LOCAL', '-', 'DICTIONARY', 'D', t1.EXTENT_MANAGEMENT) ||
decode (t1.SEGMENT_SPACE_MANAGEMENT,
'AUTO', '-', 'MANUAL', 'M', t1.SEGMENT_SPACE_MANAGEMENT) ||
decode (t1.ALLOCATION_TYPE, 'SYSTEM', '-',
'UNIFORM', 'U', t1.ALLOCATION_TYPE)
TBS_FLAGS,
t1.TABLESPACE_NAME || decode (t1.STATUS, 'ONLINE', '', '*('|| t1.STATUS ||')') TBS_NAME
from DBA_TABLESPACES t1
),
Q_TBS_ALLOC_MAX as (
select t1.TABLESPACE_NAME TBS_NAME,
sum (greatest (0, nvl (f1.BYTES, 0))) / 1048576 TBS_ALLOC,
sum (greatest (0, nvl (f1.MAXBYTES, 0), nvl (f1.BYTES, 0))) / 1048576 TBS_MAX,
count (f1.FILE_ID) TBS_FILE_CNT
from DBA_TABLESPACES t1,
DBA_DATA_FILES f1
where t1.TABLESPACE_NAME = f1.TABLESPACE_NAME
and t1.CONTENTS != 'TEMPORARY'
group by t1.TABLESPACE_NAME
union all
select t2.TABLESPACE_NAME TBS_NAME,
sum (greatest (0, nvl (f2.BYTES, 0))) / 1048576 TBS_ALLOC,
sum (greatest (0, nvl (f2.MAXBYTES, 0), nvl (f2.BYTES, 0))) / 1048576 TBS_MAX,
count (f2.FILE_ID) TBS_FILE_CNT
from DBA_TABLESPACES t2,
DBA_TEMP_FILES f2
where t2.TABLESPACE_NAME = f2.TABLESPACE_NAME
and t2.CONTENTS = 'TEMPORARY'
group by t2.TABLESPACE_NAME
),
Q_TBS_FREE as (
select t1.TABLESPACE_NAME TBS_NAME,
sum (greatest (0, nvl (s1.BYTES, 0))) / 1048576 TBS_FREE
from DBA_TABLESPACES t1,
DBA_FREE_SPACE s1
where t1.TABLESPACE_NAME = s1.TABLESPACE_NAME (+)
and t1.CONTENTS not in ('TEMPORARY','UNDO')
group by t1.TABLESPACE_NAME
),
Q_TBS_USED as (
select t1.TBS_NAME TBS_NAME,
sum (greatest (0, nvl (t1.TBS_ALLOC, 0)))
- sum (greatest (0, nvl (t2.TBS_FREE, 0))) TBS_USED
from Q_TBS_ALLOC_MAX t1,
Q_TBS_FREE t2
where t1.TBS_NAME = t2.TBS_NAME
group by t1.TBS_NAME
union all
select t3.NAME TBS_NAME,
(avg (greatest (0, greatest (nvl (s3.USED_BLOCKS, 0), nvl (s4.BLOCKS, 0))
* nvl (f3.BYTES / f3.BLOCKS, 8192)))) / 1048576 TBS_USED
from V$TABLESPACE t3,
V$TEMPFILE f3,
GV$SORT_SEGMENT s3,
GV$SORT_USAGE s4
where t3.TS# = f3.TS#
and t3.NAME = s3.TABLESPACE_NAME (+)
and t3.NAME = s4.TABLESPACE (+)
group by t3.NAME
union all
select t4.TABLESPACE_NAME TBS_NAME,
sum (greatest (0, nvl (s4.BYTES, 0))) / 1048576 TBS_USED
from DBA_TABLESPACES t4,
DBA_UNDO_EXTENTS s4
where t4.TABLESPACE_NAME = s4.TABLESPACE_NAME (+)
and t4.CONTENTS = 'UNDO'
and s4.STATUS != 'EXPIRED'
group by t4.TABLESPACE_NAME
)
select lpad (C1, max (length (C1)) over (), C0P) ||'|'||
lpad (C2, max (length (C2)) over (), C0P) ||'|'||
lpad (C3, max (length (C3)) over (), C0P) ||''||
lpad (C4, max (length (C4)) over (), C0P) ||''||
lpad (C5, max (length (C5)) over (), C0P) ||'['||
rpad (C6, max (length (C6)) over (), C0P) ||'<'||
lpad (C7, max (length (C7)) over (), C0P) ||']'||
lpad (C8, max (length (C8)) over (), C0P) ||'|'||
rpad (C9, max (length (C9)) over (), C0P)
from (
(select 0 C0O, '_' C0P,
'CLESA' C1,
'#F' C2,
'USED' C3,
'ALLOC' C4,
'MAX_' C5,
'GRAPH' C6,
'USE' C7,
'USABLE' C8,
'_TableSpace_' C9
from dual)
union all
(select decode (t.TBS_NAME, 'SYSTEM', 1, 'SYSAUX', 2, 'XDB', 3, 'TOOLS', 4, 'DRSYS', 5,
'ODM', 6, 'CWMLITE', 7, 'PERFSTAT', 8, 'EXAMPLE', 9, 'USERS', 10, 'INDX', 11,
decode (substr (t.TBS_FLAGS, 1, 1), 'U', 12, 't', 13, 14)) C0O,
' ' C0P,
nvl (t.TBS_FLAGS, '????') C1,
to_char (nvl (s.TBS_FILE_CNT, 0), 'FM990') C2,
to_char (nvl (u.TBS_USED, 0), '9G999G990') ||'M' C3,
to_char (nvl (s.TBS_ALLOC, 0), '9G999G990') ||'M' C4,
decode (greatest (s.TBS_MAX, 999), 999, to_char (s.TBS_MAX, '9990') ||'M ',
to_char (ceil (s.TBS_MAX / 1024), '9G990') ||'G ') C5,
rpad (substr (decode (substr (t.TBS_FLAGS, 1, 1), 'U', '*********!!', '*******#!@@'),
1, greatest (1, 100 * nvl (u.TBS_USED, 0) / s.TBS_MAX / 10)), 10, ' ') C6,
to_char (100 * nvl (u.TBS_USED, 0) / s.TBS_MAX, 'FM90') ||'%' C7,
to_char ((greatest (s.TBS_MAX, s.TBS_ALLOC) - s.TBS_ALLOC
+ nvl (f.TBS_FREE, s.TBS_ALLOC - nvl (u.TBS_USED, 0))) / 1024, '990D0') ||'G' C8,
' '|| t.TBS_NAME C9
from Q_TBS t,
Q_TBS_ALLOC_MAX s,
Q_TBS_FREE f,
Q_TBS_USED u
where t.TBS_NAME = s.TBS_NAME (+)
and t.TBS_NAME = f.TBS_NAME (+)
and t.TBS_NAME = u.TBS_NAME (+)
)
) order by C0O, reverse (C9) ;



### MAIORES TABELAS ####

set tab off underline off linesize 2050 newpage none pagesize 4000
set feedback on colsep | editfile /tmp/sqlplusedit.tmp long 10000000 trimout on;
set numwidth 13;
set serveroutput on size 1000000 trimspool on longchunksize 10000000 time on;
col  owner format a15
col  segment_name format a30
col  segment_type format a15
col  mb format 999,999,999
select owner, segment_name, segment_type, mb
from (select owner, segment_name, segment_type, bytes / 1024 / 1024 "MB"
from dba_segments
order by bytes desc)
where rownum < 20
/

####

1 - Rebuild de �ndices do menor para o maior, para ir liberando espa�o gradativamente na tablespace de �ndices.
2 - Enable row movement (habilitar a movimenta��o das tabelas para utilizar o shrink)
3 - Shrink de todas as tabelas ordenando da menor para a maior, para ir liberando espa�o gradativamente no tablespace de dados.
4 - Shrink de lobs, novamente do menor para o maior. (SE TIVER JANELA BOA, PORQUE PESA BASTANTE)
5 - Disable row movement (desabilitar a movimenta��o das tabelas)
6 - Coleta de estat�sticas

###
##### 1 ######
## Rebuild em PARALLEL quando for entreprise
## REBUILD DE INDICES EM PARALLEL ###
## Validar sempre se � ENTERPRISE e a QTD de CPU ###
## Ficar de olho na gera��o de archives / espa�o / DR / DG ##
## Se colocar em noarchivelog, recriar o standby / dg, se tiver em archivelog, provavelmente vai perder o standby / dr e ser� necess�rio recupera-lo.
## Caso queira jogar os indices em outra tablespace, basta adicionar o comando TABLESPACE NOME ap�s o parallel 4, por�m, valida qual schema vai para qual tablespace.

exec DBMS_OUTPUT.ENABLE(10000000);
set serveroutput on size 1000000

spool rebuild_index.sql;
declare
retorno varchar2(30000);c
begin
 DBMS_OUTPUT.ENABLE(10000000);
for t in (select a.OWNER, a.OBJECT_NAME
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
AND a.owner in ('XXXXXSCHEMAXXXXX')
order by b.bytes)
loop
DBMS_OUTPUT.ENABLE (buffer_size => NULL);
  DBMS_OUTPUT.PUT_LINE('ALTER INDEX '||t.owner||'.'||t.OBJECT_NAME ||' REBUILD ONLINE PARALLEL 4;');
  DBMS_OUTPUT.PUT_LINE('ALTER INDEX '||t.owner||'.'||t.OBJECT_NAME||' NOPARALLEL;');
end loop;
end;
/
spool off;
##@rebuild_index.sql;


#########

##### 2 ######
####### ENABLE ROW MOVEMENT TABLES #####
spool enable.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' ENABLE ROW MOVEMENT;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

###### SHRINK por order de tamanho, maiores no final.
spool shrink.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' SHRINK SPACE;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

## Shrink de todos os lobs por  tamanho
spool shrink_lobs.sql
select 'alter table '||a.owner||'."' || a.TABLE_NAME ||'" MODIFY LOB ("'||a.column_name||'")  (SHRINK SPACE);'
from dba_lobs a, DBA_SEGMENTS B
where A.OWNER=B.OWNER
and UPPER(a.owner) not in        ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
       'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
       'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
       'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.table_name = b.segment_name
ORDER BY B.BYTES;
spool off

####### DISABLE ROW MOVEMENT TABLES #####
spool disable.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' DISABLE ROW MOVEMENT;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

###### coleta.sql ordenado por bytes
spool coleta.sql
select 'exec dbms_stats.gather_table_stats(''"'||a.owner||'"'' ,''"'||a.object_name||'"'',  cascade => true, method_opt=>''FOR ALL COLUMNS SIZE AUTO'', degree=>4);'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.owner not in ('DVSYS','ORDDATA','ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER','MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM','QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS','SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;





#####
## criar um arquivo com vi chamado tuning.sql

spool tuning.log;
@enable.sql;
@enable.sql;
@shrink.sql;
##@shrink_lobs.sql; <- s� descomentar se for fazer shrink dos lobs, opcional.
@rebuild_index.sql;
@disable.sql;
@disable.sql;

@?/rdbms/admin/utlrp.sql;
@coleta.sql;
spool off;

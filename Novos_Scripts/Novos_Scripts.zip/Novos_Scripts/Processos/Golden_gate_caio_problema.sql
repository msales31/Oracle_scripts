COLUMN CONSUMER_NAME HEADING 'Capture|Process|Name' FORMAT A15
COLUMN SOURCE_DATABASE HEADING 'Source|Database' FORMAT A10
COLUMN SEQUENCE# HEADING 'Sequence|Number' FORMAT 999999
COLUMN NAME HEADING 'Archived Redo Log|File Name' format a35
column first_scn HEADING 'Archived Log|First SCN'
COLUMN FIRST_TIME HEADING 'Archived Log Begin|Timestamp'
column next_scn HEADING 'Archived Log|Last SCN'
COLUMN NEXT_TIME HEADING 'Archived Log Last|Timestamp'
COLUMN MODIFIED_TIME HEADING 'Archived Log|Registered Time'
COLUMN DICTIONARY_BEGIN HEADING 'Dictionary|Build|Begin' format A6
COLUMN DICTIONARY_END HEADING 'Dictionary|Build|End' format A6
COLUMN PURGEABLE HEADING 'Purgeable|Archive|Log' format a9

SELECT r.CONSUMER_NAME,
r.SOURCE_DATABASE,
r.SEQUENCE#,
r.NAME,
r.first_scn,
r.FIRST_TIME,
r.next_scn,
r.next_time,
r.MODIFIED_TIME,
r.DICTIONARY_BEGIN,
r.DICTIONARY_END,
r.purgeable
FROM DBA_REGISTERED_ARCHIVED_LOG r, DBA_CAPTURE c
WHERE r.CONSUMER_NAME = c.CAPTURE_NAME
AND r.SEQUENCE# in (49731,51572)
ORDER BY source_database, consumer_name, r.first_scn;



0x000000811f914b17

SET LINESIZE 200
COLUMN SOURCE_DATABASE HEADING 'Source|Database' FORMAT A10
COLUMN SEQUENCE# HEADING 'Sequence|Number' FORMAT 999999
COLUMN NAME HEADING 'Archived Redo Log|File Name' FORMAT A35
COLUMN FIRST_SCN HEADING 'Archived Log|First SCN' FORMAT 999999999999999999999999999
COLUMN FIRST_TIME HEADING 'Archived Log Begin|Timestamp' FORMAT A20
COLUMN NEXT_SCN HEADING 'Archived Log|Last SCN' FORMAT 999999999999999999999999999
COLUMN NEXT_TIME HEADING 'Archived Log Last|Timestamp' FORMAT A20
COLUMN MODIFIED_TIME HEADING 'Archived Log|Registered Time' FORMAT A20
COLUMN DICTIONARY_BEGIN HEADING 'Dictionary|Build|Begin' FORMAT A6
COLUMN DICTIONARY_END HEADING 'Dictionary|Build|End' FORMAT A6
COLUMN PURGEABLE HEADING 'Purgeable|Archive|Log' FORMAT A9

SELECT r.CONSUMER_NAME,
       r.SOURCE_DATABASE,
       r.SEQUENCE#,
       r.NAME,
       TO_CHAR(r.FIRST_SCN, '999999999999999999999999999') AS FIRST_SCN,
       r.FIRST_TIME,
       TO_CHAR(r.NEXT_SCN, '999999999999999999999999999') AS NEXT_SCN,
       r.NEXT_TIME,
       r.MODIFIED_TIME,
       r.DICTIONARY_BEGIN,
       r.DICTIONARY_END,
       r.PURGEABLE
FROM DBA_REGISTERED_ARCHIVED_LOG r
JOIN DBA_CAPTURE c ON r.CONSUMER_NAME = c.CAPTURE_NAME
WHERE r.SEQUENCE# IN (49731, 51572)
ORDER BY r.SOURCE_DATABASE, r.CONSUMER_NAME, r.FIRST_SCN;



COLUMN FIRST_SCN HEADING 'Archived Log|START_SCN' FORMAT 999999999999999999999999999
COLUMN FIRST_SCN HEADING 'Archived Log|First SCN' FORMAT 999999999999999999999999999
column FILTERED_SCN 
SELECT START_SCN, CAPTURED_SCN, APPLIED_SCN, FIRST_SCN, OLDEST_SCN, FILTERED_SCN FROM DBA_CAPTURE;

SELECT 
    TO_CHAR(START_SCN, '999999999999999999999999999') AS "Start SCN",
    TO_CHAR(CAPTURED_SCN, '999999999999999999999999999') AS "Captured SCN",
    TO_CHAR(APPLIED_SCN, '999999999999999999999999999') AS "Applied SCN",
    TO_CHAR(FIRST_SCN, '999999999999999999999999999') AS "First SCN",
    TO_CHAR(OLDEST_SCN, '999999999999999999999999999') AS "Oldest SCN",
    TO_CHAR(FILTERED_SCN, '999999999999999999999999999999999') AS "Filtered SCN"
FROM 
    DBA_CAPTURE;
	
	select FILTERED_SCN from DBA_CAPTURE;
	
Start SCN                   |Captured SCN                |Applied SCN                 |First SCN                   |Oldest SCN                  |Filtered SCN
539369008443|                541661859457|               541512499836                  539369008443               541512499836|                482323750863
				

SELECT *  FROM V$ARCHIVED_LOG
where first_change# = 539369008443;


SELECT first_change#, first_time, archived, deleted  
FROM V$ARCHIVED_LOG
where first_change# = 539369008443;

                |Archived Log Begin  |   |
     FIRST_CHANGE#|Timestamp           |ARC|DEL
      539369008443|2024-04-01 07:46:36 |YES|NO
      539369008443|2024-04-01 07:46:36 |YES|YES


539369008443

select  capture_name
, (select scn_to_timestamp(539369008443) from dual) as start_scn
, (select scn_to_timestamp(541661859457) from dual) as captured_scn
, (select scn_to_timestamp(541512499836) from dual) as applied_scn
, (select scn_to_timestamp(539369008443) from dual) as first_scn
, (select scn_to_timestamp(541512499836) from dual) as oldest_scn
, (select scn_to_timestamp(482323750863) from dual) as filtered_scn
from dba_capture;

select scn_to_timestamp(541512499836) from dual;

SCN_TO_TIMESTAMP(541512499836)
12-APR-24 05.55.39.000000000 PM

SELECT *  FROM V$ARCHIVED_LOG
where first_change# = 539369008443;

SELECT first_change#, first_time, archived, deleted  
FROM V$ARCHIVED_LOG
where first_change# = 539369008443;

482323750863

482323750863


Archived Log|          |
 START_SCN|CAPTURED_SCN|APPLIED_SCN|                   First SCN|OLDEST_SCN|FILTERED_SCN
5.3937E+11|  5.4166E+11| 5.4151E+11|                539369008443|5.4151E+11|  4.8232E+11






create public database link LINK_STDB connect to C##EXPORTA identified by  "EX##Porta123" using 'CDB01';




create pluggable database PDBHML from QVISPRD@LINK_STDB keystore identified by "im2Op#ZyRZIpF_#-n5" including shared key parallel 5;

sB28z03#V3HnZ-p7HFr_cXMUPh#BQT

create pluggable database PDBHML from QVISPRD@LINK_STDB keystore identified by "Cloud-Vision-2390" including shared key parallel 5;

create pluggable database PDBHML from QVISPRD@LINK_PRD keystore identified by "sB28z03#V3HnZ-p7HFr_cXMUPh#BQT" including shared key parallel 5;

im2Op#ZyRZIpF_#-n5 -->> senha da wallet 
C2y5vAP-06WsHFv#059GQOV1QgOXy_
d36yY#_cznFM47SUSQM-bf9#gyvnmt
d36yY#_cznFM47SUSQM-bf9#gyvnmt
sB28z03#V3HnZ-p7HFr_cXMUPh#BQT

LINK_STDB.HPESUBTRE01DB01.HPEVCNTRE01.ORACLEVCN.COM


create public database link LINK_PRD.HPESUBTRE01DB01.HPEVCNTRE01.ORACLEVCN.COM connect to C##EXPORTA identified by EX##Porta123 using '10.221.3.108:1521/CDB01_PDB01.paas.oracle.com';

create pluggable database PDBHML from QVISPRD@LINK_STDB keystore identified by "im2Op#ZyRZIpF_#-n5" including shared key parallel 5;




list backup of archivelog   sequence 51572  thread=2;


run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
         restore archivelog from logseq 51572  thread=2;
}


run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=51570 until logseq=51580 thread=2;	
}

rman_arc_c5db_ARCHIVE_dbid2204412412_s347484_t1166122024_p1.bkp

rman_arc_c5db_ARCHIVE_dbid2204412412_s347486_t1166122024_p1.bkp


restore archivelog from logseq=51570 until logseq=51573;	




CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON STANDBY;



run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from time "to_date( '13.04.2024 17:50:00', 'DD.MM.YYYY HH24:MI:SS')"  until time "to_date( '14.04.2024 00:00:00', 'DD.MM.YYYY HH24:MI:SS')" thread=2;	
}


restore ARCHIVELOG FROM TIME "to_date('12/04/2024 17:50:01','MM/DD/YY HH24:MI:SS')" UNTIL TIME "to_date('13/04/2024 15:00:00','MM/DD/YY HH24:MI:SS')";


"to_date( '13.04.2024 17:50:00', 'DD.MM.YYYY HH24:MI:SS')";
"to_date( '14.04.2024 00:00:00', 'DD.MM.YYYY HH24:MI:SS')"


select ALRID,'0x' || to_char(ALFLG,'fmxx') flg,
'0x' || to_char(ALFL2,'fmxx') flg2
from x$kccal where alseq=0";




SQL> Alter database register logical logfile '+RECOC1/C5DB_GUA1X9/ARCHIVELOG/2024_04_12c5db_2_51574_1120027036.arc' for 'OGG$CAP_EC5DB';


Alter database register logical logfile '+RECOC1/C5DB_GUA1X9/ARCHIVELOG/2024_06_23/c5db_1_58163_1120027036.arc' for 'OGG$CAP_EC5DB';

select name, thread#, sequence#, status,first_time, next_time, to_char(first_change#), to_char(next_change#) from v$archived_log; where 51572 between first_change# and next_change#


select name, thread#, sequence#, status,first_time, next_time, to_char(first_change#), to_char(next_change#) from v$archived_log where  58163 between first_change# and next_change#;



58869

 Alter database register logical logfile '+RECOC1/C5DB_GUA1X9/ARCHIVELOG/2024_04_12c5db_2_51574_1120027036.arc' for 'OGG$CAP_EC5DB';


select name, thread#, sequence#, status,first_time, next_time, to_char(first_change#), to_char(next_change#) from v$archived_log order by first_time;

select ALRID,'0x' || to_char(ALFLG,'fmxx') flg,
'0x' || to_char(ALFL2,'fmxx') flg2
from x$kccal where alseq= 51572;


exec dbms_logmnr.add_logfile('/acfs01/acfs/backup/c5db_2_51572_1120027036.arc');
SQL> exec dbms_logmnr.start_logmnr;
SQL> select count(1) from v$logmnr_contents;


exec dbms_logmnr.add_logfile('/acfs01/acfs/backup/golden_gate/c5db_2_58742_1120027036.arc');
SQL> exec dbms_logmnr.start_logmnr;
SQL> select count(1) from v$logmnr_contents;


select scn_to_timestamp(0x0000007e14a9027c) from dual;

select scn_to_timestamp(0x000000811f914b17) from dual;


Select sequence# from v$archived_log where 51572 is between first_change# and next_change#;     Sequence#     ==========     100

Select sequence# from v$archived_log where 553784264151 is between first_change# and next_change#;   

 Select sequence# from v$archived_log where 553784264151 is between first_change# and next_change#;     Sequence#     ==========     100

Select sequence# from v$archived_log where sequence# > 51572;


c5db_2_58869_1120027036.arc


run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=51570 until logseq=51600 thread=2;
	   restore archivelog from logseq=49730 until logseq=49750 thread=1;
}

run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=49730 until logseq=49750 thread=1;	
}


run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=51600 until logseq=51700 thread=2;	
	   restore archivelog from logseq=49750 until logseq=49850 thread=1;
}



run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
	   restore archivelog from logseq=49750 until logseq=49850 thread=1;
}



run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=51700 until logseq=51800 thread=2;	
	   restore archivelog from logseq=49850 until logseq=49950 thread=1;
}

run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=51800 until logseq=51865 thread=2;	
	   restore archivelog from logseq=49950 until logseq=49990 thread=1;
}



run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs';
       restore archivelog from logseq=51700 until logseq=51800 thread=2;	
}

49990




--STANDBY VOLTAR
CONFIGURE ARCHIVELOG DELETION POLICY TO BACKED UP 1 TIMES TO DISK;




--PROD VOLTAR 
CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON ALL STANDBY;




c5db_2_51573_1120027036.arc

 Alter database register logical logfile '/acfs01/acfs/backup/golden_gate/c5db_2_51572_1120027036.arc' for 'OGG$CAP_EC5DB';


 Alter database register logical logfile '+RECOC1/C5DB_GUA1X9/ARCHIVELOG/2024_06_23/thread_1_seq_58919.4023.1172434263' for 'OGG$CAP_EC5DB';

Select sequence# from v$archived_log where 1891451938 is between first_change# and next_change#;

https://videohub.oracle.com/media/OCI+in+Lab+-+OCI+GoldenGate+na+pr%C3%A1tica%21/1_v42jq9ve
https://videohub.oracle.com/media/Initial+Load+consistente+com+OCI+GoldenGate+%28OCIGG%29/1_asfpnuks
MOS Note: OGG How to Resync Tables / Schemas on Different SCN s in a Single Replicat (Doc ID 1339317.1)
How to add tables to an Existing GoldenGate Configuration with Transaction Integrity? (Doc ID 1607591.1)

https://oraclespin.com/2021/11/21/purge-trail-file-manually-from-ogg-oci/
https://docs.oracle.com/en/cloud/paas/goldengate-service/ntzlj/#NTZLJ-GUID-051F5E35-89F6-41A9-9E82-D75F4C1DA6DD



################- adicionar trandata na tabela

#- pode ser direto via banco ou via console adminclient 

-- adminclient via OCI (acessar portal oci -> golden gate -> Deployments, comparment golden gate)
     acessar OGG-deploy-GRU-Redeoba01
     Launch Admin Client

-- adminclient via servidor (obaexavcpx9mc2-eglbi1)

#- REDEOBA (obaexavcpx9mc2-eglbi1)
adminclient

connect https://192.29.142.28 as ggadmin !
senha: vault

##--- KOCH (dtc01bd01)
adminclient
connect https://172.17.0.45 as ggadmin PASSWORD Cloud-Koch-2390 !


#- informacoes do extract
info extract ec5db detail
view params ec5db

#- fazer login do banco origem (consinco)
dblogin USERIDALIAS OGGConnc5dbGRU DOMAIN OracleGoldenGate


#- verifiar se ja tem trandata na tabela
info trandata consincomonitor.tb_docto

-- quando nao tem "Logging of supplemental transaction log data is disabled for table consincomonitor.tb_docto"

#- se tem, mas nao esta usando apenas a PK, apagar e adicionar novamente
delete trandata CONSINCO.MRL_PRODEMPSEG

#- adicionar 
add trandata consincomonitor.tb_docto

#- verifiar se ja tem trandata na tabela
info trandata consincomonitor.tb_docto




################- adicionar no extract e fazer a carga inicial

#- ogg Redeoba  (interface web)
https://5oi6yzneweiq.deployment.goldengate.sa-saopaulo-1.oci.oraclecloud.com/
usuario: ggadmin
senha: vault

#- ogg KOCH (interface web)
https://3ja7s24ufdhq.deployment.goldengate.sa-saopaulo-1.oci.oraclecloud.com/
usuario: ggadmin
senha: vault



#- pegar ddl da origem (consinco producao) e criar a tabela no destino (novo dw)
  - somente com PK
  - se tem FK, tira
  - sem indices
  - se tem supplemental log, tira
  - se for owner diferente de consinco, muda e criar tudo com cosinco, na tablespace tsd_consinco
  - adicionar coluna DW_DTAGERACAO DATE (no caso do OBA)


#- adicionar tabela no extract
 - stop no replicat (action / stop )
 - stop no extract (action / stop )
 - edita e adiciona tabela no extract (clicar em EC5DB -> parameters), salva e volta (overview)
 - start no extract (action / start)  ***** APENAS EXTRAT, REPLICAT NAO PODE *******
   - aguardar / verificar se ja comecou a captura (clicar em EC5DB -> statistics), pode demorar alguns poucos minutos

 - fazer carga inicial ( * IMPORTANTE * ATENCAO * APENAS DEPOIS DE VERIFICAR ITEM ACIMA )
 
    - export na origem (base producao consinco)
      - pegar SCN atual e usar no flashback_scn do expdp e tmb nos parametros do replicat

         select to_char((dbms_flashback.get_system_change_number)) from dual;

      - fazer export data_only com flashback_scn (exadata producao)
        rm -f /acfs01/acfs/temp/dw-exp01*

expdp userid='"/ as sysdba"' \
tables=CONSINCO.MAP_MARCA,CONSINCOMONITOR.TB_DOCTOITE \
CONTENT=DATA_ONLY \
flashback_scn=487967354347 \
parallel=4 \
DIRECTORY=DPTEMP \
FILESIZE=22G \
DUMPFILE=dw-exp01%U.dmp \
LOGFILE=dw-exp01-exp.log

scp /acfs01/acfs/temp/dw-exp01* 10.201.8.204:/acfs01/acfs/temp

      - fazer import (exadata novo dw obaexavcpx9mc2-eglbi1)

rm /acfs01/acfs/temp/dw-exp01*

impdp userid='"/ as sysdba"' \
tables=CONSINCO.MAP_MARCA,CONSINCOMONITOR.TB_DOCTOITE \
CONTENT=DATA_ONLY \
REMAP_SCHEMA=CONSINCOMONITOR:CONSINCO \
parallel=4 \
DIRECTORY=DPTEMP \
DUMPFILE=dw-exp01%U.dmp \
LOGFILE=dw-exp01-imp.log



    - apos finalizado export e import, incluir tabelas no replicat
       - edita e adiciona tabela no replicat (clicar em RNDW -> parameters), salva e volta (overview)
        - MUITO IMPORTANTE, USAR O MESMO SCN utilizado no EXPORT

       MAP CONSINCO.MAP_MARCA, TARGET CONSINCO.MAP_MARCA, FILTER ( @GETENV('TRANSACTION', 'CSN') > 487967354347);

   - start no replicat (action / start)
      - aguardar / verificar se ja comecou a replicacao (clicar em RNDW -> statistics), pode demorar alguns poucos minutos


0x000000811f914b17.


######---- comandos uteis


stop REPLICAT RNDW !
info REPLICAT RNDW

edit params RNDW
view params RNDW
start REPLICAT RNDW !
info REPLICAT RNDW
info REPLICAT RNDW detail


info extract EC5DB detail

stop extract EC5PRD !
info extract EC5PRD

edit params EC5PRD
view params EC5PRD
start extract EC5PRD
status extract EC5PRD
info extract EC5PRD detail



opatch apply /acfs01/acfs/patch/34713413  -online -connectString c5db2:sys:Cloud-Oba-2390:c5db2,c5db1:sys:Cloud-Oba-2390:c5db1

opatch apply /acfs01/acfs/patch/34713413  -online -connectString c5db2:sys:Cloud-Oba-2390:
Oracle Interim Patch Installer version 12.2.0.1.33
Copyright (c) 2024, Oracle Corporation.  All rights reserved.


Oracle Home       : /u02/app/oracle/product/19.0.0.0/dbhome_1
Central Inventory : /u01/app/oraInventory
   from           : /u02/app/oracle/product/19.0.0.0/dbhome_1/oraInst.loc
OPatch version    : 12.2.0.1.33
OUI version       : 12.2.0.7.0
Log file location : /u02/app/oracle/product/19.0.0.0/dbhome_1/cfgtoollogs/opatch/opatch2024-04-14_18-44-56PM_1.log

Verifying environment and performing prerequisite checks...
OPatch continues with these patches:   34713413

Do you want to proceed? [y|n]
y
User Responded with: Y
All checks passed.
Backing up files...

The patch should be applied/rolled back in '-all_nodes' mode only.
Converting the RAC mode to '-all_nodes' mode.
Applying interim patch '34713413' to OH '/u02/app/oracle/product/19.0.0.0/dbhome_1'

Patching component oracle.rdbms, 19.0.0.0.0...
Installing and enabling the online patch 'bug34713413.pch', on database 'c5db2'.

Patch 34713413 successfully applied.
Log file location: /u02/app/oracle/product/19.0.0.0/dbhome_1/cfgtoollogs/opatch/opatch2024-04-14_18-44-56PM_1.log

OPatch succeeded.

REDEOBA-EXACS-SP-NODE2-PRD:obaexaguax9m01-lo1lf2> (SID=c5db2)





2024-04-14T19:19:14.200144-03:00
LOGMINER: End   mining logfile for session 24 thread 2 sequence 51597, /acfs01/acfs/backup/golden_gate/c5db_2_51597_1120027036.arc
2024-04-14T19:19:14.310533-03:00
LOGMINER: Begin mining logfile for session 24 thread 2 sequence 51598, /acfs01/acfs/backup/golden_gate/c5db_2_51598_1120027036.arc
2024-04-14T19:19:36.104800-03:00
LOGMINER: End   mining logfile for session 24 thread 1 sequence 49742, /acfs01/acfs/backup/golden_gate/c5db_1_49742_1120027036.arc
2024-04-14T19:19:39.705973-03:00
LOGMINER: End   mining logfile for session 24 thread 2 sequence 51598, /acfs01/acfs/backup/golden_gate/c5db_2_51598_1120027036.arc
2024-04-14T19:19:48.622761-03:00
LOGMINER: Missing log for upstream capture session# 24, thread 2, sequence 51599, scn 0x0000007e15a8c57f
2024-04-14T19:19:49.447426-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), builder MS00 pid=251 OS id=275269 sid=5877 stopped
2024-04-14T19:19:49.447870-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), preparer MS03 pid=403 OS id=275276 sid=4423 stopped
2024-04-14T19:19:49.448428-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), preparer MS01 pid=257 OS id=275272 sid=7032 stopped
2024-04-14T19:19:49.448795-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), preparer MS02 pid=401 OS id=275274 sid=4005 stopped
2024-04-14T19:19:49.966754-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), reader H002 pid=407 OS id=275283 sid=5156 stopped
2024-04-14T19:19:50.158948-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), reader H001 pid=405 OS id=275281 sid=4793 stopped
2024-04-14T19:19:50.331123-03:00
LOGMINER: session#=24 (OGG$CAP_EC5DB), merger LX00 pid=125 OS id=275266 sid=4756 stopped
2024-04-14T19:19:50.619586-03:00

OGG Capture client successfully detached from GoldenGate Capture OGG$CAP_EC5DB (OS pid=275259).
2024-04-14T19:20:56.103519-03:00
GoldenGate Capture OGG$CAP_EC5DB cleared _SKIP_LCR_FOR_ASSERT
2024-04-14T19:20:56.103652-03:00
GoldenGate Capture OGG$CAP_EC5DB
setting IGNORE_UNSUPPORTED_TABLE for table (*)
2024-04-14T19:20:56.103787-03:00
GoldenGate Capture OGG$CAP_EC5DB setting _FILTER_PARTIAL_ROLLBACK:
2024-04-14T19:20:56.103838-03:00


list archivelog sequence 58869 thread=1;


SELECT SEQUENCE#, THREAD#, FIRST_TIME, NEXT_TIME, NAME
FROM V$ARCHIVED_LOG
WHERE SEQUENCE# > 58869
AND THREAD#=2
ORDER BY SEQUENCE#;

thread 01


thread 2
58870 - 59081



run{
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)';
 set archivelog destination to '/acfs01/acfs/golden_gate/';
       restore archivelog from logseq=58870 until logseq=59081 thread=2;
}



SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';

SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
   allocate channel d11 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d12 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d13 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d14 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d15 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d16 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d17 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d18 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d19 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d20 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d21 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d22 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   allocate channel d23 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u02/app/oracle/opc/lib/c5db/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/c5db/opcc5db.ora)' ;
   set archivelog destination to '/acfs01/acfs/golden_gate/';
       restore archivelog from logseq=58870 until logseq=59081 thread=2;
}


/acfs01/acfs/golden_gate/

58902 59278

59278 58975


58786
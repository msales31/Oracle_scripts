#!/bin/bash
source /home/oracle/for01.env
$ORACLE_HOME/perl/bin/perl $ORACLE_HOME/rdbms/admin/catcon.pl -b create_user -d /home/oracle/for -l /home/oracle/for/logs -e -C 'PDB$SEED CDB$ROOT' create_user.sql



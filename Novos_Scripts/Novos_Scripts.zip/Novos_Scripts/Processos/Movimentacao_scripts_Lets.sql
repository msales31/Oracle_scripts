
col text for a160
select sum(s.bytes)/1024/1024/1024 GB, case 
when e.segment_type='TABLE' then 
  'alter table '||e.owner||'.'||e.segment_name||' move online tablespace USERS parallel 8 update indexes;'
else e.segment_type
end as TEXT
from dba_extents e, dba_segments s
where e.tablespace_name = 'USERS'
and e.block_id>128
and e.file_id=223
and s.owner=e.owner
and s.segment_name=e.segment_name
and s.partition_name=e.partition_name 
--and s.segment_type='TABLE'
group by e.owner, e.segment_name,e.partition_name, e.tablespace_name, e.segment_type
order by sum(s.bytes);

col text for a160
select sum(s.bytes)/1024/1024/1024 GB, case 
when e.segment_type='TABLE' then 
  'alter table '||e.owner||'.'||e.segment_name||' move online tablespace USERS parallel 8 update indexes;'
end as TEXT 
from dba_extents e, dba_segments s
where e.tablespace_name = 'USERS'
and e.block_id>4194000
--and e.file_id=223
and s.owner=e.owner
and s.segment_name=e.segment_name
and s.partition_name=e.partition_name 
and s.segment_type='TABLE'
group by e.owner, e.segment_name,e.partition_name, e.tablespace_name, e.segment_type
order by sum(s.bytes);



## pra ver tamanho dos segmentos 
select sum(s.bytes)/1024/1024/1024 GB,
case 
  when e.segment_type like 'LOB%' then
    (select 'alter table '||l.owner||'.'||l.table_name||' move lob('||l.column_name||') store as (tablespace USERS) online parallel 8;' 
     from dba_lobs l where l.segment_name = e.segment_name)  
  when e.segment_type='TABLE' and e.partition_name is null then 
    'alter table '||e.owner||'.'||e.segment_name||' move online tablespace USERS parallel 8;'
  when e.segment_type='TABLE PARTITION' then 
    'alter table '||e.owner||'.'||e.segment_name||' move partition '||e.partition_name||' tablespace SMARTSRV_DADOS_GR parallel 8;'
  when e.segment_type='INDEX' and e.partition_name is null then 
    'alter index '||e.owner||'.'||e.segment_name||' rebuild tablespace USERS parallel 8 online; '||chr(10)||
    'alter index '||e.owner||'.'||e.segment_name||' noparallel;' 
  when e.segment_type='INDEX PARTITION' then 
    'alter index '||e.owner||'.'||e.segment_name||' rebuild partition '||e.partition_name||' tablespace USERS parallel 8 online; '||chr(10)||
    'alter index '||e.owner||'.'||e.segment_name||' noparallel;'
  else e.segment_type
end as TEXT
from dba_extents e, dba_segments s
where e.tablespace_name = 'USERS'
and e.block_id>4194000
and s.owner=e.owner
and s.segment_name=e.segment_name
group by e.owner, e.segment_name,e.partition_name, e.tablespace_name, e.segment_type
order by sum(s.bytes);


### pra fazer direto

select 
case 
  when e.segment_type like 'LOB%' then
    (select 'alter table '||l.owner||'.'||l.table_name||' move lob('||l.column_name||') store as (tablespace USERS) online parallel 8;' 
     from dba_lobs l where l.segment_name = e.segment_name)  
  when e.segment_type='TABLE' and e.partition_name is null then 
    'alter table '||e.owner||'.'||e.segment_name||' move online tablespace USERS parallel 8;'
  when e.segment_type='TABLE PARTITION' then 
    'alter table '||e.owner||'.'||e.segment_name||' move partition '||e.partition_name||' tablespace SMARTSRV_DADOS_GR parallel 8;'
  when e.segment_type='INDEX' and e.partition_name is null then 
    'alter index '||e.owner||'.'||e.segment_name||' rebuild tablespace USERS parallel 8 online; '||chr(10)||
    'alter index '||e.owner||'.'||e.segment_name||' noparallel;' 
  when e.segment_type='INDEX PARTITION' then 
    'alter index '||e.owner||'.'||e.segment_name||' rebuild partition '||e.partition_name||' tablespace USERS parallel 8 online; '||chr(10)||
    'alter index '||e.owner||'.'||e.segment_name||' noparallel;'
  else e.segment_type
end as TEXT
from dba_extents e, dba_segments s
where e.tablespace_name = 'USERS'
and e.block_id>4190000
group by e.owner, e.segment_name, e.partition_name, e.tablespace_name, e.segment_type
order by e.owner, e.segment_name, e.partition_name;




11,673


col text for a160
select sum(s.bytes)/1024/1024/1024 GB, case 
when e.segment_type like 'LOB%' then
  (select 'alter table '||l.owner||'.'||l.table_name||' move lob('||l.column_name||') store as (tablespace TSD_CONSINCO) online parallel 8;' 
  from dba_lobs l where l.segment_name = e.segment_name)  
when e.segment_type='TABLE' then 
  'alter table '||e.owner||'.'||e.segment_name||' move online tablespace TSD_CONSINCO parallel 8 update indexes;'
when e.segment_type='INDEX' then 
  'alter index '||e.owner||'.'||e.segment_name||' rebuild tablespace TSI_CONSINCO parallel 8; '||chr(10)||
  'alter index '||e.owner||'.'||e.segment_name||' noparallel;' 
else e.segment_type
end as TEXT
from dba_extents e, dba_segments s
where e.tablespace_name = 'TSD_CONSINCO'
and e.block_id>260000
and e.file_id=127
and s.owner=e.owner
and s.segment_name=e.segment_name
group by e.owner, e.segment_name,e.partition_name, e.tablespace_name, e.segment_type
order by sum(s.bytes);




4194288



select max(block_id),min(block_id) from dba_extents where tablespace_name='USERS';

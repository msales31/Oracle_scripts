Para configurar um compartilhamento NFS de uma partição chamada /backup/ no servidor 192.168.168.200 para o servidor 192.168.168.206 no Oracle Linux, siga estas etapas:

No Servidor 192.168.168.200:

Instale os pacotes necessários:
Certifique-se de que o servidor NFS esteja instalado no servidor 192.168.168.200. Execute o seguinte comando para instalar os pacotes necessários:

bash
Copy code
sudo yum install nfs-utils
Configure o compartilhamento NFS:
Edite o arquivo /etc/exports para adicionar a configuração do compartilhamento NFS. Adicione a seguinte linha:

bash
Copy code
/backup/ 192.168.168.206(rw,sync,no_root_squash)
Isso permite ao servidor 192.168.168.206 ler e gravar no compartilhamento /backup/. Salve e feche o arquivo.

Inicie e habilite o serviço NFS:
Inicie o serviço NFS e configure-o para iniciar automaticamente durante o boot:

bash
Copy code
sudo systemctl start nfs-server
sudo systemctl enable nfs-server
Abra as portas necessárias no firewall:
Se o firewall estiver habilitado, abra as portas necessárias para o NFS:

bash
Copy code
sudo firewall-cmd --permanent --zone=public --add-service=nfs
sudo firewall-cmd --reload
No Servidor 192.168.168.206:

Instale os pacotes necessários:
Instale o cliente NFS no servidor 192.168.168.206:

bash
Copy code
sudo yum install nfs-utils
Monte o compartilhamento NFS:
Crie um ponto de montagem e monte o compartilhamento:

bash
Copy code
sudo mkdir /mnt/backup
sudo mount -t nfs 192.168.168.200:/backup/ /mnt/backup
Verifique o compartilhamento:
Verifique se o compartilhamento foi montado corretamente:

bash
Copy code
df -h
Você deve ver o compartilhamento montado em /mnt/backup.

Configure a montagem automática (opcional):
Para montar o compartilhamento automaticamente durante a inicialização, adicione uma entrada ao arquivo /etc/fstab:

bash
Copy code
192.168.168.200:/backup/   /mnt/backup   nfs   defaults   0 0
Salve e feche o arquivo.

Agora, o servidor 192.168.168.206 deve ter acesso ao diretório /backup/ do servidor 192.168.168.200 via NFS. Certifique-se de ajustar as configurações conforme necessário para atender aos requisitos específicos do seu ambiente.




sudo mount -t nfs 10.1.1.112:/projedata/ /projedata

10.1.1.112:/projedata                         /projedata      nfs    defaults,noatime,_netdev                0 0

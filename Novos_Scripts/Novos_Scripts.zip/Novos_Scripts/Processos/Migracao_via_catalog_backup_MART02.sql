[17:06] Everton Bentlin

Origem: kmm-srvmart02

destino: kmm-srvmart01

 

- desativar jobs do rundeck (antigo)

- desativar host no zabbix (antigo)

- checkpoint / switch logfile / ARCHIVE LOG CURRENT

- job_queue = 0

- Shutdown origem (srvctl)

- startup restrict (srvctl)

- checkpoint / switch logfile / ARCHIVE LOG CURRENT

- Shutdown origem (srvctl)

- Startup Mount (srvctl)

- Roda backup archive (rundeck)

- Recover no destino usando catalog

- open resetlogs

- Aplicar datapatch

- utlrp

- Valida (atencao no java, dba_registry)

- job_queue = x

- stop / start destino (srvctl)

- conectar no catalog e fazer upgrade

   rman

   connect target /

   connect catalog rc_mart02/RC_mart02_kmm2020@RCAT01

   upgrade catalog ;

   crosscheck archivelog

- apagar groupos de redo 1,2,3

- ajustar monitoramento / zabbix (novo) (fazer discover, etc e por fim add tamplate Template Primedb Zabbix Sender v3)

- ativar jobs do rundeck (novo) e validar

 


Domingo, inicio as 08h, final 12h

connect target /

connect catalog rc_mart02/RC_mart02_kmm2020@RCAT01

SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';

RUN {

   allocate channel d11 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/mart02/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/mart02/opcmart02.ora)';

   allocate channel d12 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/mart02/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/mart02/opcmart02.ora)';

   allocate channel d13 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/mart02/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/mart02/opcmart02.ora)';

   allocate channel d14 type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/mart02/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/mart02/opcmart02.ora)';

   recover database delete archivelog;

}

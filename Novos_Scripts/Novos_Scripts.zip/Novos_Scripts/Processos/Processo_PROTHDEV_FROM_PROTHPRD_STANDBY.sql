#####################################################################################################################################################
#####
####      Procedimento para qualquer  atualizacao de bases teste
#####





#################################################################
##-- salvar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/acfs01/acfs/temp/chamado_220192';
spool /acfs01/acfs/temp/chamado_220192/dbnameuserpass.sql
SELECT 'ALTER USER "' || username || '"' ||
  DECODE (password,
          'EXTERNAL',' IDENTIFIED EXTERNALLY',
          'GLOBAL',' IDENTIFIED GLOBALLY AS ''' || external_name,
          ' IDENTIFIED BY VALUES '||''''||(SELECT PASSWORD FROM SYS.USER$ WHERE NAME = u.username )||'''') ||' account unlock;'
FROM dba_users u
WHERE username NOT IN
         ('ANONYMOUS','CTXSYS','DBSNMP','DIP','DMSYS','EXFSYS','HR','IX','LBACSYS','BACKUPDUMP','USERBKP','BKPUSER',
          'MDDATA','MDSYS','ODM','ODM_MTR','OE','OLAPSYS','ORDPLUGINS','ORDSYS','OUTLN','OWNER','PM','QS','QS_ADM',
          'QS_CB','QS_CBADM','QS_CS','QS_ES','QS_OS','QS_WS','RECOVER','SCOTT','SH','SI_INFORMTN_SCHEMA','SYS',
          'SYSMAN','SYSTEM','TSMSYS','USERBKP','WKPROXY','WKSYS','WMSYS','XDB','ORACLE_OCM','XS$NULL','APPQOSSYS')
ORDER BY username;
spool off
_SQL_


##--- export dos usuarios
expdp msales/msales123@172.25.1.204:1521/PROTHDEV \
DIRECTORY=dprefresh \
DUMPFILE=dbname-users%U.dmp \
LOGFILE=dbname-exp-users.log \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=USER \
INCLUDE=SYSTEM_GRANT \
INCLUDE=ROLE_GRANT \
INCLUDE=TABLESPACE_QUOTA \
INCLUDE=GRANT


##--- export dos dblinks
expdp msales/msales123@172.25.1.204:1521/PROTHDEV \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=exp_dbnamedblinks.log \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=DB_LINK:"\"IN(SELECT db_link FROM dba_db_links)\""



##### CRIAR DBLINK

CREATE PUBLIC DATABASE LINK LINK_STANDBY  msales identified by msales123 


### DROPAR/CRIAR PDB


sqlplus / as sysdba << eof
alter pluggable database PROTHDEV close immediate instances=all;
drop pluggable database PROTHDEV including datafiles;
CREATE PLUGGABLE DATABASE PROTHDEV FROM NON$CDB@PROTHPRD_EXACS02.NETBANCO.MADEROVCNLAN.ORACLEVCN.COM KEYSTORE identified by "Cloud-Madero-2390" including shared key parallel 12;
alter session set container=PROTHDEV;
ADMINISTER KEY MANAGEMENT SET KEYSTORE OPEN IDENTIFIED BY "Cloud-Madero-2390" Container =Current;
alter pluggable database PROTHDEV open ;
@?/rdbms/admin/noncdb_to_pdb.sql
alter pluggable database PROTHDEV close immediate instances=all ;
alter pluggable database PROTHDEV open instances=all;
alter pluggable database PROTHDEV save state instances=all;
exit
eof 




ADMINISTER KEY MANAGEMENT CREATE AUTO_LOGIN KEYSTORE FROM KEYSTORE '/var/opt/oracle/dbaas_acfs/prothdtq/wallet_root/tde/' IDENTIFIED BY "Cloud-Madero-2390";



administer key management set keystore close identified by "Cloud-Madero-2390";

   administer key management set keystore open  identified by "Cloud-Cat-2390#" ;



 EXECUTAR APENAS EM BASES QUE O CLIENTE SOLICITE OS PASSOS ABAIXO



#####################################################################################################################################################
#####
####      depois de atualizar a base, executar os procedimentos abaixo **** NA BASE TESTE ****


###

##-- restaurar senhas atuais
sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
create or replace directory dprefresh as '/acfs01/acfs/temp/chamado_220192';
@/acfs01/acfs/temp/chamado_220192/dbnameuserpass.sql
_SQL_

spool /backup/dbname/rman/dropdblinks.sql
begin
for o in (select distinct owner from dba_db_links where owner<>'PUBLIC' order by 1) loop
   DBMS_OUTPUT.PUT_LINE('CREATE PROCEDURE '||o.owner||'.drop_db_link AS' );
   DBMS_OUTPUT.PUT_LINE('BEGIN' );
   for d in (select distinct DB_LINK from dba_db_links where owner=o.owner order by 1) loop
      DBMS_OUTPUT.PUT_LINE('EXECUTE IMMEDIATE ''drop database link '||d.DB_LINK||''';');
   end loop;
   DBMS_OUTPUT.PUT_LINE('END drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('/');
   DBMS_OUTPUT.PUT_LINE('EXEC '||o.owner||'.drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('DROP PROCEDURE '||o.owner||'.drop_db_link;');
   DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------');
end loop;

for d in (select distinct DB_LINK from dba_db_links where owner='PUBLIC' order by 1) loop
  DBMS_OUTPUT.PUT_LINE('drop public database link '||d.DB_LINK||';');
end loop;

end;
/
spool off

@/backup/dbname/rman/dropdblinks.sql



##--- import dos dblinks
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=imp_dbnamedblinks.log


##--- import dos usuarios
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-users%U.dmp \
LOGFILE=dbname-imp-users.log \
INCLUDE=SCHEMA:"\"NOT IN(SELECT USERNAME FROM DBA_USERS)\"" 


sqlplus -S /nolog << '_SQL_'
conn / as sysdba
set verify off echo off feedback off heading off pagesize 0 linesize 130 trimout on trimspool on termout off
@$ORACLE_HOME/rdbms/admin/utlrp.sql
'_SQL_'
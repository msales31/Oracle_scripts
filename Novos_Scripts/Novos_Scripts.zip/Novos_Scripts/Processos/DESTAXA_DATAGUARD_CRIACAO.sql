 create index SIGA.IDX$$_PRM01 on SIGA.SD3010("D3_CHVNFE","D3_FILIAL","D3_TM");




/opt/oracle/dcs/commonstore/wallets/cdbprod_vcp01/tde/


2 rows selected.

Elapsed: 00:00:00.00
12:05:51 SYS@cdbprd>
NAME                                |TYPE       |VALUE
ssl_wallet                          |string     |
wallet_root                         |string     |/opt/oracle/dcs/commonstore/wa
                                    |           |llets/cdbprd_vcp01
12:05:52 SYS@cdbprd>




###

list backup of controlfile completed between "to_date('16/12/2025 00:00:00','DD/MM/YYYY HH24:MI:SS')" and "to_date('16/12/2025 23:00:00','DD/MM/YYYY HH24:MI:SS')";

BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ -------------------
195883  Full    11.50M     SBT_TAPE    00:00:05     17/12/2025 08:51:47
        BP Key: 195883   Status: AVAILABLE  Compressed: YES  Tag: ARCHIVEHORARIO202512170850
        Handle: rman_ctrl_cdbprod_ARCHIVE_dbid4204416914_s198369_t1220086302_p1.bkp   Media: objectstorag~.sa-saopaulo~.oraclecloud.com/n/gri~/Backup-CDBPROD
  Control File Included: Ckp SCN: 23465405459   Ckp time: 17/12/2025 08:51:42






rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
restore CONTROLFILE from 'rman_ctrl_cdbprod_ARCHIVE_dbid4204416914_s198369_t1220086302_p1.bkp';
}
ALTER DATABASE MOUNT;
__RMAN__


rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
spool log to '/tmp/restore01.log';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c6 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c7 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c8 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c9 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c10 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c11 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c12 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c13 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
allocate channel c14 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/CDBPROD/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/CDBPROD/opcCDBPROD.ora)';
RECOVER DATABASE;
}
__RMAN__





RUN{
set newname for database to new;
ALLOCATE CHANNEL prim1 TYPE DISK;
ALLOCATE CHANNEL prim2 TYPE DISK;
ALLOCATE CHANNEL prim3 TYPE DISK;
ALLOCATE CHANNEL prim4 TYPE DISK;
ALLOCATE CHANNEL prim5 TYPE DISK;
ALLOCATE CHANNEL prim6 TYPE DISK;
ALLOCATE CHANNEL prim7 TYPE DISK;
ALLOCATE CHANNEL prim8 TYPE DISK;
ALLOCATE CHANNEL prim9 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux1 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux2 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux3 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux4 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux5 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux6 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux7 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux8 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux9 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux10 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux11 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux12 TYPE DISK;
DUPLICATE TARGET DATABASE FOR STANDBY FROM ACTIVE DATABASE DORECOVER NOFILENAMECHECK;
}


/u01/app/oracle/product/11.2.0.4/dbhome_3/dbs] srvctl add database -d config_grustb -o /u01/app/oracle/product/11.2.0.4/dbhome_3 -p /u01/app/oracle/product/11.2.0.4/dbhome_3/spfileconfig.ora -s MOUNT -t IMMEDIATE -i config


rman target sys/"hVzZEwrs##198"@ auxiliary sys/"hVzZEwrs##198"@CDBDR01
#- spool log to /home/oracle/duplicate.log
run {
allocate channel prmy1 type disk;
allocate channel prmy2 type disk;
allocate channel prmy3 type disk;
allocate channel prmy4 type disk;
allocate channel prmy5 type disk;
allocate channel prmy6 type disk;
allocate channel prmy7 type disk;
allocate channel prmy8 type disk;
allocate channel prmy9 type disk;
allocate channel prmy10 type disk;
allocate channel prmy11 type disk;
allocate auxiliary channel stby1 type disk;
allocate auxiliary channel stby2 type disk;
allocate auxiliary channel stby3 type disk;
allocate auxiliary channel stby4 type disk;
allocate auxiliary channel stby5 type disk;
allocate auxiliary channel stby6 type disk;
allocate auxiliary channel stby7 type disk;
allocate auxiliary channel stby8 type disk;
allocate auxiliary channel stby9 type disk;
allocate auxiliary channel stby10 type disk;
allocate auxiliary channel stby11 type disk;
   DUPLICATE TARGET DATABASE
      FOR STANDBY
      FROM ACTIVE DATABASE
      DORECOVER;
	  
	  
	  run{
	  allocate channel prmy1 type disk;
	  backup current controlfile for standby format '';
      }

set controlfile autobackup off;

run{
allocate channel t1 device type disk;
set controlfile autobackup format for device type disk to '/tmp/%F';
restore standby controlfile from '/tmp/cf_autobak_b22c50gg_89442_1_1';
}

restore controlfile from autobackup db_recovery_file_dest='/tmp/%F' db_name=CDB01;


set controlfile autobackup format for device type disk to'/u01/autobackup/%F';
set controlfile autobackup format for device type disk to '/tmp/%F';


Sem Gaps:
   DEST_ID SYSDATE             THREAD# ULTIMO RECEBIDO ULTIMO APLICADO LAST_APP_TIMESTA   ARC_DIFF
---------- ---------------- ---------- --------------- --------------- ---------------- ----------
         2 21/11/2023 23:50          1           71798           71798 21/11/2023 23:30          0

Processos:
   INST_ID PROCESS      THREAD#  SEQUENCE#     BLOCK# STATUS       CLIENT_P
---------- --------- ---------- ---------- ---------- ------------ --------
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 DGRD               0          0          0 ALLOCATED    N/A
         1 DGRD               0          0          0 ALLOCATED    N/A
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 RFS                1          0          0 IDLE         Archival
         1 RFS                1      71799      68034 RECEIVING    LGWR
         1 MRP0               1      71796      87772 APPLYING_LOG N/A


Configuração Standby:

NAME                      VALUE
------------------------- ------------------------------------------------------------------------------------------------------------------------
log_archive_dest_1        LOCATION=USE_DB_RECOVERY_FILE_DEST  MANDATORY REOPEN VALID_FOR=(ALL_ROLES, ALL_LOGFILES) db_unique_name=CDBDR01_b24_gru
log_archive_dest_2        service=CDB01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDB01_vcp1jx
log_archive_dest_3
log_archive_dest_4
log_archive_dest_state_2  enable
log_archive_dest_state_3  enable
log_archive_dest_state_4  enable
fal_client                CDBDR01
fal_server                CDB01
log_archive_config        DG_CONFIG=(CDBDR01_b24_gru,CDB01_vcp1jx)
log_archive_format        %t_%s_%r.dbf
log_archive_max_processes 4
standby_file_management   AUTO
remote_login_passwordfile EXCLUSIVE
db_name                   CDB01
db_unique_name            CDBDR01_b24_gru


Configuração Primary:

NAME                      VALUE
------------------------- ---------------------------------------------------------------------------------------------------
log_archive_dest_1        location=USE_DB_RECOVERY_FILE_DEST valid_for=(ALL_LOGFILES,ALL_ROLES) db_unique_name=CDB01_vcp1jx
log_archive_dest_2        service=CDBDR01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDBDR01_b24_gru
log_archive_dest_3
log_archive_dest_4
log_archive_dest_state_2  ENABLE
log_archive_dest_state_3  enable
log_archive_dest_state_4  enable
fal_client                CDB01
fal_server                CDBDR01
log_archive_config        dg_config=(CDB01_vcp1jx,CDBDR01_b24_gru,cdbdr01_gru155)
log_archive_format        %t_%s_%r.dbf
log_archive_max_processes 4
standby_file_management   AUTO
remote_login_passwordfile EXCLUSIVE
db_name                   CDB01
db_unique_name            CDB01_vcp1jx




rman <<EOF
connect target sys/hVzZEwrs##198@;
connect auxiliary sys/hVzZEwrs##198@dup;
run {
allocate channel prmy1 type disk;
allocate channel prmy2 type disk;
allocate channel prmy3 type disk;
allocate channel prmy4 type disk;
allocate channel prmy5 type disk;
allocate channel prmy6 type disk;
allocate channel prmy7 type disk;
allocate channel prmy8 type disk;
allocate channel prmy9 type disk;
allocate channel prmy10 type disk;
allocate channel prmy11 type disk;
DUPLICATE TARGET DATABASE FOR STANDBY FROM ACTIVE DATABASE DORECOVER NOFILENAMECHECK;
}
EOF


###################################################################################################################
#######
###                              Criar DG sem Broker


###########################################################
##
##     adicionar redos standby (se ainda nao tem )
##        mesma quantidade e tamanho de redos existente

alter database add standby logfile group 911 size 500M;
alter database add standby logfile group 912 size 500M;
alter database add standby logfile group 913 size 500M;
alter database add standby logfile group 914 size 500M;
alter database add standby logfile group 915 size 500M;
alter database add standby logfile group 916 size 500M;

alter database add standby logfile group 917 size 2048M;
alter database add standby logfile group 918 size 2048M;


###########################333###########################################################
##
##     configurar listener e tnsnames
##        (primary e standby)


##########################################
#-- adicionar entrada no listener


#-- se NAO tem uma network de dr/backup, adicionar entrada no listener default

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

SID_LIST_LISTENER =
    (SID_LIST =
	   (SID_DESC =
	        (GLOBAL_DBNAME=rumo01_bm04)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/stdone)
		    (SID_NAME=pano01)
	    )
	)

lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status



#--- OU se TEM uma network de dr/backup configurar um listener separado


[/home/grid] srvctl add listener -l LISTENERDG -p TCP:1599


export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

LISTENER_DG =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = srvora02)(PORT = 1599))
    )
  )

SID_LIST_LISTENER_DG =
    (SID_LIST=
	   (SID_DESC=
	        (GLOBAL_DBNAME=cdbprod_vcp01)
	        (ORACLE_HOME=/u01/app/oracle/product/19.0.0.0/dbhome_1)
		    (SID_NAME=cdbprod)
	    )
	)


lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status


#-- adicionar entrada no tnsnames (verificar qual tns a base usa) dois dois lados

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/tnsnames.ora

cdbprod_gru01 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 10.13.100.80)(PORT = 1599))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = cdbprod_gru01.db.destaxagru.oraclevcn.com)
      (UR = A)
    )
  )

cdbprod_vcp01 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 10.14.100.36)(PORT = 1599))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = cdbprod_vcp01.db.destaxavcp.oraclevcn.com)
      (UR = A)
    )
  )



local_listener                                              |string     | (ADDRESS=(PROTOCOL=TCP)(HOST=172.25.1.36)(PORT=1521)), (ADDRESS=(PROTOCOL=TCP)(HOST=172.25.1.36)(PO
                                                            |           |RT=1599)), (ADDRESS=(PROTOCOL=TCPS)(HOST=172.25.1.36)(PORT=2484))


alter system set local_listener='(ADDRESS=(PROTOCOL=TCP)(HOST=10.14.100.36)(PORT=1521)), (ADDRESS=(PROTOCOL=TCP)(HOST=10.14.100.36)(PORT=1599)), (ADDRESS=(PROTOCOL=TCPS)(HOST=10.14.100.36)(PORT=2484))';




###################################################################################################################
#######
###                              Copiar o pwdfile da producao para o standby

mv /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01 /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01.ori
scp $ORACLE_HOME/dbs/orapwpano01 152.67.45.93:/u01/app/oracle/product/11.2.0.4/dbhome_3/dbs



###################################################################################################################
#######
###                              Testar e validar conexao dos dois lados


conn sys/"hVzZEwrs##198"@rumo01_dbcs as sysdba
select host_name,STATUS from v$instance;


conn sys/"hVzZEwrs##198"@rumo01_bm04 as sysdba
select host_name,STATUS from v$instance;


###################################################################################################################
#######
###                              Duplicate

#. TARGET     = banco origem
#. AUXILIARY  = banco destino

connect target sys/"hVzZEwrs##198"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.221.3.2)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A))) auxiliary sys/"hVzZEwrs##198"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))

rman target sys/"hVzZEwrs##198"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.32)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A)))" auxiliary sys/"hVzZEwrs##198"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))"
#- spool log to /home/oracle/duplicate.log
run {
   allocate channel prmy1 type disk;
   allocate channel prmy2 type disk;
   allocate channel prmy3 type disk;
   allocate channel prmy4 type disk;
   allocate auxiliary channel stby1 type disk;
   DUPLICATE TARGET DATABASE
      FOR STANDBY
      FROM ACTIVE DATABASE
      DORECOVER;
}




###################################################################################################################
#######
###                              Configurar DG sem broker


##########################################
#-- no primary

alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- verificar se foram adicionados redos standby (mesmo numero de grupos e tamanho dos atuais)


#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_3='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(cdbprod_gru01,cdbprod_vcp01)'; -- DBUNIQUE PROD,DBUNIQUE STANDBY 

PARAMETER_NAME                                              |TYPE       |VALUE
fal_client                                                  |string     |CDBPROD_SGL
fal_server                                                  |string     |CDBPROD_RAC

log_archive_config                                          |string     |DG_CONFIG=(cdbprod_gru01,CDBPROD_gru12k)

NAME                                |TYPE       |VALUE
log_archive_config                  |string     |dg_config=(CDB01_vcp1jx,CDBDR0
                                    |           |1_b24_gru,cdbdr01_gru155)


#- tns do outro db (nesse caso standby)
alter system set fal_server='cdbprod_vcp01';

#- tns do proprio db (nesse caso primary)


alter system set fal_client='cdbprod_gru01';

#-configurar log dest do standby
alter system set log_archive_dest_3='SERVICE=cdbprod_vcp01 LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=cdbprod_vcp01'; 

log_archive_dest_2                                          |string     |service=CDBPROD_RAC lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDBPROD_gru12k




service=CDBDR01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDBDR01_b24_gru

#- ativar log shipping (*** depois de tudo configurado)
alter system set log_archive_dest_state_2='ENABLE' scope=both;


###- se for DG cascade (3 nos)
##-- alter system set log_archive_dest_3='SERVICE=pano01_bm02 VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01_gru1nw';
##-- alter system set log_archive_dest_state_3='ENABLE';



##########################################
#-- no standby


alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_3='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(cdbprod_vcp01,cdbprod_gru01)'; -- STANDBY,PROD

#- tns do outro db (nesse caso primary)
alter system set fal_server='cdbprod_gru01';

#- tns do proprio db (nesse caso standby)
alter system set fal_client='cdbprod_vcp01';

#-configurar log dest do standby
alter system set log_archive_dest_3='SERVICE=cdbprod_gru01 LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=cdbprod_gru01';

service=CDB01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDB01_vcp1jx

###- se for DG cascade (3 nos)
### alter system set log_archive_dest_3='SERVICE= VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01';


#- start recover no standby (com standby redo)
alter database recover managed standby database disconnect using current logfile;




###################################################################################################################
#######
###                              script para apagar archives

echo $ORACLE_BASE
export ORACLE_BASE=/u01/app/oracle
mkdir -p $ORACLE_BASE/admin/scripts/
vi $ORACLE_BASE/admin/scripts/deletearchive

export ORACLE_SID=$1
ORAENV_ASK=NO
. oraenv

export NLS_DATE_FORMAT='DD/MM/YYYY HH24:MI:SS';
$ORACLE_HOME/bin/rman target / nocatalog << EOF >> /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log
   spool log to /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log;
   CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON ALL STANDBY;
   show all;
   DELETE noprompt archivelog until time 'sysdate-1';
EOF

chmod +x $ORACLE_BASE/admin/scripts/deletearchive

/u01/app/oracle/admin/scripts/deletearchive

20  08,20  * * *    root  su - oracle -c "/u01/app/oracle/admin/scripts/deletearchive vial01"

###################################################################################################################
#######
###                              Virada DG com SwitchOver



###########################################################
##
##     no primary
##

#- verificar o switchover_status
# -->>> A value of TO STANDBY or SESSIONS ACTIVE indicates that the primary database can be switched to the standby role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

# -->>> RECOVERY_MODE = MANAGED REAL TIME APPLY (recover ativo no standby)
# -->>> GAP_STATUS = NO GAP

col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id, DB_UNIQUE_NAME, DATABASE_MODE, recovery_mode, status, TYPE, gap_status, ARCHIVED_SEQ#, ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;

#- executar commit to switchover
alter database commit to switchover to physical standby with session shutdown;

#- montar o banco como standby
conn / as sysdba
startup nomount;
alter system set log_archive_dest_state_2='DEFER' ;
alter system set job_queue_processes=0;
alter database mount standby database;



###########################################################
##
##      no standby
##


#- verificar staus switchover_status
#->>> A value of TO PRIMARY or SESSIONS ACTIVE indicates that the standby database is ready to be switched to the primary role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

#- executar o switchover to primary
alter database commit to switchover to primary with session shutdown;


#- abrir o banco
-->>>> verificar parametro UNDO
alter database open;


#- ativar o log shipping para o antigo primary (se estiver tudo corretamente configurado)
alter system set log_archive_dest_state_2='ENABLE' ;


SELECT THREAD#, LOW_SEQUENCE#, HIGH_SEQUENCE# FROM V$ARCHIVE_GAP;


alter system set job_queue_processes=1000;





ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 7;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 8;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 9;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 10;


ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  7;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  8;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  9;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 10;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 11;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 12;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 13;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 14;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 15;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 16;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 17;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 18;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 19;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 20;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 21;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 22;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 23;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 24;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 25;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 26;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 27;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 28;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 29;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 30;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 31;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 32;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 60;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 61;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 70;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 71;


contents of Memory Script:
{
   backup as copy reuse
   passwordfile auxiliary format  '/u01/app/oracle/product/19.0.0.0/dbhome_1/dbs/orapwCDB01'   ;
}
executing Memory Script

Starting backup at 2023/11/22 17:55:19
Finished backup at 2023/11/22 17:55:20
duplicating Online logs to Oracle Managed File (OMF) location
duplicating Datafiles to Oracle Managed File (OMF) location

contents of Memory Script:
{
   sql clone "alter system set  control_files =
  ''+RECO/CDB01_JQD_GRU/CONTROLFILE/current.259.1153590921'' comment=
 ''Set by RMAN'' scope=spfile";
   restore clone from service  'CDB01' standby controlfile;
}
executing Memory Script

sql statement: alter system set  control_files =   ''+RECO/CDB01_JQD_GRU/CONTROLFILE/current.259.1153590921'' comment= ''Set by RMAN'' scope=spfile

+RECO/CDB01_JQD_GRU/CONTROLFILE/current.257.1153590925

backup current controlfile for standby format 'control_bkp01.ctl';

Starting restore at 2023/11/22 17:55:21

channel stby1: starting datafile backup set restore
channel stby1: using network backup set from service CDB01
channel stby1: restoring control file
channel stby1: restore complete, elapsed time: 00:00:02






col id for 99
col destination for a40
col sequence for 99999999999
col tmode for a12
col error for a40
select dest_id id,
DESTINATION,
LOG_SEQUENCE sequence,
TRANSMIT_MODE tmode,
DELAY_MINS,
STATUS,
error
from v$archive_dest
where DESTINATION is not null
order by dest_id;





col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id,
DB_UNIQUE_NAME,
DATABASE_MODE,
recovery_mode,
STANDBY_LOGFILE_COUNT stdlogfile,
status,
TYPE,
gap_status,
ARCHIVED_SEQ#,
ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;



col id for 99
col message for a125
select DEST_ID ID,
to_char(timestamp,'DD/MM/YYYY HH24:MI:SS')||' '||message message
from v$dataguard_status;


select distinct process, status, thread#, sequence#, block#, blocks from v$managed_standby ;






+DATA/config_grustb/datafile/



ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  911;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  912;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  913;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  914;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  915;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  916;



186.235.130.114
p - 10052

186.235.130.114
p - 10053


Host andrade-srvoda01
HostName 186.235.130.113
Port 11022
--
Host andrade-srvoda02
HostName 186.235.130.113
Port 21022
#####



Pra ver se estou certo:

 

1- validar comunicação do host para o bridge novo


2- parar o monitoramento no antigo

3 - Excluir o zabbix-agent  no servidor

3 - Create zabbix host RUNDECK

4 - INstalar java 

5- 2.1 - Install Zabbix Agent and Sender with Oracle DB V3


5 - criar o usuário PRIMEDB_zabbix nas instancia e no asm

6 - vincular os templates

7 - fazer testes de sender (discover) obs: se tiver asm validar oratab e deve conectar primeiro nele

8 - vincular o ultimo template

9 - conf dos jobs do rundeck




#- template Geral (qualquer banco, colocar por ultimo, depois de ter feito todo procedimento)
Template Primedb Zabbix Sender v3	

#- templates de Oracle
Template Oracle Primary Database V3	
Template Oracle Standby Database v3
Template Oracle Pluggable database V3	
Template Oracle ASM V3	
Template Oracle Rman V3
Template Rundeck



###########################################################
##
## ---- Criar usuario primedb.rundeck
##   
##

{ userdel -r rundeck; userdel primedb.rundeck; D=/home/primedb.rundeck; mkdir -p $D/.ssh;
useradd -M -d $D -s /bin/bash -c 'primedb.rundeck - PrimeDB Rundeck User' -g wheel primedb.rundeck;
cat << '__' > $D/.ssh/authorized_keys;
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDVBAyLXrMUFxNGC7oiF6j3xdhBzkQx48BPxeyZ4f7XwlHyF642AkjEMIVrGn4HGiYVlEZpePeMqKyb9DUlxUc+Gfa4Gj5UcQedkHPuIOITzbdZm4HulxagIY34eZAjEovIZIwHTYgMSgMTlPxvDkTpXXK1L5sK3PfLU4qStKWPtT2nHe0y2Isi7wsvltSO6E7mdTA7Ms/Ql8YoyUTgaW9eCkN6LdM6XcKWE1Q+ruHBCNenhPg5mSF5wDDXpIzisictDoy01QuXQ0rrRNby9t27X4bl1aP4UQECap8fWlIm72mcLmr+WeV4rvLcKkSjnZ+4ZiClloqm1qndg/L7xOxj primedb.rundeck@srvprimedb.rundeck
__
chown primedb.rundeck:wheel $D $D/.ssh $D/.ssh/authorized_keys;
chmod 0750 $D;
chmod 0700 $D/.ssh;
chmod 0644 $D/.ssh/authorized_keys;
id primedb.rundeck;
##-- password noexpire
chage -m 0 -M 99999 -I -1 -E -1 primedb.rundeck
#- permisao para executar su - root
chmod 4755 /bin/su
};

#-testar se usa AllowUsers e configurar
if [ $(grep -cEw '^AllowUsers' /etc/ssh/sshd_config) -gt 0 ]; then
   if [ $(grep -cEw "^AllowUsers primedb rundeck" /etc/ssh/sshd_config) -eq 1 ] ; then 
      sed -i 's/AllowUsers primedb rundeck/AllowUsers primedb primedb.rundeck/g' /etc/ssh/sshd_config
      service sshd restart;
   fi
   if [ $(grep -cEw "^AllowUsers primedb primedb.rundeck" /etc/ssh/sshd_config) -eq 0 ]; then 
      echo " " >> /etc/ssh/sshd_config; 
      echo "##-- Users PRIMEDB " >> /etc/ssh/sshd_config; 
      echo "AllowUsers primedb primedb.rundeck" >> /etc/ssh/sshd_config; 
      service sshd restart;
   fi
fi

######################################################################################
#
##-- oracle 11g e 12g sem pdb
#

CREATE USER PRIMEDB_ZABBIX IDENTIFIED BY Prm#2022#zbxV3;
create role PRIMEDB_RZABBIX ;
GRANT create session TO PRIMEDB_RZABBIX;
GRANT SELECT ANY DICTIONARY TO PRIMEDB_RZABBIX;
grant select on DBA_DATA_FILES  to PRIMEDB_RZABBIX;
grant select on DBA_FREE_SPACE  to PRIMEDB_RZABBIX;
grant select on DBA_INDEXES     to PRIMEDB_RZABBIX;
grant select on DBA_SEGMENTS    to PRIMEDB_RZABBIX;
grant select on DBA_TABLESPACES to PRIMEDB_RZABBIX;
grant select on DBA_TEMP_FILES  to PRIMEDB_RZABBIX;
grant select on GV_$INSTANCE    to PRIMEDB_RZABBIX;
grant select on GV_$LOCK        to PRIMEDB_RZABBIX;
grant select on GV_$PARAMETER   to PRIMEDB_RZABBIX;
grant select on GV_$SESSION     to PRIMEDB_RZABBIX;
grant select on V_$INSTANCE     to PRIMEDB_RZABBIX;
grant select on V_$LOCK         to PRIMEDB_RZABBIX;
grant select on V_$PARAMETER    to PRIMEDB_RZABBIX;
grant select on V_$SESSION      to PRIMEDB_RZABBIX;
grant select on sys.V_$PDBS to PRIMEDB_RZABBIX;
grant select on sys.gV_$PDBS to PRIMEDB_RZABBIX;


#-11g >
grant sysdba, PRIMEDB_RZABBIX to PRIMEDB_ZABBIX ;
grant sysdg, PRIMEDB_RZABBIX to PRIMEDB_ZABBIX ;

#-12c >
grant sysdg, PRIMEDB_RZABBIX to PRIMEDB_ZABBIX;
grant sysdba, PRIMEDB_RZABBIX to PRIMEDB_ZABBIX;


pwcopy /tmp/orapwcdblog_oda02 +DATA/CDBLOG_ODA02/PASSWORD/

######################################################################################
#
##-- oracle 12g com pdb
#
CREATE USER c##primedb_zabbix IDENTIFIED BY Prm#2022#zbxV3;
create role C##PRIMEDB_RZABBIX CONTAINER=ALL;

GRANT create session            TO C##PRIMEDB_RZABBIX CONTAINER=ALL;
GRANT SELECT ANY DICTIONARY     TO C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on DBA_DATA_FILES  to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on DBA_FREE_SPACE  to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on DBA_INDEXES     to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on DBA_SEGMENTS    to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on DBA_TABLESPACES to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on DBA_TEMP_FILES  to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on GV_$INSTANCE    to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on GV_$LOCK        to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on GV_$PARAMETER   to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on GV_$SESSION     to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on V_$INSTANCE     to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on V_$LOCK         to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on V_$PARAMETER    to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on V_$SESSION      to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on sys.V_$PDBS     to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant select on sys.gV_$PDBS    to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant set container             to C##PRIMEDB_RZABBIX CONTAINER=ALL;
grant sysdg, C##PRIMEDB_RZABBIX to C##PRIMEDB_ZABBIX CONTAINER=ALL;
grant sysdba, C##PRIMEDB_RZABBIX to C##PRIMEDB_ZABBIX CONTAINER=ALL;
alter user C##PRIMEDB_ZABBIX set container_data=all for sys.v_$pdbs container = current;


##-- ASM
sqlplus -S / as sysasm << '_ASM_'
CREATE USER PRIMEDB_ZABBIX IDENTIFIED BY Prm#2022#zbxV3;
grant create session,sysdba to PRIMEDB_ZABBIX ;
_ASM_


#- Exeutar Job
2.3 - Install Zabbix Agent and Sender with Oracle DB V3

###- no servidor

#- fazer discovery
sudo java -jar /etc/zabbix/zbxsender.jar -discovery -n -v -o screen

  # -discovery = executar discovery e atualizar o /etc/zabbix/zbxconfig.json
  # -n = nao enviar para o zabbix
  # -v = verbose
  # -o screen = output screen  


#- conferir o /etc/zabbix/zbxconfig.json e ajustar se necessario
  *** se nao tem backup, ajustar o monitoringrman para 0

sudo vi /etc/zabbix/zbxconfig.json

#- se estiver tudo ok, executar discovery novamente enviando para o zabbix

sudo java -jar /etc/zabbix/zbxsender.jar -discovery -v -o screen


#- verificar se foram criados itens do servidor no zabbix server


#- executar testes de envio
sudo java -jar /etc/zabbix/zbxsender.jar -i 3m -v -o screen
sudo java -jar /etc/zabbix/zbxsender.jar -i 10m -v -o screen
sudo java -jar /etc/zabbix/zbxsender.jar -i 1h -v -o screen
sudo java -jar /etc/zabbix/zbxsender.jar -i 1d -v -o screen


# - Adicionar Template Primedb Zabbix Sender v3

#- help
sudo java -jar /etc/zabbix/zbxsender.jar -h

# - Rodar invetário.

sudo java -jar /etc/zabbix/zbxsender.jar -inventory -n -v -o screen
sudo java -jar /etc/zabbix/zbxsender.jar -inventory -v -o screen


wget https://yum.oracle.com/repo/OracleLinux/OL7/latest/x86_64/getPackage/tzdata-java-2022g-1.el7.noarch.rpm



#### backups 

cdberpp_oda01
recwindows 3 

dlog -> /u01/app/odaorabase/oracle/admin
dest -> /backup/oracle

cdblog_oda01
recwindows 6

dlog -> 



cdbrmp_oda01
recwindows 6 



#### se precisar

yum install java-1.8.0-openjdk-devel

alternatives --config java



#### se precisar

yum install java-1.8.0-openjdk-devel

alternatives --config java





## para rodar inventario

yum install python2
alternatives --config python
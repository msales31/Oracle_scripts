BEGIN
dbms_scheduler.create_job('"JOB_KILL_OLD_REPORT_SESSIONS_01"',
job_type=>'PLSQL_BLOCK', job_action=>
'BEGIN kill_old_report_sessions_01; END;'
, number_of_arguments=>0,
start_date=>TO_TIMESTAMP_TZ('30-DEC-2020 10.30.00.000000000 PM -03:00','DD-MON-RRRR HH.MI.SSXFF AM TZR','NLS_DATE_LANGUAGE=english'), repeat_interval=>
'Freq=DAILY'
, end_date=>NULL,
job_class=>'"DEFAULT_JOB_CLASS"', enabled=>FALSE, auto_drop=>FALSE,comments=>
'My new job'
);
sys.dbms_scheduler.set_attribute('"JOB_KILL_OLD_REPORT_SESSIONS_01"','NLS_ENV','NLS_LANGUAGE=''AMERICAN'' NLS_TERRITORY=''AMERICA'' NLS_CURRENCY=''$'' NLS_ISO_CURRENCY=''AMERICA'' NLS_NUMERIC_CHARACTERS=''.,'' NLS_CALENDAR=''GREGORIAN'' NLS_DATE_FORMAT=''DD-MON-RR'' NLS_DATE_LANGUAGE=''AMERICAN'' NLS_SORT=''BINARY'' NLS_TIME_FORMAT=''HH.MI.SSXFF AM'' NLS_TIMESTAMP_FORMAT=''DD-MON-RR HH.MI.SSXFF AM'' NLS_TIME_TZ_FORMAT=''HH.MI.SSXFF AM TZR'' NLS_TIMESTAMP_TZ_FORMAT=''DD-MON-RR HH.MI.SSXFF AM TZR'' NLS_DUAL_CURRENCY=''$'' NLS_COMP=''BINARY'' NLS_LENGTH_SEMANTICS=''BYTE'' NLS_NCHAR_CONV_EXCP=''FALSE''');
dbms_scheduler.enable('"JOB_KILL_OLD_REPORT_SESSIONS_01"');
COMMIT;
END;


SELECT OBJECT_NAME,OBJECT_TYPE,OWNER FROM DBA_OBJECTS WHERE OBJECT_NAME LIKE '%KILL_OLD_REPORT_SESSIONS_01%';

VERDEMAR.KILL_OLD_REPORT_SESSIONS_01

SELECT DBMS_METADATA.get_ddl ('PROCEDURE', 'KILL_OLD_REPORT_SESSIONS_01')  FROM sys.dual;

select dbms_metadata.get_ddl('PROCEDURE','KILL_OLD_REPORT_SESSIONS_01','ROX') from dual;
select dbms_metadata.get_ddl('PROCEDURE','KILL_OLD_REPORT_SESSIONS_02','ROX') from dual;



CREATE OR REPLACE EDITIONABLE PROCEDURE "ROX"."KILL_OLD_REPORT_SESSIONS_01" AS
BEGIN
  FOR cur_rec IN (select 'alter system kill session ''' || sid || ',' || serial# || ',@' || inst_id || ''' immediate' AS ddl
                  from   gv$session
                  where  upper(program) like '%SUPERUS.EXE%' or upper(program) like '%GERENCIAL.EXE%' or upper(program) like '%PL-SQL%'
                  )
  LOOP
    BEGIN
      EXECUTE IMMEDIATE cur_rec.ddl;
      dbms_output.put_line('OK, finalizada a sessao');
    EXCEPTION
      WHEN OTHERS THEN
         --RAISE;
         --NULL;
         dbms_output.put_line('Erro ao finalizar a sessao, SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM);
    END;
  END LOOP;
END;



CREATE OR REPLACE EDITIONABLE PROCEDURE "ROX"."KILL_OLD_REPORT_SESSIONS_02" AS
BEGIN
  FOR cur_rec IN (select 'alter system kill session ''' || sid || ',' || serial# || ',@' || inst_id || ''' immediate' AS ddl
                  from   gv$session
                  where  upper(program) like '%SUPERUS.EXE%' or upper(program) like '%GERENCIAL.EXE%' or upper(program) like '%PL-SQL%'
                  )
  LOOP
    BEGIN
      EXECUTE IMMEDIATE cur_rec.ddl;
      dbms_output.put_line('OK, finalizada a sessao');
    EXCEPTION
      WHEN OTHERS THEN
         --RAISE;
         --NULL;
         dbms_output.put_line('Erro ao finalizar a sessao, SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM);
    END;
  END LOOP;
END;

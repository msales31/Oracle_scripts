#!/bin/bash

source /home/oracle/via03.env

##variaveis
SCRIPT_DIR=/u02/app/oracle/admin/via03_gru1x9/scripts/
LOG_DIR=/u02/app/oracle/admin/via03_gru1x9/logs
SCRIPT_NAME=gather_fixed_stats.sql

## pegando lista de pdbs
PDB_LIST=$($ORACLE_HOME/bin/sqlplus -S / as sysdba <<EOF
SET PAGESIZE 0
SET FEEDBACK OFF
SELECT name FROM v\$pdbs WHERE name NOT IN (
  'PDB\$SEED', 'CDB\$ROOT'
);
EOF
)

## Executando um de cada vez
for PDB_NAME in $PDB_LIST; do
  # Executando o catcon.pl para o PDB atual
  $ORACLE_HOME/perl/bin/perl $ORACLE_HOME/rdbms/admin/catcon.pl -R -b gather_fixed_stats -d $SCRIPT_DIR -l $LOG_DIR -e -c "$PDB_NAME" $SCRIPT_NAME
done

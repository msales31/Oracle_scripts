-- restore arch:

-- PARAR ROTINAS NO CRONTAB COMENTANDO
sync.archive
sync.standby



-- verificar última seq no stby:

col CURRENT_SCN format 9999999999999999 
SELECT CURRENT_SCN FROM V$DATABASE;


-- comparar com o menor valor (abaixo)         <-----------------------------------------------|
																							   |
col CURRENT_SCN format 9999999999999999                                                        |
select to_char (min (d.CURRENT_SCN)) from V$DATABASE d                                         |
union                                                                                          |
select to_char (max (d.CURRENT_SCN)) from V$DATABASE d                                         |
union                                                                                          |
select to_char (min (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           |
union                                                                                          |
select to_char (max (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           |
union                                                                                          |
select to_char (min (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f                                  |
union                                                                                          |
select to_char (max (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f ;                                |
																							   |
                                                                                               |
---fazer backup dos archives no primary ### IR NO PRIMARY                                      |
                                       +-------------------------------------------------------+
                                       |
                                  |----------|
RMAN> set encryption on identified by 'Primedb#Rman2020';

run{
allocate channel c1 device type DISK;
allocate channel c2 device type DISK;
allocate channel c3 device type DISK;
BACKUP INCREMENTAL FROM SCN 1260440199539 DATABASE FORMAT '/u01/app/oracle/temp/ForStandby_%U' tag 'FORSTANDBY';
}
                                                               |------------------------------|        <-------------------------------------+
															                 |                                                               |
																			 +--------> caminho com espaço livre suficiente                  |
																																			 |
-- Fazer a cópis dos scns para o STANDBY com scp mesmo para algum diretório que tenha espaço suficiente.                                     |
                                                                  |-----------------------------------|   <------------+                     |
																                     |                                 |                     |
							          +----------------------------------------------+                                 |                     |
                                      |                                                                                |                     |
-- catalogar no STANDBY   |--------------------------|                                                                 |                     |
RMAN> CATALOG START WITH '/u01/backup/oracle/orcl/temp/';                                                              |                     |
																													   |				     |
																													   |				     |
-- recuperar no stby:                                                                                                  |                     |
																													   |					 |
RECOVER DATABASE NOREDO;                                                                                               |                     | 
                                                               +------------------------------------------------------ | --------------------+
-- ###### NO PRIMARY ####                                      |                                                       |
-- Fazer backup do controlfile 

run{
allocate channel c1 device type DISK;
BACKUP CURRENT CONTROLFILE FOR STANDBY FORMAT '/u01/app/oracle/temp/ForStandbyCTRL.bck';                    
}																													   |
-- enviar o bkp do control file para o stby com scp mesmo igual feito com os demais e para o mesmo caminho.            |
                                                                                             |-----------|             |
																							       |                   |
--### STANDBY                                                                                      +-------------------+
-- restaurar no stby                                                                               | 
                                                   +-----------------------------------------------+
RMAN> SHUTDOWN IMMEDIATE;                          |
RMAN> STARTUP NOMOUNT;                  |---------------------------|
RMAN> RESTORE STANDBY CONTROLFILE FROM '/u02/ForStandbyCTRL.bck';
RMAN> alter database mount;

-- REATIVAR ROTINAS NO CRONTAB DESCOMANTANDO:
sync.archive
sync.standby

									
						
						
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 104;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 105;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 101;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 102;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 103;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 201;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 202;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 203;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 204;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 205;


alter database clear unarchived logfile group 911;
alter database clear unarchived logfile group 912;
alter database clear unarchived logfile group 913;
alter database clear unarchived logfile group 914;
alter database clear unarchived logfile group 915;
alter database clear unarchived logfile group 916;
alter database clear unarchived logfile group 921;
alter database clear unarchived logfile group 922;
alter database clear unarchived logfile group 923;
alter database clear unarchived logfile group 924;
alter database clear unarchived logfile group 925;
alter database clear unarchived logfile group 926;
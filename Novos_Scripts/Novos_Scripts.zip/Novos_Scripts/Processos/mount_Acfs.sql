168.75.87.141

volcreate -G DATA -s 50G EXPORTPRIME


volinfo --all
Diskgroup Name: DATA

         Volume Name: EXPORTPRIME
         Volume Device: /dev/asm/exportprime-315
         State: ENABLED
         Size (MB): 51200
         Resize Unit (MB): 64
         Redundancy: UNPROT
         Stripe Columns: 8
         Stripe Width (K): 1024
         Usage:
         Mountpath:




/sbin/mkfs -F acfs /dev/asm/exportprime-315




[root@srv1 ~]# mkdir -p /mnt/advm/fs1
[root@srv1 ~]# mount -t acfs  /dev/asm/advmvol1-301 /mnt/advm/fs1/
[root@srv1 ~]# mkdir -p /mnt/advm/fs2
[root@srv1 ~]# mount -t acfs  /dev/asm/advmvol2-301 /mnt/advm/fs2/
mount.acfs: ACFS-00591: error found in volume  disk header
mount.acfs: ACFS-02037: File system not  created on a Linux system. Cannot  mount.
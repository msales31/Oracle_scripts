BLOCKRECOVER

--This command is available only in the Enterprise Edition.
--The target database must be mounted or open. You do not have to take a datafile offline if you are performing block media recovery on it.
--You can only perform complete media recovery of individual blocks. Point-in-time recovery of individual data blocks is not supported.
--You can only perform block media recovery on corrupt blocks.
--Blocks marked media corrupt are not accessible until recovery completes.
--You cannot perform block media recovery when using a backup control file.
--You cannot use proxy backups to perform block media recovery. If the only backups that you have are proxy backups, then you can restore them to a nondefault location on disk, which causes RMAN to view the restored files as datafile copies. You can then use the datafile copies for block media recovery.
--You must have a full backup of the file containing the corrupt blocks: block media recovery cannot use incremental backups.
--If RMAN fails to access a specific archived redo log file needed for block media recovery, it performs restore failover, trying all other backups listed in the RMAN repository that are suitable for use in this operation, and only fails if no suitable backup is available. See Oracle Database Backup and Recovery Advanced User's Guide for details on restore failover.
--Block media recovery cannot survive a missing or inaccessible archived log, although it can sometimes survive missing or inaccessible records (Oracle Database Backup and Recovery Advanced User's Guide).
--The datafile header block (block 1) cannot be recovered.
--You cannot perform block media recovery in NOARCHIVELOG mode.

Examples
Recovering a Group of Corrupt Blocks: Example
This example recovers corrupt blocks in three datafiles:

RMAN >BLOCKRECOVER DATAFILE 2 BLOCK 12, 13 DATAFILE 3 BLOCK 5, 98, 99 DATAFILE 4 BLOCK 19;

####Limiting Block Media Recovery by Type of Restore: Example
####The following example recovers a series of blocks and restores only from datafile copies:

RUN
{
  BLOCKRECOVER DATAFILE 3 BLOCK 2,3,4,5 TABLESPACE sales DBA 4194405, 4194409, 4194412
  FROM DATAFILECOPY;
}

####Limiting Block Media Recovery by Backup Tag: Example
###This example recovers blocks and restores only from the backup with the tag weekly_backup:

RMAN >BLOCKRECOVER TABLESPACE SYSTEM DBA 4194404, 4194405 FROM TAG "weekly_backup";

###Limiting Block Media Recovery by Time: Example
###The following example recovers two blocks in the SYSTEM tablespace. It restores only from backups that could be used to recover the database to a point two days ago:

BLOCKRECOVER TABLESPACE SYSTEM DBA 4194404, 4194405 RESTORE UNTIL TIME 'SYSDATE-2';


####Repairing All Block Corruption in the Database: Example
####The following example runs a backup validation to populate V$DATABASE_BLOCK_CORRUPTION, then repairs any corrupt blocks recorded in the view:

BACKUP VALIDATE DATABASE;
BLOCKRECOVER CORRUPTION LIST;


BACKUP VALIDATE CHECK LOGICAL datafile 193;

BLOCKRECOVER DATAFILE 193 BLOCK 859684;



set pagesize 2000
set linesize 250
SELECT e.owner, e.segment_type, e.segment_name, e.partition_name, c.file#
, greatest(e.block_id, c.block#) corr_start_block#
, least(e.block_id+e.blocks-1, c.block#+c.blocks-1) corr_end_block#
, least(e.block_id+e.blocks-1, c.block#+c.blocks-1)
- greatest(e.block_id, c.block#) + 1 blocks_corrupted
, null description
FROM dba_extents e, v$database_block_corruption c
WHERE e.file_id = c.file#
AND e.block_id <= c.block# + c.blocks - 1
AND e.block_id + e.blocks - 1 >= c.block#
UNION
SELECT s.owner, s.segment_type, s.segment_name, s.partition_name, c.file#
, header_block corr_start_block#
, header_block corr_end_block#
, 1 blocks_corrupted
, 'Segment Header' description
FROM dba_segments s, v$database_block_corruption c
WHERE s.header_file = c.file#
AND s.header_block between c.block# and c.block# + c.blocks - 1
UNION
SELECT null owner, null segment_type, null segment_name, null partition_name, c.file#
, greatest(f.block_id, c.block#) corr_start_block#
, least(f.block_id+f.blocks-1, c.block#+c.blocks-1) corr_end_block#
, least(f.block_id+f.blocks-1, c.block#+c.blocks-1)
- greatest(f.block_id, c.block#) + 1 blocks_corrupted
, 'Free Block' description
FROM dba_free_space f, v$database_block_corruption c
WHERE f.file_id = c.file#
AND f.block_id <= c.block# + c.blocks - 1
AND f.block_id + f.blocks - 1 >= c.block#
order by SEGMENT_NAME,file#, corr_start_block#;

WMSPRD.NFIMPRESSAO


BACKUP AS COPY DATAFILE 193 AUXILIARY FORMAT '/backup/SMARTPR/temp/wms_dadosmov193.bk';
backup datafile 193 format '/backup/SMARTPR/temp/wms_dadosmov193.bk';





--- criar user destino 
CREATE USER CLONESOADB03 IDENTIFIED BY CLON##123Rum;
grant dba,create pluggable database to  CLONESOADB03;



-- criar dblink
create public database link SOADB03_link connect to CLONESOADB03 identified by CLON##123Rum using 'SOADB03';


SOADB03 





--- clone pdb: tempo estimado 10 minutos

CREATE PLUGGABLE DATABASE SOADB03 from NON$CDB@SOADB03_link KEYSTORE identified by "Rumo#Cdbsoa#2024" including shared key parallel 4;



-- Converter para pdb 15 minutos :  

@?/rdbms/admin/noncdb_to_pdb.sql




-- ativar base
alter pluggable database SOADB03 close immediate instances=all;
alter pluggable database SOADB03 open  instances=all;






-- Coletar estatistica do dicionario e do fixed objects

CREATE TEMPORARY TABLESPACE TEMP1 TEMPFILE  SIZE 2G;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TEMP1;



-- lembrar de validar fila de jobs

alter system set job_queue_processes=10;


-- ativar wallet tde 

ADMINISTER KEY MANAGEMENT SET KEY USING TAG 'rotate_key' FORCE KEYSTORE IDENTIFIED BY "Rumo#Cdbsoa#2024" WITH BACKUP USING 'backup_key';







-- Ajustar timezone.

SQL> select value$ from props$ where name = 'DBTIMEZONE';
VALUE$
--------------------------------------------------------------------------------
-07:00

1 row selected.

SQL> alter pluggable database <pdb1> set time_zone = '00:00';

SQL> select value$ from props$ where name = 'DBTIMEZONE';

VALUE$
--------------------------------------------------------------------------------
00:00

1 row selected.

SQL> select sysdate from dual;

SYSDATE
--------------------
20-MAY-2016 12:13:00

1 row selected.

SQL> select current_timestamp from dual;

CURRENT_TIMESTAMP
---------------------------------------------------------------------------
20-MAY-16 07.13.08.077632 PM +00:00

1 row selected.
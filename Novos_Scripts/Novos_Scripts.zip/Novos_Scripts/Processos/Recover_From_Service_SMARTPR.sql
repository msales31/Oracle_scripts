##############################################################################################
#######--- from service 


### CATALOGAR BACKUP 

spool catalog.cmd
set pagesize 0
select '   '''||HANDLE||''','||chr(10)
from V$BACKUP_PIECE bp
where bp.HANDLE is not null
and DEVICE_TYPE = 'SBT_TAPE'
order by START_TIME, PIECE#;
spool off

### CANCELAR APLICACAO

ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;




#.. executar no standby utilizando servico da producao

RMAN > recover standby database from service SMARTPR1;


### LIMPAR GRUPO DE REDO:

ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 104;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 105;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 101;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 102;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 103;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 201;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 202;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 203;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 204;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 205;

### ATIVAR BASE 

ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;
alter database recover managed standby database disconnect using current logfile;


#######--- catalogar todos os backups pieces gerados anteriormente

rman target / cmdfile=catalog.cmd




248696 - ATUALIZAÇÃO DO BANCO PARA 21c

TABLESPACE_NAME               |   FILE_ID|EXT|        MB|     MAXSZ|FILE_NAME
EDOCSPARAL_DATA               |         5|YES|        10|     30000|/u01/app/oracle/oradata/projepar/edocsparal_data01.dbf
EDOCS_DATA                    |         6|YES|       939|     30000|/u01/app/oracle/oradata/projepar/edocs_data01.dbf
SYSAUX                        |         2|YES|      7290|  32767.98|/u01/app/oracle/oradata/projepar/sysaux01.dbf
SYSTEM                        |         1|YES|      1533|  32767.98|/u01/app/oracle/oradata/projepar/system01.dbf
TEMP                          |         1|YES|       139|  32767.98|/u01/app/oracle/oradata/projepar/temp01.dbf
UNDOTBS1                      |         3|YES|      1491|  32767.98|/u01/app/oracle/oradata/projepar/undotbs01.dbf
USERS                         |         4|YES|   1771.75|  32767.98|/u01/app/oracle/oradata/projepar/users01.dbf
USER_DATA                     |         7|YES|      6600|     30000|/u01/app/oracle/oradata/projepar/user_data_01.dbf
USER_DATA                     |         8|YES|      5434|     30000|/u01/app/oracle/oradata/projepar/user_data_02.dbf
USER_INDEX                    |         9|YES|      1843|     30000|/u01/app/oracle/oradata/projepar/user_index_01.dbf
USER_INDEX                    |        10|YES|      1574|     30000|/u01/app/oracle/oradata/projepar/user_index_02.dbf

11 rows selected.

Elapsed: 00:00:00.38
15:23:57 SYS@projepar> @du %
old   8:     lower(owner) like lower('&1')
new   8:     lower(owner) like lower('%%%')
OWNER                         |         MB|         GB
SYS                           |     7901.5|        7.7
CO_PROJEPAR                   |     2600.8|        2.5
CO_PROJEPARPARAL              |     2224.1|        2.2
RH_PROJEPAR                   |     1423.1|        1.4
RH_PROJEPARPARAL              |     1311.9|        1.3
SAPIENSNFE                    |      773.8|         .8
SAPIENSNFEPARAL               |      741.8|         .7
BACKUPDUMP                    |      387.4|         .4
EDOCSPARAL                    |      106.4|         .1
EDOCS                         |      106.2|         .1
XDB                           |       62.4|         .1
SYSTEM                        |       21.8|         .0
AUDSYS                        |        9.8|         .0
WMSYS                         |        7.4|         .0
CTXSYS                        |        7.1|         .0
GSMADMIN_INTERNAL             |        6.3|         .0
DBSNMP                        |        1.5|         .0
OJVMSYS                       |         .9|         .0
OUTLN                         |         .6|         .0
DBSFWUSER                     |         .4|         .0
APPQOSSYS                     |         .3|         .0



UNION ALL
SELECT 'current date and time '||lower(to_char(sysdate, 'DDMONYYYY HH24:MI:SS'))
FROM dual;15:37:06 SYS@projepar> 15:37:06   2  15:37:06   3  15:37:06   4  15:37:06   5  15:37:06   6  15:37:06   7  15:37:06   8  15:37:06   9  15:37:06  10  15:37:06  11  15:37:06  12  15:37:06  13  15:37:06  14  15:37:06  15  15:37:06  16  15:37:06  17  15:37:06  18  15:37:06  19  15:37:06  20  15:37:06  21
INFO
database PROJEPAR role PRIMARY log_mode ARCHIVELOG open_mode READ WRITE
instance PROJEPAR thread 1 version 12.2.0.1.0 host SRVORA01 status OPEN
default_temp_tablespace TEMP
dbtimezone -03:00
global_db_name PROJEPAR
nls_nchar_characterset AL16UTF16
nls_characterset WE8ISO8859P1
nls_territory AMERICA
nls_language AMERICAN
startup time 31oct2023 10:31:14
current date and time 08nov2023 15:37:07



NAME                                |TYPE       |VALUE
cdb_cluster_name                    |string     |projepar
cell_offloadgroup_name              |string     |
db_file_name_convert                |string     |
db_name                             |string     |projepar
db_unique_name                      |string     |projepar
global_names                        |boolean    |FALSE
instance_name                       |string     |projepar
lock_name_space                     |string     |
log_file_name_convert               |string     |
pdb_file_name_convert               |string     |
processor_group_name                |string     |
service_names                       |string     |projepar




#### rodar backup FULL /u01/app/oracle/admin/projepar/scripts/fullbackup

00  21    *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/dpnoite" > /dev/null 2>&1
00  01    *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/fullbackup" > /dev/null 2>&1
00  06-23 *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/archbackup" > /dev/null 2>&1
# --- Procedimento coleta statisticas consinco
10 02 * * *  root su - oracle -c "/u01/app/oracle/admin/projepar/scripts/analyze" >/dev/null 2>&1
# ---

##comentar backups

00  21    *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/dpnoite" > /dev/null 2>&1
00  01    *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/fullbackup" > /dev/null 2>&1
00  06-23 *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/archbackup" > /dev/null 2>&1
# --- Procedimento coleta statisticas consinco
10 02 * * *  root su - oracle -c "/u01/app/oracle/admin/projepar/scripts/analyze" >/dev/null 2>&1
# ---

## parar e subir base, derrubar todas conexoes

alter system set job_queue_processes=0 scope=both;
shutdown immediate;
lsnrctl stop;
startup;



OWNER                         |         MB|         GB
SYS                           |     7905.6|        7.7
CO_PROJEPAR                   |     2600.8|        2.5
CO_PROJEPARPARAL              |     2224.1|        2.2
RH_PROJEPAR                   |     1424.1|        1.4
RH_PROJEPARPARAL              |     1311.9|        1.3
SAPIENSNFE                    |      773.8|         .8
SAPIENSNFEPARAL               |      741.8|         .7
BACKUPDUMP                    |      387.4|         .4
EDOCSPARAL                    |      106.4|         .1
EDOCS                         |      106.2|         .1
XDB                           |       62.4|         .1
SYSTEM                        |       21.8|         .0
AUDSYS                        |        9.8|         .0
WMSYS                         |        7.4|         .0
CTXSYS                        |        7.1|         .0
GSMADMIN_INTERNAL             |        6.3|         .0
DBSNMP                        |        1.5|         .0
OJVMSYS                       |         .9|         .0
OUTLN                         |         .6|         .0
DBSFWUSER                     |         .4|         .0
APPQOSSYS                     |         .3|         .0






Home do 21c:  /u01/app/oracle/product/21.0.0/dbhome_1/



### INSTALL SOFTWARE ORACLE 21C

export ORACLE_HOME=$ORACLE_BASE/product/21.0.0/dbhome_1
export PATH=$ORACLE_HOME/bin:$PATH
export ORACLE_SID=cdbprd
export ORA_INVENTORY=/u01/app/oraInventory
export ORACLE_HOSTNAME=srvora01

mkdir -p ${ORACLE_HOME}
cd $ORACLE_HOME

/bin/unzip -oq ${SOFTWARE_DIR}/LINUX.X64_213000_db_home.zip

./runInstaller -ignorePrereq -waitforcompletion -silent \
    -responseFile ${ORACLE_HOME}/install/response/db_install.rsp \
    oracle.install.option=INSTALL_DB_SWONLY \
    ORACLE_HOSTNAME=${ORACLE_HOSTNAME} \
    UNIX_GROUP_NAME=oinstall \
    INVENTORY_LOCATION=${ORA_INVENTORY} \
    SELECTED_LANGUAGES=en,en_GB  \
    ORACLE_HOME=${ORACLE_HOME} \
    ORACLE_BASE=${ORACLE_BASE} \
    oracle.install.db.InstallEdition=SE \
    oracle.install.db.OSDBA_GROUP=dba \
	oracle.install.db.OSBACKUPDBA_GROUP=dba \
	oracle.install.db.OSDGDBA_GROUP=dba \
	oracle.install.db.OSKMDBA_GROUP=dba \
	oracle.install.db.OSRACDBA_GROUP=dba \
    SECURITY_UPDATES_VIA_MYORACLESUPPORT=false                                 \
    DECLINE_SECURITY_UPDATES=true
	
	
/u01/app/oracle/product/21.0.0/dbhome_1/root.sh


#### Criar o container 

dbca -silent -createDatabase \
 -templateName General_Purpose.dbc \
 -gdbname cdbprd -sid cdbprd -responseFile NO_VALUE \
 -characterSet WE8ISO8859P1 \
 -sysPassword PassProjet123 \
 -systemPassword PassProjet123 \
 -createAsContainerDatabase true \
 -numberOfPDBs 0 \
 -databaseType MULTIPURPOSE \
 -memoryMgmtType auto_sga \
 -totalMemory 3048 \
 -storageType FS \
 -datafileDestination "/u01/app/oracle/oradata/" \
 -redoLogFileSize 100 \
 -emConfiguration NONE \
 -ignorePreReqs
 
 PassProjet123
 PassProjet123
 
 
### rodar o gerador do sample file 

 $ORACLE_BASE/product/21.0.0/dbhome_1/jdk/bin/java   -jar $ORACLE_BASE/product/21.0.0/dbhome_1/rdbms/admin/autoupgrade.jar   -create_sample_file config /tmp/config2.txt noncdbtopdb
 
 
### ajustar sample file config 

vi /tmp/config.txt

upg1.log_dir=/u01/app/oracle/cfgtoollogs/autoupgrade/projepar
upg1.sid=projetar
upg1.source_home=/u01/app/oracle/product/12.2.0/db_1
upg1.target_cdb=cdbprd
upg1.target_home=/u01/app/oracle/product/21.0.0/dbhome_1
upg1.target_pdb_name=projetar
#upg1.target_pdb_copy_option=file_name_convert=('emp', 'emppdb')
upg1.start_time=NOW                  # Optional. 10 Minutes from now
upg1.upgrade_node=localhost           # Optional. To find out the name of your node, run the hostname utility. Default is ''localhost''
upg1.run_utlrp=yes             # Optional. Whether or not to run utlrp after upgrade
upg1.timezone_upg=yes           # Optional. Whether or not to run the timezone upgrade
upg1.target_version=21  # Oracle version of the target ORACLE_HOME.  Only required when the target Oracle database version is 12.2




### rodar analyze 

$ORACLE_BASE/product/21.0.0/dbhome_1/jdk/bin/java \
  -jar $ORACLE_BASE/product/21.0.0/dbhome_1/rdbms/admin/autoupgrade.jar \
  -config /tmp/config2.txt -mode analyze
  
 

### PRE UPGRADE 
ALTER USER APPQOSSYS quota unlimited on USERS;
ALTER USER GSMADMIN_INTERNAL quota unlimited on USERS;
 
EXECUTE DBMS_STATS.GATHER_DICTIONARY_STATS;
EXECUTE DBMS_STATS.GATHER_FIXED_OBJECTS_STATS;
 
select 'grant select on sys.v_$parameter to '|| username ||';'
from dba_users
order by username;
 
SELECT 'grant ADMINISTER DATABASE TRIGGER to '||owner||';'
FROM DBA_TRIGGERS
WHERE TRIM(BASE_OBJECT_TYPE)='DATABASE'
AND OWNER NOT IN (SELECT GRANTEE FROM DBA_SYS_PRIVS WHERE PRIVILEGE='ADMINISTER DATABASE TRIGGER');
 
grant ADMINISTER DATABASE TRIGGER to SYSTEM;
 
alter system set SEC_CASE_SENSITIVE_LOGON=false sid='*' scope=both; 








### validar /u01/app/oracle/cfgtoollogs/autoupgrade/cfgtoollogs/upgrade/auto/status/status.log


--- RODAR UPGRADE

$ORACLE_BASE/product/21.0.0/dbhome_1/jdk/bin/java \
  -jar $ORACLE_BASE/product/21.0.0/dbhome_1/rdbms/admin/autoupgrade.jar \
  -config /tmp/config.txt -mode deploy
  
  
 ### BAIXAR BASE ANTIGA
 
 source /home/oracle/projetar.env
sqlplus / as sysdba <<EOF
alter system set job_queue_processes=0 scope=both;
shutdown immediate;
lsnrctl stop;
startup;
EOF


  
 ### AJUSTAR PARAMETRO DE MEMORIA
 
 
 
### COLOCAR BASE EM SAVE STATE e ajustar parametro de memoria
	
	

sqlplus / as sysdba <<EOF
alter system set sga_max_size=9G;
alter system set sga_target=9G;
alter system set pga_aggregate_target=2G;
alter pluggable database PROJETAR save state;
shutdown immediate;
startup;
ALTER SYSTEM REGISTER;
show pdbs
exit;
EOF


	
####validar listener 

lsnrctl status

### validar backups e setar novas variaveis

00  21    *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/dpnoite" > /dev/null 2>&1
00  01    *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/fullbackup" > /dev/null 2>&1
00  06-23 *  *  *  root  su - oracle -c "/u01/app/oracle/admin/projepar/scripts/archbackup" > /dev/null 2>&1
# --- Procedimento coleta statisticas consinco
10 02 * * *  root su - oracle -c "/u01/app/oracle/admin/projepar/scripts/analyze" >/dev/null 2>&1
# ---




### +++ Faz um Backup Full
============================================================================================
/u01/app/oracle/admin/projepar/scripts/fullbackup


### +++ Migra Non-CDB to CDB (pdb)
============================================================================================

export ORACLE_SID=projepar
sqlplus / as sysdba
SHUTDOWN IMMEDIATE;
STARTUP OPEN READ ONLY;

BEGIN
  DBMS_PDB.DESCRIBE(
    pdb_descr_file => '/tmp/cdb-projepar.xml');
END;
/

SHUTDOWN IMMEDIATE;

--------------------------------------------------------------------------------------------

- Sobe a base cdbprd no ORACLE_HOME 21c

export ORACLE_SID=cdbprd

sqlplus / as sysdba
startup;

CREATE PLUGGABLE DATABASE projepar USING '/tmp/cdb-projepar.xml' NOCOPY;

ALTER SESSION SET CONTAINER=PROJEPAR;
@$ORACLE_HOME/rdbms/admin/noncdb_to_pdb.sql;

ALTER SESSION SET CONTAINER=PROJEPAR;
ALTER PLUGGABLE DATABASE PROJEPAR OPEN;
ALTER PLUGGABLE DATABASE PROJEPAR SAVE STATE;

select name,status,action from PDB_PLUG_IN_VIOLATIONS where status<>'RESOLVED';


#### lembrar de aumentar a memoria do banco de dados



ID|  SID|SERIAL#| PID|SPID  |SQL_ID        |OS_USER         |PROGRAM                       |USERNAME          |MODULE                   |LOGON               |ELAPSE|LAST_|EVENT
 1| 5768|  16994| 179|386382|48wv9vbq0ucfd |oracle          |oracle@pfocidbexacs02-vn7wg1 (|TEKNISA           |DBMS_SCHEDULER           |08-11-2023 17:30:41 |0:07  |0:07 |latch: cache buffers l
  |     |       |    |      |              |                |J003)                         |                  |                         |                    |      |     |

 1| 2485|  36889| 298|163718|f8yuufvgaxq5t |service.bi      |QvOdbcConnectorPackage.exe    |BI                |QvOdbcConnectorPackage.ex|08-11-2023 17:31:37 |0:07  |0:06 |cell multiblock physic
  |     |       |    |      |              |                |                              |                  |e                        |                    |      |     |

 1| 3394|  57432| 361|226048|2chggp2b8uabq |service.bi      |QvConnect64.EXE               |BI                |QvConnect64.EXE          |08-11-2023 17:35:12 |0:03  |0:03 |cell multiblock read r
 1|   18|  61037| 110|106173|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00A)                         |                  |                         |                    |      |     |

 1|   25|  33816| 240|395819|0w8gcuqdgk7yc |oracle          |sqlplus@pfocidbexacs02-vn7wg1 |SYS               |dba                      |08-11-2023 17:04:36 |0:34  |0:00 |PX Deq: Execute Reply
  |     |       |    |      |              |                |(TNS V1-V3)                   |                  |                         |                    |      |     |

 1|   69|   8498| 120|106353|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00S)                         |                  |                         |                    |      |     |

 1|   74|  16955| 150|108122|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P012)                         |                  |                         |                    |      |     |

 1|  616|  51859| 132|106284|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00O)                         |                  |                         |                    |      |     |

 1|  633|   6980| 122|106232|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00I)                         |                  |                         |                    |      |     |

 1|  651|  46928| 102|106164|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |gc current block busy
  |     |       |    |      |              |                |P008)                         |                  |                         |                    |      |     |

 1|  667|   3111| 112|106182|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |wait for a undo record
  |     |       |    |      |              |                |P00C)                         |                  |                         |                    |      |     |

 1| 1219|  58519| 304|200501|0w8gcuqdgk7yc |oracle          |oracle@pfocidbexacs02-vn7wg1 (|SYS               |dba                      |08-11-2023 17:38:38 |0:00  |0:00 |PX Deq: Execution Msg
  |     |       |    |      |              |                |PPA7)                         |                  |                         |                    |      |     |

 1| 1225|  23333| 154|108083|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00Y)                         |                  |                         |                    |      |     |

 1| 1252|  12418| 224|384265|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |wait for a undo record
  |     |       |    |      |              |                |P002)                         |                  |                         |                    |      |     |

 1| 1258|  57456| 134|106328|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |wait for a undo record
  |     |       |    |      |              |                |P00Q)                         |                  |                         |                    |      |     |

 1| 1265|  22961| 114|106204|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00E)                         |                  |                         |                    |      |     |

 1| 1832|  26224| 116|106247|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00K)                         |                  |                         |                    |      |     |

 1| 1860|  57788| 126|106380|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00U)                         |                  |                         |                    |      |     |

 1| 1865|   6519| 246|384279|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block read
  |     |       |    |      |              |                |P006)                         |                  |                         |                    |      |     |

 1| 1890|  26760| 166|270922|59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:41 |0:00  |0:00 |SQL*Net message from c
 1| 1898|  57812| 566|274658|55d5fdp5c4uyq |SYSTEM          |MaderoApiSvc.exe              |TEKNISA           |MaderoApiSvc.exe         |08-11-2023 17:38:16 |0:00  |0:00 |SQL*Net message to cli
 1| 2426|  63286| 118|106214|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00G)                         |                  |                         |                    |      |     |

 1| 2434|  61179| 148|108067|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00W)                         |                  |                         |                    |      |     |

 1| 2437|  12262| 198|384259|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |wait for a undo record
  |     |       |    |      |              |                |P000)                         |                  |                         |                    |      |     |

 1| 2472|  47443|  98|106137|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P004)                         |                  |                         |                    |      |     |

 1| 2496|   4005| 128|106267|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block phys
  |     |       |    |      |              |                |P00M)                         |                  |                         |                    |      |     |

 1| 2505|  26726| 158|108096|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |gc current request
  |     |       |    |      |              |                |P010)                         |                  |                         |                    |      |     |

 1| 3360|  22359| 101|106150|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P005)                         |                  |                         |                    |      |     |

 1| 3395|  53989| 161|108090|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block phys
  |     |       |    |      |              |                |P00Z)                         |                  |                         |                    |      |     |

 1| 3420|  31883| 121|106277|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |wait for a undo record
  |     |       |    |      |              |                |P00N)                         |                  |                         |                    |      |     |

 1| 3443|  43711| 111|106209|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00F)                         |                  |                         |                    |      |     |

 1| 3947|   5442| 103|106162|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block read
  |     |       |    |      |              |                |P007)                         |                  |                         |                    |      |     |

 1| 3979|  15628| 133|106364|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block read
  |     |       |    |      |              |                |P00T)                         |                  |                         |                    |      |     |

 1| 4022|  17938| 113|106239|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00J)                         |                  |                         |                    |      |     |

 1| 4613|   4055| 125|106300|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00P)                         |                  |                         |                    |      |     |

 1| 4625|  58565| 155|108126|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P013)                         |                  |                         |                    |      |     |

 1| 4644|  31400|  95|105966|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P001)                         |                  |                         |                    |      |     |

 1| 4649|   9643| 115|106221|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block phys
  |     |       |    |      |              |                |P00H)                         |                  |                         |                    |      |     |

 1| 4652|  21449| 105|106180|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00B)                         |                  |                         |                    |      |     |

 1| 5153|  22261| 157|108078|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00X)                         |                  |                         |                    |      |     |

 1| 5205|  62906| 107|106166|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P009)                         |                  |                         |                    |      |     |

 1| 5775|  37499| 129|106345|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00R)                         |                  |                         |                    |      |     |

 1| 5784|  42619| 119|106260|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |cell single block phys
  |     |       |    |      |              |                |P00L)                         |                  |                         |                    |      |     |

 1| 5788|  19341|  99|106124|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P003)                         |                  |                         |                    |      |     |

 1| 5799|  17653| 109|106196|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00D)                         |                  |                         |                    |      |     |

 1| 5803|  23594| 159|108109|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |row cache mutex
  |     |       |    |      |              |                |P011)                         |                  |                         |                    |      |     |

 1| 5804|  49387| 139|106399|              |oracle          |oracle@pfocidbexacs02-vn7wg1 (|                  |                         |08-11-2023 17:34:52 |0:03  |0:00 |latch: ges resource ha
  |     |       |    |      |              |                |P00V)                         |                  |                         |                    |      |     |

 2|  723|   7610| 262|378518|59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:27:52 |0:10  |0:00 |gc transaction table
 2| 1837|  46977|  76|97792 |0w8gcuqdgk7yc |oracle          |oracle@pfocidbexacs02-vn7wg2 (|SYS               |dba                      |08-11-2023 17:38:38 |0:00  |0:00 |PX Deq: Execution Msg
  |     |       |    |      |              |                |PPA7)                         |                  |                         |                    |      |     |

 2| 3335|   9966| 181|81921 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:22 |0:01  |0:00 |gc transaction table
 2| 3354|  30691| 421|80751 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:13 |0:01  |0:00 |gc transaction table
 2| 3357|  13174| 551|84710 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:43 |0:00  |0:00 |gc transaction table
 2| 3361|  39805| 451|80538 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:11 |0:01  |0:00 |gc transaction table
 2| 3381|  24019| 271|81924 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:22 |0:01  |0:00 |gc transaction table
 2| 3392|  14451| 151|60527 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:35:08 |0:03  |0:00 |gc transaction table
 2| 3398|   8282| 401|16140 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:30:53 |0:07  |0:00 |gc transaction table
 2| 3946|  41511| 353|12832 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:30:28 |0:08  |0:00 |gc transaction table
 2| 3956|  21607| 243|39539 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:33:27 |0:05  |0:00 |gc transaction table
 2| 3962|  58735| 253|84130 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:38 |0:00  |0:00 |gc transaction table
 2| 3970|   7189| 293|61121 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:35:11 |0:03  |0:00 |gc transaction table
 2| 3983|  62956| 413|83993 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:37 |0:01  |0:00 |gc transaction table
 2| 3985|  49786| 483|91839 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:38:29 |0:00  |0:00 |gc transaction table
 2| 3994|  60116| 433|82976 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:29 |0:01  |0:00 |gc transaction table
 2| 3997|  28866| 403|83988 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:37 |0:01  |0:00 |gc transaction table
 2| 3999|  14055| 513|84527 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:41 |0:00  |0:00 |gc transaction table
 2| 4002|  63253| 333|76568 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:36:56 |0:01  |0:00 |gc transaction table
 2| 4556|  12155| 475|82597 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:26 |0:01  |0:00 |gc transaction table
 2| 4567|  61415|  55|76424 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:36:55 |0:01  |0:00 |gc transaction table
 2| 4573|   3126| 655|88520 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:38:02 |0:00  |0:00 |gc transaction table
 2| 4578|  64456| 315|61115 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:35:11 |0:03  |0:00 |gc transaction table
 2| 4589|  32239| 375|84429 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:40 |0:00  |0:00 |gc transaction table
 2| 4590|  53300| 245|81280 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:16 |0:01  |0:00 |gc transaction table
 2| 5175|  29100| 447|69269 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:36:05 |0:02  |0:00 |gc transaction table
 2| 5179|  45996| 407|51369 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:34:23 |0:04  |0:00 |gc transaction table
 2| 5193|   7864| 387|84198 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:39 |0:00  |0:00 |gc transaction table
 2| 5195|  24689| 427|45442 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:33:47 |0:04  |0:00 |gc transaction table
 2| 5746|  49629| 489|84175 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:38 |0:00  |0:00 |gc transaction table
 2| 5761|  28364| 369|91084 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:38:20 |0:00  |0:00 |gc transaction table
 2| 5799|  20402| 289|82183 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:37:24 |0:01  |0:00 |gc transaction table
 2| 5810|  62376| 329|55060 |59n5xu5u9yjfb |administrator   |dllhost.exe                   |TEKNISA           |EXP.dll                  |08-11-2023 17:34:38 |0:04  |0:00 |gc transaction table
 2| 5815|  56087|  89|92094 |1stk6vbpkgj6w |administrator   |dllhost.exe                   |TEKNISA           |FAD.dll                  |08-11-2023 17:38:31 |0:00  |0:00 |PGA memory operation




QUERY=TEKNISA.LOGOPERFOS:"WHERE DTHROPERFOS < SYSDATE - 45"

WHERE DTHROPERFOS < SYSDATE - 45



select machine,program,sid,sql_id from v$session where sql_id='4r8fwqcd40fcf';


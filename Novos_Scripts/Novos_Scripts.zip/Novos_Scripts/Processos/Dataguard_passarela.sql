-- validacao de parametros

- nome da base
- wallet
- desativar parametros como sensitive, global name e db_doman


LET_OR|KEYSTORE|FULLY_BAC|    CON_ID
FILE      |/opt/oracle/dcs/commonstore/wallets/dbprod_nw6_vcp/tde/               |OPEN                |AUTOLOGIN           |SINGLE   |NONE    |NO       |         1

1 row selected.

NAME                                |TYPE       |VALUE
cdb_cluster_name                    |string     |
cell_offloadgroup_name              |string     |
db_file_name_convert                |string     |
db_name                             |string     |dbprod
db_unique_name                      |string     |dbprod_nw6_vcp
global_names                        |boolean    |FALSE
instance_name                       |string     |dbprod
lock_name_space                     |string     |
log_file_name_convert               |string     |
pdb_file_name_convert               |string     |
processor_group_name                |string     |
service_names                       |string     |dbprod_nw6_vcp.subnetdatabasev
                                    |           |.vcnpassarelavcp.oraclevcn.com




 show parameter plugg

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
enable_pluggable_database            boolean     TRUE
SQL> alter system set enable_pluggable_database=FALSE;

SQL> alter system set enable_pluggable_database=FALSE SCOPE=SPFILE;


428 rows selected.


#### deleta todos datafiles, redo e afins


### levar wallet backup,wallet tde 


#### sobe em nomount e altera dbname

###

startup nomount;
alter system set db_name='dbprod' scope=spfile sid='*';




 list backup of controlfile completed between "to_date('15/05/2024 00:00:00','DD/MM/YYYY HH24:MI:SS')" and "to_date('15/05/2024 23:30:00','DD/MM/YYYY HH24:MI:SS')";

BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ -------------------
80701   Full    5.50M      SBT_TAPE    00:00:02     2024/05/15 16:37:06
        BP Key: 80701   Status: AVAILABLE  Compressed: YES  Tag: ARCHIVEHORARIO202405151635
        Handle: rman_ctrl_dbprod_ARCHIVE_dbid2989654969_s80727_t1169051824_p1.bkp   Media: objectstorag~.sa-saopaulo~.oraclecloud.com/n/grgv~/Backup-dbprod
  Control File Included: Ckp SCN: 85397207749   Ckp time: 2024/05/15 16:37:04



rman_ctrl_dbprod_ARCHIVE_dbid2989654969_s80727_t1169051824_p1.bkp


rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
restore CONTROLFILE from 'rman_ctrl_dbprod_ARCHIVE_dbid2989654969_s80727_t1169051824_p1.bkp';
}
ALTER DATABASE MOUNT;
__RMAN__



###################################################################################################################
#######
###                              Criar DG sem Broker


###########################################################
##
##     adicionar redos standby (se ainda nao tem )
##        mesma quantidade e tamanho de redos existente

alter database add standby logfile group 911 size 1048M;
alter database add standby logfile group 912 size 1048M;
alter database add standby logfile group 913 size 1048M;
alter database add standby logfile group 914 size 1048M;
alter database add standby logfile group 915 size 1048M;
alter database add standby logfile group 916 size 1048M;
alter database add standby logfile group 917 size 1048M;
alter database add standby logfile group 918 size 1048M;



ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 104;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 105;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 101;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 102;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 103;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 201;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 202;

 ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 911;
 ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 912;
 ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 913;
 ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 914;
 ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 915;
 ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 916;

###########################333###########################################################
##
##     configurar listener e tnsnames
##        (primary e standby)


##########################################
#-- adicionar entrada no listener


#-- se NAO tem uma network de dr/backup, adicionar entrada no listener default

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

SID_LIST_LISTENER =
    (SID_LIST =
	   (SID_DESC =
	        (GLOBAL_DBNAME=)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/stdone)
		    (SID_NAME=PIP)
	    )
	)

lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status



#--- OU se TEM uma network de dr/backup configurar um listener separado

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

LISTENER_DG =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = xxIP_DRxx)(PORT = 1525))
    )
  )

SID_LIST_LISTENER_DG =
    (SID_LIST=
	   (SID_DESC=
	        (GLOBAL_DBNAME=rumo01_bm03)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_2)
		    (SID_NAME=rumo01)
	    )
	)


lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status


#-- adicionar entrada no tnsnames (verificar qual tns a base usa) dois dois lados

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/tnsnames.ora

VOX_PRD =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.29.10.71)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = voxline_gru16d.subnetdb.vcnvoxline.oraclevcn.com)
      (UR = A)
    )
  )

VOX_DG =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.29.10.236)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = voxline_dg)
      (UR = A)
    )
  )




###################################################################################################################
#######
###                              Copiar o pwdfile da producao para o standby
SQL> select username,sysdba from v$pwfile_users;

mv /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01 /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01.ori
scp $ORACLE_HOME/dbs/orapwpano01 152.67.45.93:/u01/app/oracle/product/11.2.0.4/dbhome_3/dbs



###################################################################################################################
#######
###                              Testar e validar conexao dos dois lados


conn sys/"Cloudpass2390#"@DBPROD_DBCS01 as sysdba
select host_name,STATUS from v$instance;


conn sys/"-3SyRumo#ww"@rumo01_bm04 as sysdba
select host_name,STATUS from v$instance;


###################################################################################################################
#######
###                              Duplicate

#. TARGET     = banco origem
#. AUXILIARY  = banco destino

rman
connect target sys/"-3SyRumo#ww"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.32)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A))) auxiliary sys/"-3SyRumo#ww"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))

rman target sys/"-3SyRumo#ww"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.32)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A)))" auxiliary sys/"-3SyRumo#ww"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))"
#- spool log to /home/oracle/duplicate.log
run {
   allocate channel prmy1 type disk;
   allocate channel prmy2 type disk;
   allocate channel prmy3 type disk;
   allocate channel prmy4 type disk;
   allocate auxiliary channel stby1 type disk;
   DUPLICATE TARGET DATABASE
      FOR STANDBY
      FROM ACTIVE DATABASE
      DORECOVER;
}




###################################################################################################################
#######
###                              Configurar DG sem broker


##########################################
#-- no primary

alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- verificar se foram adicionados redos standby (mesmo numero de grupos e tamanho dos atuais)


#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
log_archive_config                                          |string     |DG_CONFIG=(dbprod_gru1dc,dbprod_gru1s6)


alter system set log_archive_config='DG_CONFIG=(dbprod_gru1dc,dbprod_nw6_vcp)'; -- DBUNIQUE STANDBY,DBUNIQUE PROD 

#- tns do outro db (nesse caso standby)
alter system set fal_server='dbprod_dg';

#- tns do proprio db (nesse caso primary)
alter system set fal_client='dbprod_dbcs01';

#-configurar log dest do standby
alter system set log_archive_dest_2='SERVICE=dbprod_dg LGWR ASYNC NET_TIMEOUT=10 MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=dbprod_nw6_vcp'; -- conf standby


#- ativar log shipping (*** depois de tudo configurado)
alter system set log_archive_dest_state_2='ENABLE' scope=both;


###- se for DG cascade (3 nos)
##-- alter system set log_archive_dest_3='SERVICE=pano01_bm02 VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01_gru1nw';
##-- alter system set log_archive_dest_state_3='ENABLE';



##########################################
#-- no standby


alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=900 scope=both;

#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(dbprod_nw6_vcp,dbprod_gru1dc)'; -- STANDBY,PROD

|DG_CONFIG=(dbprod_gru1s6,dbprod_gru1dc)

#- tns do outro db (nesse caso primary)
alter system set fal_server='dbprod_dbcs01';


PARAMETER_NAME                                              |TYPE       |VALUE
fal_client                                                  |string     |dbprod_dg
fal_server                                                  |string     |dbprod_dbcs01


#- tns do proprio db (nesse caso standby)
alter system set fal_client='dbprod_dg';

#-configurar log dest do standby

PARAMETER_NAME                                              |TYPE       |VALUE
log_archive_dest_2                                          |string     |SERVICE=dbprod_dbcs01 LGWR ASYNC NET_TIMEOUT=10 MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=dbprod_gru1dc


alter system set log_archive_dest_2='SERVICE=dbprod_dbcs01 LGWR ASYNC NET_TIMEOUT=10 MAX_CONNECTIONS=1 REOPEN=60 VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=dbprod_gru1dc';

###- se for DG cascade (3 nos)
### alter system set log_archive_dest_3='SERVICE= VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01';


#- start recover no standby (com standby redo)
alter database recover managed standby database disconnect using current logfile;


So, the quick solution for ORA-01665 will be:

ALTER DATABASE CONVERT TO PHYSICAL STANDBY;





---recuperar gap 



##VER MENOR SCN

col CURRENT_SCN format 9999999999999999                                                        
select to_char (min (d.CURRENT_SCN)) from V$DATABASE d                                         
union                                                                                          
select to_char (max (d.CURRENT_SCN)) from V$DATABASE d                                         
union                                                                                          
select to_char (min (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           
union                                                                                          
select to_char (max (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           
union                                                                                          
select to_char (min (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f                                  
union                                                                                          
select to_char (max (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f ;   




TO_CHAR(MIN(D.CURRENT_SCN))
85397117672
85397207748

allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';



1315669756824

##GERAR BACKUP NO SERVIDOR DE DESTINO:


SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
BACKUP INCREMENTAL FROM SCN 85397117672 DATABASE FORMAT 'ForStandby_%U' tag 'FORSTANDBY';
}

##GERAR CONTROLFILE 

SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
BACKUP CURRENT CONTROLFILE FOR STANDBY TAG 'FORSTANDBY' FORMAT 'rman_ctrl_orcl_ARCHIVE_dbid%I_s%s_t%t_p%p.bkp';
}

rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
restore CONTROLFILE from 'rman_ctrl_orcl_ARCHIVE_dbid2989654969_s80893_t1169124840_p1.bkp';
}
ALTER DATABASE MOUNT;
__RMAN__


+DATA/DBPROD_NW6_VCP/DATAFILE/

# fazer um catalog para mandar pro destino com o nome dos arquivos


catalog DEVICE TYPE 'SBT_TAPE' backuppiece 
spool /tmp/catalog.cmd
set pagesize 0
select '   '''||HANDLE||''','||chr(10)
from V$BACKUP_PIECE bp
where bp.HANDLE is not null
and DEVICE_TYPE = 'SBT_TAPE'
AND TAG='FORSTANDBY'
order by START_TIME, PIECE#;
spool off



catalog DEVICE TYPE 'SBT_TAPE' backuppiece 
spool /tmp/catalog.cmd
set pagesize 0
select '   '''||HANDLE||''','||chr(10)
from V$BACKUP_PIECE bp
where bp.HANDLE is not null
and DEVICE_TYPE = 'SBT_TAPE'
--AND TAG='FORSTANDBY'
order by START_TIME, PIECE#;
spool off




#catalogar

rman target / cmdfile=catalog2.cmd



## fazer o recover 



SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/dbprod/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/dbprod/opcdbprod.ora)';
recover database noredo;
}


list backup of controlfile completed between "to_date('06/03/2024 00:00:00','DD/MM/YYYY HH24:MI:SS')" and "to_date('06/03/2024 23:30:00','DD/MM/YYYY HH24:MI:SS')";


recover standby database from service sine01_gru19j;


using target database control file instead of recovery catalog
RMAN configuration parameters for database with db_unique_name SINE01_STGO01 are:
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 30 DAYS;
CONFIGURE BACKUP OPTIMIZATION ON;
CONFIGURE DEFAULT DEVICE TYPE TO DISK; # default
CONFIGURE CONTROLFILE AUTOBACKUP OFF;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F';
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE 'SBT_TAPE' TO '%F';
CONFIGURE DEVICE TYPE DISK BACKUP TYPE TO COMPRESSED BACKUPSET PARALLELISM 4;
CONFIGURE DEVICE TYPE 'SBT_TAPE' PARALLELISM 4 BACKUP TYPE TO COMPRESSED BACKUPSET;
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1;
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE 'SBT_TAPE' TO 1;
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1;
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE 'SBT_TAPE' TO 1;
CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT   '/oracle/backup/fra/sine01/bkp_%d-%I-%T-%p_%U';
CONFIGURE MAXSETSIZE TO 40 G;
CONFIGURE ENCRYPTION FOR DATABASE OFF;
CONFIGURE ENCRYPTION ALGORITHM 'AES128';
CONFIGURE COMPRESSION ALGORITHM 'MEDIUM' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE;
CONFIGURE RMAN OUTPUT TO KEEP FOR 7 DAYS; # default
CONFIGURE ARCHIVELOG DELETION POLICY TO NONE;
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/u01/app/oracle/product/19.0.0.0/dbhome_1/dbs/snapcf_sine01.f'; # default








SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c6 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c7 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c8 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c9 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c10 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c11 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c12 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c13 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c14 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c15 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
recover database noredo;
}




SET ENCRYPTION ON IDENTIFIED BY 'Primedb#Rman2020';
run{
allocate channel c1 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS 'SBT_LIBRARY=/u01/app/oracle/opc/lib/sine01/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/sine01/opcsine01.ora)';
BACKUP INCREMENTAL FROM SCN 1315669756824 DATABASE FORMAT 'ForStandby_%U' tag 'FORSTANDBY';
}


29 de fevereiro -> INC1D DIA 01, INC1 DIA 02, INC1D DIA 03 , INC1D DIA04 , 






###################################################################################################################
#######
###                              script para apagar archives

echo $ORACLE_BASE
export ORACLE_BASE=/u01/app/oracle
mkdir -p $ORACLE_BASE/admin/scripts/
vi $ORACLE_BASE/admin/scripts/deletearchive

export ORACLE_SID=$1
ORAENV_ASK=NO
. oraenv

export NLS_DATE_FORMAT='DD/MM/YYYY HH24:MI:SS';
$ORACLE_HOME/bin/rman target / nocatalog << EOF >> /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log
   spool log to /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log;
   CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON ALL STANDBY;
   show all;
   DELETE noprompt archivelog until time 'sysdate-1';
EOF

chmod +x $ORACLE_BASE/admin/scripts/deletearchive

/u01/app/oracle/admin/scripts/deletearchive

20  08,20  * * *    root  su - oracle -c "/u01/app/oracle/admin/scripts/deletearchive vial01"

###################################################################################################################
#######
###                              Virada DG com SwitchOver



###########################################################
##
##     no primary
##

#- verificar o switchover_status
# -->>> A value of TO STANDBY or SESSIONS ACTIVE indicates that the primary database can be switched to the standby role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

# -->>> RECOVERY_MODE = MANAGED REAL TIME APPLY (recover ativo no standby)
# -->>> GAP_STATUS = NO GAP

col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id, DB_UNIQUE_NAME, DATABASE_MODE, recovery_mode, status, TYPE, gap_status, ARCHIVED_SEQ#, ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;

#- executar commit to switchover
alter database commit to switchover to physical standby with session shutdown;

#- montar o banco como standby
conn / as sysdba
startup nomount;
alter system set log_archive_dest_state_2='DEFER' ;
alter system set job_queue_processes=0;
alter database mount standby database;



###########################################################
##
##      no standby
##


#- verificar staus switchover_status
#->>> A value of TO PRIMARY or SESSIONS ACTIVE indicates that the standby database is ready to be switched to the primary role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

#- executar o switchover to primary
alter database commit to switchover to primary with session shutdown;


#- abrir o banco
-->>>> verificar parametro UNDO
alter database open;


#- ativar o log shipping para o antigo primary (se estiver tudo corretamente configurado)
alter system set log_archive_dest_state_2='ENABLE' ;


SELECT THREAD#, LOW_SEQUENCE#, HIGH_SEQUENCE# FROM V$ARCHIVE_GAP;


alter system set job_queue_processes=1000;











col id for 99
col destination for a40
col sequence for 99999999999
col tmode for a12
col error for a40
select dest_id id,
DESTINATION,
LOG_SEQUENCE sequence,
TRANSMIT_MODE tmode,
DELAY_MINS,
STATUS,
error
from v$archive_dest
where DESTINATION is not null
order by dest_id;





col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id,
DB_UNIQUE_NAME,
DATABASE_MODE,
recovery_mode,
STANDBY_LOGFILE_COUNT stdlogfile,
status,
TYPE,
gap_status,
ARCHIVED_SEQ#,
ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;



col id for 99
col message for a125
select DEST_ID ID,
to_char(timestamp,'DD/MM/YYYY HH24:MI:SS')||' '||message message
from v$dataguard_status;


select distinct process, status, thread#, sequence#, block#, blocks from v$managed_standby ;



















@?/rdbms/admin/ashrpt.sql

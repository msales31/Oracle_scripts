Notas:

########################## CATALOGO -  <<<< NO CASO DA KMM  ##########################
###
### DBSystem-RCAT01 (srvrcat01 rcat01_gru1tg )
### 152.70.221.69 -p 9922
###
### Adicionar ip no hosts (como root)
#

[ $(cat /etc/hosts | grep -ci srvrcat) -eq 0 ] && \
echo '
#- Rman Catalog
172.17.82.193 srvrcat' >> /etc/hosts
######


## Adicionar ip no hosts (como oracle, verificar $TNS_ADMIN
#

{
export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
test -f $TNS_ADMIN/tnsnames.ora &&
   cat $TNS_ADMIN/tnsnames.ora | grep 'RCAT01' ||

cat << EOFTNS >> $TNS_ADMIN/tnsnames.ora


RCAT01 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = srvrcat)(PORT = 2230))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = rcat01_pdb1.kmm.com.br)
    )
  )

EOFTNS

tnsping RCAT01
}
###################### 11c ############################
##
## Criar usuario no catalogo
#

sqlplus -s /nolog << CREATEUSER
   conn kmmrcatadm/KmmRCatAdmin#2020#@RCAT01
   create user rc_${ORACLE_SID} identified by RC_${ORACLE_SID}_kmm2020 default tablespace TBS_RCDATA;
   grant connect, resource, RECOVERY_CATALOG_OWNER, unlimited tablespace to rc_${ORACLE_SID};
CREATEUSER

############################################################
##
## Conectar no catalogo, registrar e configurar o database.
#

rman << RMAN
connect target /
connect catalog rc_${ORACLE_SID}/RC_${ORACLE_SID}_kmm2020@RCAT01
create catalog tablespace TBS_RCDATA;
register database;
RMAN


###########################################################################

ocid1.tenancy.oc1..aaaaaaaa6xdqdimduxwk7u532odbt7z7auidknja3hfe24hx63cfnemgrhfq
ocid1.user.oc1..aaaaaaaa53mtl7ip6mbnvpk5lfpgbccmnniy6r6m32gsolw75e363ooqs2za
ocid1.compartment.oc1..aaaaaaaae7wqn5scdhg6nbncayr7kpiw3vdsn7wowexerszp7ifr7k6gnbsa


echo rc_${ORACLE_SID}/RC_${ORACLE_SID}_kmm2020@RCAT01

show parameter control_file_record_keep_time;
show parameter archive_lag_target;

alter system set control_file_record_keep_time=31 scope=both;
alter system set archive_lag_target=900 scope=both;
alter system set recyclebin=off  scope=spfile;


KMM
Contrato:
112023
0 0/15 * * * ? *



####################################################
================ RCLONE  ======================


cat > rclone.conf <<EOF
[oci-dest]
type = s3
env_auth = false
access_key_id = bdc50d8fc5447859cc49c6f4b14170d2ac1d051e
secret_access_key = Aep/+oEWD1ceMAoAJRC+EMB8aYKbiiArttSLS6LJS9c=
region = sa-saopaulo-1
endpoint = https://grzcvzqjrljm.compat.objectstorage.sa-saopaulo-1.oraclecloud.com
EOF

Namespace: grzcvzqjrljm

Rclone KMM - VINHEDO

mkdir -p ~/.config/rclone
cd ~/.config/rclone

cat > rclone.conf <<EOF
[oci-dest]
type = s3
env_auth = false
access_key_id = bdc50d8fc5447859cc49c6f4b14170d2ac1d051e
secret_access_key = Aep/+oEWD1ceMAoAJRC+EMB8aYKbiiArttSLS6LJS9c=
region = sa-vinhedo-1
endpoint = https://grzcvzqjrljm.compat.objectstorage.sa-vinhedo-1.oraclecloud.com
EOF


rclone -I --progress copy rclone.conf oci-dest:Backup-esta01 
=========================================
List of Permanent Datafiles
===========================
File Size(MB) Tablespace           RB segs Datafile Name
---- -------- -------------------- ------- ------------------------
1    1493     SYSTEM               YES     /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_system_kk24n7bz_.dbf
2    1055     SYSAUX               NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_sysaux_kk24n7q7_.dbf
3    9352     UNDOTBS1             YES     /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_undotbs1_kk24n874_.dbf
4    544      USERS                NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_users_kk24n907_.dbf
5    697093   TS_DADOS             NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_dados_kk24nsxl_.dbf
6    162082   TS_INDICE            NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_indic_kk24nsf3_.dbf
7    2        TS_MAXIMA            NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_maxim_kk24nsnw_.dbf
8    2534     TS_CLOBS             NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_clobs_kk24nvn9_.dbf
9    2        TS_WMS               NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_wms_kk24oyrj_.dbf
10   2        TS_ENTREGAS          NO      /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_entre_kk24p2h6_.dbf

List of Temporary Files
=======================
File Size(MB) Tablespace           Maxsize(MB) Tempfile Name
---- -------- -------------------- ----------- --------------------
1    532      TEMP                 32767       /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_temp_kk3x61k0_.tmp
2    3072     TS_TEMP              32767       /oracle/oradata/CNFWINT_TST01/datafile/o1_mf_ts_temp_kk3x61o5_.tmp





NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
_fix_control                         string      18960760:on
control_file_record_keep_time        integer     7
control_files                        string      /oracle/oradata/CNFWINT/contro
                                                 l01.ctl
control_management_pack_access       string      DIAGNOSTIC+TUNING


NAME                                |TYPE       |VALUE
cdb_cluster_name                    |string     |
cell_offloadgroup_name              |string     |
db_file_name_convert                |string     |
db_name                             |string     |CNFWINT
db_unique_name                      |string     |CNFWINT_mq9_vcp
global_names                        |boolean    |TRUE
instance_name                       |string     |CNFWINT
lock_name_space                     |string     |
log_file_name_convert               |string     |
pdb_file_name_convert               |string     |
processor_group_name                |string     |
service_names                       |string     |CNFWINT_mq9_vcp.sndbvcp.vcncon
                                    |           |feiteirov.oraclevcn.com


NAME                                |TYPE       |VALUE
db_create_file_dest                 |string     |+DATA
db_create_online_log_dest_1         |string     |+RECO

CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';



CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';


## COPIAR LIB E OPC, COPIAR WALLET DO BANCO 


list backup of controlfile completed between "to_date('09/05/2023 00:00:00','DD/MM/YYYY HH24:MI:SS')" and "to_date('09/05/2023 23:59:00','DD/MM/YYYY HH24:MI:SS')";

BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ -------------------
25531   Full    39.75M     SBT_TAPE    00:00:46     09/05/2023 20:20:13
        BP Key: 28571   Status: AVAILABLE  Compressed: YES  Tag: INC1DDIARIO202305091930
        Handle: rman_ctrl_CNFWINT_INC1D_dbid2783289429_s27175_t1136405967_p1.bkp   Media: objectstorag~.sa-vinhedo-~.oraclecloud.com/n/axv~/Backup-CNFWINT
  Control File Included: Ckp SCN: 18617577086   Ckp time: 09/05/2023 20:19:27




rman target / << '__RMAN__'
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
restore CONTROLFILE from 'rman_ctrl_CNFWINT_INC1D_dbid2783289429_s27175_t1136405967_p1.bkp';
}
ALTER DATABASE MOUNT;
__RMAN__


## SE FOR PLUGABLLE SE ATENTAR AO PARAMETRO

*.enable_pluggable_database=false



rman_ctrl_prothprd_ARCHIVE_dbid462293352_s103718_t1118653192_p1.bkp

SBT_LIBRARY=/u02/app/oracle/opc/lib/prothprd/libopc.so, SBT_PARMS=(OPC_PFILE=/u02/app/oracle/opc/config/prothprd/opcprothprd.ora)


rman target / << eof
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
spool log to '/tmp/restore01.log';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
set newname for database to new;
SET UNTIL SCN 18617577086;
RESTORE DATABASE;
switch datafile all;
switch tempfile all;
recover database;
}
eof



rman target / << eof
SET DECRYPTION IDENTIFIED BY 'Primedb#Rman2020';
spool log to '/tmp/restore03.log';
run {
allocate channel c1 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
allocate channel c2 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
allocate channel c3 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
allocate channel c4 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
allocate channel c5 device type 'SBT_TAPE' PARMS  'SBT_LIBRARY=/u01/app/oracle/opc/lib/CNFWINT/libopc.so, SBT_PARMS=(OPC_PFILE=/u01/app/oracle/opc/config/CNFWINT/opcCNFWINT.ora)';
recover database UNTIL TIME "TO_DATE('09/05/2023 10:00:00','DD/MM/YYYY HH24:MI:SS')";
}
eof




"TO_DATE('26/10/
2022 10:00:00','DD/MM/YYYY HH24:MI:SS')";

"TO_DATE('21/10/2022 08:00:00','DD/MM/YYYY HH24:MI:SS')";


alter database backup controlfile to trace as '/home/oracle/ctlteste.ctl';

validar checkpoint apply

F#_|CheckPoint:Difference_____|_CheckPointTime___|Fzy|File___________________
001|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/system.275.1137668661
002|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/sysaux.269.1137676509
003|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/undotbs1.271.1137676169
004|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/users.283.1137676711
005|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/ts_dados.272.1137668659
006|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/ts_indice.284.1137676765
007|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/ts_maxima.285.1137677607
008|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/ts_clobs.282.1137676585
009|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/ts_wms.286.1137677643
010|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/ts_entregas.287.1137677677
011|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/system.273.1137668661
012|186175,42221:0            |09May2023/20:18:20|NO |+DATA/CNFWINT_MQ9_VCP/DATAFILE/system.274.1137676215


ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 7;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 8;




DIRECTORY=export_dir
DUMPFILE=exp_chamado_1189186_%U.dmp
FILESIZE=10g
LOGFILE=exp_chamado_1189186.log
PARALLEL=5
tables=MARCOSART.PCTABTRIB



\"/ as sysdba\"
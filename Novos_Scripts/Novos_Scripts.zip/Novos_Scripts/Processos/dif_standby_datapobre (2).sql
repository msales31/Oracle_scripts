-- restore arch:

-- PARAR ROTINAS NO CRONTAB COMENTANDO
sync.archive
sync.standby



-- verificar última seq no stby:

col CURRENT_SCN format 9999999999999999 
SELECT CURRENT_SCN FROM V$DATABASE;


-- comparar com o menor valor (abaixo)         <-----------------------------------------------|
																							   |
col CURRENT_SCN format 9999999999999999                                                        |
select to_char (min (d.CURRENT_SCN)) from V$DATABASE d                                         |
union                                                                                          |
select to_char (max (d.CURRENT_SCN)) from V$DATABASE d                                         |
union                                                                                          |
select to_char (min (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           |
union                                                                                          |
select to_char (max (h.CHECKPOINT_CHANGE#)) from V$DATAFILE_HEADER h                           |
union                                                                                          |
select to_char (min (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f                                  |
union                                                                                          |
select to_char (max (f.CHECKPOINT_CHANGE#)) from V$DATAFILE f ;                                |
																							   |
                                                                                               |
---fazer backup dos archives no primary ### IR NO PRIMARY                                      |
                                       +-------------------------------------------------------+
                                       |
                                  |----------|
RMAN> BACKUP INCREMENTAL FROM SCN 10982481530 DATABASE FORMAT '/backup/oracle/orcl/temp/183255/ForStandby_%U' tag 'FORSTANDBY';
                                                               |------------------------------|        <-------------------------------------+
															                 |                                                               |
																			 +--------> caminho com espaço livre suficiente                  |
																																			 |
-- Fazer a cópis dos scns para o STANDBY com scp mesmo para algum diretório que tenha espaço suficiente.                                     |
                                                                  |-----------------------------------|   <------------+                     |
																                     |                                 |                     |
							          +----------------------------------------------+                                 |                     |
                                      |                                                                                |                     |
-- catalogar no STANDBY   |--------------------------|                                                                 |                     |
RMAN> CATALOG START WITH '/u01/backup/oracle/orcl/temp/';                                                              |                     |
																													   |				     |
																													   |				     |
-- recuperar no stby:                                                                                                  |                     |
																													   |					 |
RECOVER DATABASE NOREDO;                                                                                               |                     | 
                                                               +------------------------------------------------------ | --------------------+
-- ###### NO PRIMARY ####                                      |                                                       |
-- Fazer backup do controlfile                 |------------------------------|                                        |
BACKUP CURRENT CONTROLFILE FOR STANDBY FORMAT '/backup/oracle/orcl/temp/183255/ForStandbyCTRL.bck';                    |
																													   |
-- enviar o bkp do control file para o stby com scp mesmo igual feito com os demais e para o mesmo caminho.            |
                                                                                             |-----------|             |
																							       |                   |
--### STANDBY                                                                                      +-------------------+
-- restaurar no stby                                                                               | 
                                                   +-----------------------------------------------+
RMAN> SHUTDOWN IMMEDIATE;                          |
RMAN> STARTUP NOMOUNT;                  |---------------------------|
RMAN> RESTORE STANDBY CONTROLFILE FROM '/u01/backup/oracle/orcl/temp/ForStandbyCTRL.bck';
RMAN> alter database mount;

-- REATIVAR ROTINAS NO CRONTAB DESCOMANTANDO:
sync.archive
sync.standby

									
						
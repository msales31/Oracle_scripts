#!/bin/bash

source /home/oracle/via01.env

##variaveis
SCRIPT_DIR=/u02/app/oracle/admin/via01_gru1x9/scripts
LOG_DIR=/u02/app/oracle/admin/via01_gru1x9/logs
SCRIPT_NAME=rebuild_index.sql

## pegando lista de pdbs
PDB_LIST=$($ORACLE_HOME/bin/sqlplus -S / as sysdba <<EOF
SET PAGESIZE 0
SET FEEDBACK OFF
SELECT name FROM v\$pdbs WHERE name NOT IN (
  'PDB\$SEED', 'CDB\$ROOT'
);
EOF
)

## Executando um de cada vez
for PDB_NAME in $PDB_LIST; do
  # Executando o catcon.pl para o PDB atual
  $ORACLE_HOME/perl/bin/perl $ORACLE_HOME/rdbms/admin/catcon.pl -R -b rebuild_index -d $SCRIPT_DIR -l $LOG_DIR -e -c "$PDB_NAME" $SCRIPT_NAME
done



---- script de rebuild  indice 
COLUMN FILE_NAME NEW_VALUE SPOOL_FILE NOPRINT
SELECT '/u02/app/oracle/admin/via01_gru1x9/scripts/' || UPPER(NAME) || '_rebuild.sql' FILE_NAME  FROM V$PDBS;
prompt &SPOOL_FILE
spool &SPOOL_FILE
exec DBMS_OUTPUT.ENABLE(10000000);
set serveroutput on size 1000000
declare
retorno varchar2(30000);
begin
 DBMS_OUTPUT.ENABLE(10000000);
for t in (select a.OWNER, a.OBJECT_NAME
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
AND a.owner like '%VIA%'
order by b.bytes)
loop
DBMS_OUTPUT.ENABLE (buffer_size => NULL);
  DBMS_OUTPUT.PUT_LINE('ALTER INDEX '||t.owner||'.'||t.OBJECT_NAME ||' REBUILD ONLINE PARALLEL 4;');
  DBMS_OUTPUT.PUT_LINE('ALTER INDEX '||t.owner||'.'||t.OBJECT_NAME||' NOPARALLEL;');
end loop;
end;
/
spool off

@&SPOOL_FILE


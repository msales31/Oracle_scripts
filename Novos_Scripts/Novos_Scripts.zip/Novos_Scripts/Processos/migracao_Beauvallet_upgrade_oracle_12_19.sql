#287939 - Instalação de novo servidor e migração de banco de dados Oracle

# -----------------------------------------------------------------------------


-------
- Para banco produção.🌀
- Parar scripts do /etc/crontab no srvoracle01 ⭕
- Aplicar até ultimo archive gerado da produção. ⭕
- Ativar Standby ⭕
- Criar tbs temp ⭕
- Rodar dbupgrade ⭕
- Rodar utlrp 2x ⭕
- Atualizar timezone ⭕
- Gerar pdb_descr_file ⭕
---- na base nova cdbprd
- Criar pdb orcl⭕
- Ajustar caminho do datafiles⭕
- Ajustar parametros process, validar parametros do bd⭕
- Fazer desfragmentacao da base(coleta de estatistica,shrink de tabelas, rebuild de indices, move de maiores objetos)⭕
* Ativar base para validações e testes⭕
* Configuração de monitoramento⭕



vi /etc/crontab


sqlplus / as sysdba <<_EOF_
shutdown immediate;
startup nomount;
alter database mount standby database;
_EOF_


sqlplus / as sysdba <<_EOF_
alter database activate standby database;
shutdown immediate;
startup upgrade;
exit;
_EOF_

# -- Cria tablespace temp

sqlplus / as sysdba << _EOF_
CREATE TEMPORARY TABLESPACE TMP TEMPFILE SIZE 50M AUTOEXTEND ON NEXT 50M MAXSIZE 32000M;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TMP;
DROP TABLESPACE TEMP INCLUDING CONTENTS AND DATAFILES;
_EOF_

$ORACLE_HOME/bin/dbupgrade

Phases [0-107]   Start Time:[2024_06_13 11:29:41]
Phases [0-107]     End Time:[2024_06_13 11:36:05]


sqlplus / as sysdba <<_EOF_
startup;
@?/rdbms/admin/utlrp.sql;
@?/rdbms/admin/utlrp.sql;
exit;
_EOF_

##--- upgrade timezone

sqlplus / as sysdba <<_EOF_
whenever sqlerror exit ; - - 
SELECT * FROM v$timezone_file;

SHUTDOWN IMMEDIATE;
STARTUP UPGRADE;

SET SERVEROUTPUT ON;
DECLARE l_tz_version PLS_INTEGER;
BEGIN l_tz_version := DBMS_DST.get_latest_timezone_version;
DBMS_OUTPUT.put_line('l_tz_version=' || l_tz_version);
DBMS_DST.begin_upgrade(l_tz_version);
END;
/

SHUTDOWN IMMEDIATE;
STARTUP;

-- Do the upgrade.
SET SERVEROUTPUT ON;
DECLARE l_failures PLS_INTEGER;
BEGIN DBMS_DST.upgrade_database(l_failures);
DBMS_OUTPUT.put_line('DBMS_DST.upgrade_database : l_failures=' || l_failures);
DBMS_DST.end_upgrade(l_failures);
DBMS_OUTPUT.put_line('DBMS_DST.end_upgrade : l_failures=' || l_failures);
END;
/

-- Check new settings.
SELECT * FROM v$timezone_file;

COLUMN property_name FORMAT A30
COLUMN property_value FORMAT A20
SELECT property_name, property_value
FROM database_properties
WHERE property_name LIKE 'DST_%'
ORDER BY property_name;
exit;
_EOF_

select banner from v$version;

### +++ Migra Non-CDB to CDB (pdb)

export ORACLE_SID=orcl

sqlplus / as sysdba 
SHUTDOWN IMMEDIATE;
STARTUP OPEN READ ONLY;
BEGIN DBMS_PDB.DESCRIBE(pdb_descr_file => '/tmp/cdb-orcl.xml');
END;
/

SHUTDOWN IMMEDIATE;

--------------------------------------------------------------------------------------------

- Sobe a base cdbprd no ORACLE_HOME 19c

. oraenv
cdbprd
export ORACLE_UNQNAME=cdbprd


-- Dropar e cria Novo PDB

sqlplus / as sysdba <<_EOF_
startup;
ALTER PLUGGABLE DATABASE orcl CLOSE IMMEDIATE INSTANCES=ALL;
DROP PLUGGABLE DATABASE orcl INCLUDING DATAFILES;
CREATE PLUGGABLE DATABASE orcl USING '/tmp/cdb-orcl.xml' TEMPFILE REUSE NOCOPY ;
ALTER SESSION SET CONTAINER=orcl;
@$ORACLE_HOME/rdbms/admin/noncdb_to_pdb.sql;
ALTER SESSION SET CONTAINER=orcl;
ALTER PLUGGABLE DATABASE orcl OPEN;
ALTER PLUGGABLE DATABASE orcl SAVE STATE;
_EOF_

COMP_TIMESTAMP UTLRP_BGN              2024-06-13 12:22:48
                                      Thu Jun 13 12:27:06 -03 2024


select name,status,action from PDB_PLUG_IN_VIOLATIONS where status<>'RESOLVED';

--/u01/app/oracle/product/19.0.0.0/dbhome_1/OPatch/datapatch -verbose -pdbs orcl


---create pfile='/tmp/initcdbprd.ora' from spfile;
---startup pfile='/tmp/initcdbprd.ora' nomount;
---create spfile from pfile='/tmp/initcdbprd.ora';
---###
---
---alter system set db_create_file_dest='/oracle/oradata' scope=both;
---alter system set db_create_online_log_dest_1='/oracle/oradata' scope=both;


SHUTDOWN IMMEDIATE;


cd /oracle/oradata/ORCL/datafile/
mv o1_mf_* /oracle/oradata/CDBPRD/ORCL/datafile/

startup nomount;
alter database mount;
alter system set standby_file_management=MANUAL;

alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_sysaux_m6ng701v_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_sysaux_m6ng701v_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_system_m6nq5b1f_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_system_m6nq5b1f_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tbs_perf_m6nkkg9s_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tbs_perf_m6nkkg9s_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6n9tt1g_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6n9tt1g_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6n9tt43_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6n9tt43_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6n9tt64_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6n9tt64_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6n9tt7j_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6n9tt7j_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6ng6zsp_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6ng6zsp_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nkkfyj_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nkkfyj_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nkkg4d_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nkkg4d_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nq59hw_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nq59hw_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nq59qn_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nq59qn_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nq59x5_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nq59x5_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nq5b4s_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nq5b4s_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsd_data_m6nq5b4x_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsd_data_m6nq5b4x_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsi_data_m6ng6zvg_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsi_data_m6ng6zvg_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsi_data_m6ng6zx7_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsi_data_m6ng6zx7_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsi_data_m6nkkg6l_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsi_data_m6nkkg6l_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsi_data_m6nq5c10_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsi_data_m6nq5c10_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_tsi_data_m6nq5c1k_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_tsi_data_m6nq5c1k_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_undotbs0_m6nq5b0o_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_undotbs0_m6nq5b0o_.dbf';
alter database rename file '/oracle/oradata/ORCL/datafile/o1_mf_users_m6nq5b3d_.dbf' to '/oracle/oradata/CDBPRD/ORCL/datafile/o1_mf_users_m6nq5b3d_.dbf';


o1_mf_system_m7ck5r8h_.dbf
o1_mf_sysaux_m7cbq4m8_.dbf
o1_mf_users_m7ck5rbr_.dbf
o1_mf_tsd_data_m7cbq4gw_.dbf
o1_mf_tsd_data_m7cf5r49_.dbf
o1_mf_tsd_data_m7c7wc03_.dbf
o1_mf_tsd_data_m7ck5qx2_.dbf
o1_mf_tsd_data_m7cf5r2d_.dbf
o1_mf_tsd_data_m7c7wbxg_.dbf
o1_mf_tsd_data_m7ck5qnc_.dbf
o1_mf_tsd_data_m7c7wc0n_.dbf
o1_mf_tsd_data_m7c7wc1g_.dbf
o1_mf_tsd_data_m7ck5r4m_.dbf
o1_mf_tsi_data_m7cbq4j7_.dbf
o1_mf_tsi_data_m7cf5r4p_.dbf
o1_mf_tsi_data_m7cbq4k8_.dbf
o1_mf_tsd_data_m7ck5rd8_.dbf
o1_mf_tsd_data_m7ck5rdd_.dbf
o1_mf_tsi_data_m7ck5s83_.dbf
o1_mf_tsi_data_m7ck5s8n_.dbf
o1_mf_undotbs0_m7ck5r7p_.dbf
o1_mf_tbs_perf_m7cf5r5r_.dbf


alter system set standby_file_management=AUTO scope=both;
alter database open;

-- ip da base antiga virou 144
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=none
DEFROUTE=yes
IPV4_FAILURE_FATAL=yes
IPV6INIT=no
IPV6_AUTOCONF=no
IPV6_DEFROUTE=no
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=eth0
UUID=19d63158-be12-4b65-bfc7-6de8d7150c33
DEVICE=eth0
ONBOOT=yes
IPADDR=192.168.10.144
PREFIX=23
GATEWAY=192.168.10.1
DNS1=192.168.10.2
~



### TUNING ######################################

shut immediate;
startup mount;
alter database noarchivelog;
alter database open;


tablespace size 

CLESA|#F|_______USED______ALLOC____MAX_[GRAPH_____<USE]__USABLE|_TableSpace_____
---M-| 1|     1,524M     1,533M    32G [*         < 5%]   30.5G| SYSTEM
-----| 1|     7,936M     8,745M    32G [**        <24%]   24.3G| SYSAUX
-----| 1|       100M       358M    32G [*         < 0%]   31.9G| USERS
U--M-| 1|        76M    12,430M    20G [*         < 0%]   19.5G| UNDOTBS01
tN-MU| 1|         0M       200M    32G [*         < 0%]   31.3G| TMP
-----|10|   278,371M   280,452M   316G [*******#  <86%]   43.7G| TSD_DATAVALE
-----| 3|    85,477M    87,317M    96G [*******#  <87%]   12.3G| TSI_DATAVALE
-----| 1|     1,229M     1,334M    32G [*         < 4%]   30.8G| TBS_PERFSTAT
-----| 2|         2M         6M    63G [*         < 0%]   62.5G| TSD_DATAVALETST
-----| 2|         2M         6M     5G [*         < 0%]    4.1G| TSI_DATAVALETST



tamanho liquido:

'_________SIZE_|_TYPE__________'
_________Size_|_Type__________
      90,623M | INDEX
           0M | INDEX PARTITION
           1M | LOB PARTITION
          10M | LOBINDEX
     179,374M | LOBSEGMENT
           0M | NESTED TABLE
      95,073M | TABLE
           0M | TABLE PARTITION
--------------|----------------
       356.5G | Total
	   
	  
	   
'_________SIZE_|_TYPE__________'
_________Size_|_Type__________
      81,144M | INDEX
           0M | INDEX PARTITION
           1M | LOB PARTITION
          10M | LOBINDEX
     179,334M | LOBSEGMENT
           0M | NESTED TABLE
      88,431M | TABLE
           0M | TABLE PARTITION
--------------|----------------
       340.7G | Total


tamanho banco bruto:
Database Size       |Used space          |Free space
391 GB              |382 GB              |9 GB


Database Size       |Used space          |Free space
396 GB              |371 GB              |25 GB



tamanho schemas:
OWNER                         |         MB|         GB
DATAVALE                      |   131959.1|      128.9
PTODATAVALE                   |    96821.9|       94.6
INDDATAVALE                   |    74411.4|       72.7
DTVDOC                        |    53079.1|       51.8
SYS                           |     9350.0|        9.1
INDDF                         |     7563.4|        7.4


##### PROCEDIMENTO PARA DESFRAGMENTAÇÃO BASE DE DADOS ORACLE ####
##### PRIME DB SOLUTIONS - 2023 ####
####
####  Premissas, salvar tamanho do banco liquido, bruto, tablespaces, maiores tabelas, tabelas mais fragmentadas ####


####

1 - Rebuild de índices do menor para o maior, para ir liberando espaço gradativamente na tablespace de índices.
2 - Enable row movement (habilitar a movimentação das tabelas para utilizar o shrink)
3 - Shrink de todas as tabelas ordenando da menor para a maior, para ir liberando espaço gradativamente no tablespace de dados.
4 - Shrink de lobs, novamente do menor para o maior. (SE TIVER JANELA BOA, PORQUE PESA BASTANTE)
5 - Disable row movement (desabilitar a movimentação das tabelas)
6 - Coleta de estatísticas

###
##### 1 ######
## Rebuild em PARALLEL quando for entreprise
## REBUILD DE INDICES EM PARALLEL ###
## Validar sempre se é ENTERPRISE e a QTD de CPU ###
## Ficar de olho na geração de archives / espaço / DR / DG ##
## Se colocar em noarchivelog, recriar o standby / dg, se tiver em archivelog, provavelmente vai perder o standby / dr e será necessário recupera-lo.
## Caso queira jogar os indices em outra tablespace, basta adicionar o comando TABLESPACE NOME após o parallel 4, porém, valida qual schema vai para qual tablespace.

exec DBMS_OUTPUT.ENABLE(10000000);
set serveroutput on size 1000000
spool /home/oracle/rebuild_index.sql;
declare
retorno varchar2(30000);
begin
 DBMS_OUTPUT.ENABLE(10000000);
for t in (select a.OWNER, a.OBJECT_NAME
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and a.object_type like '%INDEX%'
AND a.TEMPORARY LIKE 'N'
AND a.owner in ('DATAVALE','PTODATAVALE','INDDATAVALE','DTVDOC','INDDF')
order by b.bytes)
loop
DBMS_OUTPUT.ENABLE (buffer_size => NULL);
  DBMS_OUTPUT.PUT_LINE('ALTER INDEX '||t.owner||'.'||t.OBJECT_NAME ||' REBUILD;');
end loop;
end;
/
spool off;
##@rebuild_index.sql;


#########

##### 2 ######
####### ENABLE ROW MOVEMENT TABLES #####
spool /home/oracle/enable.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' ENABLE ROW MOVEMENT;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) in ('DATAVALE','PTODATAVALE','INDDATAVALE','DTVDOC','INDDF')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

###### SHRINK por order de tamanho, maiores no final.
spool /home/oracle/shrink.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' SHRINK SPACE;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) in ('DATAVALE','PTODATAVALE','INDDATAVALE','DTVDOC','INDDF')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

## Shrink de todos os lobs por  tamanho
spool /home/oracle/shrink_lobs.sql
select 'alter table '||a.owner||'."' || a.TABLE_NAME ||'" MODIFY LOB ("'||a.column_name||'")  (SHRINK SPACE);'
from dba_lobs a, DBA_SEGMENTS B
where A.OWNER=B.OWNER
and UPPER(a.owner) in ('DATAVALE','PTODATAVALE','INDDATAVALE','DTVDOC','INDDF')
and a.table_name = b.segment_name
ORDER BY B.BYTES;
spool off

####### DISABLE ROW MOVEMENT TABLES #####
spool /home/oracle/disable.sql;
select 'ALTER TABLE '||a.OWNER||'.'||a.OBJECT_NAME||' DISABLE ROW MOVEMENT;'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) in ('DATAVALE','PTODATAVALE','INDDATAVALE','DTVDOC','INDDF')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;

###### coleta.sql ordenado por bytes
spool /home/oracle/coleta.sql
select 'exec dbms_stats.gather_table_stats(''"'||a.owner||'"'' ,''"'||a.object_name||'"'',  cascade => true, method_opt=>''FOR ALL COLUMNS SIZE AUTO'', degree=>4);'
from dba_objects a, dba_segments b
where a.owner = b.owner
and a.object_name = b.segment_name
and UPPER(a.owner) in ('DATAVALE','PTODATAVALE','INDDATAVALE','DTVDOC','INDDF')
and a.object_type like '%TABLE%'
AND a.TEMPORARY LIKE 'N'
order by b.bytes;
spool off;





#####
## criar um arquivo com vi chamado tuning.sql

spool /home/oracle/tuning.log;
@/home/oracle/rebuild_index.sql;
@/home/oracle/enable.sql;
@/home/oracle/enable.sql;
@/home/oracle/shrink.sql;
@/home/oracle/shrink_lobs.sql; 
@/home/oracle/disable.sql;
@/home/oracle/disable.sql;
@?/rdbms/admin/utlrp.sql;
@/home/oracle/coleta.sql;
spool off;

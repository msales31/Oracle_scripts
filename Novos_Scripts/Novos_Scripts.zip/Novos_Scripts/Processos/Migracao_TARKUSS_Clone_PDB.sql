Fase 1:

-origem:tarkussdb
-destino:tarkussdb01


- desativar jobs do rundeck (antigo)
- desativar host no zabbix (antigo)
- verificar fila de jobs
alter system set job_queue_processes=0;
- criar pdbs 

CREATE PLUGGABLE DATABASE TARKUSS FROM TARKUSS@LINK_IMPORT keystore identified by "Cloud-Clientar-2390#" including shared key parallel 6;
CREATE PLUGGABLE DATABASE TARKUSS_DEV FROM TARKUSS_DEV@LINK_IMPORT keystore identified by "Cloud-Clientar-2390#" including shared key parallel 6;
alter pluggable database  TARKUSS open;
alter pluggable database  TARKUSS open;

- rodar datapatch
cd $ORACLE_HOME/OPatch/
./datapatch -pdbs TARKUSS,TARKUSS_DEV

- criar tablespace de teste
create tablespace TESTE LOGGING DATAFILE SIZE 1M;

-  ajustar monitoramento / zabbix (novo) (ativar o host, fazer discover, etc e por fim add tamplate Template Primedb Zabbix Sender v3)


- rodar calibrate IO
SET SERVEROUTPUT ON
DECLARE
  lat  INTEGER;
  iops INTEGER;
  mbps INTEGER;
BEGIN
-- DBMS_RESOURCE_MANAGER.CALIBRATE_IO (num_physical_disks, max_latency, iops, mbps, lat);
   DBMS_RESOURCE_MANAGER.CALIBRATE_IO (8, 10, iops, mbps, lat);

  DBMS_OUTPUT.PUT_LINE ('max_iops = ' || iops);
  DBMS_OUTPUT.PUT_LINE ('latency  = ' || lat);
  dbms_output.put_line('max_mbps = ' || mbps);
end;
/


- rodar inventario

- rodar backup inc0

- rodar coleta de estatistica rundeck

- descomentar scripts crontab











Origem: srvtarkuss01

destino: srvtarkuss02

 

- desativar jobs do rundeck (antigo)
- desativar host no zabbix (antigo)
- fila de job ja zerada

## antes job_queue_processes=20

- Shutdown origem (srvctl)
- startup;
- parar o listener
- gerar backup 

## EXPDP -- origem
cd /u01/app/oracle/backup
expdp  msales/msales123 parfile=parfile.par

##--- export dos dblinks
expdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=exp_dbnamedblinks.log \
full=y \
REUSE_DUMPFILES=y \
INCLUDE=DB_LINK:"\"IN(SELECT db_link FROM dba_db_links)\""



## DESTINO

- dropar usuarios = @drop_users.sql 
- criar usuarios - @create_users.sql 
- importar
cd /u01/app/oracle/backup
SQL>@drop_user.sql
SQL>@create_user.sql
--impdp \"/ as sysdba\" parfile=parfile.par

##--- import dos dblinks
impdp "'/ as sysdba'" \
DIRECTORY=dprefresh \
DUMPFILE=dbname-dblinks%U.dmp \
LOGFILE=imp_dbnamedblinks.log

- recompilar objetos - @?/rdbms/admin/utlrp.sql 
-ajustar monitoramento / zabbix (novo) (ativar host,fazer discover, etc e por fim add tamplate Template Primedb Zabbix Sender v3)
sudo java -jar /etc/zabbix/zbxsender.jar -discovery -v -o screen


- rodar backup inc0
- validar scripts da crontab



PENDENTE

- Criar monitoramento zabbix no srvtarkuss02
- validar scripts da crontab da fase 1 e 2
- levar a wallet












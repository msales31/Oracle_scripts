list backup of archivelog sequence 336341;
run{
set archivelog destination to '/u03/app/oracle/fast_recovery_area/ORCLDB02/archivelog';
restore archivelog from logseq=336341 until logseq=336342;						
}						
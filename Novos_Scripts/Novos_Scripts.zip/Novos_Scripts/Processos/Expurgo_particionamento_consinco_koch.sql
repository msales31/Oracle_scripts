SELECT constraint_name, status, validated
FROM ALL_CONSTRAINTS a
WHERE a.constraint_type = 'R'
AND a.owner='CONSINCO'
and a.r_constraint_name in
( SELECT p.constraint_name
 FROM ALL_CONSTRAINTS p
 WHERE p.table_name IN (
'MFL_CUPOMFISCAL',
'MFL_CUPOMFISCALPROMOCPDV',
'MFL_CUPOMFISCALCOMPRECEITA',
'MFL_CUPOMFISCALACRESDESCTO'
)
);


--#### RESULTADO 

CONSTRAINT_NAME                                                                                                                 |STATUS  |VALIDATED
MFL_CUPOMFISCALACRESDESCTOFK1                                                                                                   |ENABLED |VALIDATED
MFL_CUPOMFISCALCOMPRECEITAFK1                                                                                                   |ENABLED |VALIDATED
MFL_CUPOMFISCALPROMOCPDVFK1                                                                                                     |ENABLED |VALIDATED



--#### PARALLEL TABLE 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL PARALLEL 10;


-- Indices de cada tabela 
TABLE_OWNER         |TABLE_NAME                    |INDEX_NAME                    |POS#|COLUMN_NAME                   |DSC
CONSINCO            |MFL_CUPOMFISCALCOMPRECEITA    |MFL_CUPOMFISCALCOMPRECEITAPK  |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|SEQRECEITARENDTO              |
                                                                                  |   4|SEQPRODUTOCOMP                |


TABLE_OWNER         |TABLE_NAME                    |INDEX_NAME                    |POS#|COLUMN_NAME                   |DSC
CONSINCO            |MFL_CUPOMFISCALACRESDESCTO    |MFL_CUPOMFISCALACRESDESCTOPK  |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|SEQACRESDESCTO                |

Display indexes where table or index name matches %CONSINCO.MFL_CUPOMFISCALPROMOCPDV%...
TABLE_OWNER         |TABLE_NAME                    |INDEX_NAME                    |POS#|COLUMN_NAME                   |DSC
CONSINCO            |MFL_CUPOMFISCALPROMOCPDV      |MFL_CUPOMFISCALPROMOCPDVPK    |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|SEQPROMOCPDV                  |
                                                                                  |   4|SEQGRUPO                      |
                                                                                  |   5|SEQSUBGRUPO                   |




--Particionar filhas por referência
ALTER TABLE CONSINCO.MFL_CUPOMFISCALCOMPRECEITA
MODIFY PARTITION BY REFERENCE (MFL_CUPOMFISCALCOMPRECEITAFK1) parallel 10;

ALTER TABLE CONSINCO.MFL_CUPOMFISCALACRESDESCTO 
MODIFY PARTITION BY REFERENCE (MFL_CUPOMFISCALACRESDESCTOFK1) parallel 10;

ALTER TABLE CONSINCO.MFL_CUPOMFISCALPROMOCPDV
MODIFY PARTITION BY REFERENCE (MFL_CUPOMFISCALPROMOCPDVFK1) parallel 20;


-- VALIDAR PARTICIONAMENTO

SELECT table_name,
 partitioning_type,
 ref_ptn_constraint_name
FROM ALL_PART_TABLES
WHERE OWNER='CONSINCO' AND table_name IN ('MFL_CUPOMFISCAL',
 'MFL_CUPOMFISCALPROMOCPDV',
'MFL_CUPOMFISCALCOMPRECEITA',
'MFL_CUPOMFISCALACRESDESCTO'
 );
-- Resultado Esperado para as tabelas filhas: partitioning_type = 'REFERENCE'

TABLE_NAME                                                                                                                      |PARTITION|REF_PTN_CONSTRAINT_NAME
MFL_CUPOMFISCAL                                                                                                                 |RANGE    |
MFL_CUPOMFISCALACRESDESCTO                                                                                                      |REFERENCE|MFL_CUPOMFISCALACRESDESCTOFK1
MFL_CUPOMFISCALCOMPRECEITA                                                                                                      |REFERENCE|MFL_CUPOMFISCALCOMPRECEITAFK1
MFL_CUPOMFISCALPROMOCPDV                                                                                                        |REFERENCE|MFL_CUPOMFISCALPROMOCPDVFK1




-- VERIFICAR PARTICIONAMENTO 
SELECT *
FROM DBA_TAB_PARTITIONS A
WHERE A.OWNER='CONSINCO' and A.TABLE_NAME IN (
 'MFL_CUPOMFISCALPROMOCPDV',
'MFL_CUPOMFISCALCOMPRECEITA',
'MFL_CUPOMFISCALACRESDESCTO'
 );
 
 
 TABLE_NAME                                                                                                                      |PARTITION|REF_PTN_CONSTRAINT_NAME
MFL_CUPOMFISCALACRESDESCTO                                                                                                      |REFERENCE|MFL_CUPOMFISCALACRESDESCTOFK1
MFL_CUPOMFISCALCOMPRECEITA                                                                                                      |REFERENCE|MFL_CUPOMFISCALCOMPRECEITAFK1
MFL_CUPOMFISCALPROMOCPDV                                                                                                        |REFERENCE|MFL_CUPOMFISCALPROMOCPDVFK1



 
---### EXPURGO 


ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION PART01      UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22492  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22485  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22493  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22459  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22477  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22479  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22453  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22452  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22461  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22505  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22450  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22486  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22489  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22483  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22500  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22502  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22480  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22482  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22507  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22508  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22503  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22473  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22476  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22468  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22487  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22474  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22481  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22460  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22465  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22466  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22506  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22498  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22497  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22491  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22494  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22496  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22495  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22462  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22471  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22475  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22472  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22439  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22455  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22451  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22458  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22464  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22449  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22467  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22448  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22457  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22456  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22443  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22447  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22445  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22484  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22490  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22488  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22454  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22463  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22469  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22442  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22470  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22504  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22446  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22512  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22514  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22515  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22516  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22517  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22509  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22444  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22441  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22440  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22499  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22511  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22513  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22501  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22478  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22510  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22706  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P23620  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P24400  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P25405  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P26013  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P26641  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P27034  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P27417  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P27778  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P28161  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P28684  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P29429  UPDATE GLOBAL INDEXES; 
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P30409  UPDATE GLOBAL INDEXES; 



### REBUILD INDICES 
alter index CONSINCO.MFL_CUPOMFISCALIE1 rebuild partition SYS_P31376 tablespace TSI_CONSINCOBIG parallel 10 online;
alter index CONSINCO.MFL_CUPOMFISCALIE1 rebuild partition SYS_P32364 tablespace TSI_CONSINCOBIG parallel 10 online;
alter index CONSINCO.MFL_CUPOMFISCALIE1 rebuild partition SYS_P33170 tablespace TSI_CONSINCOBIG parallel 10 online;
alter index CONSINCO.MFL_CUPOMFISCALIE1 rebuild partition SYS_P34094 tablespace TSI_CONSINCOBIG parallel 10 online;

alter index CONSINCO.MFL_CUPOMFISCALIE22 rebuild partition SYS_P31376 tablespace TSI_CONSINCOBIG parallel 10 online;
alter index CONSINCO.MFL_CUPOMFISCALIE22 rebuild partition SYS_P32364 tablespace TSI_CONSINCOBIG parallel 10 online;
alter index CONSINCO.MFL_CUPOMFISCALIE22 rebuild partition SYS_P33170 tablespace TSI_CONSINCOBIG parallel 10 online;
alter index CONSINCO.MFL_CUPOMFISCALIE22 rebuild partition SYS_P34094 tablespace TSI_CONSINCOBIG parallel 10 online;

ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE9 REBUILD online   PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE8 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE7 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE6 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE5 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE4 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE3 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE2 REBUILD online  PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE10 REBUILD online PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALIE11 REBUILD online PARALLEL 10;
ALTER INDEX CONSINCO.MFL_CUPOMFISCALPK REBUILD online PARALLEL 10;






ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTIALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22474  UPDATE GLOBAL INDEXES
*
ERROR at line 1:
ORA-04022: nowait requested, but had to wait to lock dictionary object


Elapsed: 00:00:49.48
22:43:21 SYS@consinco1> TION SYS_P22440  UPDATE GLOBAL INDEXES;
ALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTIALTER TABLE CONSINCO.MFL_CUPOMFISCAL DROP PARTITION SYS_P22481  UPDATE GLOBAL INDEXES
*
ERROR at line 1:
ORA-04022: nowait requested, but had to wait to lock dictionary object









TABLE_OWNER         |TABLE_NAME                    |INDEX_NAME                    |POS#|COLUMN_NAME                   |DSC
CONSINCO            |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE1            |   1|DTAMOVIMENTO                  |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|NROSERIEECF                   |
                                                   |MFL_CUPOMFISCALIE10           |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|SEQITEMDF                     |
                                                   |MFL_CUPOMFISCALIE11           |   1|SYS_NC00194$                  |
                                                                                  |   2|SYS_NC00195$                  |
                                                                                  |   3|NROEMPRESA                    |
                                                                                  |   4|NROSERIEECF                   |
                                                   |MFL_CUPOMFISCALIE2            |   1|NUMERODF                      |
                                                                                  |   2|SERIEDF                       |
                                                                                  |   3|NROSERIEECF                   |
                                                                                  |   4|NROEMPRESA                    |
                                                                                  |   5|NROECF                        |
                                                   |MFL_CUPOMFISCALIE22           |   1|NUMERODF                      |
                                                                                  |   2|SEQITEMDF                     |
                                                                                  |   3|NROEMPRESA                    |
                                                                                  |   4|DTAMOVIMENTO                  |
                                                   |MFL_CUPOMFISCALIE3            |   1|INDREPLICACAO                 |
                                                   |MFL_CUPOMFISCALIE4            |   1|SEQEXPORTACAOFISCI            |
                                                   |MFL_CUPOMFISCALIE5            |   1|SEQEXPORTACAOFISCICANC        |
                                                   |MFL_CUPOMFISCALIE6            |   1|NROEMPRESA                    |
                                                                                  |   2|INDEXPORTACAOFISCI            |
                                                   |MFL_CUPOMFISCALIE7            |   1|NUMERONF                      |
                                                                                  |   2|SERIENF                       |
                                                                                  |   3|NROEMPRESA                    |
                                                   |MFL_CUPOMFISCALIE8            |   1|SEQPROMOCPDV                  |
                                                                                  |   2|NROEMPRESA                    |
                                                   |MFL_CUPOMFISCALIE9            |   1|SEQDOCTOPDV                   |
                                                                                  |   2|SEQITEMPDV                    |
                                                                                  |   3|NROEMPRESAPDV                 |
                                                                                  |   4|NROCHECKOUTPDV                |
                                                   |MFL_CUPOMFISCALPK             |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                    |MFL_CUPOMFISCALACRESDESCTO    |MFL_CUPOMFISCALACRESDESCTOPK  |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|SEQACRESDESCTO                |
                    |MFL_CUPOMFISCALCOMPRECEITA    |MFL_CUPOMFISCALCOMPRECEITAPK  |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|SEQRECEITARENDTO              |
                                                                                  |   4|SEQPRODUTOCOMP                |
                    |MFL_CUPOMFISCALPROMOCPDV      |MFL_CUPOMFISCALPROMOCPDVPK    |   1|SEQCUPOMFISCAL                |
                                                                                  |   2|NROEMPRESA                    |
                                                                                  |   3|SEQPROMOCPDV                  |
                                                                                  |   4|SEQGRUPO                      |
                                                                                  |   5|SEQSUBGRUPO                   |

Elapsed: 00:00:00.21
INDEX_OWNER         |TABLE_NAME                    |INDEX_NAME                    |IDXTYPE   |UNIQ|STATUS  |PART|TEMP| H|    LFBLKS|          NDK|NUM_ROWS|   CLUF|LAST_ANALYZED      |DEGREE|VISIBILIT
CONSINCO            |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE1            |NORMAL    |NO  |N/A     |YES |N   | 4|  22629147|      1177776| 4.4E+09|7.4E+08|2026-01-18 03:32:14|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE10           |NORMAL    |NO  |VALID   |NO  |N   | 4|  16642821|   4445536903| 4.4E+09|2.9E+09|2026-01-18 03:41:40|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE11           |FBI NORMAL|NO  |VALID   |NO  |N   | 5|  26639871|    355394019| 4.4E+09|8.3E+08|2026-01-18 03:23:37|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE2            |NORMAL    |NO  |VALID   |NO  |N   | 5|  27732258|    279731248| 4.4E+09|8.3E+08|2026-01-18 03:27:41|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE22           |NORMAL    |NO  |N/A     |YES |N   | 4|  18454404|   4229601167| 4.4E+09|3.7E+09|2026-01-04 03:23:23|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE3            |NORMAL    |NO  |VALID   |NO  |N   | 4|  12345657|            1| 4.4E+09|2.9E+08|2026-01-18 03:29:14|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE4            |NORMAL    |NO  |VALID   |NO  |N   | 4|   9417734|    201981952| 2.5E+09|4.7E+08|2026-01-18 03:33:22|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE5            |NORMAL    |NO  |VALID   |NO  |N   | 3|      4832|       110032| 1373621| 237202|2026-01-18 03:32:14|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE6            |NORMAL    |NO  |VALID   |NO  |N   | 4|  14088347|          205| 4.4E+09|6.8E+08|2026-01-18 03:46:50|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE7            |NORMAL    |NO  |VALID   |NO  |N   | 4|  18070094|    196838871| 4.4E+09|7.6E+08|2026-01-18 03:35:59|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE8            |NORMAL    |NO  |VALID   |NO  |N   | 4|  13293968|       243364| 4.4E+09|6.8E+08|2026-01-18 03:38:42|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALIE9            |NORMAL    |NO  |VALID   |NO  |N   | 4|  22166885|   4166287739| 4.2E+09|4.1E+09|2026-01-18 03:44:28|1     |VISIBLE
                    |MFL_CUPOMFISCAL               |MFL_CUPOMFISCALPK             |NORMAL    |YES |VALID   |NO  |N   | 4|   7607451|   4445536903| 4.4E+09|2.9E+09|2026-01-18 03:24:54|1     |VISIBLE
                    |MFL_CUPOMFISCALACRESDESCTO    |MFL_CUPOMFISCALACRESDESCTOPK  |NORMAL    |YES |VALID   |NO  |N   | 4|    558143|    451799501| 4.5E+08|1.7E+08|2026-01-18 03:47:39|1     |VISIBLE
                    |MFL_CUPOMFISCALCOMPRECEITA    |MFL_CUPOMFISCALCOMPRECEITAPK  |NORMAL    |YES |VALID   |NO  |N   | 1|         0|            0|       0|      0|2026-01-18 03:47:39|1     |VISIBLE
                    |MFL_CUPOMFISCALPROMOCPDV      |MFL_CUPOMFISCALPROMOCPDVPK    |NORMAL    |YES |VALID   |NO  |N   | 3|     39543|      8558842| 8558842|2542977|2026-01-18 03:47:42|1     |VISIBLE
Elapsed: 00:00:00.59




---### RETIRAR PARALELISMO

ALTER TABLE CONSINCO.MFL_CUPOMFISCAL NOPARALLEL;
ALTER TABLE CONSINCO.MFL_CUPOMFISCALPROMOCPDV NOPARALLEL;
ALTER TABLE CONSINCO.MFL_CUPOMFISCALCOMPRECEITA NOPARALLEL;
ALTER TABLE CONSINCO.MFL_CUPOMFISCALACRESDESCTO NOPARALLEL;

SELECT a.degree, 'ALTER INDEX ' || a.INDEX_NAME || ' NOPARALLEL;'
FROM dba_indexes a
WHERE a.TABLE_NAME IN (
'MFL_CUPOMFISCAL',
 'MFL_CUPOMFISCALPROMOCPDV',
'MFL_CUPOMFISCALCOMPRECEITA',
'MFL_CUPOMFISCALACRESDESCTO'
 );

--### coletar estatistica 
EXEC DBMS_STATS.gather_table_stats (ownname => 'CONSINCO',tabname=> 'MFL_CUPOMFISCAL',method_opt => 'FOR ALL COLUMNS SIZE AUTO',GRANULARITY => 'GLOBAL AND PARTITION',cascade=> true,DEGREE=>'10');


OWNER                         |T|  TOTAL
CONSINCO                      |N|2171.78



---### RETIRAR PARALELISMO

ALTER TABLE MFL_CUPOMFISCAL NOPARALLEL;
ALTER TABLE MFL_CUPOMFISCALPROMOCPDV NOPARALLEL;
ALTER TABLE MFL_CUPOMFISCALCOMPRECEITA NOPARALLEL;
ALTER TABLE MFL_CUPOMFISCALACRESDESCTO NOPARALLEL;
SELECT a.degree, 'ALTER INDEX ' || a.INDEX_NAME || ' NOPARALLEL;'
FROM user_indexes a
WHERE a.TABLE_NAME IN (
'MFL_CUPOMFISCAL',
 'MFL_CUPOMFISCALPROMOCPDV',
'MFL_CUPOMFISCALCOMPRECEITA',
'MFL_CUPOMFISCALACRESDESCTO'
 );
 
 
 
 
 
TABLE_OWNER                   |TABLE_NAME                    |    POS|COM|PARTITION_NAME                |NUM_ROWS|SUBPARTITION_COUNT|HIGH_VALUE_RAW                                                                                      |HIGH_VALUE_LENGTH|COMPRESS|COMPRESS_FOR
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      1|NO |PART01                        | 9.8E+08|                 0|TO_DATE(' 2022-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|ENABLED |ARCHIVE LOW
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      2|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20604;                    | 5.4E+07|                 0|TO_DATE(' 2022-02-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      3|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20606;                    | 5.1E+07|                 0|TO_DATE(' 2022-03-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      4|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20607;                    | 8.0E+07|                 0|TO_DATE(' 2022-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      5|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20605;                    | 9.3E+07|                 0|TO_DATE(' 2022-05-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      6|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20322;                    | 1.0E+08|                 0|TO_DATE(' 2022-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      7|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20323;                    | 7.0E+07|                 0|TO_DATE(' 2022-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      8|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20324;                    | 7.0E+07|                 0|TO_DATE(' 2022-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      9|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20325;                    | 1.2E+08|                 0|TO_DATE(' 2022-09-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     10|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20326;                    | 1.2E+08|                 0|TO_DATE(' 2022-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     11|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20327;                    | 8.0E+07|                 0|TO_DATE(' 2022-11-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     12|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20328;                    | 9.1E+07|                 0|TO_DATE(' 2022-12-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     13|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20329;                    | 1.4E+08|                 0|TO_DATE(' 2023-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     14|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20330;                    | 1.7E+08|                 0|TO_DATE(' 2023-02-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     15|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20331;                    | 2.1E+08|                 0|TO_DATE(' 2023-03-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     16|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20332;                    | 2.7E+08|                 0|TO_DATE(' 2023-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     17|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20333;                    | 2.0E+08|                 0|TO_DATE(' 2023-05-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     18|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20334;                    | 2.6E+08|                 0|TO_DATE(' 2023-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     19|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20335;                    | 3.5E+08|                 0|TO_DATE(' 2023-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     20|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20336;                    | 3.1E+08|                 0|TO_DATE(' 2023-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     21|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20337;                    | 4.3E+08|                 0|TO_DATE(' 2023-09-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     22|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20338;                    | 3.9E+08|                 0|TO_DATE(' 2023-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     23|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20339;                    | 3.5E+08|                 0|TO_DATE(' 2023-11-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     24|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20340;                    | 3.4E+08|                 0|TO_DATE(' 2023-12-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     25|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20341;                    | 4.3E+08|                 0|TO_DATE(' 2024-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     26|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20346;                    | 5.0E+08|                 0|TO_DATE(' 2024-02-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     27|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20347;                    | 5.0E+08|                 0|TO_DATE(' 2024-03-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     28|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20348;                    | 4.5E+08|                 0|TO_DATE(' 2024-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     29|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20349;                    | 5.1E+08|                 0|TO_DATE(' 2024-05-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     30|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20379;                    | 5.2E+08|                 0|TO_DATE(' 2024-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     31|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P20599;                    | 4.6E+08|                 0|TO_DATE(' 2024-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     32|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P21622;                    | 4.6E+08|                 0|TO_DATE(' 2024-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     33|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P22708;                    |        |                 0|TO_DATE(' 2024-09-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     34|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P23604;                    |        |                 0|TO_DATE(' 2024-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     35|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P24439;                    |        |                 0|TO_DATE(' 2024-11-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     36|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P25424;                    |        |                 0|TO_DATE(' 2024-12-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                      |MRL_CUSTOVERBA_LOG            |     37|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P26015;                    |        |                 0|TO_DATE(' 2025-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|




 TABLE_OWNER                   |TABLE_NAME                    |    POS|COM|PARTITION_NAME                |NUM_ROWS|SUBPARTITION_COUNT|HIGH_VALUE_RAW                                                                                      |HIGH_VALUE_LENGTH|COMPRESS|COMPRESS_FOR
CONSINCO                      |MRL_CUSTOVERBA_LOG            |      1|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P26654;                    |        |                 0|TO_DATE(' 2025-02-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      2|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P27020;                    |        |                 0|TO_DATE(' 2025-03-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      3|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P27407;                    |        |                 0|TO_DATE(' 2025-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      4|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P27788;                    |        |                 0|TO_DATE(' 2025-05-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      5|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P28215;                    |        |                 0|TO_DATE(' 2025-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      6|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P28693;                    |        |                 0|TO_DATE(' 2025-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      7|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P29440;                    |        |                 0|TO_DATE(' 2025-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')                 |               83|DISABLED|
CONSINCO                                                     |      8|NO |ALTER TABLE CONSINCO.MRL_CUSTOVERBA_LOG drop PARTITION SYS_P30420;                    |        |                 0|TO_DATE(' 2025-09-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')           
 
 
 
 
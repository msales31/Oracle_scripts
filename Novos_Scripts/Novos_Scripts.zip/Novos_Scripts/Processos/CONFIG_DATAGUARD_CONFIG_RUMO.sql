RUN{
set newname for database to new;
ALLOCATE CHANNEL prim1 TYPE DISK;
ALLOCATE CHANNEL prim2 TYPE DISK;
ALLOCATE CHANNEL prim3 TYPE DISK;
ALLOCATE CHANNEL prim4 TYPE DISK;
ALLOCATE CHANNEL prim5 TYPE DISK;
ALLOCATE CHANNEL prim6 TYPE DISK;
ALLOCATE CHANNEL prim7 TYPE DISK;
ALLOCATE CHANNEL prim8 TYPE DISK;
ALLOCATE CHANNEL prim9 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux1 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux2 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux3 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux4 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux5 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux6 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux7 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux8 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux9 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux10 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux11 TYPE DISK;
ALLOCATE AUXILIARY CHANNEL aux12 TYPE DISK;
DUPLICATE TARGET DATABASE FOR STANDBY FROM ACTIVE DATABASE DORECOVER NOFILENAMECHECK;
}


/u01/app/oracle/product/11.2.0.4/dbhome_3/dbs] srvctl add database -d config_grustb -o /u01/app/oracle/product/11.2.0.4/dbhome_3 -p /u01/app/oracle/product/11.2.0.4/dbhome_3/spfileconfig.ora -s MOUNT -t IMMEDIATE -i config


rman target sys/"hVzZEwrs##198"@ auxiliary sys/"hVzZEwrs##198"@CDBDR01
#- spool log to /home/oracle/duplicate.log
run {
allocate channel prmy1 type disk;
allocate channel prmy2 type disk;
allocate channel prmy3 type disk;
allocate channel prmy4 type disk;
allocate channel prmy5 type disk;
allocate channel prmy6 type disk;
allocate channel prmy7 type disk;
allocate channel prmy8 type disk;
allocate channel prmy9 type disk;
allocate channel prmy10 type disk;
allocate channel prmy11 type disk;
allocate auxiliary channel stby1 type disk;
allocate auxiliary channel stby2 type disk;
allocate auxiliary channel stby3 type disk;
allocate auxiliary channel stby4 type disk;
allocate auxiliary channel stby5 type disk;
allocate auxiliary channel stby6 type disk;
allocate auxiliary channel stby7 type disk;
allocate auxiliary channel stby8 type disk;
allocate auxiliary channel stby9 type disk;
allocate auxiliary channel stby10 type disk;
allocate auxiliary channel stby11 type disk;
   DUPLICATE TARGET DATABASE
      FOR STANDBY
      FROM ACTIVE DATABASE
      DORECOVER;
	  
	  
	  run{
	  allocate channel prmy1 type disk;
	  backup current controlfile for standby format '';
      }

set controlfile autobackup off;

run{
allocate channel t1 device type disk;
set controlfile autobackup format for device type disk to '/tmp/%F';
restore standby controlfile from '/tmp/cf_autobak_b22c50gg_89442_1_1';
}

restore controlfile from autobackup db_recovery_file_dest='/tmp/%F' db_name=CDB01;


set controlfile autobackup format for device type disk to'/u01/autobackup/%F';
set controlfile autobackup format for device type disk to '/tmp/%F';


Sem Gaps:
   DEST_ID SYSDATE             THREAD# ULTIMO RECEBIDO ULTIMO APLICADO LAST_APP_TIMESTA   ARC_DIFF
---------- ---------------- ---------- --------------- --------------- ---------------- ----------
         2 21/11/2023 23:50          1           71798           71798 21/11/2023 23:30          0

Processos:
   INST_ID PROCESS      THREAD#  SEQUENCE#     BLOCK# STATUS       CLIENT_P
---------- --------- ---------- ---------- ---------- ------------ --------
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 DGRD               0          0          0 ALLOCATED    N/A
         1 DGRD               0          0          0 ALLOCATED    N/A
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 ARCH               0          0          0 CONNECTED    ARCH
         1 RFS                1          0          0 IDLE         Archival
         1 RFS                1      71799      68034 RECEIVING    LGWR
         1 MRP0               1      71796      87772 APPLYING_LOG N/A


Configuração Standby:

NAME                      VALUE
------------------------- ------------------------------------------------------------------------------------------------------------------------
log_archive_dest_1        LOCATION=USE_DB_RECOVERY_FILE_DEST  MANDATORY REOPEN VALID_FOR=(ALL_ROLES, ALL_LOGFILES) db_unique_name=CDBDR01_b24_gru
log_archive_dest_2        service=CDB01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDB01_vcp1jx
log_archive_dest_3
log_archive_dest_4
log_archive_dest_state_2  enable
log_archive_dest_state_3  enable
log_archive_dest_state_4  enable
fal_client                CDBDR01
fal_server                CDB01
log_archive_config        DG_CONFIG=(CDBDR01_b24_gru,CDB01_vcp1jx)
log_archive_format        %t_%s_%r.dbf
log_archive_max_processes 4
standby_file_management   AUTO
remote_login_passwordfile EXCLUSIVE
db_name                   CDB01
db_unique_name            CDBDR01_b24_gru


Configuração Primary:

NAME                      VALUE
------------------------- ---------------------------------------------------------------------------------------------------
log_archive_dest_1        location=USE_DB_RECOVERY_FILE_DEST valid_for=(ALL_LOGFILES,ALL_ROLES) db_unique_name=CDB01_vcp1jx
log_archive_dest_2        service=CDBDR01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDBDR01_b24_gru
log_archive_dest_3
log_archive_dest_4
log_archive_dest_state_2  ENABLE
log_archive_dest_state_3  enable
log_archive_dest_state_4  enable
fal_client                CDB01
fal_server                CDBDR01
log_archive_config        dg_config=(CDB01_vcp1jx,CDBDR01_b24_gru,cdbdr01_gru155)
log_archive_format        %t_%s_%r.dbf
log_archive_max_processes 4
standby_file_management   AUTO
remote_login_passwordfile EXCLUSIVE
db_name                   CDB01
db_unique_name            CDB01_vcp1jx




rman <<EOF
connect target sys/hVzZEwrs##198@;
connect auxiliary sys/hVzZEwrs##198@dup;
run {
allocate channel prmy1 type disk;
allocate channel prmy2 type disk;
allocate channel prmy3 type disk;
allocate channel prmy4 type disk;
allocate channel prmy5 type disk;
allocate channel prmy6 type disk;
allocate channel prmy7 type disk;
allocate channel prmy8 type disk;
allocate channel prmy9 type disk;
allocate channel prmy10 type disk;
allocate channel prmy11 type disk;
DUPLICATE TARGET DATABASE FOR STANDBY FROM ACTIVE DATABASE DORECOVER NOFILENAMECHECK;
}
EOF


###################################################################################################################
#######
###                              Criar DG sem Broker


###########################################################
##
##     adicionar redos standby (se ainda nao tem )
##        mesma quantidade e tamanho de redos existente

alter database add standby logfile group 911 size 500M;
alter database add standby logfile group 912 size 500M;
alter database add standby logfile group 913 size 500M;
alter database add standby logfile group 914 size 500M;
alter database add standby logfile group 915 size 500M;
alter database add standby logfile group 916 size 500M;

alter database add standby logfile group 917 size 2048M;
alter database add standby logfile group 918 size 2048M;


###########################333###########################################################
##
##     configurar listener e tnsnames
##        (primary e standby)


##########################################
#-- adicionar entrada no listener


#-- se NAO tem uma network de dr/backup, adicionar entrada no listener default

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

SID_LIST_LISTENER =
    (SID_LIST =
	   (SID_DESC =
	        (GLOBAL_DBNAME=rumo01_bm04)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/stdone)
		    (SID_NAME=pano01)
	    )
	)

lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status



#--- OU se TEM uma network de dr/backup configurar um listener separado

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/listener.ora

LISTENER_DG =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = xxIP_DRxx)(PORT = 1525))
    )
  )

SID_LIST_LISTENER_DG =
    (SID_LIST=
	   (SID_DESC=
	        (GLOBAL_DBNAME=rumo01_bm03)
	        (ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_2)
		    (SID_NAME=rumo01)
	    )
	)


lsnrctl reload && lsnrctl status
ou
srvctl stop listener && srvctl start listener && lsnrctl status


#-- adicionar entrada no tnsnames (verificar qual tns a base usa) dois dois lados

export TNS_ADMIN=${TNS_ADMIN:-$ORACLE_HOME/network/admin}
vi $TNS_ADMIN/tnsnames.ora

VOX_PRD =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.29.10.71)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = voxline_gru16d.subnetdb.vcnvoxline.oraclevcn.com)
      (UR = A)
    )
  )

VOX_DG =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 172.29.10.236)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = voxline_dg)
      (UR = A)
    )
  )




###################################################################################################################
#######
###                              Copiar o pwdfile da producao para o standby

mv /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01 /u01/app/oracle/product/11.2.0.4/dbhome_3/dbs/orapwpano01.ori
scp $ORACLE_HOME/dbs/orapwpano01 152.67.45.93:/u01/app/oracle/product/11.2.0.4/dbhome_3/dbs



###################################################################################################################
#######
###                              Testar e validar conexao dos dois lados


conn sys/"hVzZEwrs##198"@rumo01_dbcs as sysdba
select host_name,STATUS from v$instance;


conn sys/"hVzZEwrs##198"@rumo01_bm04 as sysdba
select host_name,STATUS from v$instance;


###################################################################################################################
#######
###                              Duplicate

#. TARGET     = banco origem
#. AUXILIARY  = banco destino

connect target sys/"hVzZEwrs##198"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.221.3.2)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A))) auxiliary sys/"hVzZEwrs##198"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))

rman target sys/"hVzZEwrs##198"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.32)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_dbcs)(UR=A)))" auxiliary sys/"hVzZEwrs##198"@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.82.22)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=rumo01_bm04)(UR=A)))"
#- spool log to /home/oracle/duplicate.log
run {
   allocate channel prmy1 type disk;
   allocate channel prmy2 type disk;
   allocate channel prmy3 type disk;
   allocate channel prmy4 type disk;
   allocate auxiliary channel stby1 type disk;
   DUPLICATE TARGET DATABASE
      FOR STANDBY
      FROM ACTIVE DATABASE
      DORECOVER;
}




###################################################################################################################
#######
###                              Configurar DG sem broker


##########################################
#-- no primary

alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- verificar se foram adicionados redos standby (mesmo numero de grupos e tamanho dos atuais)


#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(config_grupri,config_grustb)'; -- DBUNIQUE PROD,DBUNIQUE STANDBY 

NAME                                |TYPE       |VALUE
log_archive_config                  |string     |dg_config=(CDB01_vcp1jx,CDBDR0
                                    |           |1_b24_gru,cdbdr01_gru155)


#- tns do outro db (nesse caso standby)
alter system set fal_server='config_grustb';

#- tns do proprio db (nesse caso primary)
alter system set fal_client='config_grupri';

#-configurar log dest do standby
alter system set log_archive_dest_2='SERVICE=config_grustb LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=config_grustb'; 

service=CDBDR01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDBDR01_b24_gru

#- ativar log shipping (*** depois de tudo configurado)
alter system set log_archive_dest_state_2='ENABLE' scope=both;


###- se for DG cascade (3 nos)
##-- alter system set log_archive_dest_3='SERVICE=pano01_bm02 VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01_gru1nw';
##-- alter system set log_archive_dest_state_3='ENABLE';



##########################################
#-- no standby


alter system set db_lost_write_protect=TYPICAL;
alter system set "_deferred_log_dest_is_valid" = FALSE scope=both;
alter system set archive_lag_target=300 scope=both;

#- desabilitar o dest_2 antes de configurar
alter system set log_archive_dest_state_2='DEFER';

#- db_unique_name dos bancos envolvidos
alter system set log_archive_config='DG_CONFIG=(config_grupri,config_grustb)'; -- STANDBY,PROD

#- tns do outro db (nesse caso primary)
alter system set fal_server='config_grupri';

#- tns do proprio db (nesse caso standby)
alter system set fal_client='config_grustb';

#-configurar log dest do standby
alter system set log_archive_dest_2='SERVICE=config_grupri LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=config_grupri';

service=CDB01 lgwr async valid_for=(online_logfiles,all_roles) db_unique_name=CDB01_vcp1jx

###- se for DG cascade (3 nos)
### alter system set log_archive_dest_3='SERVICE= VALID_FOR=(STANDBY_LOGFILES,STANDBY_ROLE) DB_UNIQUE_NAME=pano01';


#- start recover no standby (com standby redo)
alter database recover managed standby database disconnect using current logfile;




###################################################################################################################
#######
###                              script para apagar archives

echo $ORACLE_BASE
export ORACLE_BASE=/u01/app/oracle
mkdir -p $ORACLE_BASE/admin/scripts/
vi $ORACLE_BASE/admin/scripts/deletearchive

export ORACLE_SID=$1
ORAENV_ASK=NO
. oraenv

export NLS_DATE_FORMAT='DD/MM/YYYY HH24:MI:SS';
$ORACLE_HOME/bin/rman target / nocatalog << EOF >> /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log
   spool log to /u01/app/oracle/admin/scripts/deletearchive.${ORACLE_SID}.log;
   CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON ALL STANDBY;
   show all;
   DELETE noprompt archivelog until time 'sysdate-1';
EOF

chmod +x $ORACLE_BASE/admin/scripts/deletearchive

/u01/app/oracle/admin/scripts/deletearchive

20  08,20  * * *    root  su - oracle -c "/u01/app/oracle/admin/scripts/deletearchive vial01"

###################################################################################################################
#######
###                              Virada DG com SwitchOver



###########################################################
##
##     no primary
##

#- verificar o switchover_status
# -->>> A value of TO STANDBY or SESSIONS ACTIVE indicates that the primary database can be switched to the standby role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

# -->>> RECOVERY_MODE = MANAGED REAL TIME APPLY (recover ativo no standby)
# -->>> GAP_STATUS = NO GAP

col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id, DB_UNIQUE_NAME, DATABASE_MODE, recovery_mode, status, TYPE, gap_status, ARCHIVED_SEQ#, ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;

#- executar commit to switchover
alter database commit to switchover to physical standby with session shutdown;

#- montar o banco como standby
conn / as sysdba
startup nomount;
alter system set log_archive_dest_state_2='DEFER' ;
alter system set job_queue_processes=0;
alter database mount standby database;



###########################################################
##
##      no standby
##


#- verificar staus switchover_status
#->>> A value of TO PRIMARY or SESSIONS ACTIVE indicates that the standby database is ready to be switched to the primary role
select db_unique_name, open_mode, database_role, switchover_status from v$database;

#- executar o switchover to primary
alter database commit to switchover to primary with session shutdown;


#- abrir o banco
-->>>> verificar parametro UNDO
alter database open;


#- ativar o log shipping para o antigo primary (se estiver tudo corretamente configurado)
alter system set log_archive_dest_state_2='ENABLE' ;


SELECT THREAD#, LOW_SEQUENCE#, HIGH_SEQUENCE# FROM V$ARCHIVE_GAP;


alter system set job_queue_processes=1000;





ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 7;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 8;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 9;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP 10;



contents of Memory Script:
{
   backup as copy reuse
   passwordfile auxiliary format  '/u01/app/oracle/product/19.0.0.0/dbhome_1/dbs/orapwCDB01'   ;
}
executing Memory Script

Starting backup at 2023/11/22 17:55:19
Finished backup at 2023/11/22 17:55:20
duplicating Online logs to Oracle Managed File (OMF) location
duplicating Datafiles to Oracle Managed File (OMF) location

contents of Memory Script:
{
   sql clone "alter system set  control_files =
  ''+RECO/CDB01_JQD_GRU/CONTROLFILE/current.259.1153590921'' comment=
 ''Set by RMAN'' scope=spfile";
   restore clone from service  'CDB01' standby controlfile;
}
executing Memory Script

sql statement: alter system set  control_files =   ''+RECO/CDB01_JQD_GRU/CONTROLFILE/current.259.1153590921'' comment= ''Set by RMAN'' scope=spfile

+RECO/CDB01_JQD_GRU/CONTROLFILE/current.257.1153590925

backup current controlfile for standby format 'control_bkp01.ctl';

Starting restore at 2023/11/22 17:55:21

channel stby1: starting datafile backup set restore
channel stby1: using network backup set from service CDB01
channel stby1: restoring control file
channel stby1: restore complete, elapsed time: 00:00:02






col id for 99
col destination for a40
col sequence for 99999999999
col tmode for a12
col error for a40
select dest_id id,
DESTINATION,
LOG_SEQUENCE sequence,
TRANSMIT_MODE tmode,
DELAY_MINS,
STATUS,
error
from v$archive_dest
where DESTINATION is not null
order by dest_id;





col id for 99
col DB_UNIQUE_NAME for a15
col stdlogfile for 999
select dest_id id,
DB_UNIQUE_NAME,
DATABASE_MODE,
recovery_mode,
STANDBY_LOGFILE_COUNT stdlogfile,
status,
TYPE,
gap_status,
ARCHIVED_SEQ#,
ERROR
from v$archive_dest_status
where DESTINATION is not null
order by dest_id;



col id for 99
col message for a125
select DEST_ID ID,
to_char(timestamp,'DD/MM/YYYY HH24:MI:SS')||' '||message message
from v$dataguard_status;


select distinct process, status, thread#, sequence#, block#, blocks from v$managed_standby ;






+DATA/config_grustb/datafile/



ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    1;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    2;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    3;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    4;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    5;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP    6;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  911;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  912;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  913;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  914;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  915;
ALTER DATABASE CLEAR UNARCHIVED LOGFILE GROUP  916;